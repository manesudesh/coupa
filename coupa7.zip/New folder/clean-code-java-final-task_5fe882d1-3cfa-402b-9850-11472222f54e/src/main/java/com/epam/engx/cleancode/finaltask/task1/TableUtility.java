package com.epam.engx.cleancode.finaltask.task1;

import java.util.List;

import com.epam.engx.cleancode.finaltask.task1.thirdpartyjar.DataSet;

public class TableUtility {

    public static int getColumnCount(List<DataSet> dataSets) {
        int result = 0;
        if (dataSets.size() > 0) {
            return dataSets.get(0).getColumnNames().size();
        }
        return result;
    }
    
	public static int getMaxColumnSize(int maxColumnSize) {
		if (maxColumnSize % 2 == 0) {
            maxColumnSize += 2;
        } else {
            maxColumnSize += 3;
        }
		return maxColumnSize;
	}

    public static String getAppendedData(List<DataSet> dataSets, int maxColumnSize, int columnCount) {
    	String result =  prepareTableData(dataSets, maxColumnSize, columnCount);
    	return DataUtility.prepareResultfromSymbols(maxColumnSize, result, columnCount, Symbol.RIGHT_BOTTOM.getValue(), Symbol.EQUAL.getValue(), Symbol.BOTH_SIDE_BOTTOM.getValue(), Symbol.LEFT_BOTTOM.getValue()+Symbol.NEW_LINE.getValue());
    }
	
    public static int getMaxColumnLength(List<DataSet> dataSets) {
        int maxLength = 0;
        if (dataSets.size() > 0) {
            maxLength = evaluateMaxLength(dataSets, findMaxLength(dataSets, 0));
        }
        return maxLength;
    }
    
    public static String prepareTableData(List<DataSet> dataSets, int maxColumnSize, int columnCount) {
		int rowsCount = dataSets.size();
		String result = "";
		result = DataUtility.generateRowData(dataSets, maxColumnSize, columnCount, rowsCount, result);
		return result;
	}

	public static int evaluateMaxLength(List<DataSet> dataSets, int maxLength) {
		for (DataSet dataSet : dataSets) {
		    List<Object> values = dataSet.getValues();
		    for (Object value : values) {
		    	maxLength = evaluateLength(maxLength, String.valueOf(value));
		    }
		}
		return maxLength;
	}

	public static int findMaxLength(List<DataSet> dataSets, int maxLength ) {
		List<String> columnNames = dataSets.get(0).getColumnNames();
		for (String columnName : columnNames) {
		    maxLength = evaluateLength(maxLength, columnName);
		}
		return maxLength;
	}

	public static int evaluateLength(int maxLength, String str) {
		if (str.length() > maxLength) {
		    maxLength = str.length();
		}
		return maxLength;
	}
	
	public static String concatTableHeader(List<DataSet> dataSets, int maxColumnSize, String result, int columnCount) {
		List<String> columnNames = dataSets.get(0).getColumnNames();
        for (int column = 0; column < columnCount; column++) {
        	result = PrintUtility.appendText(result, Symbol.DOUBLE_PIPE.getValue());
            int columnNamesLength = columnNames.get(column).length();
            result = PrintUtility.addSuffixPrefixLength(maxColumnSize, result, columnNames, column, columnNamesLength);
        }
        result = prepareTableHeader(dataSets, maxColumnSize, result, columnCount);
		return result;
	}

	public static String prepareTableHeader(List<DataSet> dataSets, int maxColumnSize, String result, int columnCount) {
		result = PrintUtility.appendText(result, Symbol.DOUBLE_PIPE.getValue()+Symbol.NEW_LINE.getValue());
        if (PrintUtility.hasDataSetEmpty(dataSets)) {
        	result = DataUtility.prepareResultfromSymbols(maxColumnSize, result, columnCount, "╚", Symbol.EQUAL.getValue(), "╩", "╝"+Symbol.NEW_LINE.getValue());
        } else {
        	result = DataUtility.prepareResultfromSymbols(maxColumnSize, result, columnCount, "╠", Symbol.EQUAL.getValue(), "╬", "╣"+Symbol.NEW_LINE.getValue());
        }
		return result;
	}

}
