package com.epam.engx.cleancode.finaltask.task1;

import java.util.List;

import com.epam.engx.cleancode.finaltask.task1.thirdpartyjar.DataSet;
import com.epam.engx.cleancode.finaltask.task1.thirdpartyjar.DatabaseManager;

public class PrintQuery {
    public String prepareTable(String tableName, DatabaseManager manager ) {
    	List<DataSet> data = manager.getTableData(tableName);
        int maxColumnSize = TableUtility.getMaxColumnLength(data);
        return prepareDataOfTable(data, maxColumnSize, tableName);
    }

	public String prepareDataOfTable(List<DataSet> data, int maxColumnSize, String tableName) {
		if (maxColumnSize == 0) {
			String textEmptyTable = Symbol.DOUBLE_PIPE.getValue()+" Table '" + tableName + "' is empty or does not exist "+Symbol.DOUBLE_PIPE.getValue();
            return DataUtility.prepareTextforEmptyTable(textEmptyTable);
        } else {
            return prepareHeaderofTheTable(data) + DataUtility.prepareDataSet(data);
        }
	}

    private String prepareHeaderofTheTable(List<DataSet> dataSets) {
        int columnLength = TableUtility.getMaxColumnLength(dataSets);
        int columnCount = TableUtility.getColumnCount(dataSets);
        int maxColumnSize = TableUtility.getMaxColumnSize(columnLength);
        String result = DataUtility.prepareResultfromSymbols(maxColumnSize, "", columnCount, "╔", Symbol.EQUAL.getValue(), "╦", "╗"+Symbol.NEW_LINE.getValue());
        return TableUtility.concatTableHeader(dataSets, maxColumnSize, result, columnCount);
    }
    
}
