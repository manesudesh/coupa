package com.epam.engx.cleancode.finaltask.task1;

public class InvalidInputException extends RuntimeException{
	
	public InvalidInputException(String message) {
		super(message);
	}
}
