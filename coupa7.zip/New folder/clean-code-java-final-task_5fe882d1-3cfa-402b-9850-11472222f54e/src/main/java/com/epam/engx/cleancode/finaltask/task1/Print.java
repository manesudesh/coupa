package com.epam.engx.cleancode.finaltask.task1;

import com.epam.engx.cleancode.finaltask.task1.thirdpartyjar.Command;
import com.epam.engx.cleancode.finaltask.task1.thirdpartyjar.DatabaseManager;
import com.epam.engx.cleancode.finaltask.task1.thirdpartyjar.View;

public class Print implements Command {

    private View view;
    private DatabaseManager manager;
    private String tableName;

    public Print(View view, DatabaseManager manager) {
        this.view = view;
        this.manager = manager;
    }

    public boolean canProcess(String command) {
        return PrintUtility.isStartWithPrint(command);
    }
    
    public void process(String input) {
        String[] command = PrintUtility.retrieveCommands(input);
        tableName = command[1];
        view.write(new PrintQuery().prepareTable(tableName, manager));
    }
}