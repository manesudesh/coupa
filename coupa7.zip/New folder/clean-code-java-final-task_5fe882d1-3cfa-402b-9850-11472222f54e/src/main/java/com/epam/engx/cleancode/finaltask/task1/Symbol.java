package com.epam.engx.cleancode.finaltask.task1;

public enum Symbol {

	NEW_LINE("\n"),
    RIGHT_TOP("╔"),
    LEFT_TOP("╗"),
    RIGHT_BOTTOM("╚"),
    LEFT_BOTTOM("╝"),
    BOTH_SIDE_BOTTOM("╩"),
    DOUBLE_PIPE("║"),
    EQUAL("═");
    
    private final String value;

    Symbol(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }
}
