package com.epam.engx.cleancode.finaltask.task1;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import com.epam.engx.cleancode.finaltask.task1.thirdpartyjar.DataSet;

public class PrintUtility {
	
	final static String COMMAND_PRINT = "print ";
 
	public static boolean isStartWithPrint(String command) {
        return command.startsWith(COMMAND_PRINT);
    }
	
	public static String appendText(String result, String text )
	{
		StringBuilder strBuilder = new StringBuilder(result);
		strBuilder.append(text);
		return strBuilder.toString();
	}
	
	public static String appendMultipleEqualSymbol(String textEmptyTable, String result) {
		for (int i = 0; i < textEmptyTable.length() - 2; i++) {
			result = PrintUtility.appendText(result, Symbol.EQUAL.getValue());
        }
		return result;
	}
	
	public static boolean isLessThanRowCount(int row, int rowCount) {
		return row < rowCount - 1;
	}

	public static String attachSuffixPrefixOnLength(int maxColumnSize, int columnCount, String result, List<Object> values) {
		for (int column = 0; column < columnCount; column++) {
		    int valuesLength = String.valueOf(values.get(column)).length();
		    result = addSuffixPrefixLength(maxColumnSize, result, values.stream().map((obj) -> Objects.toString(obj)).collect(Collectors.toList()), column, valuesLength);
		    result = PrintUtility.appendText(result, Symbol.DOUBLE_PIPE.getValue());
		}
		return result;
	}
	
	public static boolean hasDataSetEmpty(List<DataSet> dataSets) {
		return dataSets.size() <= 0;
	}
	
	public static String addSuffixPrefixLength(int maxColumnSize, String result, List<String> names, int index,
			int length) {
		result = appendSuffixPrefixColumn(maxColumnSize, result, names, index, length, " ", length % 2);
		return result;
	}

	public static String appendSuffixPrefixColumn(int maxColumnSize, String result, List<String> names, int index,
			int nameLength, String space, int evenOddBuffer) {
		try {
			int columnSize = (maxColumnSize - nameLength) / 2;
			result = appendSymbol(columnSize, result, space);
			StringBuilder strBuilder = new StringBuilder(result);
			result = strBuilder.append(names.get(index)).toString();
			result = appendSymbol(columnSize + evenOddBuffer, result, space);
		} catch(Exception e) {
			throw new InvalidInputException(e.getMessage());
		}
		return result;
	}

	public static String appendSymbol(int maxColumnSize, String result, String symbol) {
		try {
			for (int i = 0; i < maxColumnSize; i++) {
				result = PrintUtility.appendText(result, symbol);
			}
		} catch (Exception e) {
			throw new InvalidInputException(e.getMessage());
	}
		return result;
	}
	
	public static String[] retrieveCommands(String input) {
		String[] command = input.split(" ");
        if (command.length != 2) {
            throw new InvalidInputException("incorrect number of parameters. Expected 2, but is " + (command.length - 1));
        }
		return command;
	}
}
