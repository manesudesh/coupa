package com.epam.engx.cleancode.finaltask.task1;

import java.util.List;

import com.epam.engx.cleancode.finaltask.task1.thirdpartyjar.DataSet;

public class DataUtility {
	
	public static String generateRowData(List<DataSet> dataSets, int maxColumnSize, int columnCount, int rowsCount,
			String result) {
		for (int row = 0; row < rowsCount; row++) {
            result = prepareRowData(dataSets, maxColumnSize, columnCount, rowsCount, result, row);
        }
		return result;
	}

	public static String prepareRowData(List<DataSet> dataSets, int maxColumnSize, int columnCount, int rowsCount,
			String result, int row) {
		List<Object> values = dataSets.get(row).getValues();
		result = getResultText(maxColumnSize, columnCount, result, values);
		if (PrintUtility.isLessThanRowCount(row, rowsCount)) {
			result = prepareResultfromSymbols(maxColumnSize, result, columnCount, "╠", Symbol.EQUAL.getValue(), "╬", "╣"+Symbol.NEW_LINE.getValue());
		}
		return result;
	}

	public static String getResultText(int maxColumnSize, int columnCount, String result, List<Object> values) {
		result = PrintUtility.appendText(result, Symbol.DOUBLE_PIPE.getValue());
		result = PrintUtility.attachSuffixPrefixOnLength(maxColumnSize, columnCount, result, values);
		result = PrintUtility.appendText(result, Symbol.NEW_LINE.getValue());
		return result;
	}

    public static String prepareTextforEmptyTable(String textEmptyTable) {
    	String text = PrintUtility.appendMultipleEqualSymbol(textEmptyTable, Symbol.RIGHT_TOP.getValue())+Symbol.LEFT_TOP.getValue()+Symbol.NEW_LINE.getValue()+textEmptyTable+Symbol.NEW_LINE.getValue()+Symbol.RIGHT_BOTTOM.getValue(); 
    	text = PrintUtility.appendMultipleEqualSymbol(textEmptyTable, text)+Symbol.LEFT_BOTTOM.getValue()+Symbol.NEW_LINE.getValue();
    	return text;
	}
    
    public static String prepareDataSet(List<DataSet> dataSets) {
    	int maxColumnSize =TableUtility.getMaxColumnLength(dataSets);
    	maxColumnSize = TableUtility.getMaxColumnSize(maxColumnSize);
    	int columnCount = TableUtility.getColumnCount(dataSets);
    	String result = TableUtility.getAppendedData(dataSets, maxColumnSize, columnCount);
    	return result;
    }
    
    public static String prepareResultfromSymbols(int maxColumnSize, String result, int columnCount, String initialSymbol, String firstSymbol, String secondSymbol, String thirdSymbol) {
		result = PrintUtility.appendText(result, initialSymbol);
		for (int j = 1; j < columnCount; j++) {
		    result = PrintUtility.appendSymbol(maxColumnSize, result, firstSymbol);
		    result = PrintUtility.appendText(result, secondSymbol);
		}
		result = PrintUtility.appendSymbol(maxColumnSize, result, firstSymbol);
		result = PrintUtility.appendText(result, thirdSymbol);
		return result;
	}
    
}
