package com.epam.engx.cleandesign;

import java.util.List;

public class Assignment {

    private Worker worker;
    private List<Zone> zones;
    private double vendorBonus;
    private double assignmentBonus;
    private double bill;
    private double salaries;
    private double totalArea;

    Assignment(Double assignmentBonus, Double bill, Double salaries, Double totalArea){
    	this.assignmentBonus = assignmentBonus;
    	this.bill = bill;
    	this.salaries = salaries;
    	this.totalArea = totalArea;
    }
    public double getVendorBonus() {
        return vendorBonus;
    }

    public void setVendorBonus(double vendorBonus) {
        this.vendorBonus = vendorBonus;
    }

    public double getAssignmentBonus() {
        return assignmentBonus;
    }

    public void setAssignmentBonus(double assignmentBonus) {
        this.assignmentBonus = assignmentBonus;
    }
    
    public Worker getWorker() {
        return worker;
    }

    public void setWorker(Worker worker) {
        this.worker = worker;
    }

    public List<Zone> getZones() {
        return zones;
    }

    public void setZones(List<Zone> zones) {
        this.zones = zones;
    }
    
	public double getTotalArea() {
		return totalArea;
	}

	public double getSalaries() {
		return salaries;
	}

	public double getBill() {
		return bill;
	}

	public double getTotalSalaries(double salaries) {
		return salaries;
	}

	public double getTotalBill() {
		return bill;
	}

	public void setTotalArea(double totalArea) {
		this.totalArea = totalArea;
	}

	public void setSalaries(double salaries) {
		this.salaries = salaries;
	}

	public void setBill(double bill) {
		this.bill = bill;
	}

	public void setTotalSalaries(double salaries) {
		this.salaries = salaries;
	}

	public void setTotalBill(double bill) {
		this.bill = bill;
	}

}
