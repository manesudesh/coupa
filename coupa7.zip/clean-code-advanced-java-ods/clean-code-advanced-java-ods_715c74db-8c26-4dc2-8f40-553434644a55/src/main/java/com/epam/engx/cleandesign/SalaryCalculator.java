package com.epam.engx.cleandesign;

public class SalaryCalculator {

	Worker worker;

	public SalaryCalculator(Worker worker) {
		this.worker = worker;
	}

	private static final double SENIOR_SALARY_FACTOR = 1.2;

	public void calculateSalary(Double area) {
		calulateDays(area);
		calculateSalaryOnDays();
	}

	public void calculateSalaryOnDays() {
		int days = worker.getDays();
		double baseSalary = worker.getDailyRate() * days;
		if (worker.isJunior()) {
			worker.setSalaryOnDay(baseSalary);
		}else{
			worker.setSalaryOnDay(baseSalary * SENIOR_SALARY_FACTOR);
		}
	}

	public void calulateDays(Double area) {
		int days = (int) Math.ceil(area / worker.getAmountPerDay());
		worker.setDays(days);
	}
}
