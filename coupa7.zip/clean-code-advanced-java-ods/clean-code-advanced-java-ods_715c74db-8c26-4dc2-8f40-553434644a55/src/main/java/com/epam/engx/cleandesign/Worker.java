package com.epam.engx.cleandesign;

public class Worker {
    private double dailyRate;
    private double amountPerDay;
    private double salaryOnDay;
    private boolean isJunior = false;
    private int days = 0;

    public Worker(double dailyRate, double amountPerDay, double salaryOnDay, int days) {
        this.dailyRate = dailyRate;
        this.amountPerDay = amountPerDay;
        this.salaryOnDay = salaryOnDay;
        this.days = days;
    }

    public Worker(double dailyRate, double amountPerDay, boolean isJunior, double salaryOnDay, int days) {
        this.dailyRate = dailyRate;
        this.amountPerDay = amountPerDay;
        this.isJunior = isJunior;
        this.salaryOnDay = salaryOnDay;
        this.days = days;
    }

    public double getSalaryOnDay() {
        return salaryOnDay;
    }
    
    public void setSalaryOnDay(Double salaryOnDay) {
    	this.salaryOnDay = salaryOnDay;
    }
    
    public double getDailyRate() {
        return dailyRate;
    }

    public double getAmountPerDay() {
        return amountPerDay;
    }
    
    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public boolean isJunior() {
        return isJunior;
    }

}
