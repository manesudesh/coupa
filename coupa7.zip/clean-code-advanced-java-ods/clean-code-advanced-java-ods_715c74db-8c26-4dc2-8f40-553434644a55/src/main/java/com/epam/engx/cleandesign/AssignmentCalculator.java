package com.epam.engx.cleandesign;

import static com.epam.engx.cleandesign.CalculationUtil.summing;

public class AssignmentCalculator {

	Assignment ass;
	AssignmentCalculator(Assignment ass){
		this.ass = ass;
		calculateAssignmentBonus();
	}
	
    private static final double SENIOR_BONUS_FACTOR = 1.5;
    public void calculateAssignmentBonus() {
    	Double assignmentBonus;
        if (ass.getWorker().isJunior()) {
        	assignmentBonus = ass.getVendorBonus();
        } else {
        	assignmentBonus = ass.getVendorBonus() * SENIOR_BONUS_FACTOR;
        }
        ass.setAssignmentBonus(assignmentBonus);
    }
    
    public void calculateTotalArea() {
    	Double totalArea = ass.getTotalArea();
    	totalArea = summing(ass.getZones(), zone-> {new ZoneCalculator(zone); return zone.getAperatureArea();});
    	ass.setTotalArea(totalArea);
    }
    
    public void calculateAreaSalaries(Double totalArea) {
    	Double salaries = ass.getSalaries();
    	new SalaryCalculator(ass.getWorker()).calculateSalary(totalArea);;
    	salaries += (ass.getWorker().getSalaryOnDay() + ass.getAssignmentBonus());
    	ass.setSalaries(salaries);
    }
    
    public void calculateBill() {
    	double bill = ass.getBill();
    	bill  += summing(ass.getZones(), zone-> zone.getBillPrice());
    	ass.setBill(bill);
    }
    
    public void calculateFundBalance() {
    	calculateTotalArea();
    	calculateAreaSalaries(ass.getTotalArea());
    	calculateBill();
   }
     
}
