package com.epam.engx.cleandesign;

import java.util.List;

public class FundCalculator {

	Double salaries = 0.0;
    Double bill = 0.0;

	public double getFundBalance(List<Assignment> assignments) {
		for (Assignment ass : assignments) {
			new AssignmentCalculator(ass).calculateFundBalance();
			calculateTotalSalaries(salaries, ass);
			calculateTotalBill(bill, ass);
		}
		return bill - salaries;
	}

    public double calculateTotalSalaries(Double salaries, Assignment ass) {
    	return this.salaries += ass.getSalaries();
   }
    public double calculateTotalBill(Double bill, Assignment ass) {
    	return this.bill += ass.getBill();
   }

}
