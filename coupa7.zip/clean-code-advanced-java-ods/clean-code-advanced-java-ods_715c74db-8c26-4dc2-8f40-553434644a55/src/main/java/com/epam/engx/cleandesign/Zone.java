package com.epam.engx.cleandesign;

import java.util.ArrayList;
import java.util.List;

public class Zone {

    private double height;
    private double width;
    private String type;
    private List<Aperture> apertures = new ArrayList<>();
    private double aperatureArea;
    private double price;
    private double billPrice;
    private double materialPrice;
    
    public Zone(String type, double height, double width, Double aperatureArea, Double price, Double billPrice, Double materialPrice) {
        this.height = height;
        this.width = width;
        this.type = type;
        this.aperatureArea = aperatureArea;
        this.price = price;
        this.billPrice = billPrice;
        this.materialPrice = materialPrice;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    public void setApertures(List<Aperture> apertures) {
        this.apertures = apertures;
    }

    public List<Aperture> getApertures() {
        return apertures;
    }

    public String getType() {
        return type;
    }
    public void setAperatureArea(Double aperatureArea) {
    	this.aperatureArea = aperatureArea;
    }
    public Double getAperatureArea() {
    	return aperatureArea;
    }
    
    public void setPrice(Double price) {
    	this.price = price;
    }
    public Double getPrice() {
    	return price;
    }
    
    public void setBillPrice(Double billPrice) {
    	this.billPrice = billPrice;
    }
    public Double getBillPrice() {
    	return billPrice;
    }
    
    public void setMaterialPrice(Double materialPrice) {
    	this.materialPrice = materialPrice;
    }
    public Double getMaterialPrice() {
    	return materialPrice;
    }
}
