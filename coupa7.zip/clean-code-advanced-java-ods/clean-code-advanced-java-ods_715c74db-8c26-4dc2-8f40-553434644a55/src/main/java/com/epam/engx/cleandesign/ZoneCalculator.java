package com.epam.engx.cleandesign;

import static com.epam.engx.cleandesign.CalculationUtil.summing;

import java.util.Map;

public class ZoneCalculator {
	Zone zone;
	ZoneCalculator(Zone zone){
		this.zone = zone;
		calculateZoneBillPrice();
		calculateAperatureArea();
	}
    public static Map<String, Double> zoneTypeWorkPrice;
    public void validateZone() {
        if (isNotContainsKey(zoneTypeWorkPrice))
            throw new WrongZoneTypeException();
    }

    private boolean isNotContainsKey(Map<String, Double> zoneTypeWorkPrice) {
        return !zoneTypeWorkPrice.keySet().contains(zone.getType());
    }

    public void calculateAperatureArea() {
    	Double aperatureArea = zone.getHeight() * zone.getWidth() - summing(zone.getApertures(), aperture-> aperture.getHeight() * aperture.getWidth());
    	zone.setAperatureArea(aperatureArea);
    }

    private static final int ONE_DAY_MAX_AREA = 50;
    private static final double MULTI_DAY_PRICE_FACTOR = 1.1;
    
    public void calculatePrice() {
    	calculateAperatureArea();
    	double area = zone.getAperatureArea();
    	 double price = area * zoneTypeWorkPrice.get(zone.getType());
    	 if (area < ONE_DAY_MAX_AREA) {
    		 zone.setPrice(price);
         }
    	 else{
    		 zone.setPrice(price * MULTI_DAY_PRICE_FACTOR);
    	 }
    }
    
    private void calculateZoneBillPrice() {
    	validateZone();
    	calculateMaterialPrice();
    	calculatePrice();
        Double billPrice = zone.getMaterialPrice() + zone.getPrice();
        zone.setBillPrice(billPrice);
    }

    private static final double MATERIAL_AREA_FACTOR = 10;
    private void calculateMaterialPrice() {
    	calculateAperatureArea();
        Double materialPrice = zone.getAperatureArea() * MATERIAL_AREA_FACTOR;
        zone.setMaterialPrice(materialPrice);
    }


}
