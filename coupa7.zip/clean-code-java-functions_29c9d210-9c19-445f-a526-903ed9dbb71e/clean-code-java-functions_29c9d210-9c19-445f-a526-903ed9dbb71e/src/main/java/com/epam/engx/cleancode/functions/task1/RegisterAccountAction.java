package com.epam.engx.cleancode.functions.task1;

import static com.epam.engx.cleancode.functions.task1.thirdpartyjar.CheckStatus.OK;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.epam.engx.cleancode.functions.task1.thirdpartyjar.Account;
import com.epam.engx.cleancode.functions.task1.thirdpartyjar.AccountException;
import com.epam.engx.cleancode.functions.task1.thirdpartyjar.AccountManager;
import com.epam.engx.cleancode.functions.task1.thirdpartyjar.Address;
import com.epam.engx.cleancode.functions.task1.thirdpartyjar.PasswordChecker;
import com.epam.engx.cleancode.functions.task1.thirdpartyjar.TooShortPasswordException;
import com.epam.engx.cleancode.functions.task1.thirdpartyjar.WrongAccountNameException;
import com.epam.engx.cleancode.functions.task1.thirdpartyjar.WrongPasswordException;

public class RegisterAccountAction {


    private PasswordChecker passwordChecker;
    private AccountManager accountManager;

    /**
     * @param account
     * create New Account if Account is password and name is valid
     */
    public void registerAccount(Account account) {
    	validateAccount(account);
    	validateAccountNameLength(account);
    	
        String password = account.getPassword();
        validatePasswordLength(password);
        validatePassword(password);

        
        List<Address> addresses = new ArrayList<Address>();
        setAddressDetails(account, addresses);
        account.setCreatedDate(new Date());
        account.setAddresses(addresses);
        
        accountManager.createNewAccount(account);
    }


	private void validateAccount(Account account) {
		if (account == null) {
            throw new AccountException();
        }
	}


	private void validatePassword(String password) {
		if (passwordChecker.validate(password) != OK) {
            throw new WrongPasswordException();
        }
	}


	private void setAddressDetails(Account account, List<Address> addresses) {
		addresses.add(account.getHomeAddress());
        addresses.add(account.getWorkAddress());
        addresses.add(account.getAdditionalAddress());
	}


	private void validatePasswordLength(String password)  {
		if (password.length() <= 8) {
            throw new TooShortPasswordException();
        }
	}


	private void validateAccountNameLength(Account account) {
		if (account.getName().length() <= 5){
            throw new WrongAccountNameException();
        }
	}


    public void setAccountManager(AccountManager accountManager) {
        this.accountManager = accountManager;
    }

    public void setPasswordChecker(PasswordChecker passwordChecker) {
        this.passwordChecker = passwordChecker;
    }

}
