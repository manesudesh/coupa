package com.epam.engx.cleancode.functions.task3;

import com.epam.engx.cleancode.functions.task3.thirdpartyjar.SessionManager;
import com.epam.engx.cleancode.functions.task3.thirdpartyjar.User;
import com.epam.engx.cleancode.functions.task3.thirdpartyjar.UserService;

public abstract class UserAuthenticator implements UserService {

    private SessionManager sessionManager;

    public User login(String userName, String password) {
    	User user = loginUser(userName, password);
        return user;
    }

    private User loginUser(String userName, String password) {
    	User user = getUserByName(userName);
        if (isPasswordCorrect(user, password)) {
            sessionManager.setCurrentUser(user);
        }else {
        	user = null;
        }
        return user;
    }

    public void setSessionManager(SessionManager sessionManager) {
        this.sessionManager = sessionManager;
    }
}
