package com.epam.engx.cleancode.functions.task2;


import com.epam.engx.cleancode.functions.task2.thirdpartyjar.Level;
import com.epam.engx.cleancode.functions.task2.thirdpartyjar.NotActivUserException;
import com.epam.engx.cleancode.functions.task2.thirdpartyjar.Review;
import com.epam.engx.cleancode.functions.task2.thirdpartyjar.User;

import java.util.TreeMap;

public abstract class Account implements User {

    private TreeMap<Integer, Level> levelMap = new TreeMap<>();

    public Level getActivityLevel() {
        validateAccountForLevel();

        int reviewAnswers = 0;
        reviewAnswers = getReviewAnswers(reviewAnswers);
            
        Level levelByReviews = getLevelByReviews(reviewAnswers);
        return levelByReviews;

    }

	private int getReviewAnswers(int reviewAnswers) {
		for (Review review : getAllReviews()) {
        	if(review == null) {
        		continue;
        	}
        	reviewAnswers += review.getAnswers().size();
        }
		return reviewAnswers;
	}

    /**
     * Throw exception if ACcount is not registered or VisitNumber is less than 1
     */
    private void validateAccountForLevel() {
        if (!isRegistered() || getVisitNumber() <= 0)
            throw new NotActivUserException();
    }

    /**
     * @param reviewAnswers
     * @return
     * Method return Level based on Review
     */
    private Level getLevelByReviews(int reviewAnswers) {
        for (Integer threshold : levelMap.keySet()) {
            if (reviewAnswers >= threshold)
                return levelMap.get(threshold);
        }

        return Level.defaultLevel();
    }

    /**
     * @param levelMap
     * set Level Map
     */
    public void setLevelMap(TreeMap<Integer, Level> levelMap) {
        this.levelMap = levelMap;
    }
}
