package com.epam.engx.cleancode.functions.task1.thirdpartyjar;

public class AccountException extends RuntimeException {
}
