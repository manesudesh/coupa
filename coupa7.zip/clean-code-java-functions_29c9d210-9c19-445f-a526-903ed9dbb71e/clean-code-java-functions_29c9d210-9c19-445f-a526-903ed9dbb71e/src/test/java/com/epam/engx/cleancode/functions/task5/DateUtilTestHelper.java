package com.epam.engx.cleancode.functions.task5;

import java.util.Calendar;
import java.util.Date;

public class DateUtilTestHelper {

    public static Date getDirectlyIncrementedDate(DateUtil dateUtil, Date date) {
        Calendar calendar = dateUtil.changeToMidnight(date, true);
        return calendar.getTime();
    }

    public static Date getInverseIncrementedDate(DateUtil dateUtil, Date date) {
    	Calendar calendar = dateUtil.changeToMidnight(date, false);
    	return calendar.getTime();
    }
}
