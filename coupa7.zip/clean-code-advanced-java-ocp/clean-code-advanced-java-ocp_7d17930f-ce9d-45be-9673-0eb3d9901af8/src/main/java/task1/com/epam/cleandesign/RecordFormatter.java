package task1.com.epam.cleandesign;

public class RecordFormatter {

    public String format(Record rec) {
    	return rec.format();
    }
}
