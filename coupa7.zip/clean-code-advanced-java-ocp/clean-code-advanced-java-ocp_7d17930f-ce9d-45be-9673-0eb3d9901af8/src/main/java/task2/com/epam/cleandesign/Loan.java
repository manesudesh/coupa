package task2.com.epam.cleandesign;

public class Loan {

	int loan ;
	int age;
	int income;

	public int getLoan() {
		return loan;
	}

	public void setLoan(int loan) {
		this.loan = loan;
	}
	
	public int calculateLoan(int age, int loan){
		return age * loan/2;
	}
	
	public int multiplierLoan(int age, int income){
		return IncomeMultiplier.multiply(calculateLoan(age, income), income);
	}
	
}
