package task2.com.epam.cleandesign;

public class CarLoan extends Loan {
	public int loan = 2_000;
	
	@Override
	public int calculateLoan(int age, int income) {
		this.age = age;
		this.income = income;
		if (age > 50) {
            loan += 1_500;
        } else if (age > 30) {
            loan += 1_000;
        }
		return loan;
	}

}
