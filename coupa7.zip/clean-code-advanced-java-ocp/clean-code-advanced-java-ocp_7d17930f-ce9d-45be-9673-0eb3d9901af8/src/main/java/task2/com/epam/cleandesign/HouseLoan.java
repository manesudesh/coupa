package task2.com.epam.cleandesign;

public class HouseLoan extends Loan {
	public int loan = 100_000;
	
	@Override
	public int calculateLoan(int age, int income) {
		this.age = age;
		this.income = income;
		if (age > 30 && income > loan / 2) {
			loan *= 2;
		}
		return loan;
	}

}
