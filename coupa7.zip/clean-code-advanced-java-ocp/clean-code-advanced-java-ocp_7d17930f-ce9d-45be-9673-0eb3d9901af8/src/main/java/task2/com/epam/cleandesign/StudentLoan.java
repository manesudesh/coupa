package task2.com.epam.cleandesign;

public class StudentLoan extends Loan {
	public int loan = 100;
	
	@Override
	public int calculateLoan(int age, int income) {
		this.age = age;
		this.income = income;
		if (age >= 21) {
			loan += 150;
	    }
		return loan;
	}

}
