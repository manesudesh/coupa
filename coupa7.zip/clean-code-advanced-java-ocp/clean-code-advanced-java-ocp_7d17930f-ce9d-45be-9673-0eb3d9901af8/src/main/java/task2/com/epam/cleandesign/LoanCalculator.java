package task2.com.epam.cleandesign;

final class LoanCalculator {

    int getStudentLoan(int age, int income) {
    	return new StudentLoan().multiplierLoan(age, income);
    }

    int getCarLoan(int age, int income) {
    	return new CarLoan().multiplierLoan(age, income);
    }

    int getHouseLoan(int age, int income) {
    	return new HouseLoan().multiplierLoan(age, income);
    }
}
