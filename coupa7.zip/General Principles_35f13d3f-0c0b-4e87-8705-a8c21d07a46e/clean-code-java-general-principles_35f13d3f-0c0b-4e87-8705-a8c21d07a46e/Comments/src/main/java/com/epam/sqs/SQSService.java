package com.epam.sqs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.epam.s3.S3Service;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sns.model.SubscribeRequest;
import software.amazon.awssdk.services.sns.model.SubscribeResponse;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

@Service
public class SQSService {

	

	@Autowired
	@Qualifier("localSqs")
	SqsClient sqsClient;

//	final String queueUrl = "https://sqs.us-east-1.amazonaws.com/565393036687/ProjectName-UploadsNotificationQueue";
	final String queueUrl = "https://sqs.us-east-1.amazonaws.com/565393036687/MyQueue";
	
	public void publishMessage(String messageBody) {
		SendMessageRequest request = SendMessageRequest.builder().queueUrl(queueUrl).messageBody(messageBody)
				.delaySeconds(10).build();

		SendMessageResponse response = sqsClient.sendMessage(request);
		System.out.println("Message ID: " + response.messageId());

	}
	
	@Autowired
	S3Service s3service;
	public void imageUploadEvent(String bucKeyName){
		s3service.putObjects(bucKeyName);
		publishMessage(s3service.showMetadata(bucKeyName).toString());
	}

}
