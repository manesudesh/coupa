package com.epam.db;

import javax.sql.DataSource;

import org.springframework.boot.jdbc.DataSourceBuilder;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.rds.RdsClient;

public class IAMAuthDataSource //extends HikariDataSource
{
	
	static DataSource datasource = DataSourceBuilder.create()
	.url("jdbc:mysql://database-1.chcq8ueuan3s.us-east-1.rds.amazonaws.com:3306/testdb")
	.username("admin")
	.password("admin1234")
	.driverClassName("com.mysql.cj.jdbc.Driver")
	.build();
	
//	@Autowired
//	Config config;
	
//    @Override
//    public Connection getConnection() throws SQLException {
//        RdsIamAuthTokenGenerator generator = RdsIamAuthTokenGenerator.builder()
//            .credentialsProvider(DefaultCredentialsProvider.create())
//            .region(Region.of("your-region"))
//            .build();
//
//        GetIamAuthTokenRequest request = GetIamAuthTokenRequest.builder()
//        		.hostname(config.getUrl().split("//")[1].split(":")[0])
//            .port(Integer.parseInt(config.getUrl().split(":")[2].split("/")[0]))
//            .userName(config.getUsername())
//            .build();

//        String authToken = generator.getAuthToken(request);
//        return super.getConnection(getUsername(), authToken);
//    }
    
//	String dbInstanceIdentifier = config.getUrl().split("//")[1].split(":")[0];
//	 String masterUsername = config.getUsername();
	String dbInstanceIdentifier = "database-1.chcq8ueuan3s.us-east-1.rds.amazonaws.com";
    String masterUsername = "admin";
    String pwd = "admin1234";
    Region region = Region.US_EAST_1;
    RdsClient rdsClient = RdsClient.builder()
            .region(region)
            .build();
    
//    public Connection getConnection22( ) throws Exception {
//        String token = getAuthToken(rdsClient, dbInstanceIdentifier, masterUsername);
//        System.out.println("The token response is " + token);
//        return super.getConnection(getUsername(), token);
//        return super.getConnection(masterUsername, token);
//    }

    public DataSource getDataAource() {
    	return	DataSourceBuilder.create()
    			.url("jdbc:mysql://database-1.chcq8ueuan3s.us-east-1.rds.amazonaws.com:3306/testdb")
    			.username("admin")
    			.password("admin1234")
    			.driverClassName("com.mysql.cj.jdbc.Driver")
    			.build();
    }
    
//    public static String getAuthToken(RdsClient rdsClient, String dbInstanceIdentifier, String masterUsername) {
//        RdsUtilities utilities = rdsClient.utilities();
//        try {
//            GenerateAuthenticationTokenRequest tokenRequest = GenerateAuthenticationTokenRequest.builder()
//                    .credentialsProvider(ProfileCredentialsProvider.create())
//                    .username(masterUsername)
//                    .port(3306)
//                    .hostname(dbInstanceIdentifier)
//                    .build();
//
//            return utilities.generateAuthenticationToken(tokenRequest);
//        } catch (RdsException e) {
//            System.out.println(e.getLocalizedMessage());
//            System.exit(1);
//        }
//        return "";
//    }
    
    /*
    {
    	String createTable = " CREATE TABLE S3Metadata "
    			+ " (  id INT AUTO_INCREMENT PRIMARY KEY, "
    			+ "   type VARCHAR(50) ,\r\n"
    			+ "    name VARCHAR(50) ,\r\n"
    			+ "    size VARCHAR(100) "
    			+ ")" ;
    	
    	System.out.println(createTable);
    	
//    	try (PreparedStatement statement = getConnection22().prepareStatement(
    	try (PreparedStatement statement = getDataAource().getConnection().prepareStatement(
    			createTable
    			)) {
            statement.executeUpdate();
        } catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    */
    
}