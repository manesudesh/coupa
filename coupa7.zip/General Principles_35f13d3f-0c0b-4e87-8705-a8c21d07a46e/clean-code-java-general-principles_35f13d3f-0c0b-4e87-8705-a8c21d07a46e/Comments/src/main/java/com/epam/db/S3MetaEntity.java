package com.epam.db;

public class S3MetaEntity {

}
