package com.epam.s3;

public class MetaInfo {

	public String name;
	public String type;
	public Long size;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Long getSize() {
		return size;
	}
	public void setSize(Long size) {
		this.size = size;
	}
	
	
	@Override
	public String toString() {
		return "name- "+name + "  type- "+ type + "size- "+size;
	}
}
