package com.epam.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class RDSConnection {
    public static void main(String[] args) {
        String jdbcUrl = "jdbc:mysql://your-rds-endpoint:3306/your-database";
        String username = "your-username";
        String password = "your-password";

        try {
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
            System.out.println("Connection successful!");
            // Perform database operations
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}