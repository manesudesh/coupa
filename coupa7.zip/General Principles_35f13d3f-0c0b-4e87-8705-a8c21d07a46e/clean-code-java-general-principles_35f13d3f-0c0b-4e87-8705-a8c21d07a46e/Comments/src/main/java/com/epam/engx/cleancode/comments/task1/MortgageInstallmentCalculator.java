package com.epam.engx.cleancode.comments.task1;

import com.epam.engx.cleancode.comments.task1.thirdpartyjar.InvalidInputException;

public class MortgageInstallmentCalculator {
 
    /**
     *
     * @param principalAmount principal amount 
     * @param term term of mortgage in years
     * @param rate rate of interest
     * @return monthly payment amount
     * This method calculate Monthly payment on principleAmount for specific terms
     */
    public static double calculateMonthlyPayment(
            int principalAmount, int term, double rate) {
        
        if (principalAmount < 0 || term <= 0 || rate < 0) {
            throw new InvalidInputException("Negative values are not allowed");
        }
        
        rate /= 100.0;

        double tim = term * 12;

        if(rate==0) {
            return  principalAmount/tim;
        }
        double monthlyRate = rate / 12.0;
        
        double monthlyPayment = (principalAmount * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -tim));

        return monthlyPayment;
    }
    
    public static void main (String args []) {
    	String str = null;
    			str = appendPrefix(str, ' ', 3);
    	System.out.print(str);
    }
    
    public static String appendPrefix(String str, char prefix, int occurance) {
//		return StringUtils.rightPad(str, 3, prefix);
    	return null;
	}
}
