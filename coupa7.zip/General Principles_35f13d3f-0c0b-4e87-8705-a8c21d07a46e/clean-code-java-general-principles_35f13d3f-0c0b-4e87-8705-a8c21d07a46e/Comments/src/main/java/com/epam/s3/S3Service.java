package com.epam.s3;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.epam.db.DBService;

import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.HeadObjectRequest;
import software.amazon.awssdk.services.s3.model.HeadObjectResponse;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Request;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Response;
import software.amazon.awssdk.services.s3.model.S3Object;

@Service
public class S3Service {
	
	

	private String bucketName = "sudeshmane-cli";
	private final AmazonS3 s3Client ;
	
	@Autowired
	DBService dbService;

	@Autowired
	public S3Service() {
		BasicAWSCredentials credentials=new BasicAWSCredentials("AKIAYHJANCWHTWVOYSJ7","Uq7Ew7+oqX8h2UBJ3NFGiu1019a22rkn9pJC46CN");
		this.s3Client = AmazonS3ClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withRegion(Regions.US_EAST_1)
                .build();
	}

	public MetaInfo showMetadata(String keyName) {

		S3Client s3software = S3Client.builder().region(Region.US_EAST_1)
				.credentialsProvider(ProfileCredentialsProvider.create()).build();

		HeadObjectRequest headObjectRequest = HeadObjectRequest.builder().bucket(bucketName).key(keyName)
				.build();

		HeadObjectResponse headObjectResponse = s3software.headObject(headObjectRequest);

		System.out.println("content length --> " + headObjectResponse.contentLength());

		System.out.println("content type --> " + headObjectResponse.contentType());
		System.out.println("sse --> " + headObjectResponse.serverSideEncryption());
		headObjectResponse.metadata().entrySet().forEach(e-> System.out.println("Metadata "+e.getKey()+" "+e.getValue()));
//		return " fileName "+keyName+" content length --> " + headObjectResponse.contentLength() + "\n" + " content type --> "
//				+ headObjectResponse.contentType()+"\n" + " sse --> " + headObjectResponse.serverSideEncryption();
//		return "Filename "+keyName + " type "+ headObjectResponse.contentType()+ " size "+headObjectResponse.contentLength();
	
		MetaInfo metaInfo = new MetaInfo();
		metaInfo.setName(keyName); metaInfo.setType(headObjectResponse.contentType()); metaInfo.setSize(headObjectResponse.contentLength());
		return metaInfo;
	}

	public void putObjects(String keyName) {
//		s3Client.putObject(bucketName, keyName, new File("C://Users/Sudesh_Mane/Downloads/a.htm"));
		s3Client.putObject(bucketName, keyName, new File("/home/ec2-user/HTML.txt"));
	}

	public List<String> listObjects() {
		ObjectListing objectListing = s3Client.listObjects(bucketName);
		return objectListing.getObjectSummaries().stream().map(S3ObjectSummary::getKey).collect(Collectors.toList());

	}

	public void deleteObject() {
		s3Client.deleteObject("sudeshmane-cli", "abcd (2).html");
	}
	
	
	
	
	
	public List<List<MetaInfo>> listDbMetadata() {
		List<List<MetaInfo>> metaInfoList = new ArrayList<List<MetaInfo>>();
		
		S3Client s3 = S3Client.builder()
				.region(Region.US_EAST_1).build();
		
        ListObjectsV2Request request = ListObjectsV2Request.builder()
                .bucket(bucketName)
                .build();

        ListObjectsV2Response response = null;
        do {
        	 response = s3.listObjectsV2(request);
            for (S3Object object : response.contents()) {
                System.out.println(object.key());
                metaInfoList.add(List.of(showMetadata( object.key())) );
                metaInfoList.add(List.of(dbService.selectS3Metadata(object.key())) );
            }
            request = request.toBuilder().continuationToken(response.nextContinuationToken()).build();
        } while (response.isTruncated());
        return metaInfoList;
    }
}
