package com.epam.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.epam.db.DBService;
import com.epam.s3.MetaInfo;
import com.epam.s3.S3Service;
import com.epam.sns.SNSService;
import com.epam.sqs.SQSService;

@RestController
public class AWSControlller {

	@Autowired
	SNSService snsService;
	@Autowired
	SQSService sqsService;
	@Autowired
	S3Service s3Service;
	
	@GetMapping("/sns/unsubscribe/{emailId}")
	public void unSubscribeEmail(@PathVariable("emailId") String emailId){
		snsService.unSubscribeEmail(emailId);
	}
	
	@GetMapping("/sns/subscribe/{emailId}")
	public void subscribeEmail(@PathVariable("emailId") String emailId){
		snsService.subscribeEmail(emailId);
	}
	
	@GetMapping("/sns/event/upload/{keyName}")
	public void uploadEvent(@PathVariable("keyName") String keyName){
//		sqsService.imageUploadEvent("From web app "+keyName);
		snsService.imageUploadEvent("From web app "+keyName);
	}
	
	@Autowired
	DBService dbService;
	
	@GetMapping("/db/event/{keyName}")
	public void insertdbEvent(@PathVariable("keyName") String keyName){
		dbService.imageUploadEvent("From web app "+keyName);
	}
	
	@GetMapping("/db/verify")
	public List<List<MetaInfo>> verifyDbRecords(){
		return s3Service.listDbMetadata();
	}
	
	@GetMapping("/lambda/invoke")
	public void invokeLambda(){
		RestTemplate restTemplate = new RestTemplate();
	    restTemplate.getForObject("https://diuubvy3vk.execute-api.us-east-1.amazonaws.com/dev/resource_1", toString().getClass());
	}
}
