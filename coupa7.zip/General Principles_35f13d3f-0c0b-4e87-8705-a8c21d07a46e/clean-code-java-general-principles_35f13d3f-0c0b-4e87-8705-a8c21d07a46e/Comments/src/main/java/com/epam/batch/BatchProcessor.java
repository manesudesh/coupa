package com.epam.batch;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.DependsOn;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.epam.sns.SNSService;
import com.epam.sqs.SQSService;

import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.DeleteMessageRequest;
import software.amazon.awssdk.services.sqs.model.Message;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageRequest;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageResponse;

@Component
@EnableScheduling
@DependsOn("localSqs")
public class BatchProcessor {
	@Autowired
	@Qualifier("localSqs")
	SqsClient sqsClient;
	
	@Autowired
	SNSService snsservice;
	@Autowired
	SQSService sqsservice;
	
	final String queueUrl = "https://sqs.us-east-1.amazonaws.com/565393036687/ProjectName-UploadsNotificationQueue";
	
//	@Scheduled(fixedRate = 300000) // Run every 60 seconds
    public void pollMessages() {
		System.out.println("You are in Batch Processor");
        ReceiveMessageRequest receiveMessageRequest = ReceiveMessageRequest.builder()
                .queueUrl(queueUrl)
                .maxNumberOfMessages(10) // Batch size
                .waitTimeSeconds(20) // Long polling
                .build();

        ReceiveMessageResponse response = sqsClient.receiveMessage(receiveMessageRequest);
        List<Message> messages = response.messages();

        for (Message message : messages) {
        	System.out.println("sending message of queue from Batch Processor");
        	snsservice.publishMessage(message.body());
        	DeleteMessageRequest deleteMessageRequest = DeleteMessageRequest.builder()
                    .queueUrl(queueUrl)
                    .receiptHandle(message.receiptHandle())
                    .build();
        	sqsClient.deleteMessage(deleteMessageRequest);
        }
    }
	

}
