package com.epam.sns;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.epam.s3.S3Service;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sns.SnsClient;
import software.amazon.awssdk.services.sns.model.ListSubscriptionsRequest;
import software.amazon.awssdk.services.sns.model.ListSubscriptionsResponse;
import software.amazon.awssdk.services.sns.model.PublishRequest;
import software.amazon.awssdk.services.sns.model.PublishResponse;
import software.amazon.awssdk.services.sns.model.SubscribeRequest;
import software.amazon.awssdk.services.sns.model.SubscribeResponse;
import software.amazon.awssdk.services.sns.model.Subscription;
import software.amazon.awssdk.services.sns.model.UnsubscribeRequest;
import software.amazon.awssdk.services.sns.model.UnsubscribeResponse;

@Service
public class SNSService {

	@Bean
	public SnsClient getSnsClient() {
		SnsClient snsClient = SnsClient.builder().region(Region.US_EAST_1).build();
		return snsClient;
	}

	@Autowired
	SnsClient snsClient;

	public void unSubscribeEmail(String emailId) {

		ListSubscriptionsRequest request = ListSubscriptionsRequest.builder().build();
		ListSubscriptionsResponse result = snsClient.listSubscriptions(request);
//		result.subscriptions().stream().filter(e -> e.endpoint().equalsIgnoreCase(emailId)).forEach(u -> {
		for (Subscription subsciption : result.subscriptions()) {
			
			UnsubscribeRequest unSubRequest = UnsubscribeRequest.builder().subscriptionArn(subsciption.subscriptionArn()).build();
			if(subsciption.endpoint().equalsIgnoreCase(emailId)){
				UnsubscribeResponse response = snsClient.unsubscribe(unSubRequest);
				System.out.println("Email unsubscribed " + response.responseMetadata().requestId());
			}
		}
	}

//	String topicArn = "arn:aws:sns:us-east-1:565393036687:ProjectName-UploadsNotificationTopic";
	String topicArn = "arn:aws:sns:us-east-1:565393036687:MySNSTopic";

	public void subscribeEmail(String emailId) {
		SubscribeRequest request = SubscribeRequest.builder().protocol("email").endpoint(emailId)
				.returnSubscriptionArn(true).topicArn(topicArn).build();

		SubscribeResponse response = snsClient.subscribe(request);
		System.out.println("subscribe " + response.responseMetadata().requestId());
	}

	@Autowired
	S3Service s3service;
	public void imageUploadEvent(String bucKeyName){
		s3service.putObjects(bucKeyName);
		publishMessage(s3service.showMetadata(bucKeyName).toString());
	}
	public void publishMessage(String message) {
		PublishRequest request = PublishRequest.builder().topicArn(topicArn).message(message).build();

		PublishResponse result = snsClient.publish(request);
		System.out.println("Message ID: " + result.messageId());
	}
}
