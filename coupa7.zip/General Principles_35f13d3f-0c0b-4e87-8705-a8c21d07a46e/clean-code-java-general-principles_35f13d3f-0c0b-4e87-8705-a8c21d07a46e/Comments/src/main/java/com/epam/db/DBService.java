package com.epam.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.stereotype.Service;

import com.epam.s3.MetaInfo;
import com.epam.s3.S3Service;


@Service
public class DBService {
	
	IAMAuthDataSource ds;

	
	public void imageUploadEvent(String keyName){
		S3Service s3Service = new S3Service();
		s3Service.putObjects(keyName);
		MetaInfo metadata = s3Service.showMetadata(keyName);
		insertS3Metadata(metadata.getName(), metadata.getSize(), metadata.getType());
	}
	
	public void insertS3Metadata(String name, Long size, String type)  {
        String sql = "INSERT INTO S3Metadata (type, name, size) VALUES (?, ?, ?)";
        try (Connection conn = IAMAuthDataSource.datasource.getConnection();PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, type);
            statement.setString(2, name);
            statement.setLong(3, size);
            statement.executeUpdate();
        }catch (Exception e) {
			e.printStackTrace();
		}
               
    }
	
	public MetaInfo selectS3Metadata(String name)  {
		MetaInfo metaInfo = new MetaInfo();
		String sql = "SELECT type, name, size from S3Metadata where name=?";
        try (Connection conn = IAMAuthDataSource.datasource.getConnection();PreparedStatement statement = conn.prepareStatement(sql)) {
        	statement.setString(1, name);
        	System.out.println("searching name");
        	ResultSet resultSet = statement.executeQuery();
        	
        	// Process the result set
            while (resultSet.next()) {
                String type = resultSet.getString("type");
                String fileName = resultSet.getString("name");
                Long size = resultSet.getLong("size");
                metaInfo.setName(fileName);
                metaInfo.setType(type);
                metaInfo.setSize(size);
            }
        }catch (Exception e) {
			e.printStackTrace();
		}
        
        return metaInfo;
    }
    
	
	
    
	
	
	

}
