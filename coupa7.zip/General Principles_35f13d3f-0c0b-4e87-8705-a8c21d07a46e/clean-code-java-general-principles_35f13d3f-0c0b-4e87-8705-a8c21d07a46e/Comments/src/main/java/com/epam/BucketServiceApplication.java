package com.epam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.epam.s3.S3Service;
import com.epam.sns.SNSService;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsClient;

@EnableScheduling
@SpringBootApplication
public class BucketServiceApplication implements CommandLineRunner{

	@Autowired
	S3Service s3Service;
	
	@Autowired
	SNSService snsService;
	
    public static void main(String[] args) {
        SpringApplication.run(BucketServiceApplication.class, args);
    }

	@Override
	public void run(String... args) throws Exception {
	}
	
	@Bean("localSqs")
	public SqsClient getSqsClient() {
		SqsClient sqsClient = SqsClient.builder().region(Region.US_EAST_1).build();
		return sqsClient;
	}
    
    

}
