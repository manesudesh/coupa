package com.epam.engx.cleancode.dry.task1;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import com.epam.engx.cleancode.dry.task1.thirdpartyjar.Profitable;

public class InterestCalculator implements Profitable {

    private static final int AGE = 60;
    private static final double INTEREST_PERCENT = 4.5d;
    private static final double SENIOR_PERCENT = 5.5d;
    private static final int BONUS_AGE = 13;
    private static final int LEAP_YEAR_SHIFT = 1;
    private static final int CENTURY = 100;


    public BigDecimal calculateInterest(AccountDetails accountDetails) {
        if (isAccountStartedAfterBonusAge(accountDetails)) {
            return interest(accountDetails);
        } else {
            return BigDecimal.ZERO;
        }
    }

    private boolean isAccountStartedAfterBonusAge(AccountDetails accountDetails) {
        return durationBetweenDatesInYears(accountDetails.getBirth(), accountDetails.getStartDate()) > BONUS_AGE;
    }

    private int durationBetweenDatesInYears(Date from, Date to) {
        Calendar startCalendar = CalendarUtility.getGregorianCalendar();
        CalendarUtility.setDateTime(from, startCalendar);
        Calendar endCalendar = CalendarUtility.getGregorianCalendar();
        CalendarUtility.setDateTime(to, endCalendar);

        int diffYear = CalendarUtility.getDiffOfYears(startCalendar, endCalendar);
        if (CalendarUtility.isStartYearDaysAhead(startCalendar, endCalendar, LEAP_YEAR_SHIFT)) {
            return diffYear - 1;
        }
        return diffYear;
    }

    private BigDecimal interest(AccountDetails accountDetails) {
        double interest = 0;
        if (isAccountStartedAfterBonusAge(accountDetails)) {
            if (AGE <= durationSinceStartDateInYears(accountDetails.getBirth())) {
                interest = calcluatePercentage(accountDetails, SENIOR_PERCENT);
            } else {
                interest = calcluatePercentage(accountDetails, INTEREST_PERCENT);
            }
        }
        return BigDecimal.valueOf(interest);
    }

	public double calcluatePercentage(AccountDetails accountDetails, double percent) {
		return accountDetails.getBalance().doubleValue()
		        * durationSinceStartDateInYears(accountDetails.getStartDate()) * percent / CENTURY;
	}

    private int durationSinceStartDateInYears(Date startDate) {
    	return durationBetweenDatesInYears(startDate, new Date());
    }
    
}
