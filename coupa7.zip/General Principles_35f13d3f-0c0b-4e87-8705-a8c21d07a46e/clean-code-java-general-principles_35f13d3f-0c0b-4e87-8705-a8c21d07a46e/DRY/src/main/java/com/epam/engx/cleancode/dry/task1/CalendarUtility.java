package com.epam.engx.cleancode.dry.task1;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class CalendarUtility{

	public static Calendar getGregorianCalendar() {
		Calendar calendar = new GregorianCalendar();
		return calendar;
	}
	
	public static void setDateTime(Date dateTime, Calendar calendar) {
		calendar.setTime(dateTime);
	}
	
	public static int getDiffOfYears(Calendar startCalendar, Calendar endCalendar) {
		int diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
		return diffYear;
	}
	
	public static boolean isStartYearDaysAhead(Calendar startCalendar, Calendar endCalendar, int leapYearShift) {
		return endCalendar.get(Calendar.DAY_OF_YEAR) + leapYearShift < startCalendar.get(Calendar.DAY_OF_YEAR);
	}
}
