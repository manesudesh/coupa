package com.epam.engx.cleancode.errorhandling.task1;

import com.epam.engx.cleancode.errorhandling.task1.thirdpartyjar.Model;

public class UserReportController {

    private UserReportBuilder userReportBuilder;

    public String getUserTotalOrderAmountView(String userId, Model model){
        String totalMessage = getUserTotalMessage(userId);
        if (totalMessage == "000.00")
            return "technicalError";
        model.addAttribute("userTotalMessage", totalMessage);
        return "userTotal";
    }

    private String getUserTotalMessage(String userId) {
		Double amount = null;
		try {
			amount = userReportBuilder.getTotalAmountofUser(userId);
		} catch (Exception e) {

			return e.getCause().getMessage();
		}
		return "User Total: " + amount + "$";
	}


    public UserReportBuilder getUserReportBuilder() {
        return userReportBuilder;
    }

    public void setUserReportBuilder(UserReportBuilder userReportBuilder) {
        this.userReportBuilder = userReportBuilder;
    }
}
