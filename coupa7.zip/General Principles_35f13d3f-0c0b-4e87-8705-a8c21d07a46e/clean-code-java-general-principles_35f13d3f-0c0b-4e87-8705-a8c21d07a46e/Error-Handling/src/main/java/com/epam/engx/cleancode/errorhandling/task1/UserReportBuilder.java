package com.epam.engx.cleancode.errorhandling.task1;

import java.util.List;

import com.epam.engx.cleancode.errorhandling.task1.thirdpartyjar.Order;
import com.epam.engx.cleancode.errorhandling.task1.thirdpartyjar.User;
import com.epam.engx.cleancode.errorhandling.task1.thirdpartyjar.UserDao;

public class UserReportBuilder {

    private UserDao userDao;

    public Double getTotalAmountofUser(String userId) {
    	return callOrder(getUser(userId));
    }
    
    public Double callOrder(User user) {
    	return callTotalOrder(getOrders(user));
    }

    public Double callTotalOrder(List<Order> orders) {
    	return getTotalOrders(orders);
    }
    public List<Order> getTotalOrder(User user) {
        List<Order> orders = getOrders(user);
        return orders;
    }

	public User getUser(String userId) {
		if (userDao == null) {
        	throw new UserException("0.0", "000.00");
        }
		User user = userDao.getUser(userId);
        if (user == null) {
        	throw new UserException("1.0", "WARNING: User ID doesn't exist.");
        }
		return user;
	}


	public List<Order> getOrders(User user) {
		List<Order> orders = user.getAllOrders();
        if (orders == null || orders.isEmpty())
        {
        	throw new OrderException("2.0", "WARNING: User have no submitted orders.");
        }
        return orders;
	}


	public Double getTotalOrders(List<Order> orders) {
		Double sum = 0.0;
        for (Order order : orders) {

            if (order.isSubmitted()) {
                Double total = order.total();
                if (total < 0)
                    throw new TotalOrderException("3.0", "ERROR: Wrong order amount.");
                sum += total;
            }
        }
		return sum;
	}


    public UserDao getUserDao() {
        return userDao;
    }

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }
}
