package com.epam.engx.cleancode.errorhandling.task1;

public class TotalOrderException extends RuntimeException{

	public TotalOrderException(String errorCode, String e) {
        super(errorCode, new Exception(e));
    }
}
