package com.epam.engx.cleancode.errorhandling.task1;

public class UserException extends RuntimeException{

	public UserException(String errorCode, String e) {
        super(errorCode,new Exception(e));
    }
}
