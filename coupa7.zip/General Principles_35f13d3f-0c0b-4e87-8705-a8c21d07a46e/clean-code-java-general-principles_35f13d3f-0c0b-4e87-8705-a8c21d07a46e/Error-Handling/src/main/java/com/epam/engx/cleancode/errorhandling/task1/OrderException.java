package com.epam.engx.cleancode.errorhandling.task1;

public class OrderException extends RuntimeException{

	public OrderException(String errorCode, String e) {
        super(errorCode,new Exception(e));
    }
}
