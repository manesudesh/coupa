package com.epam.engx.cleancode.naming.task4.thirdpartyjar;

public interface ICustomerContactDAO {
    CustomerContact findById(Long customerId);

    void update(CustomerContact contact);
}
