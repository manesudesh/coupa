package com.epam.engx.cleancode.naming.task1.thirdpartyjar;

public interface IDeliveryService {
    boolean isDeliverable(IOrder order);
}
