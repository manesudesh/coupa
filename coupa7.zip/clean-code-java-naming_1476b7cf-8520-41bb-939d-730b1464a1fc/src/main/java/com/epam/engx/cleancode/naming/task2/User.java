package com.epam.engx.cleancode.naming.task2;

import java.util.Arrays;
import java.util.Date;

public class User {

	protected boolean isAdmin = false;

	private String dateOfBirth;

	private String surName;

	private User[] subordinates;

	private int intrestRate;

	public User(String surName, String dateOfBirth, User[] subordinate) {
		this.dateOfBirth = dateOfBirth;
		this.surName = surName;
		this.subordinates = subordinate;
	}

	@Override
	public String toString() {
		return "User [dateOfBirth=" + String.valueOf(dateOfBirth) + ", name=" + surName + ", isAdmin=" + isAdmin + ", subordinates="
				+ Arrays.toString(subordinates) + ", rating=" + intrestRate + "]";
	}

	public void setIntrestRate(int intrestRate) {
		this.intrestRate = intrestRate;
	}
}
