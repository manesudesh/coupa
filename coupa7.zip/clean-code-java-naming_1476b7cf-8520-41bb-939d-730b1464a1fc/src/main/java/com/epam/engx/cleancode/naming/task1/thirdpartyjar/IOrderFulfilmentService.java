package com.epam.engx.cleancode.naming.task1.thirdpartyjar;

import java.util.List;

public interface IOrderFulfilmentService {
    void fulfilProducts(List<IProduct> products);
}
