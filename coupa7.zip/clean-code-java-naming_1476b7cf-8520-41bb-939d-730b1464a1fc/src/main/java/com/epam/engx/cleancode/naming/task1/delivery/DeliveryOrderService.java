package com.epam.engx.cleancode.naming.task1.delivery;

import java.util.List;

import com.epam.engx.cleancode.naming.task1.OrderService;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IDeliveryService;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IOrder;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IOrderFulfilmentService;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IProduct;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.NotDeliverableOrderException;

public class DeliveryOrderService implements OrderService {

    private IDeliveryService mailDeliveryService;

    private IOrderFulfilmentService mailOrderFulfilmentService;

    public void submitOrder(IOrder purchaseOrder) {
        if (mailDeliveryService.isDeliverable(purchaseOrder)) {
            List<IProduct> products = purchaseOrder.getProducts();
            mailOrderFulfilmentService.fulfilProducts(products);
        } else {
            throw new NotDeliverableOrderException();
        }
    }

    public void setDeliveryService(IDeliveryService privateDeliveryService) {
        this.mailDeliveryService = privateDeliveryService;
    }

    public void setOrderFulfilmentService(IOrderFulfilmentService mailOrderFulfilmentService) {
        this.mailOrderFulfilmentService = mailOrderFulfilmentService;
    }
}
