package com.epam.engx.cleancode.naming.task1.thirdpartyjar;

public interface INotificationManager {
    void notifyCustomer(Message message, int level);
}
