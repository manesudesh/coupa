package com.epam.engx.cleancode.naming.task1.thirdpartyjar;

import java.util.List;

public interface IOrder {
    List<IProduct> getProducts();
}
