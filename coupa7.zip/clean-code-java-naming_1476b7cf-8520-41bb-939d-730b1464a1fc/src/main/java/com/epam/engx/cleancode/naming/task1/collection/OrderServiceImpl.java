package com.epam.engx.cleancode.naming.task1.collection;


import com.epam.engx.cleancode.naming.task1.OrderService;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.ICollectionService;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.INotificationManager;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IOrder;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.Message;

public class OrderServiceImpl implements OrderService {

	private ICollectionService collectionService;
    private INotificationManager notificationManager;

    public void submitOrder(IOrder purchaseOrder) {
        if (collectionService.isEligibleForCollection(purchaseOrder))
        	notificationManager.notifyCustomer(Message.READY_FOR_COLLECT, 4); 
        else
        	notificationManager.notifyCustomer(Message.IMPOSSIBLE_TO_COLLECT, 1); 
    }

    public void setCollectionService(ICollectionService collectionService) {
        this.collectionService = collectionService;
    }

    public void setNotifiactionManager(INotificationManager notificationManager) {
        this.notificationManager = notificationManager;
    }
}
