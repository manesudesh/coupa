package com.epam.engx.cleancode.naming.task1;

import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IOrder;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.Submitable;

public interface OrderService  extends Submitable {
    void submitOrder(IOrder purchaseOrder);
}
