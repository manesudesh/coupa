package com.epam.engx.cleancode.naming.task1.thirdpartyjar;

public interface ICollectionService {
    boolean isEligibleForCollection(IOrder order);
}
