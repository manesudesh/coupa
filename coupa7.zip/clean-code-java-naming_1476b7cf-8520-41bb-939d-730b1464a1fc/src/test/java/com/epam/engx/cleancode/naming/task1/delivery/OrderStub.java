package com.epam.engx.cleancode.naming.task1.delivery;

import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IOrder;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IProduct;

import java.util.Collections;
import java.util.List;

class OrderStub implements IOrder {

    private String name;

    public OrderStub(String name) {
        this.name = name;
    }

    @Override
    public List<IProduct> getProducts() {
        return Collections.<IProduct>singletonList(new IProduct() {
            @Override
            public String getName() {
                return name;
            }
        });
    }
}
