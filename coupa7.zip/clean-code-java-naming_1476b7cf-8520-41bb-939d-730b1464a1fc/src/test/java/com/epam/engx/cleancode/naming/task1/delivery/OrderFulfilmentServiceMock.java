package com.epam.engx.cleancode.naming.task1.delivery;

import java.util.List;

import org.junit.Assert;

import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IOrderFulfilmentService;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IProduct;

class OrderFulfilmentServiceMock implements IOrderFulfilmentService {

    private String productName;

    @Override
    public void fulfilProducts(List<IProduct> products) {
    	try {
    		productName = products.get(0).getName();
    	}catch(NullPointerException npe) {
    		System.out.println("Product List is empty");
    	}
    }

    public void assertFirstProductName(String s){
        Assert.assertEquals(s, productName);
    }
}
