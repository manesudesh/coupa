package com.epam.engx.cleancode.naming.task1.collection;

import java.util.List;

import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IOrder;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IProduct;

class OrderDummy implements IOrder {
    @Override
    public List<IProduct> getProducts() {
        return null;
    }
}
