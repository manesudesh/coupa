package com.epam.engx.cleancode.naming.task1.collection;

import com.epam.engx.cleancode.naming.task1.thirdpartyjar.INotificationManager;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.Message;

class NotificationManagerMock implements INotificationManager {

    Message message;
    int level;

    @Override
    public void notifyCustomer(Message message, int level) {
        this.message = message;
        this.level = level;
    }
}
