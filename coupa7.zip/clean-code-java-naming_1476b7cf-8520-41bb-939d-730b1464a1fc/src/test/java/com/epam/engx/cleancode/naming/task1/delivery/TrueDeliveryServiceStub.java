package com.epam.engx.cleancode.naming.task1.delivery;

import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IDeliveryService;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IOrder;

public class TrueDeliveryServiceStub implements IDeliveryService {

    @Override
    public boolean isDeliverable(IOrder o) {
        return true;
    }
}
