package com.epam.engx.cleancode.naming.task1.collection;

import com.epam.engx.cleancode.naming.task1.thirdpartyjar.ICollectionService;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.IOrder;

public class FalseCollectionServiceStub implements ICollectionService {
    @Override
    public boolean isEligibleForCollection(IOrder order) {
        return false;
    }
}
