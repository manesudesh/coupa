package com.epam.engx.cleancode.naming.task1.collection;

import com.epam.engx.cleancode.naming.task1.thirdpartyjar.ICollectionService;
import com.epam.engx.cleancode.naming.task1.thirdpartyjar.Submitable;

public class CollectionOrderServiceTestHelper {

    public OrderServiceImpl getService(){
        return new OrderServiceImpl();
    }

    public void submit(Submitable submitOrderService) {
        ((OrderServiceImpl) submitOrderService).submitOrder(new OrderDummy());
    }

    public void setNotificationManager(NotificationManagerMock notificationManagerMock, Submitable orderService) {
        ((OrderServiceImpl) orderService).setNotifiactionManager(notificationManagerMock);
    }

    public void setCollectionService(Submitable orderService, ICollectionService collectionServiceStub) {
        ((OrderServiceImpl) orderService).setCollectionService(collectionServiceStub);
    }
}
