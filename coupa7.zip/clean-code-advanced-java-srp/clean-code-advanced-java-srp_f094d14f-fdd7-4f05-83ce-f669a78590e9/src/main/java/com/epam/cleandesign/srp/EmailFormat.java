package com.epam.cleandesign.srp;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailFormat {
	
	public static MimeMessage formatEmailMessage( EmailConfiguration emailConfig, String employeesHtml) {
		MimeMessage message = new MimeMessage(emailConfig.getSession());
        try {
            message.setFrom(new InternetAddress(emailConfig.FROM));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(emailConfig.TO));
            message.setSubject("Employees report");

            message.setContent(employeesHtml, "text/html; charset=utf-8");
            
        } catch (MessagingException e) {
        	throw new IllegalStateException(e);
        }
        return message; 
	}

	
}
