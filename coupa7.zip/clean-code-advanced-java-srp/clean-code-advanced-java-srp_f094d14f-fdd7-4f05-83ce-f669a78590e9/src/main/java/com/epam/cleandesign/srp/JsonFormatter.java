package com.epam.cleandesign.srp;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonFormatter {
	ObjectMapper mapper = new ObjectMapper();
	
    public synchronized String employeesAsJson(List<Employee> employees) {
        try {
            return mapper.writeValueAsString(employees);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

}
