package com.epam.cleandesign.srp;

import java.sql.Connection;

public final class EmployeeManager {

	EmployeeReport empReport = new EmployeeReport();
	
	public void sendEmployeesReport(Connection connection) {
		empReport.sendEmployeesReport(connection);
	}

}
