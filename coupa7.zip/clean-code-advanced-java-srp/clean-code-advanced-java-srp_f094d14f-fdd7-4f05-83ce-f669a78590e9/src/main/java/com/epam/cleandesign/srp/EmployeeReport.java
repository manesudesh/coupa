package com.epam.cleandesign.srp;

import java.sql.Connection;

public class EmployeeReport {

	HtmlFormatter htmlFormatter = new HtmlFormatter();
	
	public void sendEmployeesReport(Connection connection) {
		EmailService.sendMessage(htmlFormatter.callEmployeeAsHtml(new EmployeeRepository().readEmployees(connection)));
    }
}
