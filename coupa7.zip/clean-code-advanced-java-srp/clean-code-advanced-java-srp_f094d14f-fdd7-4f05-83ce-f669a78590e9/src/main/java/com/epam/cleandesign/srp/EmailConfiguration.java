package com.epam.cleandesign.srp;

import java.util.Properties;

import javax.mail.Session;
import javax.mail.internet.MimeMessage;

public class EmailConfiguration {

	static final String TO = "abcd@gmail.com";
	static final String FROM = "web@gmail.com";
	static final String HOST = "localhost";
	Properties properties = System.getProperties();
	MimeMessage mimeMessage;
	
	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	Session session;
	
	public EmailConfiguration() {
        properties.setProperty("mail.smtp.host", HOST);
        session = Session.getDefaultInstance(properties);
	}
	
	public static MimeMessage callMimeMessage(String employeesHtml)
	{
		return EmailFormat.formatEmailMessage(new EmailConfiguration(), employeesHtml);
	}
}
