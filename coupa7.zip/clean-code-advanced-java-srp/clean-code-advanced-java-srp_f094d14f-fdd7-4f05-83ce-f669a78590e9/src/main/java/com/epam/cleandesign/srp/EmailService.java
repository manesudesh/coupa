package com.epam.cleandesign.srp;

import javax.mail.MessagingException;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;

public class EmailService {
	
	public static void sendMessage(MimeMessage message) {
		try {
			Transport.send(message);
		} catch (MessagingException e) {
			throw new IllegalStateException(e);
		}
	}

}
