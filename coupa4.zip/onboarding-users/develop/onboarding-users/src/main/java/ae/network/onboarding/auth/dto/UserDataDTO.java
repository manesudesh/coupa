package ae.network.onboarding.auth.dto;

import ae.network.onboarding.auth.model.BackendSystem;
import ae.network.onboarding.auth.model.Role;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

@Data
public class UserDataDTO {

    @ApiModelProperty(position = 0)
    @NotNull
    @Size(min = 2, max = 32)
    private String username;
    @ApiModelProperty(position = 1)
    @Size(min = 5, max = 32)
    private String email;
    @ApiModelProperty(position = 2)
    @NotNull
    private List<Role> roles;
    @ApiModelProperty(position = 3)
    private List<BackendSystem> backendSystems;
    @NotNull
    @ApiModelProperty(position = 4)
    private String acquirer;
}
