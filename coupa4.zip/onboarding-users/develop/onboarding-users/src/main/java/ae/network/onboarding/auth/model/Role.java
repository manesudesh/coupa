package ae.network.onboarding.auth.model;

import org.springframework.security.core.GrantedAuthority;

public enum Role implements GrantedAuthority {
    ADMIN("ROLE_ADMIN"), CLIENT("ROLE_CLIENT"),
    NGO_REFUND_SERVICE("ROLE_NGO_REFUND_SERVICE"),
    GAMECHANGE_SERVICE("ROLE_GAMECHANGE_SERVICE");

    private final String id;

    Role(String id) {
        this.id = id;
    }

    public String getAuthority() {
        return id;
    }

}
