package ae.network.onboarding.auth.mongodata;

import ae.network.onboarding.auth.model.BackendSystem;
import ae.network.onboarding.auth.model.Role;
import ae.network.onboarding.auth.model.User;
import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Objects;

/**
 * Creating mongodb initial data
 *
 * @author walid.sewaify
 * @since 12-02-2020
 */
@ChangeLog(order = "001")
@Slf4j
public class MongoInitialSetup {
    private static final String TEST_PASS = new BCryptPasswordEncoder(12).encode("Test@1234");

    @ChangeSet(order = "01", author = "octopus", id = "01-createDefaultAdminUser")
    public void createDefaultAdminUser(MongoTemplate mongoTemplate) {
        User admin = new User();
        admin.setUsername("admin");
        admin.setPassword(TEST_PASS);
        admin.setEmail("onboarding@network.global");
        admin.setRoles(new ArrayList<>(Collections.singletonList(Role.ADMIN)));
        admin.setBackendSystems(Collections.emptyList());
        mongoTemplate.save(admin);
    }

    @ChangeSet(order = "02", author = "octopus", id = "02-createDefaultNIClient")
    public void createDefaultNIClient(MongoTemplate mongoTemplate) {
        User user = new User();
        user.setUsername("ni");
        user.setPassword(TEST_PASS);
        user.setAcquirer("NI");
        user.setEmail("onboarding@network.global");
        user.setRoles(new ArrayList<>(Collections.singletonList(Role.CLIENT)));
        user.setBackendSystems(Arrays.asList(BackendSystem.values()));
        mongoTemplate.save(user);
    }

    @ChangeSet(order = "03", author = "octopus", id = "03-createDefaultTymeClient")
    public void createDefaultTymeClient(MongoTemplate mongoTemplate) {
        User user = new User();
        user.setUsername("tyme");
        user.setPassword(TEST_PASS);
        user.setAcquirer("TYME");
        user.setEmail("onboarding@network.global");
        user.setRoles(new ArrayList<>(Collections.singletonList(Role.CLIENT)));
        user.setBackendSystems(Arrays.asList(BackendSystem.values()));
        mongoTemplate.save(user);
    }

    @ChangeSet(order = "04", author = "octopus", id = "03-createTymeTestUser")
    public void createTymeTestUser(MongoTemplate mongoTemplate) {
        User user = new User();
        user.setUsername("tyme_test");
        user.setPassword(TEST_PASS);
        user.setAcquirer("TYME");
        user.setEmail("onboarding@network.global");
        user.setRoles(new ArrayList<>(Collections.singletonList(Role.CLIENT)));
        user.setBackendSystems(Collections.singletonList(BackendSystem.TEST));
        mongoTemplate.save(user);
    }

    @ChangeSet(order = "05", author = "octopus", id = "03-createNITestUser")
    public void createNITestUser(MongoTemplate mongoTemplate) {
        User user = new User();
        user.setUsername("ni_test");
        user.setPassword(TEST_PASS);
        user.setAcquirer("NI");
        user.setEmail("onboarding@network.global");
        user.setRoles(new ArrayList<>(Collections.singletonList(Role.CLIENT)));
        user.setBackendSystems(Collections.singletonList(BackendSystem.TEST));
        mongoTemplate.save(user);
    }

    @ChangeSet(order = "06", author = "octopus", id = "03-createNOQODITestUser")
    public void createNOQODITestUser(MongoTemplate mongoTemplate) {
        User user = new User();
        user.setUsername("noqodi_test");
        user.setPassword(TEST_PASS);
        user.setAcquirer("NOQODI");
        user.setEmail("onboarding@network.global");
        user.setRoles(new ArrayList<>(Collections.singletonList(Role.CLIENT)));
        user.setBackendSystems(Arrays.asList(BackendSystem.FISERV, BackendSystem.MATCH));
        mongoTemplate.save(user);
    }

    @ChangeSet(order = "07", author = "octopus", id = "04-changeNOQODIUserBackendSystem")
    public void changeNOQODIUserBackendSystem(MongoTemplate mongoTemplate) {
        String username = "noqodi_test";
        User user = mongoTemplate.findOne(Query.query(Criteria.where("username").is(username)), User.class);
        if (!Objects.isNull(user)) {
            user.getBackendSystems().remove(BackendSystem.FISERV);
            user.getBackendSystems().add(BackendSystem.AMLOCK);
            mongoTemplate.save(user);
        }
    }
    
    @ChangeSet(order = "08", author = "Sudesh_Mane", id = "01-createPayoutUserBackendSystem")
    public void createPayoutUserBackendSystem(MongoTemplate mongoTemplate) {
    	User user = new User();
        user.setUsername("payout");
        user.setPassword(TEST_PASS);
        user.setAcquirer("NI");
        user.setEmail("onboarding@network.global");
        user.setRoles(new ArrayList<>(Collections.singletonList(Role.CLIENT)));
        user.setBackendSystems(Arrays.asList(BackendSystem.PAYOUT, BackendSystem.WAY4));
        mongoTemplate.save(user);
    }
}
