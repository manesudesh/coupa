package ae.network.onboarding.auth.model;


/**
 * @author walid.sewaify
 * @since 2020-02-06
 */
public enum BackendSystem {

    //Authorization User Access
    WAY4, BASE24, NGO, NGT, MCSEC, PP, MCP, FXCO, TRUSTWAVE, POSINV, SS, TEST, MATCH, FISERV, ALIPAY, QRPAY, WECHAT, G2,
    LOYALTY, VERIFONE, SOFTPOS, MPGS, SOFTPOS_MOSAMBEE,_3ds2,AMLOCK,D2C,
    VISA, POS, PAYOUT;
}
