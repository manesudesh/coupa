# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)
The SoftPOS MOsambee adaptor is a system which converts the merchant information from message queue into Mosambee accepted format in order to bulk onboard merchants into Mosambee system

### How do I get set up? ###

* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###
JSON API should include the following request headers and payload (request body) parameters as per the requirement. 
Any invalid parameters will be ignored or request discarded by service. 

Request Header:
Parameter Type      Description                             Mandatory 
clientId  String    API client reference number.             Y
dateTime  Timestamp Timestamp including milliseconds.        Y
hmac      String    Generated HMAC value ofrequest payload.  Y


clientId: Shared by Synergistic Financial Networks Pvt. Ltd (Mosambee) with client after successful setup of client in API platform system.
dateTime: timestamp in milliseconds. Ex –1655780920129, if date time is Tuesday, June 21, 2022 3:08:40.129 AM
hmac: Client generate HMAC with shared secret key and request body payload. 
algorithm: HmacSha512
hmac = encodeBase64(hmac(‘clientId+ datetime +request payload’, ‘secret key’))

Note: Above HTTP request headers are required fields. 

Request Payload:
Parameter       Type    Description                                                            Mandatory
clientId        String  Client referenceor identifier valueprovided by Mosambee.                Y
encRequestMsg   String  Encrypted value of request payload.Refer API section for fields detail. Y

Request Payload Encryption:
Each request JSON object or array is encrypted using symmetric key and generated cipher text value will be the final data used in encRequestMsg field.
Algorithm: AES, Mode: GCM, Padding: NoPadding, Key Size: 256 Bits
* Repo owner or admin
* Other community or team contact