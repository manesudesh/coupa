package ae.network.onboarding.softpos.mosambee.rabbitmq.service.exchange;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ae.network.onboarding.softpos.mosambee.common.APIConstant;
import ae.network.onboarding.softpos.mosambee.common.AppConfig;
import ae.network.onboarding.softpos.mosambee.common.TextUtils;
import ae.network.onboarding.softpos.mosambee.common.TgConfig;
import ae.network.onboarding.softpos.mosambee.exception.AcquierNotFoundException;
import ae.network.onboarding.softpos.mosambee.exception.BusinessException;
import ae.network.onboarding.softpos.mosambee.exception.MessageCancelledException;
import ae.network.onboarding.softpos.mosambee.model.APIDto;
import ae.network.onboarding.softpos.mosambee.model.Acquirer;
import ae.network.onboarding.softpos.mosambee.model.ApplicationRequest;
import ae.network.onboarding.softpos.mosambee.model.Status;
import ae.network.onboarding.softpos.mosambee.model.TaskName;
import ae.network.onboarding.softpos.mosambee.model.apirequest.APIRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apirequest.MerchantRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apirequest.TerminalRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.APIResponseDto;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.MerchantResponseDto;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.TerminalResponseDto;
import ae.network.onboarding.softpos.mosambee.model.payload.Address;
import ae.network.onboarding.softpos.mosambee.model.payload.AmendmentType;
import ae.network.onboarding.softpos.mosambee.model.payload.Merchant;
import ae.network.onboarding.softpos.mosambee.model.payload.Terminal;
import ae.network.onboarding.softpos.mosambee.service.utils.ProcessingHelper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * @author 
 */
@Slf4j
@AllArgsConstructor
@Service
public class AmendmentService {

	/**
	 * Injection of ProcessingHelper for helper utility
	 */
	private final ProcessingHelper processingHelper;
	
	private final AppConfig appConfig;
    
	private final SoftPosMosambeeService softPosMosambeeService;

	private synchronized APIRequestDto profileHandler(Merchant merchant) {
		log.info("Handling message for amendment profile");

		APIRequestDto reqDto = new APIRequestDto();

		reqDto.setIsEnterprise(APIConstant.isEnterprise);

		if (merchant.getTrimLegalName() != null) {
			reqDto.setMerchantName(merchant.getTrimLegalName());
		}
		if (merchant.getTrimMerchantName() != null) {
			reqDto.setMerchantDba(merchant.getTrimMerchantName());
		}
		if (merchant.getFormatMcc() != null) {
			reqDto.setMccCode(merchant.getFormatMcc());
		}

		Address address = null;
		if (merchant.getAddresses() != null && ((address = merchant.getAddresses().get(0)) != null)) {
			if (address.getMerchantAddress() != null) {
				reqDto.setMerchantAddress(address.getMerchantAddress());
			}
			if (address.getCity() != null) {
				reqDto.setCity(address.getCity());
				reqDto.setState(address.getCity());
			}
			if (address.getPhone() != null) {
				reqDto.setMobileNumber(TextUtils.leftPadUptoMaxLen(address.getPhone(), 10, '0'));
			}
			if (address.getEmail() != null) {
				reqDto.setBusinessEmail(address.getEmail());
			}
		}

		return reqDto;
	}
    
	private synchronized MerchantRequestDto buildMerchantRequestDto(Merchant merchant,
			MerchantRequestDto merchantRequestDto) {
		log.info("building requestDto for amendment Merchant");

		MerchantRequestDto merchantReq = new MerchantRequestDto();
		merchantReq.setMid(merchant.getMerchantId());

		String authSystem = null;
		if (merchant.getConfigurations() != null
				&& (authSystem = merchant.getConfigurations().getSoftPosAuthSystem()) != null) {
			TgConfig tgConfig = appConfig.getSoftposauthSystem().get(authSystem);
			merchantReq.setInstrument(tgConfig.getInstrument());
			merchantReq.setAcquirer(tgConfig.getAcquirerMosambee());
			merchantReq.setTg(tgConfig.getTg());
		} else {
			merchantReq.setInstrument(merchantRequestDto.getInstrument());
			merchantReq.setAcquirer(merchantRequestDto.getAcquirer());
			merchantReq.setTg(merchantRequestDto.getTg());
		}
		return merchantReq;
	}

    
	private synchronized List<TerminalRequestDto> amendmentTerminalHandler(Merchant merchant) {
		log.info("Handling message for amendment Terminals");

		List<Terminal> terminals = merchant.getTerminals();
		Address address = null;
		if (merchant.getAddresses() != null) {
			address = merchant.getAddresses().get(0);
		}

		String authSystem = merchant.getConfigurations().getSoftPosAuthSystem();
		TgConfig tgConfig = null;
		if (authSystem != null) {
			tgConfig = appConfig.getSoftposauthSystem().get(authSystem);
		}

		List<TerminalRequestDto> terminalAddList = new ArrayList<TerminalRequestDto>();

		for (Terminal terminal : terminals) {
			TerminalRequestDto terminalReq = new TerminalRequestDto();

			if (terminal.getTerminalId() != null) {
				terminalReq.setTid(terminal.getTerminalId());
			}
			if (address != null) {
				if (address.getCity() != null) {
					terminalReq.setTerminalLocation(TextUtils.truncate(address.getCity(), 60));
				}
				if (address.getPhone() != null) {
					terminalReq.setTerminalContactNo(TextUtils.leftPadUptoMaxLen(address.getPhone(), 10, '0'));
				}
				if (address.getEmail() != null) {
					terminalReq.setTerminalEmail(address.getEmail());
				}
			}
			terminalAddList.add(terminalReq);
		}
		return terminalAddList;
	}
    
    
    /**
     * Retrieves the queued message, maps it
     * into an MerchantRequest object
     * Call HMAC Api call
     * and persist the document
     */
	public synchronized void processAmendmentMerchant(ApplicationRequest entity) {
		log.info("Handling message  {}", entity);
		try {
			Acquirer acquirer = appConfig.getAcquirer(entity.getAcquirer());
			if (acquirer != null) {
				List<Merchant> merchants = getValidMerchants(entity);
				if (merchants.size() == 0) {
					throw new MessageCancelledException("No changes required");
				}
				log.info("Total number of valid merchants " + merchants.size());
				entity.setSendUpdateCallBackStatus(true);
				prepareAmendmentReq(entity, merchants);
			} else {
				throw new AcquierNotFoundException(entity.getApplicationId());
			}
			// after all merchant processed then decide final status for appReq/entity and
			// decide to sendUpdate or not
			entity.setSendUpdateCallBackStatus(true);
			softPosMosambeeService.finalActivityOnAppReq(entity, Arrays.asList(Status.AMENDMENT_DONE), null);
		} catch (Exception ex) {
			throw new BusinessException(entity.getApplicationId(), ex);
		} finally {
			softPosMosambeeService.saveAppReqDb(entity);
		}
	}
	
    private synchronized void prepareAmendmentReq(ApplicationRequest applicationRequest, List<Merchant> merchants) throws NullPointerException {
    	for(Merchant merchant : merchants) 
        {
    		if(merchant.getAmendmentList().contains(AmendmentType.ADDING_TERMINALS)) {
    			buildAddTerminalRequest(applicationRequest, merchant);
    		}if(merchant.getAmendmentList().contains(AmendmentType.ADDRESS) || merchant.getAmendmentList().contains(AmendmentType.LEGAL_NAME) || merchant.getAmendmentList().contains(AmendmentType.MCC) || merchant.getAmendmentList().contains(AmendmentType.MERCHANT_NAME)) {
    			buildAmendmentRequest(applicationRequest, merchant);
    		}
        }
    }
    
    private void buildAddTerminalRequest(ApplicationRequest applicationRequest, Merchant merchant)
    {
    	log.info("request to build Adding Terminals Request call ");
    	softPosMosambeeService.assignAuthSystem(merchant);
        MerchantRequestDto merchantData = softPosMosambeeService.createMerchantHandler(merchant);
        List<TerminalRequestDto> terminalList = softPosMosambeeService.createTerminalHandler(merchant);
        
        merchantData.setTidDetails(terminalList);
        processingHelper.handleEachMerchant(merchantData, applicationRequest, appConfig.getAddTidUrl(), TaskName.AMENDMENT_MERCHANT, null, null, MerchantResponseDto.class);
    }
    
    /*
     * retreive all previous Success Merchant and those success terminals
     * payload might be not sending terminal details in amendment request 
     * but terminal Id is mandatory to Amendment API
     * So, need to set those terminal id, which is already assigned to merchant in previous request
     * 
     */
    private void buildAmendmentRequest(ApplicationRequest applicationRequest, Merchant merchant)
    {
    	log.info("request to build Amendment Request call ");
		String merchantId = null;
		try {
			merchantId = merchant.getMerchantId();
    		List<ApplicationRequest> allSucessRecords = softPosMosambeeService.retreiveSuccessMerchantRecords(merchantId, "success", "success");
    	    if(allSucessRecords != null || ! allSucessRecords.isEmpty()) {
    	       	ApplicationRequest sucessMerchantRecord = allSucessRecords.get(0);
    	        	
    	       	List<APIDto> apiDtos = filterSuccessAPIDtos(sucessMerchantRecord, merchantId, "success");
    	       	if(apiDtos != null && !apiDtos.isEmpty()) {
    	       		APIDto apiDto = apiDtos.get(0);  
    	       		APIRequestDto apiRequestDto = (APIRequestDto)apiDto.getRequestCall();
    	       		MerchantRequestDto merchantRequestDto = apiRequestDto.getMidRequest();
    	       		APIRequestDto amendApiReqCall =  profileHandler(merchant);
    	            MerchantRequestDto merchantDto = buildMerchantRequestDto(merchant, merchantRequestDto);
    	               
    	            APIResponseDto apiResponseDto = (APIResponseDto)apiDto.getResponseCall();
    	        	List<TerminalResponseDto> terminalDtos = apiResponseDto.getMidDetails().getTidDetails();
    	            List<TerminalRequestDto> terminalAmendList = new ArrayList<TerminalRequestDto>();
    	            TerminalRequestDto terminalReq = new TerminalRequestDto();
    	            
    	            //SF is not sending terminal details so need to fetch it from database
    	            List<TerminalResponseDto> terminalResponseDtos = retreiveTerminalDtos(terminalDtos, "success");
    	            if(terminalResponseDtos != null && ! terminalResponseDtos.isEmpty()) {
    	            	TerminalResponseDto terminalResponseDto = terminalResponseDtos.get(0);
    	            	terminalReq.setTid(terminalResponseDto.getTerminalId());
	    	            terminalAmendList.add(terminalReq);
	    	            merchantDto.setTidDetails(terminalAmendList);
	    	               
	    	            amendApiReqCall.setMidRequest(merchantDto);
	    	               
	    	            processingHelper.handleEachMerchant(amendApiReqCall, applicationRequest, appConfig.getAmendmentUrl(), TaskName.AMENDMENT_MERCHANT, null, null, APIResponseDto.class);
	    	                
    	            }
    	        }else {
    	        	log.info("Onboarded Merchantdetails not found in db "+merchantId);
    	        }
    	    }else {
    	    	log.info("Merchantdetails not found in db "+merchantId);
    	    }
        } catch(Exception e) {log.error("Error occured while amendment merchant details "+merchantId +" "+e.getMessage());}
    }
    
    /*
     * Structure of ApiDatas in database as
     * 
     * ApiDatas[].merchantID, requestCAll, responseCall....
     * .......responseCall.result, responseCode, midDetails
     * .........midDetails.result, responseCode, tidDetails
     * ............tidDetails[].result, responseCode, message
     * 
     * filter the ApiDatas as per mrechantId and tidDetails.result="success"
     */
    private List<APIDto> filterSuccessAPIDtos(ApplicationRequest applicationRequest, String merchantId, String status)  {
    	log.info("Mapping request to filterSuccessAPIDtos call ");
    	List<APIDto> successAPIDtos = applicationRequest.getApiDatas().stream()
    			.filter(ap -> ap.getMerchantId().equals(merchantId))
    			.filter(ap -> (ap.getResponseCall() instanceof APIResponseDto) && ((APIResponseDto)ap.getResponseCall()).getMidDetails().getTidDetails().stream().anyMatch(tr->tr.getResult().equals(status)))
    			.collect(Collectors.toList());
    	return successAPIDtos;
    }
    
    
    private List<TerminalResponseDto> retreiveTerminalDtos(List<TerminalResponseDto> terminalDto, String status)  {
    	log.info("Mapping request to retreiveTerminalDtos call ");
    	return (List<TerminalResponseDto>) terminalDto.stream().filter(tr -> tr.getResult() != null && tr.getResult().equals(status)).collect(Collectors.toList());
    }
    
	/**
	 * @param applicationRequest
	 * Service = SOFTPOS && terminalModel = mosambee && suProductType = NG1_TAPTOPAY && AmendmentList not null
	 * @return
	 */
	public List<Merchant> getValidMerchants(ApplicationRequest applicationRequest) {
		log.info("get valid merchants ");
    	List<Merchant> merchants = applicationRequest.getPayload().getApplications().stream()
                .flatMap(app -> app.getMerchants().stream())
                .filter(mer -> mer.isSoftPos() && mer.isSubProductSupported() && !mer.isAmendmentListEmpty())
                .collect(Collectors.toList());
    	return merchants;
    }
    
}
