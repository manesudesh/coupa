package ae.network.onboarding.softpos.mosambee.scheduler;


import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.onboarding.softpos.mosambee.common.AppConfig;
import ae.network.onboarding.softpos.mosambee.common.TgConfig;
import ae.network.onboarding.softpos.mosambee.integration.HMACClient;
import ae.network.onboarding.softpos.mosambee.model.APIDto;
import ae.network.onboarding.softpos.mosambee.model.ApplicationRequest;
import ae.network.onboarding.softpos.mosambee.model.RetryBlock;
import ae.network.onboarding.softpos.mosambee.model.RetryTerminal;
import ae.network.onboarding.softpos.mosambee.model.Status;
import ae.network.onboarding.softpos.mosambee.model.TaskName;
import ae.network.onboarding.softpos.mosambee.model.apirequest.APIRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apirequest.MerchantRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apirequest.TerminalRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.CommonResponse;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.MerchantResponseDto;
import ae.network.onboarding.softpos.mosambee.model.payload.Address;
import ae.network.onboarding.softpos.mosambee.model.payload.Merchant;
import ae.network.onboarding.softpos.mosambee.model.payload.Terminal;
import ae.network.onboarding.softpos.mosambee.rabbitmq.service.exchange.SoftPosMosambeeService;
import ae.network.onboarding.softpos.mosambee.service.utils.ProcessingHelper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * @author 
 */
@Slf4j
@AllArgsConstructor
@Component
public class RetryTerminalService {

    /**
     * Injection of SoftPosMosambeeService 
     */
	@Autowired
    private final SoftPosMosambeeService mosambeeService;
    
	/**
     * Injection of ProcessingHelper for helper utility
     */
	@Autowired
    private final ProcessingHelper processingHelper;

	/**
	 * Application properties configuration
	 */
	private final AppConfig appConfig;
    

    /**
     * retry all fail terminals
     */
    public void retryTerminals() {
    	List<ApplicationRequest> appRequestsList = mosambeeService.pickRetryRecords(Status.TERMINAL_FAIL.getValue(), appConfig.getRetryMaxCount(), Status.TYPE_TERMINAL.getValue(), Status.RETRY.getValue());
    	if(appRequestsList == null || appRequestsList.size()== 0) {
    		log.info("No data to be RETRY processed");
    		return;
    	}
    	log.info("Total {} payload is to be retry ",appRequestsList.size());
    	updateAllRecordsStatusInProgress(appRequestsList, Status.IN_PROGRESS.getValue());
    	try 
    	{
    		processRetryTerminals(appRequestsList);
	    }finally { 
	    	updateStatusInProgressToOriginal(appRequestsList, Status.IN_PROGRESS.getValue(), Status.TERMINAL_FAIL.getValue());
    	}
    }

   /**
	* @param appRequestsList
	*/
   //updatestatus inProgress of all appReq so, while processing, no other job should pick these payloads 
	private void updateAllRecordsStatusInProgress(List<ApplicationRequest> appRequestsList, String status) {
		appRequestsList.stream()
    	.map(e-> {e.setMosambeeRetryStatus(status); return e;})
    	.forEach(e-> mosambeeService.saveAppReqDb(e));
	}

    /**
	 * @param appRequestsList
	 * @param processingRecords
	 * @param originaStatus
	 */
    //update status of app so next interval, job should pick these payloads if retrycount is less than count
	private void updateStatusInProgressToOriginal(List<ApplicationRequest> appRequestsList, String processingRecordsStatus, String originaStatus) {
		appRequestsList.stream().filter(e->e.getMosambeeRetryStatus()
				.equalsIgnoreCase(processingRecordsStatus))
				.map(e-> {e.setMosambeeRetryStatus(originaStatus); return e;})
				.forEach(e-> mosambeeService.saveAppReqDb(e));
	}

    /**
     * @param appRequestsList
     * structure of retryBlocks in database as
     * retryBlocks[].retryType=Terminal, merchantId, retryTerminals
     * ......retryTerminals[].terminalId, status=RETRY 
     */
    public void processRetryTerminals(List<ApplicationRequest> appRequestsList) {
    	try {
	    	for(ApplicationRequest appRequest: appRequestsList) {
	    		log.info("processRetryTerminals AppReqId "+appRequest.getApplicationId());
	    		List<Status> allRetryStatusList = new ArrayList<Status>();
	    		appRequest.setSendUpdateCallBackStatus(true);
	    		
	    		List<RetryBlock> newRetryObjList = new ArrayList<>(); 
	    		for(RetryBlock retryObj : appRequest.getRetryBlocks())
	    		{
	    			String retryMerchnatId = retryObj.getMerchantId();
	    			Optional<Merchant> merchantOpt = mosambeeService.getValidMerchants(appRequest).stream().filter(m->m.getMerchantId().equalsIgnoreCase(retryMerchnatId)).findFirst();
	    			if(merchantOpt.isPresent()) {
	    				Merchant merchantDetail = merchantOpt.get();
	    				log.info("MerchantId "+merchantDetail.getMerchantId());
	    				List<Terminal> terminalsEntity = merchantDetail.getSoftPosTerminals();
	    				if(terminalsEntity == null || terminalsEntity.size()==0) {continue;}
	    				
	    				mosambeeService.assignAuthSystem(merchantDetail);
	    				
	    				List<TerminalRequestDto> terminalAddList = prepareTerminalReqList(retryObj, merchantDetail, terminalsEntity);
	    				if(terminalAddList == null || terminalAddList.size()==0) { continue; }
	    				MerchantRequestDto merchantAddReq = mosambeeService.createMerchantHandler(merchantDetail);
	    				merchantAddReq.setTidDetails(terminalAddList);
	    		        try 
	    		        {
		    				MerchantResponseDto merchantResponseDto = makeHttpCall(merchantAddReq);
		    		        APIDto aptDto = buildReqResAPIDto(merchantDetail, merchantAddReq, merchantResponseDto);
		    		        appRequest.getApiDatas().add(aptDto);
		    		        RetryBlock retryAddNew = processingHelper.handleTerminalResponse(appRequest, merchantAddReq, merchantResponseDto, allRetryStatusList);
		    		        addFailedTerminalsInPayload(appRequest, newRetryObjList, retryAddNew);
		    		        updateStatusTerminalsProcessed(retryObj, terminalAddList, Status.RETRY_PROCESSED.getValue());
		    		        manageResponseTask(appRequest, merchantDetail, merchantResponseDto);
	    		        }catch(Exception e) {
	    		        	log.error(e.getMessage(), e);
	    		        	appRequest.setSendUpdateCallBackStatus(false);
	    		        }
	    			}
	    		}
	    		finalActionOnRetryAppReq(appRequest, allRetryStatusList, newRetryObjList);
	    		mosambeeService.saveAppReqDb(appRequest);
	    	}
    	}catch(Exception e) {
    		log.error(e.getMessage(), e);
    	}
    }

	/**
	 * @param appRequest
	 * @param merchantDetail
	 * @param merchantResponseDto
	 */
	private void manageResponseTask(ApplicationRequest appRequest, Merchant merchantDetail,
			MerchantResponseDto merchantResponseDto) {
		String responseResult = (merchantResponseDto == null? "failed" : merchantResponseDto.getResult() == null ? "failed" : merchantResponseDto.getResult());
		processingHelper.prepareTaskPostResponse(appRequest, TaskName.ONBOARDING_TERMINAL, merchantDetail.getMerchantId(), responseResult);
	}

	/**
	 * @param retryObj
	 * @param terminalAddList
	 */
	private void updateStatusTerminalsProcessed(RetryBlock retryObj, List<TerminalRequestDto> terminalAddList, String statusProcessed) {
		//update new status and lastmodifieddate to retry terminal
		List<String> processTerminal = terminalAddList.stream().map(e->e.getTid()).collect(Collectors.toList());
		retryObj.getRetryTerminals().stream()
				.filter(e->processTerminal.contains( e.getTerminalId() ) )
				.forEach(e->{e.setStatus(statusProcessed); 
				e.setLastModifiedDate(new Date());});
	}

	/**
	 * @param appRequest
	 * @param newRetryObjList
	 * @param retryAddNew
	 */
	private void addFailedTerminalsInPayload(ApplicationRequest appRequest, List<RetryBlock> newRetryObjList, RetryBlock retryAddNew) {
		//IF ANY TERMINALRESPONSE FAIL THEN DONT SENUPDATE
		if(retryAddNew != null ) { 
		   newRetryObjList.add(retryAddNew);
		   appRequest.setSendUpdateCallBackStatus(false);
		}
	}

	/**
	 * @param merchantAddReq
	 * @return
	 * @throws JsonProcessingException
	 * @throws IOException
	 * @throws GeneralSecurityException
	 */
	private MerchantResponseDto makeHttpCall(MerchantRequestDto merchantAddReq)
			throws JsonProcessingException, IOException, GeneralSecurityException {
		ObjectMapper mapper = new ObjectMapper();
		String reqCreateAPIJSON = mapper.writeValueAsString(merchantAddReq);
		log.info("Plain request --> "+reqCreateAPIJSON );
		HMACClient client = new HMACClient();
		MerchantResponseDto merchantResponseDto = client.makeHTTPCallUsingHMAC(reqCreateAPIJSON,  appConfig.getAddTidUrl(), appConfig, MerchantResponseDto.class);
		return merchantResponseDto;
	}

	/**
	 * @param appRequest
	 * @param allRetryStatusList
	 * @param newRetryObjList
	 */
	private void finalActionOnRetryAppReq(ApplicationRequest appRequest, List<Status> allRetryStatusList,
			List<RetryBlock> newRetryObjList) {
		appRequest.setMosambeeRetryCount( appRequest.getMosambeeRetryCount() + 1 );
		appRequest.getRetryBlocks().addAll(newRetryObjList);
		
		Status status = mosambeeService.decideAppRetryStatus(allRetryStatusList);
		log.info(appRequest.getApplicationId()+" status is "+status);
		appRequest.setMosambeeRetryStatus(  status.getValue() );
		
		if(appRequest.getMosambeeRetryCount() >= appConfig.getRetryMaxCount()) {
			log.info("retryCount reached maximum limit");
			appRequest.setMosambeeRetryStatus(Status.MAX_RETRY.getValue());
		}
		
		if(appRequest.isSendUpdateCallBackStatus() || appRequest.getMosambeeRetryCount() >= appConfig.getRetryMaxCount()) {
			appRequest.setSendUpdateCallBackStatus(true);
			mosambeeService.sendUpdate(appRequest.getApplicationId(), appRequest);
		}
	}

	

	/*
	 * Retrieve and process all Terminals of merchant from retry block of db, those terminals are need to RETRY again
	 * 
	 * structure of retryBlocks in database as
     * retryBlocks[].retryType=Terminal, merchantId, retryTerminals
     * ......retryTerminals[].terminalId, status=RETRY 
     * 
	 */
	private List<TerminalRequestDto> prepareTerminalReqList(RetryBlock retryObj, Merchant merchant, List<Terminal> allPayloadTerminalsOfMerchant) {
		List<TerminalRequestDto> terminalAddList = new ArrayList<TerminalRequestDto>();
		
		Address address = merchant.getAddresses().get(0);
		String authSystem = merchant.getConfigurations().getSoftPosAuthSystem();
	    TgConfig tgConfig = appConfig.getSoftposauthSystem().get(authSystem);
		
		for(RetryTerminal retryTerminal : retryObj.getRetryTerminals())
		{
			if(retryTerminal.getStatus().equalsIgnoreCase(Status.RETRY.getValue()))
			{
				String retryTerminalId = retryTerminal.getTerminalId();
				Optional<Terminal> retryTerminalOpt = allPayloadTerminalsOfMerchant.stream().filter(terminalsOfMerchant->terminalsOfMerchant.getTerminalId().equalsIgnoreCase(retryTerminalId)).findFirst();
				if(retryTerminalOpt.isPresent())
				{
					log.info("    Retry Terminal {} is in Merchant Terminal List of Payload ",retryTerminalId);
					Terminal terminal = retryTerminalOpt.get();
					TerminalRequestDto terminalReqDto = mosambeeService.buildTerminalReqDto(address, tgConfig.getTerminalAuthType(), terminal);
				    terminalAddList.add(terminalReqDto);
				}else {
					log.info("    Retry Terminal {} is NOT FOUND in Merchant Terminal List of Payload ",retryTerminalId+"   ");
					retryTerminal.setStatus(Status.RETRY_PROCESSED.getValue());
					retryTerminal.setLastModifiedDate(new Date());
				}
			}
		}
		return terminalAddList;
	}

	/**
	 * @param merchantDetail
	 * @param merchantAddReq
	 * @param resDto
	 * @return
	 */
	private APIDto buildReqResAPIDto(Merchant merchantDetail, MerchantRequestDto merchantAddReq, CommonResponse resDto) {
		APIDto aptDto = APIDto.builder().build();
		aptDto.setMerchantId(merchantDetail.getMerchantId());
		aptDto.setRequestCall( APIRequestDto.builder().midRequest(merchantAddReq).build());
		aptDto.setRetryProcessed(Status.RETRY_PROCESSED.getValue());
		aptDto.setResponseCall(resDto);
		return aptDto;
	}
	
}
