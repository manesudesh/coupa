package ae.network.onboarding.softpos.mosambee.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import ae.network.onboarding.softpos.mosambee.common.APIConstant;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class Terminal {
    @JsonProperty("terminalId")
    private String terminalId;
    @JsonProperty("terminalModel")
    private String terminalModel;
    @JsonProperty("maker")
    private String maker;

    private String userId;
    private boolean processed;
    private boolean success;
    private String response;

    public boolean isSoftPos() {
        return APIConstant.MOSAMBEE.equalsIgnoreCase(maker);
    }
}
