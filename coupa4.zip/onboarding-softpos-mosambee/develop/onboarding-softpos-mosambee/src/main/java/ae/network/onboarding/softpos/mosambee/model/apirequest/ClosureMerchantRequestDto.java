package ae.network.onboarding.softpos.mosambee.model.apirequest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClosureMerchantRequestDto extends CommonRequest{

	private String refId ;
	private String refType;
	
	private String acquirer; 
	private String tg; 
	private String instrument;
	private String instrumentCode;
	private String status;
	private String remark;
	
}
