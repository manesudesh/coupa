package ae.network.onboarding.softpos.mosambee.common;

/**
 * @author 
 * @since 
 */
public interface DateFormat {
    String FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
}
