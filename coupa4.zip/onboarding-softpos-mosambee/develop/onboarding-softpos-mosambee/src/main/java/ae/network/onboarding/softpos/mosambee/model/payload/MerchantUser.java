package ae.network.onboarding.softpos.mosambee.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.ToString;

import static ae.network.onboarding.softpos.mosambee.common.TextUtils.toAlphaNumeric;
import static ae.network.onboarding.softpos.mosambee.common.TextUtils.truncate;

/**
 * @author 
 * @since 
 */
@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantUser {
    private String email;
    private String firstName;
    private String lastName;
    private String mobile;

    public String getFirstName() {
        return truncate(toAlphaNumeric(firstName), 24);
    }

    public String getLastName() {
        return truncate(toAlphaNumeric(lastName), 24);
    }
}
