package ae.network.onboarding.softpos.mosambee.common;

import java.text.DecimalFormat;

import net.logstash.logback.encoder.org.apache.commons.lang.StringUtils;



/**
 * @author 
 * @since 
 */
public class TextUtils {

    public static String truncate(String str, int maxLen) {
        if (str == null) {
            return null;
        }
        int maxLength = Math.min(str.length(), maxLen);
        return str.substring(0, maxLength);
    }

    public static String toAlphaNumeric(String str) {
        if (str == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (char c : str.toCharArray()) {
            if (Character.isDigit(c) || Character.isLetter(c) || Character.isSpaceChar(c)) {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /**
     * @param inStr
     * @param maxLen
     * @param padChar
     * @return
     */
    public static String leftPadUptoMaxLen(String inStr, int maxLen, char padChar) {
        if (inStr == null) { inStr = ""; }
        if(maxLen < 0) { maxLen = 0; }
        inStr = inStr.trim();
        int strLen = inStr.length();
        String subString = "";
        if(strLen > maxLen) {
        	subString = inStr.substring(strLen - maxLen, strLen);
        }
        else {
        	subString = inStr;
        }
        return StringUtils.leftPad(subString, maxLen, padChar);
    }
    
    /**
     * @param mcc
     * @return
     */
    public static String formatMcc(Integer mcc) {
        if (mcc == null) return null;
        return new DecimalFormat("0000").format(mcc);
    }
}
