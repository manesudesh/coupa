package ae.network.onboarding.softpos.mosambee.model.apiresponse;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class APIResponseDto extends CommonResponse implements Serializable{

	private String merchantRefNo;
	private MerchantResponseDto midDetails;
	
}
