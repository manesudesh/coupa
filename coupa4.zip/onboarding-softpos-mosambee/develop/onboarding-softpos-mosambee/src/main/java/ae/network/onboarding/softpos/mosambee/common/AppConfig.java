package ae.network.onboarding.softpos.mosambee.common;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import ae.network.onboarding.softpos.mosambee.model.Acquirer;
import lombok.Data;

@Component
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "config")
@Data
public class AppConfig {
    private Map<String, Acquirer> acquirers;
    private Map<String, TgConfig> softposauthSystem;
    private ProxyConfig proxy;
    private String hmacSecret;
    private String onboardingUrl;
    private String addTidUrl;
    private String amendmentUrl;
    private String closureUrl;
    private String queryProfileUrl;
    private String hmacAlgorithm;
    private String encrptSecret;
    private String clientId;
    private String nonce;
    private int retryMaxCount;
    private String jobInterval;

    public Acquirer getAcquirer(String acquirer) {
        return acquirers.get(acquirer);
    }
    
}
