package ae.network.onboarding.softpos.mosambee.integration;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.util.Base64;
import java.util.stream.Collectors;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;

import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.onboarding.softpos.mosambee.common.APIConstant;
import ae.network.onboarding.softpos.mosambee.common.AppConfig;
import ae.network.onboarding.softpos.mosambee.common.ProxyConfig;
import ae.network.onboarding.softpos.mosambee.model.apirequest.EncryptPayload;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HMACClient {
	public <T> T makeHTTPCallUsingHMAC(String reqCreateAPIJSON,  String url, AppConfig appConfig, Class<T> responseTypeClass) throws IOException, GeneralSecurityException {
		log.info("calling HMAC call ");
		String hmacSecret = appConfig.getHmacSecret();
		String algorithm = appConfig.getHmacAlgorithm();
		String clientId = appConfig.getClientId();
		String aesSecret = appConfig.getEncrptSecret(); 
		String nonce = appConfig.getNonce();
		ProxyConfig proxyConfig = appConfig.getProxy();
		
		long currentDate = System.currentTimeMillis();
		log.info("Mosambee URL "+url);
		HttpPost post = new HttpPost(url);

		String encryptedPayload = AESGCMUtil.encrypt(reqCreateAPIJSON, aesSecret, nonce);

		EncryptPayload encRequest = EncryptPayload.builder().clientId(clientId).encRequestMsg(encryptedPayload).build();

		ObjectMapper objMapper = new ObjectMapper();
		String jsonEncryptPaylod = objMapper.writeValueAsString(encRequest);

		StringEntity data = new StringEntity(jsonEncryptPaylod, APIConstant.ENTITY_VALUE_CHARSET);

		post.setEntity(data);

		String message = clientId + currentDate + jsonEncryptPaylod;
		log.info("message = clientId + currentDate + payload ---->      \n" + message);
		String hmac = computeHMAC(message, hmacSecret, algorithm);
		post.addHeader(APIConstant.HEADER_CLIENTID, clientId);
		post.addHeader(APIConstant.HEADER_NAME_HMAC, hmac);
		post.addHeader(APIConstant.HEADER_NAME_DATETIME, currentDate + "");

		post.addHeader(APIConstant.HEADER_NAME_CONTENT_TYPE, APIConstant.HEADER_VALUE_CONTENT_TYPE);

		log.info("ClientId---->  " + clientId);
		log.info("datetime---->   " + currentDate + "");
		log.info("HMAC---->\n" + hmac);

		DefaultHttpClient client = new DefaultHttpClient();
		
		if(proxyConfig != null && proxyConfig.isEnabled()) {
			HttpHost proxy = new HttpHost(proxyConfig.getHost(), proxyConfig.getPort());
			DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
			client.setRoutePlanner(routePlanner);
		}
		
		HttpResponse response = client.execute(post);
		InputStream inStream = response.getEntity().getContent();
		String responseText = new BufferedReader(new InputStreamReader(inStream, StandardCharsets.UTF_8)).lines()
				.collect(Collectors.joining("\n"));
		log.info("JSON RESPONSE MAPPING : {}", responseText +"  "+response.getStatusLine().getStatusCode());

		T resDto = objMapper.readValue(responseText, responseTypeClass);
		inStream.close();
		client.getConnectionManager().closeExpiredConnections();
		client.close();
		return resDto;
	}
	

	public static String computeHMAC(String message, String signatureKey, String algorithm) throws GeneralSecurityException {
		byte[] signatureKeyInByteArray = hexStringToByteArray(signatureKey);
		SecretKeySpec secretKeySpec = new SecretKeySpec(signatureKeyInByteArray, algorithm);
		Mac mac = Mac.getInstance(algorithm);
		mac.init(secretKeySpec);
		return Base64.getEncoder().encodeToString(mac.doFinal(message.getBytes()));
	}

	private static byte[] hexStringToByteArray(String hexString) {
		int len = hexString.length();
		byte[] data = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			data[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4)
					+ Character.digit(hexString.charAt(i + 1), 16));
		}
		return data;
	}
	
	
	
	/**
	 * @param <T>
	 * @param refId
	 * @param url
	 * @param appConfig
	 * @param responseTypeClass
	 * @return
	 * @throws IOException
	 * @throws GeneralSecurityException
	 */
	public <T> T makeHTTPQueryCallUsingHMAC(String refId,  String url, AppConfig appConfig, Class<T> responseTypeClass) throws IOException, GeneralSecurityException {
		log.info("calling HMAC GET call ");
		String hmacSecret = appConfig.getHmacSecret();
		String algorithm = appConfig.getHmacAlgorithm();
		String clientId = appConfig.getClientId();
		ProxyConfig proxyConfig = appConfig.getProxy();
		
		long currentDate = System.currentTimeMillis();
		log.info("Mosambee URL "+url);
		HttpGet getHttp = new HttpGet(url);

		String message = clientId + currentDate + refId;
		log.info("message = clientId + currentDate + payload ---->      \n" + message);
		String hmac = computeHMAC(message, hmacSecret, algorithm);
		getHttp.addHeader(APIConstant.HEADER_CLIENTID, clientId);
		getHttp.addHeader(APIConstant.HEADER_NAME_HMAC, hmac);
		getHttp.addHeader(APIConstant.HEADER_NAME_DATETIME, currentDate + "");

		getHttp.addHeader(APIConstant.HEADER_NAME_CONTENT_TYPE, APIConstant.HEADER_VALUE_CONTENT_TYPE);

		log.info("ClientId---->  " + clientId);
		log.info("datetime---->   " + currentDate + "");
		log.info("HMAC---->\n" + hmac);

		DefaultHttpClient client = new DefaultHttpClient();
		
		if(proxyConfig != null && proxyConfig.isEnabled()) {
			HttpHost proxy = new HttpHost(proxyConfig.getHost(), proxyConfig.getPort());
			DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
			client.setRoutePlanner(routePlanner);
		}
		
		HttpResponse response = client.execute(getHttp);
		InputStream inStream = response.getEntity().getContent();
		String responseText = new BufferedReader(new InputStreamReader(inStream, StandardCharsets.UTF_8)).lines()
				.collect(Collectors.joining("\n"));
		log.info("JSON RESPONSE MAPPING : {}", responseText +"  "+response.getStatusLine().getStatusCode());

		ObjectMapper objMapper = new ObjectMapper();
		T resDto = objMapper.readValue(responseText, responseTypeClass);
		inStream.close();
		client.getConnectionManager().closeExpiredConnections();
		client.close();
		return resDto;
	}


}
