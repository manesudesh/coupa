package ae.network.onboarding.softpos.mosambee.model.apiresponse;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import ae.network.onboarding.softpos.mosambee.model.apirequest.MerchantRequestDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetAPIResponseDto {

	private String merchantName;
	private String merchantDba;
	private String IsEnterprise;
	private String mobileNumber;
	private String businessEmail;
	private String spocName;
	private String merchantAddress;
	private String city;
	private String state ;
	private String country ; 
	private String businessPin;
	private String mccCode;
	
	private MerchantRequestDto midRequest;
}
