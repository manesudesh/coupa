package ae.network.onboarding.softpos.mosambee.exception;

/**
 * @author 
 * @since 
 */
public class BusinessException extends RuntimeException {
    public BusinessException(String applicationId, Exception e) {
        super(applicationId,e);
    }
}
