package ae.network.onboarding.softpos.mosambee.model;

import org.springframework.data.annotation.Id;

import ae.network.onboarding.softpos.mosambee.model.apirequest.CommonRequest;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.CommonResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class APIDto {
	@Id
	private String id;

    private String merchantId;
    
    private CommonRequest requestCall;
    
    private CommonResponse responseCall;
    
    private String retryProcessed;
}
