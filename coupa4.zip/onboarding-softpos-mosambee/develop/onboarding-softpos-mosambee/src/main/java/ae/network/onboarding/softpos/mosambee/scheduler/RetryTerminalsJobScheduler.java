package ae.network.onboarding.softpos.mosambee.scheduler;

import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@EnableScheduling
@AllArgsConstructor
public class RetryTerminalsJobScheduler {

	private IRetryTerminal retryTerminal;
	
	@Scheduled(cron = "${config.jobInterval}")
	public void startScheduler() {
		log.info("Staring Scheduled to retry SoftPos Mosambee Terminals");
		 retryTerminal.processTerminal();
	}
}
