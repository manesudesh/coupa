package ae.network.onboarding.softpos.mosambee.exception;

/**
 * @author 
 * @since 
 */
public class AcquierNotFoundException extends MessageRejectionException {
    public AcquierNotFoundException(String applicationId) {
        super(applicationId, "Acquirer not found");
    }
}
