package ae.network.onboarding.softpos.mosambee.scheduler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RetryTerminalImpl implements IRetryTerminal{

	@Autowired
    private RetryTerminalService service;
	
	@Override
	public void processTerminal() {
		service.retryTerminals();
	}

}
