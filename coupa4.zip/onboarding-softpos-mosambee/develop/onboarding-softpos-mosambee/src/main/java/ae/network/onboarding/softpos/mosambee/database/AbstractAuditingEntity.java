package ae.network.onboarding.softpos.mosambee.database;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

import static ae.network.onboarding.softpos.mosambee.common.DateFormat.FORMAT;
/**
 * Base abstract class for entities which will hold definitions for created, last modified by and created,
 * last modified by date.
 *
 * @author 
 * @since 
 */
@Data
public abstract class AbstractAuditingEntity implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@CreatedDate
    @JsonFormat(pattern = FORMAT)
    @DateTimeFormat(pattern = FORMAT)
    private Date createdDate = new Date();

    @LastModifiedDate
    @JsonFormat(pattern = FORMAT)
    @DateTimeFormat(pattern = FORMAT)
    private Date lastModifiedDate = new Date();
}
