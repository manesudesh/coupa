package ae.network.onboarding.softpos.mosambee.model;

import lombok.Data;

@Data
public class Acquirer {
    private String name;
    private String id;
}
