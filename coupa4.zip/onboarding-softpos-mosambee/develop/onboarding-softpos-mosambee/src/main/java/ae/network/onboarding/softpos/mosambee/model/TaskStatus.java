package ae.network.onboarding.softpos.mosambee.model;

/**
 * @author 
 * @since 
 */
public enum TaskStatus {
    COMPLETED, PARTIALLY_COMPLETED, FAILED, CANCELLED, IN_PROGRESS
}
