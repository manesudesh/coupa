package ae.network.onboarding.softpos.mosambee.database.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import ae.network.onboarding.softpos.mosambee.model.ApplicationRequest;


/**
 * @author 
 * @since 
 */
public interface MosambeeApplicationRequestRepository extends MongoRepository<ApplicationRequest, String> {
	@Query(value="{  '$and' : [ {'mosambeeRetryStatus': '?0'}, {'mosambeeRetryCount' :{$lt:?1}}, { 'retryBlocks.retryType':'?2'}, {'retryBlocks.retryTerminals.status': '?3'} ] }", sort = "{createdDate : -1}")
	List<ApplicationRequest> findApplicationsByRetryStatusAndRetryCount(String appRetryStatus, int retryCount, String retryType, String terminalRetryStatus);

	@Query(value="{  '$and' : [ {'ApiDatas.merchantId': '?0'}, {'ApiDatas.responseCall.result' : ?1}, { 'ApiDatas.responseCall.midDetails.tidDetails.result':'?2'} ] }", sort = "{createdDate : -1}")
	List<ApplicationRequest> findApplicationsByMerchantAndStatusAndTerminalStatus(String merchant, String merchantStatus, String terminalStatus);

}
