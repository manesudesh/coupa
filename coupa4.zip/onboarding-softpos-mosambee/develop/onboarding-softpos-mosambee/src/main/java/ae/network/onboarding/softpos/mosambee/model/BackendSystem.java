package ae.network.onboarding.softpos.mosambee.model;

import ae.network.onboarding.softpos.mosambee.rabbitmq.config.RabbitQueue;

/**
 * List of all onboarding backend systems
 */
public enum BackendSystem {
	SOFTPOS_MOSAMBEE(RabbitQueue.SOFTPOS_MOSAMBEE);
//	SOFTPOS(RabbitQueue.SOFTPOS);

    private final RabbitQueue rabbitQueue;

    BackendSystem(RabbitQueue rabbitQueue) {
        this.rabbitQueue = rabbitQueue;
    }

    public RabbitQueue getRabbitQueue() {
        return rabbitQueue;
    }
}
