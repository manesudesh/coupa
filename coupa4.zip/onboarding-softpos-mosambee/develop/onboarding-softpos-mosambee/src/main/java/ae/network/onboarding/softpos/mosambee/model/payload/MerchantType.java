package ae.network.onboarding.softpos.mosambee.model.payload;

/**
 * @author 
 * @version 
 */
public enum MerchantType {
    POS
}
