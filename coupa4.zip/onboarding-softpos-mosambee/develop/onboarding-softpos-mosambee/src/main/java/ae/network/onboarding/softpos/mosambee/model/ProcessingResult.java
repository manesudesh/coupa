package ae.network.onboarding.softpos.mosambee.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @author 
 * @since 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProcessingResult {
    private TaskStatus finalStatus;
    private Collection<Task> tasks = new ArrayList<>();
    private Boolean mergeToExisting;
}
