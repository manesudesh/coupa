package ae.network.onboarding.softpos.mosambee.common;

/**
 * @author 
 * @since 
 */
public interface APIConstant {
//    String instrument_card = "card";
    String tidType_both = "both";
    String devicePairFlag = "N";
    String terminalAuthType_NONE = "none";
//    String terminalAuthType_CERTIFICATE = "certificate";
    String base24 = "BASE24";
//    String TG_NIACQ = "NIACQ";
//    String MPGSNI = "MPGSNI";
    String MPGS = "MPGS";
    String posTerminalSupported_TAPTOPHONE = "TAPTOPHONE";
    String posTerminalSupported_CPOC = "CPOC";
    String CPOCPIN = "CPOCPIN";
    String MOSAMBEE = "MOSAMBEE";
    String isEnterprise = "no";
    String HEADER_CLIENTID = "clientId";
    String HEADER_NAME_HMAC = "hmac";
    String HEADER_NAME_DATETIME = "dateTime";
    String HEADER_NAME_CONTENT_TYPE = "Content-Type";
    String HEADER_VALUE_CONTENT_TYPE = "application/json";
    String ENTITY_VALUE_CHARSET = "UTF-8";
}
