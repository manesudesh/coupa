package ae.network.onboarding.softpos.mosambee.validation;

import static org.springframework.util.StringUtils.isEmpty;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ae.network.onboarding.softpos.mosambee.common.AppConfig;
import ae.network.onboarding.softpos.mosambee.model.ApplicationRequest;
import ae.network.onboarding.softpos.mosambee.model.ValidationError;
import ae.network.onboarding.softpos.mosambee.model.payload.Address;
import ae.network.onboarding.softpos.mosambee.model.payload.Merchant;
import ae.network.onboarding.softpos.mosambee.model.payload.Terminal;

/**
 * @author 
 * @since 
 */
@Service
public class PayloadValidator {

	@Autowired
	private AppConfig appConfig;

	public Collection<ValidationError> validateApplication(ApplicationRequest request) {
		List<ValidationError> errors = new ArrayList<>();
		if(request == null) {
			 errors.add(ValidationError.EMPTY_PAYLOAD);
	            return errors;
		}
		else if(appConfig.getAcquirer(request.getAcquirer()) == null )
		{
			errors.add(ValidationError.EMPTY_ACQUIRER);
		}
		return errors;
	}
	
    public Collection<ValidationError> validateMerchant(Merchant merchant) {
        List<ValidationError> errors = new ArrayList<>();
        if (merchant == null) {
            errors.add(ValidationError.EMPTY_PAYLOAD);
            return errors;
        }

        if (isEmpty(merchant.getMerchantId())) {
            errors.add(ValidationError.EMPTY_MERCHANT_IDENTIFIER);
        }
        if (isEmpty(merchant.getMerchantName())) {
            errors.add(ValidationError.EMPTY_MERCHANT_NAME);
        }
        if (isEmpty(merchant.getLegalName())) {
            errors.add(ValidationError.EMPTY_LEGAL_NAME);
        }
        if (isEmpty(merchant.getMcc())) {
            errors.add(ValidationError.EMPTY_MCC);
        }
        if (merchant.getAddresses() == null || merchant.getAddresses().isEmpty()) {
            errors.add(ValidationError.EMPTY_ADDRESSES);
        } else {
            Address address = merchant.getAddresses().get(0);
            if (isEmpty(address.getCity())) {
                errors.add(ValidationError.EMPTY_CITY);
            }
            if (isEmpty(address.getPostalCode())) {
                errors.add(ValidationError.EMPTY_POSTALCODE);
            }
            if (isEmpty(address.getMerchantAddress())) {
                errors.add(ValidationError.EMPTY_ADDRESS);
            }
            if (isEmpty(address.getPhone())) {
                errors.add(ValidationError.EMPTY_ADDRESS_MOBILE);
            }
            if (isEmpty(address.getEmail())) {
                errors.add(ValidationError.EMPTY_ADDRESS_EMAIL);
            }
        }

        for (Terminal terminal : merchant.getTerminals()) {
            if (isEmpty(terminal.getTerminalId()) ) {
                errors.add(ValidationError.EMPTY_TERMINAL_ID);
            }else if(terminal.getTerminalId().length() > 30) {
            	errors.add(ValidationError.LENGTH_TERMINAL_ID);
            }
            if (isEmpty(terminal.getTerminalModel())) {
                errors.add(ValidationError.EMPTY_TERMINAL_MODEL);
            }
            if (isEmpty(terminal.getMaker())) {
			  errors.add(ValidationError.EMPTY_TERMINAL_MAKER); }
        }
        return errors;
    }
}
