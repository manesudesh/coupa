package ae.network.onboarding.softpos.mosambee.model.apirequest;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class APIRequestDto extends CommonRequest implements Serializable{

	private String merchantName;
	private String merchantDba;
	private String IsEnterprise;
	private String mobileNumber;
	private String businessEmail;
	private String spocName;
	private String merchantAddress;
	private String city;
	private String state ;
	private String country ; 
	private String businessPin;
	private String mccCode;
	
	private MerchantRequestDto midRequest;
}
