package ae.network.onboarding.softpos.mosambee.model.apirequest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class EncryptPayload {
	private String clientId; 
	private String encRequestMsg; 
}
