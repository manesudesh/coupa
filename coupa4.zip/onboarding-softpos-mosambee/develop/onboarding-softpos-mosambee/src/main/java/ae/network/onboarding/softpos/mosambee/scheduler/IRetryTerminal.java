package ae.network.onboarding.softpos.mosambee.scheduler;

public interface IRetryTerminal {
       public void processTerminal();
}
