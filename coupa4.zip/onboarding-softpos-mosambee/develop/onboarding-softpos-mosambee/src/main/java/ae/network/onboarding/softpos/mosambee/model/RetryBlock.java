package ae.network.onboarding.softpos.mosambee.model;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RetryBlock {

	private String retryType;
	private String merchantId;
	private String merchantProcessStatus;
	private List<RetryTerminal> retryTerminals;
}
