package ae.network.onboarding.softpos.mosambee.model;

public enum RequestType {
    ONBOARDING, AMENDMENT, MERCHANT_CLOSURE, TERMINAL_CLOSURE, SCREENING
}
