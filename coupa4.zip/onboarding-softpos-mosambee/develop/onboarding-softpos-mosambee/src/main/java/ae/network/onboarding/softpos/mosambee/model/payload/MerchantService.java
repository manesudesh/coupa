package ae.network.onboarding.softpos.mosambee.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.Data;

/**
 * @author 
 * @since 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "serviceType", visible = true, defaultImpl = MerchantService.class)
@JsonSubTypes({@JsonSubTypes.Type(value = MosambeeService.class, name = "SOFTPOS")})
@Data
public class MerchantService {

    @JsonProperty("serviceType")
    protected String serviceType;

    public boolean isSoftPosMosambee() {
        return this instanceof MosambeeService;
    }
}
