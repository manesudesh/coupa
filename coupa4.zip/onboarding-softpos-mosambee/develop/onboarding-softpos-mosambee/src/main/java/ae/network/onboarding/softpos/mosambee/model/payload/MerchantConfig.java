package ae.network.onboarding.softpos.mosambee.model.payload;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 
 * @version 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantConfig {

    /**
     * by default it is false, if the Acquirer set it into true, the new values should be provided for Visa, MC at least
     * in the accepted card part under the merchant configuration.
     */
//    private boolean overrideDefaultSchemesMcc;

//    private List<FeesParam> fees;
    
    @JsonProperty("softPosAuthSystem")
    private String softPosAuthSystem;

}
