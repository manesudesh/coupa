package ae.network.onboarding.softpos.mosambee.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import ae.network.onboarding.softpos.mosambee.database.AbstractAuditingEntity;
import ae.network.onboarding.softpos.mosambee.model.payload.Merchant;
import ae.network.onboarding.softpos.mosambee.model.payload.Payload;
import ae.network.onboarding.softpos.mosambee.model.payload.Terminal;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 
 * @since 
 */
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@JsonIgnoreProperties(ignoreUnknown = true)
@Document("softpos_mosambee_requests")
public class ApplicationRequest extends AbstractAuditingEntity {
    /**
     * unique global id
     */
    @Id
    private String applicationId;
    /**
     * field to control optimistic locking
     */
    @Version
    @JsonIgnore
    private Integer version;
    /**
     * Partner acquirer
     */
    private String acquirer;
    /**
     * Request type (Create-update-close)
     */
    private RequestType requestType;
    /**
     * acquirer request id (unique across each acquirer)
     */
    private String requestId;
    /**
     * dru run option
     */
    private boolean dryRun;
    
    private String mosambeeRetryStatus ; 
    private int mosambeeRetryCount = 0;
    private boolean sendUpdateCallBackStatus = false;
    private List<RetryBlock> retryBlocks = new ArrayList<RetryBlock>();
    /**
     * application content
     */
    private Payload payload;
    
    private Collection<APIDto> ApiDatas = new ArrayList<APIDto>();
    
    private Collection<Task> tasks = new ArrayList<Task>(); 

    public List<Merchant> getSoftPosMerchants() {
    	if(requestType == RequestType.AMENDMENT) {
	    	return payload.getApplications().stream().flatMap(app -> app.getMerchants().stream())
	        		.filter( mer ->  mer.isSubProductSupported() 
	        				&& ! mer.isAmendmentListEmpty()
	        				&& mer.isSoftPos() )
	        		.collect(Collectors.toList());
    	}else {
    		return payload.getApplications().stream().flatMap(app -> app.getMerchants().stream())
    				.filter(Merchant::isSoftPos).collect(Collectors.toList());
    	}
    	
    }

    public List<Terminal> getSoftPosTerminals() {
        return getSoftPosMerchants().stream().flatMap(merchant -> merchant.getSoftPosTerminals().stream())
                .collect(Collectors.toList());
    }

    public boolean isProcessed() {
        return getSoftPosTerminals().stream().allMatch(Terminal::isProcessed);
    }
}
