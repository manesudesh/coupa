package ae.network.onboarding.softpos.mosambee.rabbitmq.service.exchange;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ae.network.onboarding.softpos.mosambee.common.AppConfig;
import ae.network.onboarding.softpos.mosambee.common.TgConfig;
import ae.network.onboarding.softpos.mosambee.exception.AcquierNotFoundException;
import ae.network.onboarding.softpos.mosambee.exception.BusinessException;
import ae.network.onboarding.softpos.mosambee.exception.MessageCancelledException;
import ae.network.onboarding.softpos.mosambee.model.Acquirer;
import ae.network.onboarding.softpos.mosambee.model.ApplicationRequest;
import ae.network.onboarding.softpos.mosambee.model.Status;
import ae.network.onboarding.softpos.mosambee.model.TaskName;
import ae.network.onboarding.softpos.mosambee.model.apirequest.ClosureMerchantRequestDto;
import ae.network.onboarding.softpos.mosambee.model.payload.Merchant;
import ae.network.onboarding.softpos.mosambee.service.utils.ProcessingHelper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * @author
 */
@Slf4j
@AllArgsConstructor
@Service
public class ClosureService {

	/**
	 * Injection of ProcessingHelper for helper utility
	 */
	@Autowired
	private final ProcessingHelper processingHelper;

	private final AppConfig appConfig;

	private final SoftPosMosambeeService softPosMosambeeService;

	/**
	 * Retrieves the message, maps it into an softposmosambee object.
	 *
	 * @throws IOException
	 */
	private synchronized ClosureMerchantRequestDto closureMerchantHandler(Merchant merchant) {
		log.info("Handling message for amendment Merchant");

		ClosureMerchantRequestDto closureMerchantReq = new ClosureMerchantRequestDto();
		closureMerchantReq.setRefId(merchant.getMerchantId());
		closureMerchantReq.setRefType("merchant");
		closureMerchantReq.setStatus("D");
		closureMerchantReq.setRemark("Merchant is no longer in use");

		softPosMosambeeService.assignAuthSystem(merchant);
		String authSystem = merchant.getConfigurations().getSoftPosAuthSystem();
		if (authSystem != null) {
			TgConfig tgConfig = appConfig.getSoftposauthSystem().get(authSystem);
			closureMerchantReq.setInstrument(tgConfig.getInstrument());
			closureMerchantReq.setAcquirer(tgConfig.getAcquirerMosambee());
			closureMerchantReq.setTg(tgConfig.getTg());
		}
		return closureMerchantReq;
	}

	/**
	 * Retrieves the queued message, maps it into an MerchantRequest object. and
	 * persist the document
	 */
	public synchronized void processClosureMerchant(ApplicationRequest entity) {
		log.info("Handling message  {}", entity);

		try {
			Acquirer acquirer = appConfig.getAcquirer(entity.getAcquirer());
			if (acquirer != null) {
				List<Merchant> merchants = entity.getPayload().getApplications().stream()
						.flatMap(app -> app.getMerchants().stream()).collect(Collectors.toList());
				// validate if changes required
				if (merchants.size() == 0) {
					throw new MessageCancelledException("No changes required");
				}
				log.info("Total number of valid merchants " + merchants.size());
				entity.setSendUpdateCallBackStatus(true);
				prepareClosureReq(entity, merchants);
			} else {
				throw new AcquierNotFoundException(entity.getApplicationId());
			}
			// after all merchant processed then decide final status for appReq/entity and
			// decide to sendUpdate or not
			entity.setSendUpdateCallBackStatus(true);
			softPosMosambeeService.finalActivityOnAppReq(entity, Arrays.asList(Status.AMENDMENT_DONE), null);

		} catch (Exception ex) {
			throw new BusinessException(entity.getApplicationId(), ex);
		} finally {
			softPosMosambeeService.saveAppReqDb(entity);
		}
	}

	private synchronized void prepareClosureReq(ApplicationRequest applicationRequest, List<Merchant> merchants)
			throws NullPointerException {
		log.info("Mapping request to prepareAmendmentReq call ");

		for (Merchant merchant : merchants) {
			ClosureMerchantRequestDto merchantData = closureMerchantHandler(merchant);
			processingHelper.queryCallEachMerchant(merchant.getMerchantId(), appConfig.getQueryProfileUrl());
			processingHelper.closureCallEachMerchant(merchantData, applicationRequest, appConfig.getClosureUrl(),
					TaskName.CLSOURE_MERCHANT);
		}
	}

}
