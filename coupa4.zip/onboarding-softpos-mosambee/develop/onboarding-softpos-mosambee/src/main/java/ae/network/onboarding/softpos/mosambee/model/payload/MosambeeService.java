package ae.network.onboarding.softpos.mosambee.model.payload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * @author 
 * @version 
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MosambeeService extends MerchantService {

    @JsonProperty("user")
    private MerchantUser user;

    @JsonProperty("sale")
    @Builder.Default
    private boolean sale = true;
    @JsonProperty("saleTip")
    private boolean saleTip;
    @JsonProperty("preAuth")
    private boolean preAuth;
    @JsonProperty("void")
    @Builder.Default
    private boolean canVoid = true;
    @JsonProperty("refund")
    private boolean refund;
    @JsonProperty("linkDevice")
    @Builder.Default
    private boolean linkDevice = true;


}
