package ae.network.onboarding.softpos.mosambee.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ValidationError {
    INVALID_JSON("SP000", "*", "invalid JSON content"),
    EMPTY_PAYLOAD("SP001", "payload", "payload is empty"),
    EMPTY_MERCHANT_IDENTIFIER("SP002", "merchantId", "merchant identifier is invalid"),
    EMPTY_MERCHANT_NAME("SP003", "merchantName", "merchant name is invalid"),
    EMPTY_LEGAL_NAME("SP004", "legal", "legal name is invalid"),
    EMPTY_MCC("SP005", "mcc", "MCC is invalid"),
    EMPTY_CURRENCY("SP006", "currency", "currency is invalid"),
    EMPTY_ADDRESSES("SP007", "addresses", "at least one address is invalid"),
    EMPTY_CITY("SP008", "address[0].city", "address city is invalid"),
    EMPTY_POSTALCODE("SP009", "address[0].postalCode", "postal code is invalid"),
    EMPTY_COUNTRYCODE("SP010", "address[0].country code", "country code is invalid"),
    EMPTY_ADDRESS("SP011", "address[0].addressLines", "address is invalid"),
    EMPTY_ADDRESS_MOBILE("SP012", "address[0].mobile", "Address[0] Contact Number is invalid"),
    EMPTY_ADDRESS_EMAIL("SP013", "address[0].email", "address[0] Email is invalid"),
    EMPTY_USER("SP014", "services.user", "softpos user is required"),
    EMPTY_USER_MOBILE("SP015", "services.user.mobile", "softpos user mobile is required to login to app"),
    EMPTY_TERMINAL_ID("SP016", "terminal.terminalId", "terminal Id is required"),
    LENGTH_TERMINAL_ID("SP017", "terminal.terminalId", "terminal Id is more than 30 characters"),
    EMPTY_TERMINAL_MODEL("SP018", "terminal.terminalModel", "terminal model is required"),
    EMPTY_TERMINAL_MAKER("SP019", "terminal.maker", "terminal maker is required"),
	EMPTY_SOFTPOSAUTHSYSTEM("SP020", "merchant.configurations.softposauthsystem", "softposauthsystem is required"),
	EMPTY_ACQUIRER("SP021", "payload acquirer", "aquirer is required");
	
    private String fieldName;
    private String errorMessage;
    private String errorCode;
}
