package ae.network.onboarding.softpos.mosambee.model.payload;

import static ae.network.onboarding.softpos.mosambee.common.TextUtils.toAlphaNumeric;
import static ae.network.onboarding.softpos.mosambee.common.TextUtils.truncate;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

//@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class Address {

    @JsonProperty("city")
    private String city;
    private String postalCode;
    private String countryCode;
    @JsonProperty("addressType")
    private String addressType;
    @JsonProperty("state")
    private String state;
    @JsonProperty("phone")
    private String phone;
    @JsonProperty("email")
    private String email;
    @JsonProperty("addressLines")
    private List<String> addressLines;

    public String getMerchantAddress() {
        if (addressLines == null) {
            return null;
        }
        String joinedAddress = addressLines.stream().filter(line -> !StringUtils.isEmpty(line)).
                collect(Collectors.joining());
        return truncate(toAlphaNumeric(joinedAddress), 80);
    }

}
