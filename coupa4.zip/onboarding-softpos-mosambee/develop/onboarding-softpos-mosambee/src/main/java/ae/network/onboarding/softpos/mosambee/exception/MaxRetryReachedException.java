package ae.network.onboarding.softpos.mosambee.exception;

/**
 * @author 
 * @since 
 */
public class MaxRetryReachedException extends MessageRejectionException {
    public MaxRetryReachedException(String applicationId) {
        super(applicationId, "Maximum retries reached");
    }
}
