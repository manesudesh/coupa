package ae.network.onboarding.softpos.mosambee.service.utils;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.onboarding.softpos.mosambee.common.APIConstant;
import ae.network.onboarding.softpos.mosambee.common.AppConfig;
import ae.network.onboarding.softpos.mosambee.exception.BusinessException;
import ae.network.onboarding.softpos.mosambee.integration.HMACClient;
import ae.network.onboarding.softpos.mosambee.model.APIDto;
import ae.network.onboarding.softpos.mosambee.model.ApplicationRequest;
import ae.network.onboarding.softpos.mosambee.model.ApplicationUpdate;
import ae.network.onboarding.softpos.mosambee.model.BackendSystem;
import ae.network.onboarding.softpos.mosambee.model.ProcessingResult;
import ae.network.onboarding.softpos.mosambee.model.RetryBlock;
import ae.network.onboarding.softpos.mosambee.model.RetryTerminal;
import ae.network.onboarding.softpos.mosambee.model.Status;
import ae.network.onboarding.softpos.mosambee.model.Task;
import ae.network.onboarding.softpos.mosambee.model.TaskHistory;
import ae.network.onboarding.softpos.mosambee.model.TaskName;
import ae.network.onboarding.softpos.mosambee.model.TaskStatus;
import ae.network.onboarding.softpos.mosambee.model.ValidationError;
import ae.network.onboarding.softpos.mosambee.model.apirequest.APIRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apirequest.ClosureMerchantRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apirequest.CommonRequest;
import ae.network.onboarding.softpos.mosambee.model.apirequest.MerchantRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apirequest.TerminalRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.APIResponseDto;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.CommonResponse;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.MerchantResponseDto;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.TerminalResponseDto;
import lombok.extern.slf4j.Slf4j;

/**
 * @author 
 */
@Service
@Slf4j
public class ProcessingHelper {

	@Autowired
	AppConfig appConfig;
	
    public ProcessingHelper() {
        super();
    }

    public Task createTask(TaskName taskName, TaskStatus status) {
		Task task = Task.builder()
        .name(taskName.name())
        .taskStatus(status)
        .taskHistory(new ArrayList<TaskHistory>())
        .build();
		return task;
	}
    
	/**
	 * @param status
	 * @param response
	 * @param statusCode
	 * @return
	 */
	public TaskHistory createTaskHistory(TaskStatus status, String response, String statusCode) {
        TaskHistory taskHistory = new TaskHistory();
        final Date now = new Date();
        taskHistory.setCreatedDate(now);
        taskHistory.setLastModifiedDate(now);
        taskHistory.setTaskStatus(status);
        taskHistory.setResponse(response);
        taskHistory.setStatusCode(statusCode);
        return taskHistory;
    }
	
    /**
     * @param applicationId
     * @param backendSystem
     * @param processingResult
     * @return
     */
    public ApplicationUpdate createApplicationUpdate(String applicationId, BackendSystem backendSystem, ProcessingResult processingResult) {
		ApplicationUpdate applicationUpdate = ApplicationUpdate.builder().applicationId(applicationId)
                .backendSystem(backendSystem).processingResult(processingResult).build();
		return applicationUpdate;
	}

	/**
	 * @param applicationRequest
	 * @return
	 */
	public ProcessingResult createProcessingResult(ApplicationRequest applicationRequest) {
		ProcessingResult processingResult = ProcessingResult.builder().tasks(applicationRequest.getTasks())
		        .finalStatus(calculateFinalStatus(applicationRequest)).build();
		return processingResult;
	}

	/**
	* @param applicationRequest
	* @return
	*/
	public static TaskStatus calculateFinalStatus(ApplicationRequest applicationRequest) {
	       Collection<Task> tasks = applicationRequest.getTasks().stream()
	               .filter(task -> !"VALIDATION".equalsIgnoreCase(task.getName())).collect(Collectors.toList());
	       if (tasks.stream().allMatch(task -> task.getTaskStatus().equals(TaskStatus.FAILED))) {
	           return TaskStatus.FAILED;
	       } else if (tasks.stream()
	               .allMatch(task -> (task.getTaskStatus().equals(TaskStatus.COMPLETED)
	                       || task.getTaskStatus().equals(TaskStatus.CANCELLED)))) {
	           return TaskStatus.COMPLETED;
	       } else {
	           return TaskStatus.PARTIALLY_COMPLETED;
	       }
	    }
	    
	/**
	 * @param validationErrors
	 * @param task
	 * @return
	 */
	public Task assignValidationErrorTaskHistory(Collection<ValidationError> validationErrors, Task task) {
		List<TaskHistory> taskHistoryList = validationErrors.stream().map(
					e->  createTaskHistory(task.getTaskStatus(), e.getFieldName() + " : " + e.getErrorMessage(), e.getErrorCode()) )
				.collect(Collectors.toList());
        task.setTaskHistory(taskHistoryList);
        return task;
	}

    /**
     * @param terminalModal
     * @return
     */
    public String getPosTerminalSupported(String terminalModal)
    {
    	return terminalModal != null && terminalModal.equalsIgnoreCase(APIConstant.CPOCPIN) ? APIConstant.posTerminalSupported_TAPTOPHONE : APIConstant.posTerminalSupported_CPOC;
    }
    
    
    /**
     * Retrieves the queued message, maps it
     * into an MerchantRequest object.
     * and persist the document
     * @throws IOException
     */
    public synchronized void handleEachMerchant(CommonRequest reqCreateAPI, ApplicationRequest entity, String urlOperation, TaskName taskOperation, List<RetryBlock> newRetryObjList , List<Status> retryStatusList, Class<? extends CommonResponse> responseClass) {
    	log.info("Handling Each Merchant {}", reqCreateAPI);
        try {
	        String merchantId = "";
        	if(reqCreateAPI instanceof APIRequestDto)
        	{
        		merchantId = ((APIRequestDto)reqCreateAPI).getMidRequest().getMid();
        	}else if(reqCreateAPI instanceof MerchantRequestDto) {
        		merchantId = ((MerchantRequestDto)reqCreateAPI).getMid();
        	}
	        log.info("assigning merchant {} detatils ", merchantId);
	        APIDto aptDto = APIDto.builder().build();
	        aptDto.setMerchantId(merchantId);
	        aptDto.setRequestCall(reqCreateAPI);
	        entity.getApiDatas().add(aptDto);
	        
	        ObjectMapper mapper = new ObjectMapper();
	        String reqCreateAPIJSON = mapper.writeValueAsString(reqCreateAPI);
	        log.info("Plain request --> "+reqCreateAPIJSON );
	        HMACClient client = new HMACClient();
	        
	        Task taskReq = createTask(TaskName.SEND_APP_REQUEST, TaskStatus.COMPLETED);
            taskReq.getTaskHistory().add( createTaskHistory(TaskStatus.COMPLETED, merchantId+" merchant calling softpos mosambee API", "OK") );
            entity.getTasks().add(taskReq);
            
            CommonResponse resDto =  client.makeHTTPCallUsingHMAC(reqCreateAPIJSON,  urlOperation, appConfig, responseClass);
            aptDto.setResponseCall(resDto);
            
			if (newRetryObjList != null && reqCreateAPI instanceof APIRequestDto && resDto instanceof APIResponseDto) {

				RetryBlock retryAddNew = handlePostResponse(entity, (APIRequestDto)reqCreateAPI, (APIResponseDto)resDto, retryStatusList);
				if (retryAddNew != null) {
					newRetryObjList.add(retryAddNew);
					entity.setSendUpdateCallBackStatus(false);
				}
			}
			
            String responseResult = (resDto == null? "failed" : resDto.getResult() == null ? "failed" : resDto.getResult());
            prepareTaskPostResponse(entity, taskOperation, merchantId, responseResult);
		  	
        }catch (IOException  | GeneralSecurityException ex) {
			throw new BusinessException(entity.getApplicationId(), ex);
		}
    }
    
    
	/**
	 * @param entity
	 * @param taskOperation
	 * @param merchantId
	 * @param resResult
	 */
	public void prepareTaskPostResponse(ApplicationRequest entity, TaskName taskOperation, String merchantId,
			String resResult) {
		log.info("prepareTaskPostResponse  merchant "+merchantId );
		Task taskRes = createTask(TaskName.RECEIVE_APP_RESPONSE, TaskStatus.COMPLETED);
		taskRes.getTaskHistory().add( createTaskHistory(TaskStatus.COMPLETED, merchantId+" Received softpos "+taskOperation+" mosambee response ", "OK") );	  
		entity.getTasks().add(taskRes);
		TaskStatus taskStatus = resResult.equalsIgnoreCase("success") ? TaskStatus.COMPLETED : TaskStatus.FAILED;
		Task taskprofile = createTask(taskOperation, taskStatus);
		taskprofile.getTaskHistory().add( createTaskHistory(taskStatus, merchantId+" "+taskOperation+"  "+taskStatus, taskStatus.toString()) );	  
		entity.getTasks().add(taskprofile);
	}

	/**
	 * @param entity
	 * @param reqDto
	 * @param resApiDto
	 * @param allRetryStatusList
	 * @return
	 */
	public RetryBlock handlePostResponse(ApplicationRequest entity, APIRequestDto reqDto, APIResponseDto resApiDto, List<Status> retryStatusList) {
		MerchantResponseDto merchantResponseObj = null;
		RetryBlock retryAddNew = null;
		
		if( StringUtils.isEmpty(resApiDto) || StringUtils.isEmpty(resApiDto.getMerchantRefNo()) || StringUtils.isEmpty(merchantResponseObj = resApiDto.getMidDetails()) || StringUtils.isEmpty(resApiDto.getMidDetails().getMidRefId()) )
		{ 
			log.info("response not has MercahntRefNo ");
			//MerchantProfile or MerchantDetails not generated
//			retryAddNew = Retry.builder().retryType("Merchant").merchantId(merchantId).merchantProcessStatus(Status.RETRY.getValue()).build();
			retryStatusList.add(Status.MERCHANT_FAIL);
		}else {
			retryAddNew = handleTerminalResponse(entity, reqDto.getMidRequest(), merchantResponseObj, retryStatusList);
		}
		return retryAddNew;
	}
	
	
	/**
	 * @param entity
	 * @param merchantReqDto
	 * @param merchantResponseObj
	 * @param allRetryStatusList
	 * @return
	 */
	public RetryBlock handleTerminalResponse(ApplicationRequest entity, MerchantRequestDto merchantReqDto, MerchantResponseDto merchantResponseObj, List<Status> retryStatusList) 
	{
		log.info("handleTerminalResponse ");
		RetryBlock retryObj = null;
		List<TerminalResponseDto> terminalResponseList = null;
		List <TerminalRequestDto> requestedTerminals = merchantReqDto.getTidDetails();
		String merchantId = merchantReqDto.getMid();
		
		if(StringUtils.isEmpty(terminalResponseList = merchantResponseObj.getTidDetails()) ) { 
			log.info("response received for MercahntDetails but response not found for Terminals ");
			//MercahntDetails generated but **ALL** Terminals get failed
				List<RetryTerminal> retryList = requestedTerminals.stream().map(e -> RetryTerminal.builder().terminalId(e.getTid()).status(Status.RETRY.getValue()).createdDate(new Date()).lastModifiedDate(new Date()).build()).collect(Collectors.toList());
				 retryObj = RetryBlock.builder().retryType(Status.TYPE_TERMINAL.getValue()).merchantId(merchantId).retryTerminals(retryList).build();
				retryStatusList.add(Status.TERMINAL_FAIL);
		}else {
			retryObj = handleNonEmptyTerminalResponse(retryStatusList, retryObj, terminalResponseList, requestedTerminals, merchantId);
		}
		return retryObj;
	}

	/**
	 * @param allRetryStatusList
	 * @param retryObj
	 * @param terminalResponseList
	 * @param requestedTerminals
	 * @param merchantId
	 * @return
	 */
	private RetryBlock handleNonEmptyTerminalResponse(List<Status> retryStatusList, RetryBlock retryObj,
			List<TerminalResponseDto> terminalResponseList, List<TerminalRequestDto> requestedTerminals,
			String merchantId) {
		List<String> requestedApiTids = requestedTerminals.stream().map(e -> e.getTid()).collect(Collectors.toList());
		List<String> successProcessTerminals = terminalResponseList.stream().filter(e -> !StringUtils.isEmpty(e.getTidRefId()) )
					.map(e -> e.getTerminalId()).collect(Collectors.toList());
		//requested terminals in api request should match terminals in api response
		if(successProcessTerminals == null || successProcessTerminals.size() == 0) {
			log.info("response for terminal list is empty ");	
		//success terminals list is empty
			List<RetryTerminal> failTerminals = requestedTerminals.stream().map(e -> RetryTerminal.builder().terminalId(e.getTid()).status(Status.RETRY.getValue()).createdDate(new Date()).lastModifiedDate(new Date()).build()).collect(Collectors.toList());
			retryObj = RetryBlock.builder().retryType(Status.TYPE_TERMINAL.getValue()).merchantId(merchantId).retryTerminals(failTerminals).build();
			retryStatusList.add(Status.TERMINAL_FAIL);
		}else { // list of non success terminals
			List<String> failTerminalIds = requestedApiTids.stream().filter(e-> ! successProcessTerminals.contains(e)).collect(Collectors.toList());
			List<RetryTerminal> retryList = failTerminalIds.stream().map(e -> RetryTerminal.builder().terminalId(e).status(Status.RETRY.getValue()).createdDate(new Date()).lastModifiedDate(new Date()).build()).collect(Collectors.toList());
			if( retryList != null && retryList.size() > 0 ) { 
		//if retryList has some terminals means some terminals have not success in api response
				log.info("response fail for some terminals ");
				retryObj = RetryBlock.builder().retryType(Status.TYPE_TERMINAL.getValue()).merchantId(merchantId).retryTerminals(retryList).build();
				retryStatusList.add(Status.TERMINAL_FAIL);
			}else if(retryList.size()==0 || requestedApiTids.size() == successProcessTerminals.size() ) {
				log.info("received response for all terminals ");
		//all terminals SUCCESSfully processed means all requested terminals have success status in api response
				retryStatusList.add(Status.ONBOARDED_DONE);
			}
		}
		return retryObj;
	}
	
    
    public synchronized void queryCallEachMerchant(String refId, String urlOperation) {
    	log.info("Handling Each GET Merchant {}", refId);
        try {
	        HMACClient client = new HMACClient();
	        String queryCallEndpoint = urlOperation +"/"+refId;
            APIResponseDto resDto = client.makeHTTPQueryCallUsingHMAC(refId,  queryCallEndpoint, appConfig, APIResponseDto.class);
		  	
        }catch (IOException  | GeneralSecurityException ex) {
			log.error(ex.getMessage());
		}
    }
    
    
    /**
     * @param reqCreateAPI
     * @param entity
     * @param urlOperation
     * @param taskOperation
     */
    public synchronized void closureCallEachMerchant(ClosureMerchantRequestDto reqClosureAPI, ApplicationRequest entity, String urlOperation, TaskName taskOperation) {
    	log.info("Handling Each Clsosing Merchant {}", reqClosureAPI);
        try {
	        String merchantId = reqClosureAPI.getRefId();
	        log.info("assigning refernce {} detatils ", merchantId);
	        APIDto aptDto = APIDto.builder().build();
	        aptDto.setMerchantId(merchantId);
	        aptDto.setRequestCall(reqClosureAPI);
	        entity.getApiDatas().add(aptDto);
	        
	        ObjectMapper mapper = new ObjectMapper();
	        String reqCreateAPIJSON = mapper.writeValueAsString(reqClosureAPI);
	        log.info("Plain request --> "+reqCreateAPIJSON );
	        HMACClient client = new HMACClient();
	        
	        Task taskReq = createTask(TaskName.SEND_CLSOURE_APP_REQUEST, TaskStatus.COMPLETED);
            taskReq.getTaskHistory().add( createTaskHistory(TaskStatus.COMPLETED, merchantId+" merchant calling softpos clsoure mosambee API", "OK") );
            entity.getTasks().add(taskReq);
            
            APIResponseDto resDto = client.makeHTTPCallUsingHMAC(reqCreateAPIJSON,  urlOperation, appConfig, APIResponseDto.class);
            aptDto.setResponseCall(resDto);
            
            String responseResult = (resDto == null? "failed" : resDto.getResult() == null ? "failed" : resDto.getResult());
            prepareTaskPostResponse(entity, taskOperation, merchantId, responseResult);
		  	
        }catch (IOException  | GeneralSecurityException ex) {
			throw new BusinessException(entity.getApplicationId(), ex);
		}
    }

}
