package ae.network.onboarding.softpos.mosambee.exception;

import org.springframework.amqp.AmqpRejectAndDontRequeueException;

/**
 * Reject message altogether, and send it to failure queue for investigation.
 * Use when there is no way to recover the error.
 *
 * @author 
 * @since 
 */
public class MessageRejectionException extends AmqpRejectAndDontRequeueException {
    private final String applicationId;

    public MessageRejectionException(String applicationId, String message) {
        super(message);
        this.applicationId = applicationId;
    }

    public MessageRejectionException(String applicationId, String message, Throwable cause) {
        super(message, cause);
        this.applicationId = applicationId;
    }

    public String getApplicationId() {
        return applicationId;
    }
}
