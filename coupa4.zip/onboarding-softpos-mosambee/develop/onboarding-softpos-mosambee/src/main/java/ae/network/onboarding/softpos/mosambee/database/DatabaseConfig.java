package ae.network.onboarding.softpos.mosambee.database;

import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.stereotype.Component;

/**
 * @author 
 * @since 
 */
@EnableMongoAuditing
@Component
public class DatabaseConfig {
}
