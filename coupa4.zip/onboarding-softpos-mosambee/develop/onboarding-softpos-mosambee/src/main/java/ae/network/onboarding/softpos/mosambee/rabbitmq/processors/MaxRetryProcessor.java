package ae.network.onboarding.softpos.mosambee.rabbitmq.processors;

import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import ae.network.onboarding.softpos.mosambee.exception.MaxRetryReachedException;

import static ae.network.onboarding.softpos.mosambee.rabbitmq.message.QueueMessage.DELAY_HEADER;
import static ae.network.onboarding.softpos.mosambee.rabbitmq.message.QueueMessage.MAX_RETRY_HEADER;

import javax.annotation.PostConstruct;

/**
 * @author 
 * @since 
 */
@Component
public class MaxRetryProcessor implements MessagePostProcessor {
    public static final int DELAY_MULTIPLIER = 5;

    private final RabbitTemplate rabbitTemplate;
    private final int maxRetryAttempts;
    private final int retryInSeconds;


    public MaxRetryProcessor(RabbitTemplate rabbitTemplate,
                             @Value("${octopus.processor.max-retry}") int maxRetryAttempts,
                             @Value("${octopus.consumer.error-retry-in-seconds}") int retryInSeconds) {
        this.rabbitTemplate = rabbitTemplate;
        this.maxRetryAttempts = maxRetryAttempts;
        this.retryInSeconds = retryInSeconds;
    }

    @Override
    public Message postProcessMessage(Message message) throws AmqpException {
        MessageProperties messageProperties = message.getMessageProperties();
        Object maxRetryHeader = messageProperties.getHeader(MAX_RETRY_HEADER);
        Object currentDelayHeader = messageProperties.getHeader(DELAY_HEADER);
        if (maxRetryHeader == null) {
            messageProperties.setHeader(MAX_RETRY_HEADER, maxRetryAttempts);
        } else {
            int maxRetry = asNumber(maxRetryHeader);
            if (maxRetry <= 0) {
                throw new MaxRetryReachedException(messageProperties.getCorrelationId());
            } else {
                messageProperties.setHeader(MAX_RETRY_HEADER, maxRetry - 1);
            }
        }

        if (currentDelayHeader == null) {
            messageProperties.setHeader(DELAY_HEADER, retryInSeconds);
        } else {
            int currentDelay = asNumber(currentDelayHeader);
            messageProperties.setHeader(DELAY_HEADER, currentDelay * DELAY_MULTIPLIER);
        }

        return message;
    }

    private int asNumber(Object maxRetryHeader) {
        try {
            return Integer.parseInt(maxRetryHeader.toString());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    @PostConstruct
    public void init() {
        rabbitTemplate.addBeforePublishPostProcessors(this);
    }
}
