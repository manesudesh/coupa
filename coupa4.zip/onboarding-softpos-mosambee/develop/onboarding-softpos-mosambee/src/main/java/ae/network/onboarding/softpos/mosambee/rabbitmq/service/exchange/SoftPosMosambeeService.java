package ae.network.onboarding.softpos.mosambee.rabbitmq.service.exchange;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ae.network.onboarding.softpos.mosambee.common.APIConstant;
import ae.network.onboarding.softpos.mosambee.common.AppConfig;
import ae.network.onboarding.softpos.mosambee.common.TextUtils;
import ae.network.onboarding.softpos.mosambee.common.TgConfig;
import ae.network.onboarding.softpos.mosambee.database.service.AppReqDbService;
import ae.network.onboarding.softpos.mosambee.exception.AcquierNotFoundException;
import ae.network.onboarding.softpos.mosambee.exception.BusinessException;
import ae.network.onboarding.softpos.mosambee.exception.MessageCancelledException;
import ae.network.onboarding.softpos.mosambee.model.Acquirer;
import ae.network.onboarding.softpos.mosambee.model.AdditionalData;
import ae.network.onboarding.softpos.mosambee.model.ApplicationRequest;
import ae.network.onboarding.softpos.mosambee.model.ApplicationUpdate;
import ae.network.onboarding.softpos.mosambee.model.BackendSystem;
import ae.network.onboarding.softpos.mosambee.model.ProcessingResult;
import ae.network.onboarding.softpos.mosambee.model.RequestType;
import ae.network.onboarding.softpos.mosambee.model.RetryBlock;
import ae.network.onboarding.softpos.mosambee.model.Status;
import ae.network.onboarding.softpos.mosambee.model.Task;
import ae.network.onboarding.softpos.mosambee.model.TaskHistory;
import ae.network.onboarding.softpos.mosambee.model.TaskName;
import ae.network.onboarding.softpos.mosambee.model.TaskStatus;
import ae.network.onboarding.softpos.mosambee.model.ValidationError;
import ae.network.onboarding.softpos.mosambee.model.apirequest.APIRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apirequest.MerchantRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apirequest.TerminalRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.APIResponseDto;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.CommonResponse;
import ae.network.onboarding.softpos.mosambee.model.payload.Address;
import ae.network.onboarding.softpos.mosambee.model.payload.Merchant;
import ae.network.onboarding.softpos.mosambee.model.payload.MerchantConfig;
import ae.network.onboarding.softpos.mosambee.model.payload.Terminal;
import ae.network.onboarding.softpos.mosambee.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.softpos.mosambee.rabbitmq.service.RabbitService;
import ae.network.onboarding.softpos.mosambee.service.utils.ProcessingHelper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * @author 
 */
@Service("mosambeeService")
@Slf4j
@AllArgsConstructor
public class SoftPosMosambeeService {

    /**
     * Injection of ApplicationRequestService for database
     * handshaking
     */
	@Autowired
    private final AppReqDbService dbsservice;
    
	/**
     * Injection of ProcessingHelper for helper utility
     */
	@Autowired
    private final ProcessingHelper processingHelper;
    /**
     * Injection of Rabbit Service to update the
     * queue
     */
    private final RabbitService rabbitService;
    
    private final AppConfig appConfig;
    
    /**
     * Retrieves the message, maps it
     * into an softposmosambee object.
     *
     * @throws IOException
     */
    public synchronized APIRequestDto createProfileHandler(Merchant merchant)  {
       log.info("Handling message for Create profile");
       
       Address address = merchant.getAddresses().get(0);
       
       APIRequestDto reqDto = APIRequestDto.builder()
    		   .merchantName(merchant.getTrimLegalName())
    		   .IsEnterprise(APIConstant.isEnterprise)
    		   .merchantDba(merchant.getTrimMerchantName())
    		   .mobileNumber(TextUtils.leftPadUptoMaxLen(address.getPhone(), 10, '0'))
    		   .businessEmail(address.getEmail())
    		   .merchantAddress(address.getMerchantAddress())
    		   .city(address.getCity())
    		   .state(address.getCity())
    		   .mccCode(merchant.getFormatMcc())
    		   .build();
       
       return reqDto;
    }
    
    /**
     * Retrieves the message, maps it
     * into an softposmosambee object.
     *
     * @throws IOException
     */
    public synchronized MerchantRequestDto createMerchantHandler(Merchant merchant )  {
       log.info("Handling message for Create Merchant");
       String authSystem = merchant.getConfigurations().getSoftPosAuthSystem();
       TgConfig tgConfig = appConfig.getSoftposauthSystem().get(authSystem);
       MerchantRequestDto merchantAddReq = MerchantRequestDto.builder()
        		.mid(merchant.getMerchantId())
        		.instrument(tgConfig.getInstrument()) //card
        		.acquirer(tgConfig.getAcquirerMosambee())
        		.tg(tgConfig.getTg())
        		.build();
        
        return merchantAddReq;
    }

    /**
     * Retrieves the message, maps it
     * into an softposmosambee object.
     *
     * @throws IOException
     */
    public synchronized List<TerminalRequestDto> createTerminalHandler(Merchant merchant)  {
       log.info("Handling message for Create Terminals");
       
       List<Terminal> terminals = merchant.getTerminals().stream().filter(t->APIConstant.MOSAMBEE.equalsIgnoreCase(t.getMaker())).collect(Collectors.toList());
       if(terminals.size() == 0) {
    	   log.info("Merchant does not have any terminals/maker mosambee");
    	   return null;
       }
       
       Address address = merchant.getAddresses().get(0);
       String authSystem = merchant.getConfigurations().getSoftPosAuthSystem();
       TgConfig tgConfig = appConfig.getSoftposauthSystem().get(authSystem);
       
       List<TerminalRequestDto> terminalAddList = new ArrayList<TerminalRequestDto>();
       
       for(Terminal terminal : terminals) { 
    	   TerminalRequestDto terminalAddReq = buildTerminalReqDto(address, tgConfig.getTerminalAuthType(), terminal);
    	   terminalAddList.add(terminalAddReq);
       }
       return terminalAddList;
    }

	/**
	 * @param address
	 * @param authType
	 * @param terminal
	 * @return
	 */
	public TerminalRequestDto buildTerminalReqDto(Address address, String authType, Terminal terminal) {
		TerminalRequestDto terminalAddReq = TerminalRequestDto.builder()
    		   .tid(terminal.getTerminalId())
    		   .tidType(APIConstant.tidType_both)
    		   .terminalLocation(TextUtils.truncate(address.getCity(), 60))
    		   .posTerminalSupported(processingHelper.getPosTerminalSupported(terminal.getTerminalModel())) 
    		   .devicePairFlag(APIConstant.devicePairFlag)
    		   .terminalAuthType(authType)
    		   .terminalContactNo(TextUtils.leftPadUptoMaxLen(address.getPhone(),10, '0'))
    		   .terminalEmail(address.getEmail())
    		   .build();
		return terminalAddReq;
	}
	
    /**
     * After mapping the JsonNode payload to
     * a list of application, the result is then
     *
     * @param applicationRequest
     * @return
     */
    private synchronized void prepareCreateReq(ApplicationRequest applicationRequest, List<Merchant> merchants, Acquirer acquirer, List<RetryBlock> newRetryObjList, List<Status> retryStatusList) throws NullPointerException {
    	log.info("Mapping request to CreateMerchant API call ");
    	 
    	for(Merchant merchant : merchants) 
        {
    		assignAuthSystem(merchant);
    		APIRequestDto apiReqCall =  createProfileHandler(merchant);
            MerchantRequestDto merchantData = createMerchantHandler(merchant);
            List<TerminalRequestDto> terminalList = createTerminalHandler(merchant);
            if(terminalList == null || terminalList.size()==0) {
            	continue;
            }
            merchantData.setTidDetails(terminalList);
            apiReqCall.setMidRequest(merchantData);
            processingHelper.handleEachMerchant(apiReqCall, applicationRequest, appConfig.getOnboardingUrl(), TaskName.ONBOARDING_MERCHANT, newRetryObjList, retryStatusList, APIResponseDto.class);
        }
    }
    
    /**
     * Retrieves the queued message, maps it
     * into an MerchantRequest object.
     * and persist the document
     * @throws IOException
     */
    public synchronized void processMerchant(ApplicationRequest entity) {
        log.info("Handling message  {}", entity);
        List<Status> retryStatusList = new ArrayList<Status>();
    	List<RetryBlock> newRetryObjList = new ArrayList<>();
    	
        try {
        	Acquirer acquirer = appConfig.getAcquirer(entity.getAcquirer());
        	if(acquirer != null) {
        		List<Merchant> merchants = getValidMerchants(entity);
                    // validate if changes required
        		if (merchants.size() == 0) {
        			throw new MessageCancelledException("No changes required");
                }
        		log.info("Total number of valid merchants "+merchants.size());
        		if(entity.getRequestType() == RequestType.ONBOARDING) {
        			entity.setSendUpdateCallBackStatus(true);
            		prepareCreateReq(entity, merchants, acquirer, newRetryObjList, retryStatusList);
            	}
        	}else
        	{
            	throw new AcquierNotFoundException(entity.getApplicationId());
            }
        	//after all merchant processed then decide final status for appReq/entity and decide to sendUpdate or not
        	finalActivityOnAppReq(entity, retryStatusList, newRetryObjList);
	     	
        }catch (Exception ex) {
			throw new BusinessException(entity.getApplicationId(), ex);
		}
        finally {
        	saveAppReqDb(entity);
        }
    }

	/**
	 * @param entity
	 * @param retryStatusList
	 * @param newRetryObjList
	 */
	public void finalActivityOnAppReq(ApplicationRequest entity, List<Status> retryStatusList, List<RetryBlock> newRetryObjList) {
		log.info("calling finalActivityOnAppReq ");
		Status status = decideAppRetryStatus(retryStatusList);
		log.info("Application status is "+status);
		entity.setMosambeeRetryStatus(  status.getValue() );
		if(newRetryObjList != null) { entity.getRetryBlocks().addAll(newRetryObjList); }
		
		if(entity.isSendUpdateCallBackStatus() || entity.getMosambeeRetryCount() >= appConfig.getRetryMaxCount()) {
			entity.setSendUpdateCallBackStatus(true); 
			sendUpdate(entity.getApplicationId(), entity);
		}
	}
    
	/**
	 * @param applicationRequest
	 * @return
	 */
	public List<Merchant> getValidMerchants(ApplicationRequest applicationRequest) {
		log.info("get valid merchants ");
    	List<Merchant> merchants = applicationRequest.getPayload().getApplications().stream()
                .flatMap(app -> app.getMerchants().stream())
                .filter(Merchant::isSoftPos)
                .collect(Collectors.toList());
    	return merchants;
    }

    /**
     * @param taskName
     * @param status
     * @param response
     * @param statusCode
     * @return
     */
    public Task assignTaskhistoryToTask(TaskName taskName, TaskStatus status, String response, String statusCode) {
    	log.info("building taskhistory "+taskName+"  response "+response +" status "+status);
    	Task task = processingHelper.createTask(taskName, status);
		TaskHistory taskhist = processingHelper.createTaskHistory(status, response, statusCode);
		task.getTaskHistory().add(taskhist);
		return task;
    }
    
    /**
     * @param validationErrors
     * @param taskName
     * @param status
     * @return
     */
    public Task assignValidationErrorTaskHistory(Collection<ValidationError> validationErrors, TaskName taskName, TaskStatus status) {
    	log.info("building validationerror taskhistory "+taskName+" status "+status);
    	Task task = processingHelper.createTask(taskName, status);
		task = processingHelper.assignValidationErrorTaskHistory(validationErrors, task);
		return task;
    }
    
    /**
     * send task to queue
     */
    public void sendUpdate(String applicationId, ApplicationRequest entity) {
        log.info("sending task to updates queue");
        ApplicationUpdate applicationUpdate = new ApplicationUpdate();
        applicationUpdate.setApplicationId(applicationId);
        applicationUpdate.setBackendSystem(BackendSystem.SOFTPOS_MOSAMBEE);
        AdditionalData addData = new AdditionalData();
        List<CommonResponse> responseCollection = entity.getApiDatas().stream().map(e -> e.getResponseCall()).collect(Collectors.toList());
        if(responseCollection != null ) {
            addData.setDataMap("Response", responseCollection);
        }
        applicationUpdate.setAdditionalData(addData);
        ProcessingResult processResult = processingHelper.createProcessingResult(entity);
        applicationUpdate.setProcessingResult(processResult);
        rabbitService.sendMessage(RabbitQueue.UPDATES, applicationUpdate);
    }
    
    /**
     * @param applicationRequest
     * @return
     */
     public static TaskStatus calculateFinalStatus(ApplicationRequest applicationRequest) {
        Collection<Task> tasks = applicationRequest.getTasks().stream()
                .filter(task -> !"VALIDATION".equalsIgnoreCase(task.getName())).collect(Collectors.toList());
        if (tasks.stream().allMatch(task -> task.getTaskStatus().equals(TaskStatus.FAILED))) {
            return TaskStatus.FAILED;
        } else if (tasks.stream()
                .allMatch(task -> (task.getTaskStatus().equals(TaskStatus.COMPLETED)
                        || task.getTaskStatus().equals(TaskStatus.CANCELLED)))) {
            return TaskStatus.COMPLETED;
        } else {
            return TaskStatus.PARTIALLY_COMPLETED;
        }
     }
     
    /**
     * @param payloadRequest
     */
    public void saveAppReqDb(ApplicationRequest payloadRequest)
    {
    	dbsservice.save(payloadRequest);
    }
    
    /**
     * @param appRetryStatus
     * @param retryCount
     * @param retryType
     * @param terminalRetryStatus
     * @return
     */
    public List<ApplicationRequest> pickRetryRecords( String appRetryStatus, int retryCount, String retryType, String terminalRetryStatus)
    {
    	return dbsservice.findRetryRecords(appRetryStatus, retryCount, retryType, terminalRetryStatus );
    }
    
    public List<ApplicationRequest> retreiveSuccessMerchantRecords( String merchantId, String merchantStatus, String terminalStatus)
    {
    	return dbsservice.findApplicationsByMerchantAndStatusAndTerminalStatus(merchantId, merchantStatus, terminalStatus );
    }
   
    /**
	 * ApplicationRequest status is depend on all merchant status and all retryObject status
	 * @param allRetryStatusList
	 * @return
	 */
	public Status decideAppRetryStatus(List<Status> retryStatusList) {
		if( retryStatusList.stream().anyMatch(e-> e.equals(Status.AMENDMENT_DONE) ) ) {
			return Status.AMENDMENT_DONE;
		}else if( retryStatusList.stream().anyMatch(e-> e.equals(Status.CLOSURE_DONE) ) ) {
			return Status.CLOSURE_DONE;
		}else if( retryStatusList.stream().anyMatch(e-> e.equals(Status.TERMINAL_FAIL) ) ) {
			return Status.TERMINAL_FAIL;
		}else if( retryStatusList.stream().anyMatch(e-> e.equals(Status.MERCHANT_FAIL) ) ) {
			return Status.MERCHANT_FAIL;
		}else if( retryStatusList.stream().allMatch(e-> e.equals(Status.ONBOARDED_DONE) ) ) {
			return Status.ONBOARDED_DONE;
		}else {
			return Status.IN_PROGRESS;
		}
	}
    
	/**
	 * @param merchant
	 * @return
	 */
	public Merchant assignAuthSystem(Merchant merchant) {
		if(merchant.getConfigurations() == null) {
			log.info("Merchant.configuration is not found so softPosAuthSystem value is MPGS ");
			merchant.setConfigurations(MerchantConfig.builder().softPosAuthSystem(APIConstant.MPGS).build());
		}else if(merchant.getConfigurations().getSoftPosAuthSystem() == null ){
			log.info("Merchant.configuration.softPosAuthSystem is not found so softPosAuthSystem value is MPGS ");
			merchant.getConfigurations().setSoftPosAuthSystem(APIConstant.MPGS);
		}
		return merchant;
	}
}
