package ae.network.onboarding.softpos.mosambee.common;

import lombok.Data;

@Data
public class ProxyConfig {
	boolean enabled;
	String host;
	Integer port;
}
