package ae.network.onboarding.softpos.mosambee.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import ae.network.onboarding.softpos.mosambee.common.DateFormat;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RetryTerminal {

	private String terminalId;
	private String status;
	
	@JsonFormat(pattern = DateFormat.FORMAT)
    @DateTimeFormat(pattern = DateFormat.FORMAT)
    private Date createdDate;
    @JsonFormat(pattern = DateFormat.FORMAT)
    @DateTimeFormat(pattern = DateFormat.FORMAT)
    private Date lastModifiedDate;
}
