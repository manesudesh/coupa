package ae.network.onboarding.softpos.mosambee.model.apiresponse;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantResponseDto extends CommonResponse implements Serializable{

	private String mid;
	private String midRefId;
	private List<TerminalResponseDto> tidDetails;
}
