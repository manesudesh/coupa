package ae.network.onboarding.softpos.mosambee.common;

import org.slf4j.MDC;

/**
 * @author 
 * @since 
 */
public abstract class MdcUtils {

    private static final String CORRELATION_ID = "correlation_id";

    /**
     * Sets correlation id in log messages
     *
     * @param correlationId application id
     */
    public static void setCorrId(String correlationId) {
        MDC.put(CORRELATION_ID, correlationId);
    }

    /**
     * remove data from context
     */
    public static void clearCorrId() {
        MDC.remove("correlation_id");
    }
}
