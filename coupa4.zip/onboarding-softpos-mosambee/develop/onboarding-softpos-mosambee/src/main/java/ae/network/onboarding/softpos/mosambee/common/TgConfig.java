package ae.network.onboarding.softpos.mosambee.common;

import lombok.Data;

@Data
public class TgConfig {
	private String instrument;
    private String acquirerMosambee;
    private String tg;
    private String instrumentCode;
    private String terminalAuthType;
}
