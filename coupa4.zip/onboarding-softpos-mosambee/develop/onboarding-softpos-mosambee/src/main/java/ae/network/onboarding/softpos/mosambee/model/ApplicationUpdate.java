package ae.network.onboarding.softpos.mosambee.model;

import ae.network.onboarding.softpos.mosambee.rabbitmq.message.QueueMessage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Update message to queue (sent from consumers)
 *
 * @author 
 * @since 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationUpdate implements QueueMessage {
    private String applicationId;
    private BackendSystem backendSystem;
    private ProcessingResult processingResult;
    private AdditionalData additionalData;
}
