package ae.network.onboarding.softpos.mosambee.model.apirequest;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantRequestDto extends CommonRequest implements Serializable{

	private String mid ;
	private String instrument;
	private String acquirer; 
	private String tg; 
	private String instrumentCode;  
	
	private List<TerminalRequestDto> tidDetails;
}
