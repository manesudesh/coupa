package ae.network.onboarding.softpos.mosambee.model.payload;

import static ae.network.onboarding.softpos.mosambee.common.TextUtils.formatMcc;
import static ae.network.onboarding.softpos.mosambee.common.TextUtils.toAlphaNumeric;
import static ae.network.onboarding.softpos.mosambee.common.TextUtils.truncate;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Slf4j
public class Merchant {

    @JsonProperty("merchantName")
    private String merchantName;
    @JsonProperty("merchantId")
    private String merchantId;
    @JsonProperty("legalName")
    private String legalName;
    @JsonProperty("mcc")
    private String mcc;
    @JsonProperty("merchantCurrency")
    private String merchantCurrency;
    @JsonProperty("merchantType")
    private String merchantType;
    @JsonProperty("addresses")
    private List<Address> addresses;
    @JsonProperty("terminals")
    private List<Terminal> terminals;
    @JsonProperty("services")
    private List<MerchantService> services;
    private MerchantConfig configurations;
    
    private String subProductType;
	private List<AmendmentType> amendmentList;
    
    public String getTrimMerchantName() {
        return truncate(toAlphaNumeric(this.merchantName), 80);
    }

    public String getTrimLegalName() {
        return truncate(toAlphaNumeric(this.legalName), 80);
    }

    public String getFormatMcc() {
        try {
            return formatMcc(Integer.parseInt(this.mcc));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public List<Terminal> getSoftPosTerminals() {
    	if (terminals == null) {
			log.info("Merchant Id " + merchantId + " has No Terminals ");
			return new ArrayList<>();
		}
    	List<Terminal> terminalList =  terminals.stream().filter(Terminal::isSoftPos).collect(Collectors.toList());
    	if(terminalList == null || terminalList.isEmpty()) {
    		log.info("Merchant Id "+merchantId+"  has no terminals or might be terminal.maker is not Mosambee");
    	}
    	return terminalList;
    }

    public Optional<MosambeeService> getSoftPosService() {
		if (services == null) {
			log.info("Merchant Id " + merchantId + " has No Services ");
			return Optional.empty();
		}
    	Optional<MosambeeService> mosambeeServices =  services.stream().filter(MerchantService::isSoftPosMosambee).findAny().map(s -> (MosambeeService) s);
    	if(! mosambeeServices.isPresent()) {
    		log.info("Merchant Id "+merchantId+" has NOT SOFTPOS Services ");
    	}
    	return mosambeeServices;
    }

    public boolean isSoftPos() {
    	boolean posFlag = MerchantType.POS.name().equalsIgnoreCase(merchantType);
    	if(! posFlag) {
    		log.info("Merchant Id "+merchantId+" has merchant type "+merchantType+" is not considered "); 
    	}
        return posFlag && getSoftPosService().isPresent() && !getSoftPosTerminals().isEmpty();
    }
    
    public boolean isSubProductSupported() {
        boolean isValidSubProductType = "NG1_TAPTOPAY".equals(subProductType);
        if(! isValidSubProductType) {
        	log.info("subProductType of merchant {} is {} ",merchantId,subProductType);
        }
        return isValidSubProductType;
    }
    
    public boolean isAmendmentListEmpty() { 
    	boolean isAmendmentListEmpty = ( amendmentList == null 
    			||	amendmentList.stream().filter(a -> (a != null)).collect(Collectors.toList()).isEmpty() );
    	if(isAmendmentListEmpty)
    	{
    		log.info("Merchant {} Amendment Type List is Empty",merchantId);
    	}
    	return isAmendmentListEmpty;
	} 
}
