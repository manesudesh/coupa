package ae.network.onboarding.softpos.mosambee.model;

/**
 * @author 
 * @since 
 */
public enum Status {
	TERMINAL_FAIL("TERMINAL_FAIL"),
	MERCHANT_FAIL("MERCHANT_FAIL"),
	IN_PROGRESS("IN_PROGRESS"), 
	RETRY("RETRY"),
	RETRY_PROCESSED("RETRY_PROCESSED"),
	
	ONBOARDED_DONE("ONBOARDED_DONE"),
	MAX_RETRY("MAX_TRIED"),
	TYPE_TERMINAL("Terminal"),
	
	AMENDMENT_DONE("AMENDMENT_DONE"),
	CLOSURE_DONE("CLOSURE_DONE");
	
	private String value;
	
	Status(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
}
