package ae.network.onboarding.softpos.mosambee.rabbitmq.consumer.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ae.network.onboarding.softpos.mosambee.model.ApplicationRequest;
import ae.network.onboarding.softpos.mosambee.model.BackendSystem;
import ae.network.onboarding.softpos.mosambee.model.RequestType;
import ae.network.onboarding.softpos.mosambee.model.Task;
import ae.network.onboarding.softpos.mosambee.model.TaskName;
import ae.network.onboarding.softpos.mosambee.model.TaskStatus;
import ae.network.onboarding.softpos.mosambee.model.ValidationError;
import ae.network.onboarding.softpos.mosambee.model.payload.Merchant;
import ae.network.onboarding.softpos.mosambee.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.softpos.mosambee.rabbitmq.consumer.AbstractConsumer;
import ae.network.onboarding.softpos.mosambee.rabbitmq.service.RabbitService;
import ae.network.onboarding.softpos.mosambee.rabbitmq.service.exchange.AmendmentService;
import ae.network.onboarding.softpos.mosambee.rabbitmq.service.exchange.ClosureService;
import ae.network.onboarding.softpos.mosambee.rabbitmq.service.exchange.SoftPosMosambeeService;
import ae.network.onboarding.softpos.mosambee.validation.AmendmentPayloadValidator;
import ae.network.onboarding.softpos.mosambee.validation.ClosurePayloadValidator;
import ae.network.onboarding.softpos.mosambee.validation.PayloadValidator;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SoftPosMosambeeConsumer extends AbstractConsumer {
    
	@Autowired
    private final SoftPosMosambeeService mosambeeService;
	
	@Autowired
    private final PayloadValidator payloadValidator;
//	@Autowired
    private final AmendmentPayloadValidator amendmentPayloadValidator;
	@Autowired
    private final AmendmentService amendmentService;
	@Autowired
    private final ClosurePayloadValidator closurePayloadValidator;
	@Autowired
    private final ClosureService closureService;
	
    SoftPosMosambeeConsumer(RabbitService rabbitService, SoftPosMosambeeService mosambeeService, PayloadValidator payloadValidator,
    		AmendmentService amendmentService, AmendmentPayloadValidator amendmentPayloadValidator,
    		ClosureService closureService, ClosurePayloadValidator closurePayloadValidator) {
        super(RabbitQueue.SOFTPOS_MOSAMBEE, rabbitService);
		this.mosambeeService = mosambeeService;
		this.payloadValidator = payloadValidator;
		this.amendmentService = amendmentService;
		this.amendmentPayloadValidator = amendmentPayloadValidator;
		this.closureService = closureService;
		this.closurePayloadValidator = closurePayloadValidator;
    }

    @Override
    public Optional<Collection<ValidationError>> validateApplication(ApplicationRequest applicationRequest) {
    	Collection<ValidationError> validationErrors = new ArrayList<>();
        if (applicationRequest.getRequestType() == RequestType.ONBOARDING) {
        	validationErrors.addAll(payloadValidator.validateApplication(applicationRequest));
            for (Merchant merchant : applicationRequest.getSoftPosMerchants()) {
            	validationErrors.addAll(payloadValidator.validateMerchant(merchant));
            }
        }else if (applicationRequest.getRequestType() == RequestType.AMENDMENT) {
            for (Merchant merchant : applicationRequest.getSoftPosMerchants()) {
            	validationErrors.addAll(amendmentPayloadValidator.validateMerchant(merchant));
            }
        }else if (applicationRequest.getRequestType() == RequestType.MERCHANT_CLOSURE) {
            for (Merchant merchant : applicationRequest.getSoftPosMerchants()) {
            	validationErrors.addAll(closurePayloadValidator.validateMerchant(merchant));
            }
        }
        
        if (validationErrors.isEmpty()) {
        	log.info("validation passed for this request");
        	handleValidationTask(applicationRequest,TaskName.VALIDATION, TaskStatus.COMPLETED, validationErrors);
        	return Optional.empty();
        }
        else {
	        log.info("validation errors found for this request "+validationErrors);
	        handleValidationTask(applicationRequest, TaskName.VALIDATION, TaskStatus.FAILED, validationErrors);
	        mosambeeService.saveAppReqDb(applicationRequest);
	        return Optional.of(validationErrors);
        }
    }

    private synchronized void handleValidationTask(ApplicationRequest applicationRequest, TaskName taskName, TaskStatus status, Collection<ValidationError> validationErrors ) {
        log.warn("Constructing update for application {}", applicationRequest.getApplicationId());
        Task task = null;
        
        if( status == TaskStatus.COMPLETED)
        {
        	task = mosambeeService.assignTaskhistoryToTask(taskName, status, "validationResult success","OK");
        }else {
        	task = mosambeeService.assignValidationErrorTaskHistory(validationErrors, taskName, status);
        }
        applicationRequest.getTasks().add(task);
        log.info("Task "+taskName+" staus "+status);
    }

    @Override
    public void processApplication(ApplicationRequest applicationRequest) {
    	if(applicationRequest.getRequestType() == RequestType.ONBOARDING)  {
    		mosambeeService.processMerchant(applicationRequest);
    	}else if(applicationRequest.getRequestType() == RequestType.AMENDMENT)  {
    		amendmentService.processAmendmentMerchant(applicationRequest);
    	}else if(applicationRequest.getRequestType() == RequestType.MERCHANT_CLOSURE)  {
    		closureService.processClosureMerchant(applicationRequest);
    	}
    	
    }

    @Override
    public BackendSystem getBackendSystem() {
        return BackendSystem.SOFTPOS_MOSAMBEE;
    }

    @Override
    public boolean isRequestSupported(ApplicationRequest applicationRequest) {
        return !applicationRequest.getSoftPosMerchants().isEmpty();
    }
    
    
}
