package ae.network.onboarding.softpos.mosambee.rabbitmq.message;

import java.io.Serializable;

/**
 * @author 
 * @since 
 * Marker interface for message sent to rabbit queues
 */
public interface QueueMessage extends Serializable {
    String MAX_RETRY_HEADER = "max_retry";
    String DELAY_HEADER = "retry_delay_seconds";

    String getApplicationId();
}
