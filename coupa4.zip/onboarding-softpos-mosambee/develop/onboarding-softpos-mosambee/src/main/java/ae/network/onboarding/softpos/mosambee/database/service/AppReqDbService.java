package ae.network.onboarding.softpos.mosambee.database.service;

import java.util.List;

import org.springframework.stereotype.Service;

import ae.network.onboarding.softpos.mosambee.database.repository.MosambeeApplicationRequestRepository;
import ae.network.onboarding.softpos.mosambee.model.ApplicationRequest;
import lombok.AllArgsConstructor;

/**
 * @author 
 */
@Service("AppReqDbService")
@AllArgsConstructor
public class AppReqDbService {

    /**
     * Injection of Repository object
     */
    private final MosambeeApplicationRequestRepository repository;

    /**
     * Persist ApplicationRequest document to the
     * database
     *
     * @param ApplicationRequest
     * @return
     */
    public synchronized ApplicationRequest save(ApplicationRequest appReq) {
        return repository.save(appReq);
    }
    
    public synchronized List<ApplicationRequest> findRetryRecords(String appRetryStatus, int retryCount, String retryType, String terminalRetryStatus) {
        return repository.findApplicationsByRetryStatusAndRetryCount( appRetryStatus, retryCount, retryType, terminalRetryStatus  );
    }

    public List<ApplicationRequest> findApplicationsByMerchantAndStatusAndTerminalStatus(String merchantId, String merchantStatus, String terminalStatus) {
        return repository.findApplicationsByMerchantAndStatusAndTerminalStatus( merchantId, merchantStatus, terminalStatus );
    }
}
