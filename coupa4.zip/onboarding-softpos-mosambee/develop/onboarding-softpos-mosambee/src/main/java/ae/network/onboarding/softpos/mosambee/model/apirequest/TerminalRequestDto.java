package ae.network.onboarding.softpos.mosambee.model.apirequest;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TerminalRequestDto extends CommonRequest implements Serializable{

	private String tid;
	private String userName; 
	private String tidType; 
	private String storeName; 
	private String terminalLocation;
	private String posTerminalSupported; 
	private String devicePairFlag; 
	private String terminalAuthType;
	private String terminalKeyValue;
	private String terminalSpocName;
	private String terminalContactNo;
	private String terminalEmail;
}
