package ae.network.onboarding.softpos.mosambee.validation;

import static org.springframework.util.StringUtils.isEmpty;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.stereotype.Service;

import ae.network.onboarding.softpos.mosambee.model.ValidationError;
import ae.network.onboarding.softpos.mosambee.model.payload.Merchant;

/**
 * @author 
 * @since 
 */
@Service
public class AmendmentPayloadValidator {

    public Collection<ValidationError> validateMerchant(Merchant merchant) {
        List<ValidationError> errors = new ArrayList<>();
        if (merchant == null) {
            errors.add(ValidationError.EMPTY_PAYLOAD);
            return errors;
        }

        if (isEmpty(merchant.getMerchantId())) {
            errors.add(ValidationError.EMPTY_MERCHANT_IDENTIFIER);
        }
        return errors;
    }
}
