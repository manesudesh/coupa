package ae.network.onboarding.softpos.mosambee.model.payload;

public enum AmendmentType {
    MERCHANT_NAME,
    LEGAL_NAME,
    MCC,
    ADDRESS,
    ADDING_TERMINALS
}
