package ae.network.onboarding.softpos.mosambee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * @author 
 * @since 
 */
@SpringBootApplication
@EnableScheduling
public class OnboardingSoftPosMosambeeApplication {

    public static void main(String[] args) {
        SpringApplication.run(OnboardingSoftPosMosambeeApplication.class, args);
    }
}
