package ae.network.onboarding.softpos.mosambee.rabbitmq.config;

import java.util.Arrays;
import java.util.List;

/**
 * @author 
 * @since 
 */
public enum RabbitQueue {
    // Working Queue
	SOFTPOS_MOSAMBEE("softpos_mosambee", "routing.backend.softpos_mosambee"),
//	SOFTPOS("softpos", "routing.backend.softpos"),
    // RPC Queues
    UTILS("utils", "routing.utils"),
    // Reply Queue
    UPDATES("updates", "routing.updates");

    private final String queueName;
    private final String[] routingKeys;

    RabbitQueue(String queueName, String... routingKeys) {
        this.queueName = queueName;
        this.routingKeys = routingKeys;
    }

    public String getQueueName() {
        return queueName;
    }

    public List<String> getRoutingKeys() {
        return Arrays.asList(routingKeys);
    }
}
