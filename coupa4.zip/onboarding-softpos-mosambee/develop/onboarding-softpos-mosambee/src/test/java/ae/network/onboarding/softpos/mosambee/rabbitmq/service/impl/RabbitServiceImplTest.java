package ae.network.onboarding.softpos.mosambee.rabbitmq.service.impl;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Date;

import org.jasypt.encryption.pbe.PBEStringCleanablePasswordEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.jasypt.util.password.BasicPasswordEncryptor;
import org.jasypt.util.text.StrongTextEncryptor;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.env.Environment;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

import ae.network.onboarding.softpos.mosambee.DummyRabbit;
import ae.network.onboarding.softpos.mosambee.model.AdditionalData;
import ae.network.onboarding.softpos.mosambee.model.ApplicationUpdate;
import ae.network.onboarding.softpos.mosambee.model.BackendSystem;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.APIResponseDto;
import ae.network.onboarding.softpos.mosambee.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.softpos.mosambee.rabbitmq.message.QueueMessage;
import ae.network.onboarding.softpos.mosambee.rabbitmq.processors.CorrelationDataProcessor;
import ae.network.onboarding.softpos.mosambee.rabbitmq.processors.MaxRetryProcessor;

@SpringBootTest
@Configuration
@EnableEncryptableProperties
@Import({DummyRabbit.class})
class RabbitServiceImplTest {


	//@InjectMocks
	RabbitServiceImpl rabbitServiceImpl;
    @MockBean
    private RabbitTemplate rabbitTemplate;
    @InjectMocks
    CorrelationDataProcessor correlationDataProcessor;
    
    @Test
    void retryMessage()  {
    	rabbitServiceImpl = new RabbitServiceImpl(rabbitTemplate, 10);
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setMessageId("123456");
    	msgProperties.setReceivedRoutingKey("routing.backend.softpos");
    	Message msg = new Message(null, msgProperties);
    	rabbitServiceImpl.retryMessage(msg);
    	Assertions.assertNotNull(msg.getMessageProperties().getMessageId());
    }
    
    @Test
    void postProcessMessage()  {
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.softpos");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	Message msg = new Message(null, msgProperties);
    	correlationDataProcessor = new CorrelationDataProcessor(rabbitTemplate, null);
    	Message retMessage = correlationDataProcessor.postProcessMessage(msg);
    	Assertions.assertNotNull(retMessage);
    }
    
    @Test
    void postProcessMessageNull()  {
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.softpos");
    	msgProperties.setAppId("AppId");
    	msgProperties.setContentType(null);
    	Message msg = new Message(null, msgProperties);
    	correlationDataProcessor = new CorrelationDataProcessor(rabbitTemplate, null);
    	Message retMessage = correlationDataProcessor.postProcessMessage(msg);
    	Assertions.assertNotNull(retMessage);
    }
    
    @Test
    void retryMessageDelay()  {
    	rabbitServiceImpl = new RabbitServiceImpl(rabbitTemplate, 10);
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setMessageId("123456");
    	msgProperties.setReceivedRoutingKey("routing.backend.softpos");
    	Message msg = new Message(null, msgProperties);
    	rabbitServiceImpl.retryMessage(msg, 1000);
    	Assertions.assertNotNull(msg.getMessageProperties().getMessageId());
    }

    @Test
    void sendMessage()  {
    	rabbitServiceImpl = new RabbitServiceImpl(rabbitTemplate, 10);
    	AdditionalData addData = new AdditionalData();
    	addData.setDataMap("response", APIResponseDto.builder().merchantRefNo("refernce number").message("Profile created").result("Succesful"));
    	ApplicationUpdate appUpdate = ApplicationUpdate.builder().applicationId("123456").backendSystem(BackendSystem.SOFTPOS_MOSAMBEE).additionalData(addData).build();
    	rabbitServiceImpl.sendMessage(RabbitQueue.SOFTPOS_MOSAMBEE, appUpdate);
    	Assertions.assertNotNull(appUpdate.getApplicationId());
    }

    @Test
    void testLogMessage() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException  {
    	rabbitServiceImpl = new RabbitServiceImpl(rabbitTemplate, 10);
    	Method method = rabbitServiceImpl.getClass().getDeclaredMethod("logQueueMessage", RabbitQueue.class, QueueMessage.class);
		method.setAccessible(true);
		ApplicationUpdate appUpdate = ApplicationUpdate.builder().applicationId("123456").backendSystem(BackendSystem.SOFTPOS_MOSAMBEE).build();
		method.invoke(rabbitServiceImpl, RabbitQueue.SOFTPOS_MOSAMBEE, appUpdate);
    	Assertions.assertNotNull(appUpdate.getApplicationId());
    }
    
    @Test
    void testDefaultRoutingKeyEmpty() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException  {
    	rabbitServiceImpl = new RabbitServiceImpl(rabbitTemplate, 10);
    	Method method = rabbitServiceImpl.getClass().getDeclaredMethod("getDefaultRoutingKey", RabbitQueue.class);
		method.setAccessible(true);
		
		RabbitQueue rabitQueue = RabbitQueue.UTILS;
		
		Field f = RabbitQueue.class.getDeclaredField("routingKeys");
        f.setAccessible(true);            
        f.set(rabitQueue, new String [] {});
        Assertions.assertThrows(InvocationTargetException.class, () -> {
        	method.invoke(rabbitServiceImpl, rabitQueue);
        }, "Invalid destination");
    }
    
    @Test
    void maxRetryPostMessageRetry()  {
    	MaxRetryProcessor maxRetry = new MaxRetryProcessor(rabbitTemplate, 6, 10);
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.softpos");
    	Message msg = new Message(null, msgProperties);
    	msgProperties.setHeader(QueueMessage.MAX_RETRY_HEADER, "5");
    	Message retMessage = maxRetry.postProcessMessage(msg);
    	Assertions.assertSame(retMessage.getMessageProperties().getHeader(QueueMessage.MAX_RETRY_HEADER),4);    
    }
    
    @Test
    void maxRetryPostMessageDelay()  {
    	MaxRetryProcessor maxRetry = new MaxRetryProcessor(rabbitTemplate, 6, 10);
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.softpos");
    	Message msg = new Message(null, msgProperties);
    	msgProperties.setHeader(QueueMessage.DELAY_HEADER, "5");
    	Message retMessage = maxRetry.postProcessMessage(msg);
    	Assertions.assertSame(retMessage.getMessageProperties().getHeader(QueueMessage.DELAY_HEADER),25);
    }
    
    @Test
    void maxRetryPostMessageNull()  {
    	MaxRetryProcessor maxRetry = new MaxRetryProcessor(rabbitTemplate, 6, 10);
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.softpos");
    	Message msg = new Message(null, msgProperties);
    	Message retMessage = maxRetry.postProcessMessage(msg);
    	Assertions.assertNotNull(retMessage);
    }
    
    @Test
    void maxRetryAsNumber() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException  {
    	MaxRetryProcessor maxRetry = new MaxRetryProcessor(rabbitTemplate, 6, 10);
    	Method method = maxRetry.getClass().getDeclaredMethod("asNumber", Object.class);
		method.setAccessible(true);
		method.invoke(maxRetry, "3"  );
    }
    
    @Test
    void maxRetryAsNumberException() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException  {
    	MaxRetryProcessor maxRetry = new MaxRetryProcessor(rabbitTemplate, 6, 10);
    	Method method = maxRetry.getClass().getDeclaredMethod("asNumber", Object.class);
		method.setAccessible(true);
		Integer zero =	(Integer)method.invoke(maxRetry, "B"  );
		Assertions.assertEquals(zero, 0);
		
    }
}
