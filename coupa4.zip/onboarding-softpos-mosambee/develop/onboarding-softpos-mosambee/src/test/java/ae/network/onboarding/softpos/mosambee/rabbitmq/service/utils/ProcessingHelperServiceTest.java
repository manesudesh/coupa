package ae.network.onboarding.softpos.mosambee.rabbitmq.service.utils;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.util.Assert;

import ae.network.onboarding.softpos.mosambee.common.AppConfig;
import ae.network.onboarding.softpos.mosambee.model.ApplicationRequest;
import ae.network.onboarding.softpos.mosambee.model.ApplicationUpdate;
import ae.network.onboarding.softpos.mosambee.model.BackendSystem;
import ae.network.onboarding.softpos.mosambee.model.ProcessingResult;
import ae.network.onboarding.softpos.mosambee.model.Status;
import ae.network.onboarding.softpos.mosambee.model.Task;
import ae.network.onboarding.softpos.mosambee.model.TaskHistory;
import ae.network.onboarding.softpos.mosambee.model.TaskName;
import ae.network.onboarding.softpos.mosambee.model.TaskStatus;
import ae.network.onboarding.softpos.mosambee.model.apirequest.MerchantRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apirequest.TerminalRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.MerchantResponseDto;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.TerminalResponseDto;
import ae.network.onboarding.softpos.mosambee.rabbitmq.service.RabbitService;
import ae.network.onboarding.softpos.mosambee.service.utils.ProcessingHelper;
import lombok.extern.slf4j.Slf4j;

/**
 * @author 
 */
@SpringBootTest
@Slf4j
public class ProcessingHelperServiceTest {

    
    
	
    /**
     * Injection of Rabbit Service to update the
     * queue
     */
	@MockBean
    private RabbitService rabbitService;
    
	@Autowired
    private AppConfig appConfig;
	
	@Autowired
    private ProcessingHelper processingHelper;
	
	
	@Test
	void testCreateApplicationUpdate()
	{
		ApplicationUpdate appUpdate = processingHelper.createApplicationUpdate("appId00112233", BackendSystem.SOFTPOS_MOSAMBEE, ProcessingResult.builder().finalStatus(TaskStatus.COMPLETED).build());
		Assert.notNull(appUpdate);
	}
	
	@Test
	void testCalculateFinalStatus()
	{
		ApplicationRequest entity = new ApplicationRequest();
		Collection <Task> tasks = new ArrayList<>();
		Task task1 = new Task(null,TaskName.SEND_APP_REQUEST.name(), "", TaskStatus.COMPLETED, new ArrayList<TaskHistory>());
		Task task2 = new Task(null,TaskName.RECEIVE_APP_RESPONSE.name(), "", TaskStatus.COMPLETED, new ArrayList<TaskHistory>());
		Task task3 = new Task(null,TaskName.ONBOARDING_MERCHANT.name(), "", TaskStatus.COMPLETED, new ArrayList<TaskHistory>());
		tasks.add(task1); tasks.add(task2);	tasks.add(task3);
		entity.setTasks(tasks);
		TaskStatus taskResult = processingHelper.calculateFinalStatus(entity);
		Assert.isTrue(taskResult.equals(TaskStatus.COMPLETED));
		
		task2.setTaskStatus(TaskStatus.FAILED);
		taskResult = processingHelper.calculateFinalStatus(entity);
		Assert.isTrue(taskResult.equals(TaskStatus.PARTIALLY_COMPLETED));
		
		task1.setTaskStatus(TaskStatus.FAILED); task3.setTaskStatus(TaskStatus.FAILED);
		taskResult = processingHelper.calculateFinalStatus(entity);
		Assert.isTrue(taskResult.equals(TaskStatus.FAILED));
		
	}
	
	@Test
	void handleTerminalSuccessResponseTest() {
		MerchantRequestDto merchantReqDto =  MerchantRequestDto.builder()
				.mid("4321567")
				.tidDetails(Arrays.asList(
							new TerminalRequestDto[]{
								TerminalRequestDto.builder().tid("12345").build(),
								TerminalRequestDto.builder().tid("23456").build()
								})	)
				.build(); 
		
		TerminalResponseDto terminalResponseDto1 = new TerminalResponseDto();
		terminalResponseDto1.setTerminalId("12345"); terminalResponseDto1.setTidRefId("12345"); terminalResponseDto1.setResult("success");
		TerminalResponseDto terminalResponseDto2 = new TerminalResponseDto();
		terminalResponseDto2.setTerminalId("23456"); terminalResponseDto2.setTidRefId("23456"); terminalResponseDto2.setResult("success");
		
		MerchantResponseDto merchantResponseObj = MerchantResponseDto.builder()
				.result("success")
				.tidDetails(Arrays.asList(new TerminalResponseDto [] {terminalResponseDto1, terminalResponseDto2}))
				.build();
		
		List<Status> allRetryStatusList = new ArrayList<>();
		processingHelper.handleTerminalResponse(null, merchantReqDto, merchantResponseObj, allRetryStatusList);
	}
	
	@Test
	void handleTerminalPartialResponseTest() {
		MerchantRequestDto merchantReqDto =  MerchantRequestDto.builder()
				.mid("4321567")
				.tidDetails(Arrays.asList(
							new TerminalRequestDto[]{
								TerminalRequestDto.builder().tid("12345").build(),
								TerminalRequestDto.builder().tid("23456").build()
								})	)
				.build(); 
		
		TerminalResponseDto terminalResponseDto2 = new TerminalResponseDto();
		terminalResponseDto2.setTerminalId("23456"); terminalResponseDto2.setTidRefId("23456"); terminalResponseDto2.setResult("success");
		
		MerchantResponseDto merchantResponseObj = MerchantResponseDto.builder()
				.result("success")
				.tidDetails(Arrays.asList(new TerminalResponseDto [] { terminalResponseDto2}))
				.build();
				
		List<Status> allRetryStatusList = new ArrayList<>();
		processingHelper.handleTerminalResponse(null, merchantReqDto, merchantResponseObj, allRetryStatusList);
	}
	
	@Test
	void handleTerminalEmptyResponseTest() {
		MerchantRequestDto merchantReqDto =  MerchantRequestDto.builder()
				.mid("4321567")
				.tidDetails(Arrays.asList(
							new TerminalRequestDto[]{
								TerminalRequestDto.builder().tid("12345").build(),
								TerminalRequestDto.builder().tid("23456").build()
								})	)
				.build(); 
		
		MerchantResponseDto merchantResponseObj = MerchantResponseDto.builder()
				.build();
				
		List<Status> allRetryStatusList = new ArrayList<>();
		processingHelper.handleTerminalResponse(null, merchantReqDto, merchantResponseObj, allRetryStatusList);
	}
	
	@Test
	void handleTerminalNonSuccessResponseTest() {
		MerchantRequestDto merchantReqDto =  MerchantRequestDto.builder()
				.mid("4321567")
				.tidDetails(Arrays.asList(
							new TerminalRequestDto[]{
								TerminalRequestDto.builder().tid("12345").build(),
								TerminalRequestDto.builder().tid("23456").build()
								})	)
				.build(); 
		
		TerminalResponseDto terminalResponseDto1 = new TerminalResponseDto();
		
		MerchantResponseDto merchantResponseObj = MerchantResponseDto.builder()
				.tidDetails(Arrays.asList(new TerminalResponseDto [] {terminalResponseDto1}))
				.build();
				
		List<Status> allRetryStatusList = new ArrayList<>();
		processingHelper.handleTerminalResponse(null, merchantReqDto, merchantResponseObj, allRetryStatusList);
	}
	    
}
