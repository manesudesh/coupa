package ae.network.onboarding.softpos.mosambee.model.payload;

import java.util.Arrays;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import ae.network.onboarding.softpos.mosambee.common.APIConstant;
import ae.network.onboarding.softpos.mosambee.exception.AcquierNotFoundException;
import ae.network.onboarding.softpos.mosambee.exception.BusinessException;
import ae.network.onboarding.softpos.mosambee.exception.MaxRetryReachedException;
import ae.network.onboarding.softpos.mosambee.exception.MessageCancelledException;
import ae.network.onboarding.softpos.mosambee.exception.MessageRejectionException;
import ae.network.onboarding.softpos.mosambee.model.APIDto;
import ae.network.onboarding.softpos.mosambee.model.Acquirer;
import ae.network.onboarding.softpos.mosambee.model.AdditionalData;
import ae.network.onboarding.softpos.mosambee.model.ApplicationRequest;
import ae.network.onboarding.softpos.mosambee.model.ApplicationUpdate;
import ae.network.onboarding.softpos.mosambee.model.BackendSystem;
import ae.network.onboarding.softpos.mosambee.model.ProcessingResult;
import ae.network.onboarding.softpos.mosambee.model.Task;
import ae.network.onboarding.softpos.mosambee.model.TaskHistory;
import ae.network.onboarding.softpos.mosambee.model.TaskStatus;
import ae.network.onboarding.softpos.mosambee.model.ValidationError;
import ae.network.onboarding.softpos.mosambee.model.apirequest.APIRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apirequest.EncryptPayload;
import ae.network.onboarding.softpos.mosambee.model.apirequest.MerchantRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apirequest.TerminalRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.APIResponseDto;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.APIResponseDto.APIResponseDtoBuilder;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.CommonResponse;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.MerchantResponseDto;
import ae.network.onboarding.softpos.mosambee.model.apiresponse.TerminalResponseDto;

class PayloadModelTest {

	@Test
    void testfieldsPayloadApplication()  {
        ApplicationRequest appRequest = new ApplicationRequest();
        appRequest.setAcquirer("NI");
        appRequest.setApplicationId("1234");
        Payload payload = new Payload();
        Application app = new Application();
        Address address = new Address();
        address.setAddressLines(Arrays.asList("addLine")); address.setAddressType("PAYM_ADDR");
        address.setCity("city");  
        address.setState("state");
        address.getAddressLines(); address.getAddressType(); address.getCity(); address.getClass(); address.getState();
        address.equals(address);address.toString();address.hashCode();
        
        Terminal terminal = new Terminal();
        terminal.setTerminalId("4545"); terminal.setTerminalModel("terminalModel"); 
        terminal.setMaker(null);terminal.setProcessed(false);terminal.setResponse(null);terminal.setSuccess(false);
        terminal.equals(terminal);terminal.toString();terminal.hashCode();
        terminal.getClass(); terminal.getMaker(); 
        terminal.getTerminalId();terminal.getTerminalModel();
        terminal.getMaker();terminal.getResponse();terminal.getResponse();terminal.isProcessed();terminal.isSoftPos();terminal.isSuccess();
        
        Merchant merchant = new Merchant();
        merchant.setMerchantId("1234");
        merchant.setMerchantName("merchantName");
        merchant.setLegalName("merchantLegalName");
        merchant.setMerchantType("ECOM");
        merchant.setMcc("9084");
        MerchantConfig merchantConfigration = MerchantConfig.builder().softPosAuthSystem("BASE24").build();
        merchant.setConfigurations(merchantConfigration);
        merchant.setMerchantCurrency("EUR");
        merchant.setTerminals(Arrays.asList(terminal));
        MerchantService service = new MerchantService();
        service.setServiceType("softpos");
        merchant.setServices(Arrays.asList(service));
        merchant.setAddresses(Arrays.asList(address));
        
        merchant.getAddresses();merchant.getMcc();merchant.getFormatMcc(); merchant.getLegalName();merchant.getMerchantCurrency();
        merchant.getMerchantId();merchant.getMerchantName();merchant.getMerchantType();merchant.getServices();
        merchant.isSoftPos(); merchant.equals(merchant);merchant.toString();merchant.hashCode();
        
        Application app2 =  new Application(); 
        app2.setMerchants(Arrays.asList(merchant));
        app2.equals(app2);app2.toString();app2.hashCode(); app2.getMerchants();
        payload.setApplications(Arrays.asList(app));
        
        appRequest.setCreatedDate(new Date()); appRequest.setLastModifiedDate(new Date());
        appRequest.getCreatedDate(); appRequest.getLastModifiedDate();
        
        appRequest.setPayload(payload);
        Assertions.assertNotNull(appRequest.getPayload().getApplications());
    }
	 
	@Test
    void testApplicationUpdate()  {
		TaskHistory taskHistory = TaskHistory.builder().taskStatus(TaskStatus.COMPLETED).statusCode("OK").response("Task history created").createdDate(new Date()).lastModifiedDate(new Date()).build();
        taskHistory.setTaskStatus(TaskStatus.COMPLETED); taskHistory.setStatusCode("OK"); taskHistory.setResponse("Task history created"); taskHistory.setCreatedDate(new Date()); taskHistory.setLastModifiedDate(new Date());
        taskHistory.getTaskStatus(); taskHistory.getStatusCode(); taskHistory.getResponse(); taskHistory.getCreatedDate(); taskHistory.getLastModifiedDate();
        taskHistory.equals(taskHistory); taskHistory.toString();  taskHistory.hashCode();
        
        Task task = Task.builder().id(1234l).name("Validation").taskStatus(TaskStatus.COMPLETED).taskHistory(Arrays.asList(taskHistory)).entityId("entity id").build();
        task.setId(1234l); task.setName("Validation");task.setTaskStatus(TaskStatus.COMPLETED); task.setTaskHistory(Arrays.asList(taskHistory)); task.setEntityId("entity id"); 
        task.getId(); task.getEntityId(); task.getName(); task.getTaskHistory(); task.getTaskStatus();
        task.equals(task); task.toString();  task.hashCode();
        
        ProcessingResult processingResult = ProcessingResult.builder().tasks(Arrays.asList(task)).finalStatus(TaskStatus.COMPLETED).build();
        processingResult.setTasks(Arrays.asList(task));processingResult.setFinalStatus(TaskStatus.COMPLETED);
        processingResult.getTasks();processingResult.getFinalStatus();
        processingResult.equals(processingResult);processingResult.toString(); processingResult.hashCode();
        
        AdditionalData additionalData = new AdditionalData(); 
        additionalData.setDataMap("add", "additionalData"); additionalData.getDataMap();
        additionalData.equals(additionalData);additionalData.toString(); additionalData.hashCode();
        
        ValidationError validationError = ValidationError.EMPTY_LEGAL_NAME;
        validationError.getFieldName();validationError.getErrorCode(); validationError.getErrorMessage();
        ApplicationUpdate applicationUpdate = ApplicationUpdate.builder().applicationId("123456").backendSystem(BackendSystem.SOFTPOS_MOSAMBEE).processingResult(processingResult).additionalData(additionalData).build();
        applicationUpdate.setApplicationId("123456"); applicationUpdate.setBackendSystem(BackendSystem.SOFTPOS_MOSAMBEE); applicationUpdate.setProcessingResult(processingResult); applicationUpdate.setAdditionalData(additionalData);
        applicationUpdate.getApplicationId(); applicationUpdate.getBackendSystem(); applicationUpdate.getBackendSystem();applicationUpdate.getProcessingResult();
        applicationUpdate.equals(applicationUpdate); applicationUpdate.toString();  applicationUpdate.hashCode();
        Assertions.assertNotNull(applicationUpdate.getBackendSystem());
	}
	
	@Test
    void testAddressPayloadApplication()  {
		Address address = new Address();
        address.setAddressLines(Arrays.asList("addLine")); address.setAddressType("PAYM_ADDR");
        address.setCity("city");  
        address.setState("state");
        address.getAddressLines(); address.getAddressType(); address.getCity(); address.getClass(); address.getState();
        address.equals(address);address.toString();address.hashCode();
        Assertions.assertNotNull(address.getCity());
	}
	
	@Test
    void testAcquirerPayloadApplication()  {
		Acquirer acquirer = new Acquirer();
		acquirer.setId("NI"); acquirer.setName("NI");
		acquirer.equals(acquirer);acquirer.toString();acquirer.hashCode();
		Assertions.assertNotNull(acquirer.getName());
	}
	
	
	@Test
    void testExceptions() throws InstantiationException, IllegalAccessException  {
    	MessageRejectionException messageRejectionException = new MessageRejectionException("1234", "Message Reject");
        messageRejectionException = new MessageRejectionException("1234", "Message Reject", new Throwable());
        messageRejectionException.getMessage();
        BusinessException businessException = new BusinessException("1234", Exception.class.newInstance());
        businessException.getMessage();
        AcquierNotFoundException acquierNotFoundException = new AcquierNotFoundException("12341312312");
        acquierNotFoundException.getMessage();
        MaxRetryReachedException maxRetryReachedException = new MaxRetryReachedException("4532512312131");
        maxRetryReachedException.getMessage();
        MessageCancelledException messageCancelledException = new MessageCancelledException("78890811242");
        Assertions.assertNotNull(messageCancelledException.getMessage());
	}
	
	@Test
	void testAPIReqDto()
	{
		TerminalRequestDto terminalRequestDto = TerminalRequestDto.builder().devicePairFlag(null).posTerminalSupported(null).storeName(null)
				.storeName(null).terminalAuthType(null).terminalContactNo(null).terminalEmail(null).tid(null).terminalKeyValue(null).terminalLocation(null)
				.terminalSpocName(null).tidType(null).userName(null).build(); TerminalRequestDto.builder().toString(); 
				TerminalRequestDto.class.equals(TerminalRequestDto.builder().getClass()); terminalRequestDto.getClass();
				terminalRequestDto.setDevicePairFlag(APIConstant.devicePairFlag); terminalRequestDto.setPosTerminalSupported("modal"); terminalRequestDto.setStoreName("storename");terminalRequestDto.setTerminalAuthType(APIConstant.terminalAuthType_NONE);
		terminalRequestDto.setTerminalContactNo("88800888"); terminalRequestDto.setTerminalEmail("abc@email.com"); terminalRequestDto.setTid("1234"); terminalRequestDto.setTerminalKeyValue(null);
		terminalRequestDto.setTerminalLocation("Dubai"); terminalRequestDto.setTerminalSpocName(null); terminalRequestDto.setTidType(APIConstant.tidType_both);
		terminalRequestDto.setUserName(null); 
		terminalRequestDto.getDevicePairFlag(); terminalRequestDto.getPosTerminalSupported(); terminalRequestDto.getStoreName();terminalRequestDto.getTerminalAuthType();
		terminalRequestDto.getTerminalContactNo(); terminalRequestDto.getTerminalEmail(); terminalRequestDto.getTid(); terminalRequestDto.getTerminalKeyValue();
		terminalRequestDto.getTerminalLocation(); terminalRequestDto.getTerminalSpocName(); terminalRequestDto.getTerminalSpocName(); terminalRequestDto.getTidType();
		terminalRequestDto.getUserName();
		terminalRequestDto.equals(terminalRequestDto); terminalRequestDto.toString(); terminalRequestDto.hashCode();
		MerchantRequestDto merchantRequestDto = MerchantRequestDto.builder().acquirer(null).instrument(null).mid(null).tg(null)
				.tidDetails(Arrays.asList(terminalRequestDto)).build(); MerchantRequestDto.builder().toString();
				merchantRequestDto.setAcquirer("NI");merchantRequestDto.setInstrument("card");
				merchantRequestDto.setMid("1234"); merchantRequestDto.setTg("NIACQ"); merchantRequestDto.getClass();
				merchantRequestDto.getAcquirer();merchantRequestDto.getInstrument();merchantRequestDto.getMid(); merchantRequestDto.getTg();
				merchantRequestDto.getTidDetails(); merchantRequestDto.equals(merchantRequestDto); merchantRequestDto.toString();merchantRequestDto.hashCode();
		EncryptPayload encrPayload = EncryptPayload.builder().clientId(null).encRequestMsg(null).build(); EncryptPayload.builder().toString();
		encrPayload.setClientId("1234");encrPayload.setEncRequestMsg("sfsfwefr"); encrPayload.getClientId(); encrPayload.getClass();
		encrPayload.getEncRequestMsg(); encrPayload.equals(encrPayload); encrPayload.toString();encrPayload.hashCode();
		APIRequestDto postAPIRequest = APIRequestDto.builder().merchantAddress(null).mccCode(null).city(null).mobileNumber(null)
				.merchantDba(null).businessEmail(null).businessEmail(null).merchantName(null).businessPin(null)
				.spocName(null).state(null).midRequest(merchantRequestDto).build(); APIRequestDto.builder().toString();
		postAPIRequest.setMerchantAddress("Dubai");postAPIRequest.setMccCode("Default");postAPIRequest.setCity("Dubai");postAPIRequest.setMobileNumber("8880808");		
		postAPIRequest.setMerchantDba("Merchant dba Name"); postAPIRequest.setBusinessEmail("abc@email.com"); postAPIRequest.setMerchantName("Merchant Name"); postAPIRequest.setBusinessPin("444888");
		postAPIRequest.setSpocName(null);postAPIRequest.setState("state"); postAPIRequest.setMidRequest(merchantRequestDto);
		postAPIRequest.getMerchantAddress();postAPIRequest.getMccCode();postAPIRequest.getCity();postAPIRequest.getMccCode();postAPIRequest.getMerchantDba();
		postAPIRequest.getBusinessEmail();postAPIRequest.getMerchantName();postAPIRequest.getBusinessPin();postAPIRequest.getSpocName();postAPIRequest.getState();
		postAPIRequest.getMidRequest();postAPIRequest.equals(postAPIRequest);postAPIRequest.toString();postAPIRequest.hashCode();
		Assertions.assertNotNull(postAPIRequest.getMidRequest());
	}
	
	@Test
	void testPostAPIDto()
	{
		CommonResponse commonResponse = new CommonResponse();
		commonResponse.setMessage("API operation successful"); commonResponse.setResponseCode("00"); commonResponse.equals(commonResponse); commonResponse.toString();commonResponse.hashCode();
		TerminalResponseDto terminalResponseDto = TerminalResponseDto.builder().message("Terminal id already exists.").responseCode("14")
				.terminalId("867564").tidRefId("s12csZ2qcC").userName("username").build(); TerminalResponseDto.builder().equals(terminalResponseDto.builder());
				terminalResponseDto.setTerminalId("867564");terminalResponseDto.setTidRefId("s12csZ2qcC");terminalResponseDto.setUserName("username");
				terminalResponseDto.setMessage("Terminal id already exists.");terminalResponseDto.setResponseCode("14");
				terminalResponseDto.getMessage();terminalResponseDto.getResponseCode();terminalResponseDto.getTerminalId();terminalResponseDto.getTidRefId();
				terminalResponseDto.getUserName();terminalResponseDto.getClass();terminalResponseDto.equals(terminalResponseDto); terminalResponseDto.toString();
				terminalResponseDto.hashCode(); TerminalResponseDto.builder().toString();
		MerchantResponseDto merchantAddResponseDto = MerchantResponseDto.builder().message(null).mid("34325211611").mid("21234").midRefId("ewrdsfa12312dca").responseCode("00")
				.tidDetails(Arrays.asList(terminalResponseDto)).build(); MerchantResponseDto.builder().toString();
				merchantAddResponseDto.setMessage(null);merchantAddResponseDto.setMid(null);merchantAddResponseDto.setMidRefId(null);merchantAddResponseDto.getResponseCode();
				merchantAddResponseDto.getTidDetails(); merchantAddResponseDto.equals(merchantAddResponseDto);merchantAddResponseDto.toString(); merchantAddResponseDto.hashCode();
				
				APIResponseDto apiResponseDto = APIResponseDto.builder().merchantRefNo("aesc1234bed").message("Success response")
				.midDetails(merchantAddResponseDto).responseCode("00").result("API operation successful").build();
				APIResponseDtoBuilder.class.equals(APIResponseDtoBuilder.class); APIResponseDtoBuilder.class.toString();
				APIResponseDtoBuilder.class.toString();
				apiResponseDto.setMerchantRefNo("aesc1234bed");apiResponseDto.setMessage("Success response");apiResponseDto.setMidDetails(merchantAddResponseDto);apiResponseDto.setResponseCode("00");
				apiResponseDto.setResult("API operation successful"); apiResponseDto.equals(apiResponseDto); apiResponseDto.toString();apiResponseDto.hashCode();
				
				APIDto apiDto = APIDto.builder().id("1234").requestCall(null).responseCall(null).build();
				apiDto = new APIDto(); apiDto.setId("1234");apiDto.setRequestCall(null);apiDto.setResponseCall(apiResponseDto);apiDto.getId();
				apiDto.getRequestCall();apiDto.getResponseCall(); apiDto.equals(apiDto); apiDto.toString(); apiDto.hashCode();
				
				Assertions.assertNotNull(apiResponseDto.getMerchantRefNo());
	}
}
