package ae.network.onboarding.softpos.mosambee.integration;

import java.security.GeneralSecurityException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import ae.network.onboarding.softpos.mosambee.common.AppConfig;

@SpringBootTest
public class EncryptTest {

	@Autowired
	private AppConfig appConfig;
	
	@Test
	public void testDecrypt() throws GeneralSecurityException {
		String plainStr = "This is test";
//		AESGCMUtil.encrypt(plainStr, appConfig.getEncrptSecret(), appConfig.getNonce());
		String text = AESGCMUtil.decrypt("3C0B9C499CBD38B77FE8BAEC8CE6A1D65386B87453667CFA5EC0068A", appConfig.getEncrptSecret(), appConfig.getNonce());
		Assertions.assertTrue(text.equals(plainStr));
	}
	
}
