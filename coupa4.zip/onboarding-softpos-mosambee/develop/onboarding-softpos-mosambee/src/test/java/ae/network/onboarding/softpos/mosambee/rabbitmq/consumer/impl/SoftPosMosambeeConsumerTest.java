package ae.network.onboarding.softpos.mosambee.rabbitmq.consumer.impl;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.context.annotation.Import;

import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.onboarding.softpos.mosambee.exception.MaxRetryReachedException;
import ae.network.onboarding.softpos.mosambee.model.ApplicationRequest;
import ae.network.onboarding.softpos.mosambee.model.ApplicationUpdate;
import ae.network.onboarding.softpos.mosambee.model.RequestType;
import ae.network.onboarding.softpos.mosambee.model.ValidationError;
import ae.network.onboarding.softpos.mosambee.rabbitmq.consumer.AbstractConsumer;
import ae.network.onboarding.softpos.mosambee.rabbitmq.service.RabbitService;
import ae.network.onboarding.softpos.mosambee.rabbitmq.service.exchange.AmendmentService;
import ae.network.onboarding.softpos.mosambee.rabbitmq.service.exchange.ClosureService;
import ae.network.onboarding.softpos.mosambee.rabbitmq.service.exchange.SoftPosMosambeeService;
import ae.network.onboarding.softpos.mosambee.validation.AmendmentPayloadValidator;
import ae.network.onboarding.softpos.mosambee.validation.ClosurePayloadValidator;
import ae.network.onboarding.softpos.mosambee.validation.PayloadValidator;

@SpringBootTest
@Import({ae.network.onboarding.softpos.mosambee.DummyRabbit.class})
public class SoftPosMosambeeConsumerTest {
	private static final String REQUESTS_PATH = "src/test/resources/requests/";
	@MockBean
    private RabbitService rabbitService;
	
	@SpyBean
    private SoftPosMosambeeService mosambeeService;

	@SpyBean
    private PayloadValidator payloadValidator;
	
	@SpyBean
    private AmendmentService amendmentService;

	@SpyBean
    private AmendmentPayloadValidator amendmentPayloadValidator;
	
	@SpyBean
    private ClosureService closureService;

	@SpyBean
    private ClosurePayloadValidator closurePayloadValidator;
	
	SoftPosMosambeeConsumer consumer;
	@BeforeEach
	void init() {
		consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator, closureService, closurePayloadValidator);
	}
	
	@Test
    void validateValidApplication() throws IOException {
    	 ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
        boolean isRequestSupported = consumer.isRequestSupported(applicationRequest);
        assertTrue(isRequestSupported);
        Optional<Collection<ValidationError>> errors = Optional.empty();
        if(isRequestSupported) {
        	errors = consumer.validateApplication(applicationRequest);
        }
        assertFalse(errors.isPresent());
    }
	
	@Test
    void validateInvalidApplication() throws IOException {
//		SoftPosMosambeeConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
        ApplicationRequest applicationRequest = getApplicationRequest("invalid-onboard-merchant.json");
        Optional<Collection<ValidationError>> errors = consumer.validateApplication(applicationRequest);
        assertTrue(errors.isPresent());
    }
	
	
	@Test
    void testForRequestValidity() throws IOException {
//		SoftPosMosambeeConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
        ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
        boolean isRequestSupported = consumer.isRequestSupported(applicationRequest);
        Assertions.assertTrue(isRequestSupported);
    }

    @Test
    void testForRequestInvalidity() throws IOException {
//    	SoftPosMosambeeConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
        ApplicationRequest applicationRequest = getApplicationRequest("NonSupported-onboard-merchant.json");
        boolean isRequestSupported = consumer.isRequestSupported(applicationRequest);
        Assertions.assertFalse(isRequestSupported);
    }

    @Test
    void testForClosureRequestValidity() throws IOException {
//    	SoftPosMosambeeConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
        ApplicationRequest applicationRequest = getApplicationRequest("merchant-closure.json");
        boolean isRequestSupported = consumer.isRequestSupported(applicationRequest);
        Assertions.assertTrue(isRequestSupported);
    }
    
	public static ApplicationRequest getApplicationRequest(String filename) throws IOException {
        String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + filename)));
        return new ObjectMapper().readValue(messageContent, ApplicationRequest.class);
    }
	
	@Test
	public void testProcessApplicationRequest() throws IOException {
		ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
//		SoftPosMosambeeConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
        consumer.processApplication(applicationRequest);
	}
	
	@Test
	public void testDryRun() throws IOException {
//		SoftPosMosambeeConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
		ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
		Optional<ApplicationUpdate> update = consumer.druRun(applicationRequest);
		Assertions.assertTrue(! update.isPresent());
	}
	
	@Test
	public void testAbstractHandler() throws IOException {
		MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.3ds2.0");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + "onboard-merchant.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
//		AbstractConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
		Mockito.doNothing().when(mosambeeService).processMerchant(Mockito.any(ApplicationRequest.class));
		consumer.onMessage(msg);
	}
	
	@Test
	public void testActualFlow() throws IOException {
		MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.softpos_mosambee");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + "onboard-merchant.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
//		AbstractConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
		consumer.onMessage(msg);
	}
	
	@Test
	public void testActualAmendmentFlow() throws IOException {
		MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.softpos_mosambee");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(SoftPosMosambeeConsumerTest.REQUESTS_PATH + "amendment-merchant.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
//    	AbstractConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
		consumer.onMessage(msg);
	}
	
	@Test
	public void testAbstractRetry() throws IOException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException {
//		AbstractConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
		Method method = AbstractConsumer.class.getDeclaredMethod("retryMessage", Message.class);
		method.setAccessible(true);
		MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.softpos_mosambee");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + "onboard-merchant.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
		method.invoke(consumer, msg); 
	}
	
	@Test
	public void testHandleError() throws InstantiationException, IllegalAccessException   {
//		AbstractConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
//		consumer.handleError(new Throwable(new MaxRetryReachedException("1234"))); 
	}
	
	@Test
	public void testAbsractMapErrTaskHist() throws IOException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException {
//		AbstractConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
		Collection<ValidationError> validationErrors = new ArrayList<ValidationError>();
		Method method = AbstractConsumer.class.getDeclaredMethod("sendApplicationInvalid", String.class,
				Collection.class);
		method.setAccessible(true);
		validationErrors.add(ValidationError.EMPTY_MCC);
		method.invoke(consumer, "1234", validationErrors); 
	}
	 
	@Test
	public void testAbsractTaskHist() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
//		AbstractConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
		Method method = AbstractConsumer.class.getDeclaredMethod("mapErrorToTaskHistory", ValidationError.class);
		method.setAccessible(true);
		method.invoke(consumer, ValidationError.EMPTY_MERCHANT_NAME);
	}
	
	@Test
	public void testAbsractAppCancelled() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
//		AbstractConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
		Method method = AbstractConsumer.class.getDeclaredMethod("sendApplicationCancelled", String.class);
		method.setAccessible(true);
		method.invoke(consumer, "1234");
	}
	
	@Test
    void inValidateMerchantIdOnboardingApplication() throws IOException {
//    	SoftPosMosambeeConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
        ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
        applicationRequest.setRequestType(RequestType.ONBOARDING);
        applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).setMerchantId(null);
        applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).setMerchantName(null);
        applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).setLegalName(null);
        applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).setMcc(null);
        applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).getAddresses().get(0).setCity(null);
        applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).getAddresses().get(0).setPostalCode(null);
        applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).getAddresses().get(0).setPhone(null);
        applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).getAddresses().get(0).setEmail(null);
        applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).getAddresses().get(0).setPostalCode(null);
        applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).getTerminals().get(0).setTerminalId(null);
        applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).getTerminals().get(0).setTerminalModel(null);
        applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).getTerminals().get(0).setMaker(null);
        
        Optional<Collection<ValidationError>> errors = consumer.validateApplication(applicationRequest);
        assertTrue(errors.isPresent());
    }
	
	@Test
    void inValidateMerchantIdAmendmentApplication() throws IOException {
//    	SoftPosMosambeeConsumer consumer = new SoftPosMosambeeConsumer(rabbitService, mosambeeService, payloadValidator, amendmentService, amendmentPayloadValidator);
        ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
        applicationRequest.setRequestType(RequestType.AMENDMENT);
        applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).setMerchantId(null);
        applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).getTerminals().get(0).setTerminalId(null);
        
        Optional<Collection<ValidationError>> errors = consumer.validateApplication(applicationRequest);
        assertTrue(errors.isPresent());
    }
}
