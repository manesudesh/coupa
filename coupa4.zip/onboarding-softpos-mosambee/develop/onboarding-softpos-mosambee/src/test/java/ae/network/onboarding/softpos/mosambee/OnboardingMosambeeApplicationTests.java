package ae.network.onboarding.softpos.mosambee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;

@SpringBootTest
@Import({DummyRabbit.class})
class OnboardingMosambeeApplicationTests {

    @Test
    void contextLoads() {
    }

}
