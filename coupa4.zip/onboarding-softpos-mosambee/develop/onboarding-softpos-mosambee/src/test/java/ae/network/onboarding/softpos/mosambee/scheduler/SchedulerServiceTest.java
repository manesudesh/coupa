package ae.network.onboarding.softpos.mosambee.scheduler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;

import ae.network.onboarding.softpos.mosambee.model.ApplicationRequest;
import ae.network.onboarding.softpos.mosambee.model.RetryBlock;
import ae.network.onboarding.softpos.mosambee.model.RetryTerminal;
import ae.network.onboarding.softpos.mosambee.model.Status;
import ae.network.onboarding.softpos.mosambee.rabbitmq.consumer.impl.SoftPosMosambeeConsumerTest;
import ae.network.onboarding.softpos.mosambee.rabbitmq.service.exchange.SoftPosMosambeeService;

@SpringBootTest
public class SchedulerServiceTest {

	@Autowired
	RetryTerminalImpl retryTerminalImpl;
	
	@SpyBean
	SoftPosMosambeeService softposMosambeeService;
	
	@Test
	void retryTerminalsTest() throws IOException 
	{
		ApplicationRequest entity1 = SoftPosMosambeeConsumerTest.getApplicationRequest("onboard-merchant.json");
		RetryTerminal retryTerminal1 = RetryTerminal.builder().terminalId("13149416").status("RETRY").build();
		RetryTerminal retryTerminal2 = RetryTerminal.builder().terminalId("13149417").status("RETRY").build();
		RetryTerminal retryTerminal3 = RetryTerminal.builder().terminalId("34567").status("RETRY").build();
		RetryTerminal retryTerminal4 = RetryTerminal.builder().terminalId("45678").status("RETRY").build();
		
		RetryBlock retryBlock1 = RetryBlock.builder().merchantId("200600528210").retryTerminals(Arrays.asList(retryTerminal1, retryTerminal2)).build();
		RetryBlock retryBlock2 = RetryBlock.builder().merchantId("2222222").retryTerminals(Arrays.asList(retryTerminal3)).build();
		RetryBlock retryBlock3 = RetryBlock.builder().merchantId("333333333333").retryTerminals(Arrays.asList(retryTerminal4)).build();
		
		entity1.setRetryBlocks(new ArrayList<>(Arrays.asList(retryBlock1, retryBlock2)) );
		ApplicationRequest entity2 = SoftPosMosambeeConsumerTest.getApplicationRequest("onboard-merchant.json");
		
		
		
		entity2.setRetryBlocks(new ArrayList<>(Arrays.asList(retryBlock3)) );
		List<ApplicationRequest> appList = Arrays.asList( entity1, entity2);
		Mockito.doReturn(appList).when(softposMosambeeService).pickRetryRecords(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyString());
		Mockito.doReturn(Status.ONBOARDED_DONE).when(softposMosambeeService).decideAppRetryStatus(Mockito.anyList());
//		Mockito.doReturn(entity1.getPayload().getApplications().get(0).getMerchants()).when(softposMosambeeService).getValidMerchants(entity1);
		
		entity2.getPayload().getApplications().get(0).getMerchants().get(0).setMerchantId("333333333333");
		entity2.setMosambeeRetryCount(2);
//		Mockito.doReturn(entity2.getPayload().getApplications().get(0).getMerchants()).when(softposMosambeeService).getValidMerchants(entity2);
		
		retryTerminalImpl.processTerminal();
			
//		Method method = mosambeeService.getClass().getDeclaredMethod("createProfileHandler", Merchant.class);
//		method.setAccessible(true);
//		APIRequestDto dto = (APIRequestDto) method.invoke(mosambeeService, merchant);
		System.out.println("");
	}
}
