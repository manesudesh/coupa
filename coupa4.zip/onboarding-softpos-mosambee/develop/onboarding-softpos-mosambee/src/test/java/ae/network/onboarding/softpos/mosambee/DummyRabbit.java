package ae.network.onboarding.softpos.mosambee;


import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;

/**
 * @author 
 */
@TestConfiguration
public class DummyRabbit {
    @MockBean
    private AmqpAdmin rabbitAdmin;

    @MockBean
    private ConnectionFactory connectionFactory;
}
