package ae.network.onboarding.softpos.mosambee.rabbitmq.service.exchange;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import ae.network.onboarding.softpos.mosambee.common.AppConfig;
import ae.network.onboarding.softpos.mosambee.model.apirequest.APIRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apirequest.MerchantRequestDto;
import ae.network.onboarding.softpos.mosambee.model.apirequest.TerminalRequestDto;
import ae.network.onboarding.softpos.mosambee.model.payload.Address;
import ae.network.onboarding.softpos.mosambee.model.payload.Merchant;
import ae.network.onboarding.softpos.mosambee.model.payload.MerchantConfig;
import ae.network.onboarding.softpos.mosambee.model.payload.MerchantUser;
import ae.network.onboarding.softpos.mosambee.model.payload.MosambeeService;
import ae.network.onboarding.softpos.mosambee.model.payload.Terminal;
import ae.network.onboarding.softpos.mosambee.rabbitmq.service.RabbitService;
import ae.network.onboarding.softpos.mosambee.service.utils.ProcessingHelper;
import lombok.extern.slf4j.Slf4j;

/**
 * @author 
 */
@SpringBootTest
@Slf4j
public class SoftPosMosambeeServiceTest {

	/**
     * Injection of ProcessingHelper for helper utility
     */
	@MockBean
    private ProcessingHelper processingHelper;
    /**
     * Injection of Rabbit Service to update the
     * queue
     */
	@MockBean
    private RabbitService rabbitService;
    
	@Autowired
    private AppConfig appConfig;
	
	@InjectMocks
    private SoftPosMosambeeService mosambeeService;
    
    
	@Test
	void testMerchantProfile() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		mosambeeService = new SoftPosMosambeeService(null, processingHelper, rabbitService, appConfig);
		Merchant merchant = new Merchant();
		String city = "Dubai", addressType = "AddressType", state="";
		List<String> addressLine = Arrays.asList("Lane1","Lane2");
		Address address = new Address();
		address.setCity(city);address.setAddressType(addressType);address.setState(state);address.setAddressLines(addressLine);
		List <Address> addressList = Arrays.asList(address);
		merchant.setAddresses(addressList);
		merchant.setLegalName("Legal Hospitality MEA LLC");
		merchant.setMcc("4722");
		merchant.setMerchantCurrency("AED");
		merchant.setMerchantId("200600888880");
		merchant.setMerchantName("Merchant Hospitality MEA LLC");
		merchant.setMerchantType("POS");
		
		MerchantUser user = new MerchantUser(); user.setFirstName("First"); user.setLastName("Last"); user.setEmail("EMail.com");user.setMobile("8888808880");
		
		MosambeeService merchantServie = MosambeeService.builder().user(user).build();
		merchantServie.setServiceType("SOFTPOS_MOSAMBEE");
		merchant.setServices(Arrays.asList(merchantServie)); 
		
		Terminal terminal = new Terminal();   terminal.setUserId("");terminal.setMaker("");terminal.setProcessed(true); terminal.setTerminalId("13149417");
		merchant.setTerminals(Arrays.asList(terminal));
		
		Method method = mosambeeService.getClass().getDeclaredMethod("createProfileHandler", Merchant.class);
		method.setAccessible(true);
		APIRequestDto dto = (APIRequestDto) method.invoke(mosambeeService, merchant);
		System.out.println(dto);
	}
	
	@Test
	void testTerminalCreation() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		mosambeeService = new SoftPosMosambeeService(null, processingHelper, rabbitService, appConfig);
		
		Merchant merchant = new Merchant();
		String city = "Dubai", addressType = "AddressType", state="";
		List<String> addressLine = Arrays.asList("Lane1","Lane2");
		Address address = new Address();
		address.setCity(city);address.setAddressType(addressType);address.setState(state);address.setAddressLines(addressLine);
		List <Address> addressList = Arrays.asList(address);
		merchant.setAddresses(addressList);
		
		MerchantUser user = new MerchantUser(); user.setFirstName("First"); user.setLastName("Last"); user.setEmail("EMail.com");user.setMobile("8888808880");
		MosambeeService merchantServie = MosambeeService.builder().user(user).build();
		merchantServie.setServiceType("SOFTPOS_MOSAMBEE");
		merchant.setServices(Arrays.asList(merchantServie));
		
		MerchantConfig merchantConfigration = MerchantConfig.builder().softPosAuthSystem("BASE24").build();
        merchant.setConfigurations(merchantConfigration);
        
		Terminal terminal = new Terminal();   terminal.setUserId("");terminal.setMaker("MOSAMBEE");terminal.setProcessed(true); terminal.setTerminalId("13149417");
		merchant.setTerminals(Arrays.asList(terminal));
		
		Method method = mosambeeService.getClass().getDeclaredMethod("createTerminalHandler", Merchant.class);
		method.setAccessible(true);
		List<TerminalRequestDto> dto = (List<TerminalRequestDto>) method.invoke(mosambeeService, merchant);
		System.out.println(dto);
	}
	
	@Test
	void testMerchantHandler() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		mosambeeService = new SoftPosMosambeeService(null, processingHelper, rabbitService, appConfig);
		Merchant merchant = new Merchant();
		merchant.setMerchantId("654376512");
		MerchantConfig merchantConfigration = MerchantConfig.builder().softPosAuthSystem("BASE24").build();
        merchant.setConfigurations(merchantConfigration);
		Method method = mosambeeService.getClass().getDeclaredMethod("createMerchantHandler", Merchant.class);
		method.setAccessible(true);
		MerchantRequestDto dto = (MerchantRequestDto) method.invoke(mosambeeService, merchant);
		System.out.println(dto);
	}
}
