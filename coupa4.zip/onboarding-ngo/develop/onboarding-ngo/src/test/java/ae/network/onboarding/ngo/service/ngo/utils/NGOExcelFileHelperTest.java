package ae.network.onboarding.ngo.service.ngo.utils;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.annotation.DirtiesContext;

import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.onboarding.ngo.DummyRabbit;
import ae.network.onboarding.ngo.FileContentLoader;
import ae.network.onboarding.ngo.database.model.MerchantExecution;
import ae.network.onboarding.ngo.integration.IntegrationService;
import ae.network.onboarding.ngo.model.ApplicationRequest;
import ae.network.onboarding.ngo.model.application.Merchant;
import ae.network.onboarding.ngo.rabbitmq.service.impl.RabbitServiceImpl;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Import(DummyRabbit.class)
@Slf4j
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class NGOExcelFileHelperTest {

	@MockBean
	RabbitServiceImpl rabbitService;

	@Autowired
	NGOExcelFileHelper ngoExcelFileHelper;

	@Test
	void testExportMerchantExcel(@TempDir Path tempDir)
			throws IOException, EncryptedDocumentException, InvalidFormatException {

		FileContentLoader fileContentLoader = new FileContentLoader();
		ObjectMapper objectMapper = new ObjectMapper();

		ApplicationRequest request;

		request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json1.json"),
				ApplicationRequest.class);

		List<MerchantExecution> dinersExecutions = new ArrayList<MerchantExecution>();
		request.getPayload().getApplications().stream().forEach(
				app -> app.getMerchants().forEach(merchant -> dinersExecutions.add(createExecution(merchant))));

		byte[] excelByteContent = ngoExcelFileHelper.exportMerchantExcel(dinersExecutions);
		String excelFileName = ngoExcelFileHelper.getCurrentExcelFile();

		Path outFile = Paths.get(tempDir.toString() + FileSystems.getDefault().getSeparator() + excelFileName);
		Files.write(outFile, excelByteContent);

		Workbook workbook = WorkbookFactory.create(new FileInputStream(outFile.toFile()));
		Sheet sheet = workbook.getSheet("Sheet1");
		assertTrue(sheet.getLastRowNum() > 3);

	}

	private MerchantExecution createExecution(Merchant merchant) {
		MerchantExecution execution = new MerchantExecution();
		execution.setMid(merchant.getMerchantId());
		execution.setName(merchant.getMerchantName());
		execution.setDiners3ds(true);
		execution.setSendEmail(true);
		Instant now = Instant.now();
		Instant lastHour = now.minus(1, ChronoUnit.HOURS);
		execution.setCreatedDate(new Date(lastHour.toEpochMilli()));
		return execution;
	}

}
