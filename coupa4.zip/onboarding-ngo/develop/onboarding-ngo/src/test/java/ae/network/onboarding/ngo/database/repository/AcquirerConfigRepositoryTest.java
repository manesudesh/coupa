package ae.network.onboarding.ngo.database.repository;

import ae.network.onboarding.ngo.rabbitmq.service.impl.RabbitServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
public class AcquirerConfigRepositoryTest {

    @MockBean
    RabbitServiceImpl rabbitService;
    @Autowired
    private AcquirerConfigRepository acquirerConfigRepository;

    @Test
    void testFindByName() {

        assertTrue(acquirerConfigRepository.findByName("NIUAT").isPresent());

    }

}
