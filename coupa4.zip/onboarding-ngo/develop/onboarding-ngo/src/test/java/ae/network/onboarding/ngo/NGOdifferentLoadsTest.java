package ae.network.onboarding.ngo;

import ae.network.onboarding.ngo.model.ApplicationRequest;
import ae.network.onboarding.ngo.rabbitmq.service.impl.RabbitServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;

import static org.junit.jupiter.api.Assertions.fail;

@SpringBootTest
@Import(DummyRabbit.class)
class NGOdifferentLoadsTest {

    @MockBean
    RabbitServiceImpl rabbitService;

    @Test
    void testdifferentApplicationPayloads() {

        try {
            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            for (int i = 1; i <= 12; i++) {
                ApplicationRequest request = objectMapper.readValue(
                        fileContentLoader.getFileContent("sample_json" + i + ".json"), ApplicationRequest.class);

                System.out.println(request);
            }

        } catch (JsonProcessingException e) {
            e.printStackTrace();
            fail("JSON Message malformed");
        }
    }

}