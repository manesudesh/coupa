package ae.network.onboarding.ngo.integration;

import ae.network.onboarding.ngo.DummyRabbit;
import ae.network.onboarding.ngo.database.model.AcquirerConfig;
import ae.network.onboarding.ngo.integration.model.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.junit.jupiter.EnabledIf;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

@SpringBootTest
@Import(DummyRabbit.class)
@EnabledIf("#{systemProperties['spring.profiles.active'] == 'it'}")
class IntegrationServiceTest {

    @Autowired
    private IntegrationService integrationService;

    @Test
    void onboardMerchant() {
        AuthRequest authRequest = ApiKeyAuthRequest.builder()
                .baseUrl("https://api-gateway-uat.ngenius-payments.com")
                .apiKey("NWM0MTMxOTgtNjdlZi00YmUzLWIxY2ItNjc2NmViZWVhNTc5OjkyOGE2NGU5LTNjODktNGNhMS1iN2E1LTBjYWE5MGU2OTE1Yw==")
                .realmName("ni").build();

        AcquirerConfig acquirerConfig = new AcquirerConfig();
        acquirerConfig.setAcquirerId("200");
        acquirerConfig.setAuthRequest(authRequest);
        acquirerConfig.setTenantReference("08c6e5b3-4158-4432-9974-0a27288a43d5");
        acquirerConfig.setMerchantUserRole("MERCHANT_ADMIN");

        HashMap<String, List<String>> paymentMethods = new HashMap<>();
        paymentMethods.put("VISA", Arrays.asList("AED", "USD"));

        HashMap<String, Integer> currencyLimits = new HashMap<>();
        currencyLimits.put("AED", 20000);
        currencyLimits.put("USD", 30000);


        MerchantData merchantData = new MerchantData();
        String testData = "193517012024";
        merchantData.setChainId(testData);
        merchantData.setChannels(Collections.singletonList(Channel.Ecom));
        merchantData.setMccCode(1234);
        merchantData.setMid(testData);
//        merchantData.setExistingChainRef("4000d6d6-5936-4052-9bf1-bcc7bfe13868");
        merchantData.setMerchantName("mer1701");
        merchantData.setTid(Collections.singletonList(testData));
        merchantData.setOrganizationName("dobMercmOr1701");
        merchantData.setPaymentMethodCurrenciesMap(paymentMethods);
        merchantData.setPropositionServices(Arrays.asList("mcp", "issuer-data", "china-union-pay"));
        merchantData.setCurrencyLimits(currencyLimits);
        merchantData.setEnable3DS(false);
        ContactDetails user = new ContactDetails();
        user.setEmail("s.walid+ngo1701@test.com");
        user.setName("First");
        user.setSurname("Last");
        user.setMobile("+971551701594");
        merchantData.setContactDetails(user);
        merchantData.setWebsite("https://test1701.ae");
        AddressDetails addressDetails = new AddressDetails();
        addressDetails.setCity("Dubai");
        addressDetails.setState("Dubai");
        addressDetails.setCountry("AE");
        merchantData.setBlockedCountries(Arrays.asList("US", "CA"));
        merchantData.setDisableCorporateCards(true);
        merchantData.setDisablePaymentsNonGGC(true);
        merchantData.setAddressDetails(addressDetails);

        Assertions.assertThrows(IntegrationException.class, () -> {
            integrationService.onboardMerchant(acquirerConfig, merchantData);
        });
    }
}