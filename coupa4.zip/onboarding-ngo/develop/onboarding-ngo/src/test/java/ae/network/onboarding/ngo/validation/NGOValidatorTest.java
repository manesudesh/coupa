package ae.network.onboarding.ngo.validation;

import ae.network.onboarding.ngo.DummyRabbit;
import ae.network.onboarding.ngo.FileContentLoader;
import ae.network.onboarding.ngo.model.ApplicationRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Slf4j
@Import(DummyRabbit.class)
class NGOValidatorTest {

    @Autowired
    private NGOValidator ngoValidator;

    @Test
    void testValidateValidRequest() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json1.json"),
                    ApplicationRequest.class);
            System.out.println(request);

            ValidationResult validationResult = ngoValidator.validate(request);
            assertTrue(validationResult.isPassed());

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        }

    }

    @Test
    void testValidateRequestWithNoTerminal() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json2.json"),
                    ApplicationRequest.class);
            System.out.println(request);

            ValidationResult validationResult = ngoValidator.validate(request);
            assertTrue(!validationResult.isPassed());

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        }

    }

    @Test
    void testValidateRequestWithNoNGO() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json3.json"),
                    ApplicationRequest.class);
            System.out.println(request);

            ValidationResult validationResult = ngoValidator.validate(request);
            assertFalse(validationResult.isPassed(),
                    "Validation will not run for if NGO Service not available, merchant will be skipped");

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        }

    }

    @Test
    void testValidateFullRequestPayload() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json6.json"),
                    ApplicationRequest.class);
            System.out.println(request);

            ValidationResult validationResult = ngoValidator.validate(request);
            assertTrue(validationResult.isPassed());

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        }

    }

    @Test
    void testValidateRequestWithNoMerchantId() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json4.json"),
                    ApplicationRequest.class);

            ValidationResult validationResult = ngoValidator.validate(request);
            assertFalse(validationResult.isPassed(), "Merchant ID is Mandatory");

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        }

    }

    @Test
    void testValidateRequestWithNoMerchantType() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json8.json"),
                    ApplicationRequest.class);
            System.out.println(request);

            ValidationResult validationResult = ngoValidator.validate(request);
            assertFalse(validationResult.isPassed(), "Merchant validation is skipped for not ECOM merchants");

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        }

    }

    @Test
    void testValidateRequestWithNoMerchantMCC() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json9.json"),
                    ApplicationRequest.class);
            System.out.println(request);

            ValidationResult validationResult = ngoValidator.validate(request);
            assertTrue(!validationResult.isPassed(), "Merchant MCC Code is Mandatory");

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        }

    }

    @Test
    void testValidUser() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("valid-merchantUser.json"),
                    ApplicationRequest.class);

            ValidationResult validationResult = ngoValidator.validate(request);
            System.out.println(validationResult);
            assertTrue(validationResult.isPassed(), "Successful Validation");

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        }

    }

    @Test
    void testValidateNoWebsiteRequest() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("no_website.json"),
                    ApplicationRequest.class);
            System.out.println(request);

            ValidationResult validationResult = ngoValidator.validate(request);
            assertFalse(validationResult.isPassed());

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        }

    }


    @Test
    void testValidateNoAddressRequest() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("no_address.json"),
                    ApplicationRequest.class);
            System.out.println(request);

            ValidationResult validationResult = ngoValidator.validate(request);
            assertFalse(validationResult.isPassed());

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        }

    }

    @Test
    void testValidateWrongMobilenoRequest() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("wrong_mobile.json"),
                    ApplicationRequest.class);
            System.out.println(request);

            ValidationResult validationResult = ngoValidator.validate(request);
            assertFalse(validationResult.isPassed());

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        }

    }


}
