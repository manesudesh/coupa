package ae.network.onboarding.ngo.database.repository;

import ae.network.onboarding.ngo.DummyRabbit;
import ae.network.onboarding.ngo.FileContentLoader;
import ae.network.onboarding.ngo.model.ApplicationRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.annotation.DirtiesContext;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

@SpringBootTest
@Import(DummyRabbit.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class ApplicationRequestRepositoryTest {

    @Autowired
    ApplicationRequestRepository applicationRequestRepository;

    @Test
    void testFindFirstByApplicationId() {

        FileContentLoader fileContentLoader = new FileContentLoader();
        ObjectMapper objectMapper = new ObjectMapper();

        ApplicationRequest request;
        try {
            request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json1.json"),
                    ApplicationRequest.class);

            applicationRequestRepository.save(request);

            assertTrue(applicationRequestRepository.findFirstByApplicationId(request.getApplicationId()).isPresent());

        } catch (JsonProcessingException e) {
            e.printStackTrace();
            fail("Transforming JSON filed");
        }

    }

}
