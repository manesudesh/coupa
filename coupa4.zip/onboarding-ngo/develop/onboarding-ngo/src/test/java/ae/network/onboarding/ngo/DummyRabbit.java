package ae.network.onboarding.ngo;

import ae.network.onboarding.ngo.database.model.MerchantExecution;
import ae.network.onboarding.ngo.integration.IntegrationService;
import ae.network.onboarding.ngo.integration.model.ExecutionResult;
import ae.network.onboarding.ngo.rabbitmq.rpc.LookupService;
import ae.network.onboarding.ngo.rabbitmq.rpc.MailService;

import org.mockito.Mockito;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

import java.util.ArrayList;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
@TestConfiguration
public class DummyRabbit {
    @MockBean
    private AmqpAdmin rabbitAdmin;

    @MockBean
    private ConnectionFactory connectionFactory;

    @Bean
    @Primary
    public LookupService getLookupService() {
        return countryCode -> countryCode;
    }
  
    @Bean
    @Primary
    public MailService getMailService() {
        return  emailAsJson -> {} ;
    }
    
    @Bean
    @Primary
    public IntegrationService getIntegrationService() {
        IntegrationService mock = Mockito.mock(IntegrationService.class);
        when(mock.onboardMerchant(any(), any()))
                .thenReturn(new ExecutionResult(new MerchantExecution()));
        return mock;
    }
}
