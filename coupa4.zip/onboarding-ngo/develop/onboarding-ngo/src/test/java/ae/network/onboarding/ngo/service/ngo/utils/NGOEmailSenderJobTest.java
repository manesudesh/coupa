package ae.network.onboarding.ngo.service.ngo.utils;

import ae.network.onboarding.ngo.DummyRabbit;
import ae.network.onboarding.ngo.FileContentLoader;
import ae.network.onboarding.ngo.database.model.MerchantExecution;
import ae.network.onboarding.ngo.database.repository.MerchantExecutionRepository;
import ae.network.onboarding.ngo.model.ApplicationRequest;
import ae.network.onboarding.ngo.model.application.Merchant;
import ae.network.onboarding.ngo.rabbitmq.service.impl.RabbitServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.annotation.DirtiesContext;

import java.nio.file.Path;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SpringBootTest
@Import(DummyRabbit.class)
@Slf4j
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class NGOEmailSenderJobTest {

	@MockBean
	RabbitServiceImpl rabbitService;

	@Autowired
	NGOEmailSenderJob ngoEmailSenderJob;
	
	@Autowired
	MerchantExecutionRepository merchantExecutionRepository;

	@Test
	void testExportExcelSendEmail(@TempDir Path tempDir)
			throws Exception {

		FileContentLoader fileContentLoader = new FileContentLoader();
		ObjectMapper objectMapper = new ObjectMapper();

		ApplicationRequest request;

		request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json1.json"),
				ApplicationRequest.class);

		List<MerchantExecution> dinersExecutions = new ArrayList<MerchantExecution>();
		request.getPayload().getApplications().stream().forEach(
				app -> app.getMerchants().forEach(merchant -> merchantExecutionRepository.save(createExecution(merchant))));
		
		ngoEmailSenderJob.loadMerchantExecutionsAndSendEmail();
    }


	        
	  private MerchantExecution createExecution(Merchant merchant) {
		MerchantExecution execution = new MerchantExecution();
		execution.setMid(merchant.getMerchantId());
		execution.setName(merchant.getMerchantName());
		execution.setDiners3ds(true);
		execution.setSendEmail(true);
		Instant now = Instant.now();
		Instant lastHour = now.minus(12, ChronoUnit.HOURS);
		execution.setCreatedDate(new Date(lastHour.toEpochMilli()));
		return execution;
	}

}
