package ae.network.onboarding.ngo.service.ngo;

import ae.network.onboarding.ngo.DummyRabbit;
import ae.network.onboarding.ngo.FileContentLoader;
import ae.network.onboarding.ngo.integration.IntegrationService;
import ae.network.onboarding.ngo.model.ApplicationRequest;
import ae.network.onboarding.ngo.model.TaskStatus;
import ae.network.onboarding.ngo.rabbitmq.service.impl.RabbitServiceImpl;
import ae.network.onboarding.ngo.service.ngo.utils.NGORequestProcessingHelper;
import ae.network.onboarding.ngo.service.processor.NGORequestProcessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.annotation.DirtiesContext;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Import(DummyRabbit.class)
@Slf4j
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class NGORequestHandlingServiceTest {

    @MockBean
    RabbitServiceImpl rabbitService;

    @MockBean
    IntegrationService integrationService;

    @Autowired
    NGORequestProcessor ngoRequestProcessor;

    @Test
    @Disabled
    void testHandleValidRequest() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json1.json"),
                    ApplicationRequest.class);
            System.out.println(request);

            ngoRequestProcessor.processApplication(request);
            assertTrue(NGORequestProcessingHelper.calculateFinalStatus(request) == TaskStatus.COMPLETED);

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        }

    }

    @Test
    void testHandleRequestWithNoTerminal() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json2.json"),
                    ApplicationRequest.class);
            System.out.println(request);

            ngoRequestProcessor.processApplication(request);

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        } catch (NullPointerException ne) {
            assertTrue(true,
                    "This case should not happen, if there is not Terminals in the list then it will not pass the validation");
            log.info("No terminals available, should not pass the validation before reaching here");
        }

    }

    @Test
    void testHandleRequestWithNoNGO() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json3.json"),
                    ApplicationRequest.class);
            System.out.println(request);

            ngoRequestProcessor.processApplication(request);
            assertTrue(NGORequestProcessingHelper.calculateFinalStatus(request) == TaskStatus.FAILED);

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        }

    }

    @Test
    @Disabled
    void testHandleFullRequestPayload() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json6.json"),
                    ApplicationRequest.class);
            System.out.println(request);

            ngoRequestProcessor.processApplication(request);
            assertTrue(NGORequestProcessingHelper.calculateFinalStatus(request) == TaskStatus.COMPLETED);

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        }

    }

    @Test
    void testHandleRequestWithNoMerchantId() {
        try {

            FileContentLoader fileContentLoader = new FileContentLoader();
            ObjectMapper objectMapper = new ObjectMapper();

            ApplicationRequest request;
            request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json4.json"),
                    ApplicationRequest.class);
            System.out.println(request);

            ngoRequestProcessor.processApplication(request);
            assertNotSame(NGORequestProcessingHelper.calculateFinalStatus(request), TaskStatus.COMPLETED);

        } catch (JsonProcessingException e) {
            log.error("Failed while parsing JSON", e);
            fail("Test Failed");
        } catch (NullPointerException ne) {
            assertTrue(true,
                    "This case should not happen, if there is not MerchantId in the list then it will not pass the validation");
            log.info("No terminals available, should not pass the validation");
        }

    }

}
