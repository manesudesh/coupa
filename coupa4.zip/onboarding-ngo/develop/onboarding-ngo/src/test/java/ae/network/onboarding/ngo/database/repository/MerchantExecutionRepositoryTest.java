package ae.network.onboarding.ngo.database.repository;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.annotation.DirtiesContext;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.onboarding.ngo.DummyRabbit;
import ae.network.onboarding.ngo.FileContentLoader;
import ae.network.onboarding.ngo.database.model.MerchantExecution;
import ae.network.onboarding.ngo.model.ApplicationRequest;
import ae.network.onboarding.ngo.model.application.Merchant;

@SpringBootTest
@Import(DummyRabbit.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class MerchantExecutionRepositoryTest {

    @Autowired
    MerchantExecutionRepository merchantExecutionRepository;

    @Test
    void testMerchantExecutionRepository() {

        FileContentLoader fileContentLoader = new FileContentLoader();
        ObjectMapper objectMapper = new ObjectMapper();

        ApplicationRequest request;
        try {
            request = objectMapper.readValue(fileContentLoader.getFileContent("sample_json1.json"),
                    ApplicationRequest.class);

            

			request.getPayload().getApplications().stream()
					.forEach(app -> app.getMerchants().forEach(merchant -> merchantExecutionRepository.save(createExecution(merchant))));
			
			Instant now = Instant.now();
			Instant yesterday = now.minus(1, ChronoUnit.DAYS);
			List<MerchantExecution> dinersExecutions = merchantExecutionRepository
					.findByCreatedDateBetweenAndSendEmail(new Date(yesterday.toEpochMilli()), new Date(now.toEpochMilli()),true);
			
			assertFalse(dinersExecutions.isEmpty());
			
			 dinersExecutions = merchantExecutionRepository
					.findByCreatedDateBetweenAndSendEmail(new Date(yesterday.toEpochMilli()), new Date(now.toEpochMilli()),false);
			 
			 assertTrue(dinersExecutions.isEmpty());
			
			
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            fail("Transforming JSON filed");
        }

    }

	private MerchantExecution createExecution(Merchant merchant) {
		MerchantExecution execution = new MerchantExecution();
		execution.setMid(merchant.getMerchantId());
		execution.setName(merchant.getMerchantName());
		execution.setDiners3ds(true);
		execution.setSendEmail(true);
		Instant now = Instant.now();
		Instant lastHour = now.minus(1, ChronoUnit.HOURS);
		execution.setCreatedDate(new Date(lastHour.toEpochMilli()));
		return execution;
	}

}
