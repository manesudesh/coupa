package ae.network.onboarding.ngo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileContentLoader {

    public String getFileContent(String resourceName) {

        try {
            return new String(Files.readAllBytes(Paths.get("src/test/resources/" + resourceName)));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
