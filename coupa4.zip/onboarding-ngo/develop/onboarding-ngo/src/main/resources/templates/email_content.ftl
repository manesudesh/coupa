Dear Discover Team - Greetings! <br>
<br>
Appreciate if you could enroll the attached MID`s for 3DS.<br>
<br>
Thanks &amp; Regards,<br>
NI ECommerce Support