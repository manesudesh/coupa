package ae.network.onboarding.ngo.model;

import ae.network.onboarding.ngo.rabbitmq.message.QueueMessage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Update message to queue (sent from consumers)
 *
 * @author walid.sewaify
 * @since 2020-01-23
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationUpdate implements QueueMessage {
    private String applicationId;
    private BackendSystem backendSystem;
    private ProcessingResult processingResult;
    private AdditionalData additionalData;
}
