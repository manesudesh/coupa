package ae.network.onboarding.ngo.integration.model;

import lombok.Data;

import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */
@Data
public class RiskConfigRequest {
    // you can also add amountLimits Map here
    private boolean corporateCardFlag;
    private boolean outsideGccFlag;
    private List<Range> binRangeBlacklist;

    @Data
    public static class Range {
        private String start;
        private String end;
    }
}

