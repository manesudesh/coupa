package ae.network.onboarding.ngo.integration.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.util.CollectionUtils;

import ae.network.onboarding.ngo.model.application.BrighterionAuthType;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */
@Data
public class MerchantData {
    private String organizationName;
    private String merchantType; 
    private boolean ecomMerchant;
    private String merchantName;
    private String groupName;
    private String website;
    private String chainId;
    private String mid;
    private List<String> tid;
    private int mccCode;
    private HashMap<String, Integer> currencyLimits;
    private List<Channel> channels;
    private HashMap<String, List<String>> paymentMethodCurrenciesMap;
    private List<String> propositionServices;
    private boolean enable3DS;
    private boolean disableCorporateCards;
    private boolean disablePaymentsNonGGC;
    private List<RiskConfigRequest.Range> blacklistBinRanges;
    private List<String> blockedCountries;
    private ContactDetails contactDetails;
    private AddressDetails addressDetails;
    private boolean qrPay;
    private String visaMPAN;
    private String mcMPAN;
    
    private boolean ngOneMerchant;
    private boolean tabToPay;
    private boolean payByLink;
    private boolean softpos;
    private boolean brighterion;
    private BrighterionAuthType brighterionFraudScreening;
    private String ecomAuthSystem;
    private String softPosAuthSystem;
    private String paymentProcessor;
    
    private String existingChainRef;
    private String existingOrganizationRef;
    private String existingMerchantUnitRef;
    private String existingOutletRef;
    private ArrayList<String> existingTerminalReferences;
    
    public ArrayList<String> getChannelsList(){
		ArrayList<String> channelStrings = new ArrayList<String>();
		if (CollectionUtils.isEmpty(channels)) {
			channelStrings.add("Ecom");
		}else {
			channels.forEach(channel -> channelStrings.add(channel.name()));
		}
		return channelStrings;
    }
}
