package ae.network.onboarding.ngo.integration.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */
@Data
@AllArgsConstructor
public class AddTidToOutletRequest {
    private List<String> tidReferences;
}
