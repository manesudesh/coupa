package ae.network.onboarding.ngo.integration.model;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */
@Data
@AllArgsConstructor
public class MerchantOrganizationRequest {
    private String name;
}
