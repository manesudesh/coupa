package ae.network.onboarding.ngo.validation;

/**
 * @param <T>
 * @author : yousry
 * @version 1.0
 */
public interface Validator<T> {

    /**
     * validate method
     */
    ValidationResult validate(T entity);
}
