package ae.network.onboarding.ngo.validation;

import ae.network.onboarding.ngo.config.NGOConfigs;
import ae.network.onboarding.ngo.database.repository.ApplicationRequestRepository;
import ae.network.onboarding.ngo.error.ErrorName;
import ae.network.onboarding.ngo.model.ApplicationRequest;
import ae.network.onboarding.ngo.model.ValidationError;
import ae.network.onboarding.ngo.model.application.*;
import ae.network.onboarding.ngo.service.ngo.NGOneUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
public class NGOValidator implements Validator<ApplicationRequest> {

    private static final String NAME_REGEX = "^[a-zA-Z0-9\\-._ ']{1,24}$";
    private static final String EMAIL_REGEX = "^[\\w-_.+]*[\\w-_.]@([\\w-]+\\.)+[\\w]+[\\w]$";
    private static final String MOBILE_REGX = "\\+?[0-9]{10,15}";

    private ApplicationRequestRepository applicationRequestRepository;
    private NGOConfigs ngoConfigs;
    private NGOneUtils ngOneUtils;

    public NGOValidator(ApplicationRequestRepository applicationRequestRepository, NGOConfigs ngoConfigs,NGOneUtils ngOneUtils) {
        this.applicationRequestRepository = applicationRequestRepository;
        this.ngoConfigs = ngoConfigs;
        this.ngOneUtils = ngOneUtils;
    }

    @Override
    public ValidationResult validate(ApplicationRequest request) {

        log.info("NGO validator started.");

        boolean applicationIdExist = applicationRequestRepository.findByApplicationId(request.getApplicationId())
                .isPresent();

        if (applicationIdExist) {
            return ValidationResult.builder().passed(false).code(ErrorName.APPLICATION_EXIST.name())
                    .message("Application with same ID exists").build();
        }

        if (request.getPayload() != null && request.getPayload().getApplications() != null) {

            ArrayList<ValidationError> errorsList = new ArrayList<>();

            request.getPayload().getApplications().forEach(app -> {
                if (app.getChain() != null && app.getChain().getChainId() != null) {

                    String chainID = app.getChain().getChainId();

                    if (!chainID.matches("[0-9]+") || !(chainID.length() >= 9 && chainID.length() <= 12)) {
                        errorsList.add(ValidationError.builder()
                                .errorMessage("ChainId length not Between 9 and 12, or containes non Digits :" + chainID)
                                .fieldName("chainId").errorCode(ErrorName.INVALID_CHAIN_ID.name()).build());
                    }
                }

                if (app.getMerchants() != null) {
                    app.getMerchants().forEach(merchant -> errorsList.addAll(validateMerchant(merchant)));

                    if (!validateApplicationNGOUsers(app))
                        errorsList.add(ValidationError.builder()
                                .errorMessage("All the provided Merchant NGO users should be unique")
                                .fieldName("merchant.NGOParams.user.email").errorCode(ErrorName.NGO_USERS_CONSTRAIN.name()).build());
                }
            });

            if (!errorsList.isEmpty())
                return ValidationResult.builder().passed(false).code("001").message(aggregateErrorMessage(errorsList))
                        .build();
        }

        return ValidationResult.builder().passed(true).code("000").message("Success").build();
    }

    private String aggregateErrorMessage(ArrayList<ValidationError> errorsList) {
        StringBuilder aggregatedMessages = new StringBuilder();

        errorsList
                .forEach(error -> aggregatedMessages.append("\nValidaion Error on Field").append(error.getFieldName())
                        .append("\n\terror Message :").append(error.getErrorMessage()).append("\n\tError Code :")
                        .append(error.getErrorCode()));

        return aggregatedMessages.toString();
    }

    private ArrayList<ValidationError> validateMerchant(Merchant merchant) {

        merchant.setValidationErrors(new ArrayList<>());

        if (ngOneUtils.isNGO(merchant)) {

            if (StringUtils.isEmpty(merchant.getMerchantId())) {
                merchant.getValidationErrors()
                        .add(ValidationError.builder()
                                .errorMessage("Merchant Id not Available for ECOM Merchant :" + merchant.getMerchantName()
                                        + "\t MerchantId :" + merchant.getMerchantId())
                                .fieldName("merchantId").errorCode(ErrorName.MERCHANT_ID_EMPTY.name()).build());
            }

            if (StringUtils.isEmpty(merchant.getMerchantName())) {
                merchant.getValidationErrors()
                        .add(ValidationError.builder()
                                .errorMessage("Merchant Name not Available for ECOM Merchant :" + merchant.getMerchantName()
                                        + "\t MerchantId :" + merchant.getMerchantId())
                                .fieldName("merchantName").errorCode(ErrorName.MERCHANT_NAME_EMPTY.name()).build());
            }

            if (!isValidURL(merchant.getWebsite())) {
                merchant.getValidationErrors().add(ValidationError.builder()
                        .errorMessage("Merchant Website not Available or not Valid:" + merchant.getWebsite()
                                + "\t MerchantId :" + merchant.getMerchantId())
                        .fieldName("website").errorCode(ErrorName.MERCHANT_WEBSITE_INVALID.name()).build());
            }


            if (merchant.getMcc() == null || merchant.getMcc() == 0) {
                merchant.getValidationErrors()
                        .add(ValidationError.builder()
                                .errorMessage("MCC Code not Available for ECOM Merchant :" + merchant.getMerchantName()
                                        + "\t MerchantId :" + merchant.getMerchantId())
                                .fieldName("Mcc").errorCode(ErrorName.MCC_CODE_EMPTY.name()).build());
            }

            if (StringUtils.isEmpty(merchant.getMerchantType())) {
                merchant.getValidationErrors()
                        .add(ValidationError.builder()
                                .errorMessage("Merchant Type not Available for Merchant :" + merchant.getMerchantName()
                                        + "\t MerchantId :" + merchant.getMerchantId())
                                .fieldName("merchantType").errorCode(ErrorName.MERCHANT_TYP_EMPTY.name()).build());
            }

            List<Terminal> terminals = merchant.getTerminals();
            if (terminals == null || terminals.isEmpty()) {
                merchant.getValidationErrors()
                        .add(ValidationError.builder()
                                .errorMessage("Terminals not Available for ECOM Merchant :" + merchant.getMerchantName()
                                        + "\t MerchantId :" + merchant.getMerchantId())
                                .fieldName("terminals").errorCode(ErrorName.TERMINALS_NOT_AVAILABLE.name()).build());
            } else {

                for (Terminal terminal : merchant.getTerminals())
                    if (StringUtils.isEmpty(terminal.getTerminalId()))

                        merchant.getValidationErrors().add(ValidationError.builder()
                                .errorMessage("Terminal ID is empty or null ECOM Merchant :"
                                        + merchant.getMerchantName() + "\t MerchantId :" + merchant.getMerchantId())
                                .fieldName("terminalId").errorCode(ErrorName.TERMINAL_ID_IS_EMPTY.name()).build());

                    else if (!terminal.getTerminalId().matches("[0-9]+")
                            || !(terminal.getTerminalId().length() >= 8 && terminal.getTerminalId().length() <= 12)) {

                        merchant.getValidationErrors().add(ValidationError.builder()
                                .errorMessage("TerminalId length not Between 8 and 12, or not only Digits :"
                                        + terminal.getTerminalId() + "\t MerchantId :" + merchant.getMerchantId())
                                .fieldName("terminalId").errorCode(ErrorName.INVALID_TERMINAL_ID.name()).build());
                    }

            }

            if (merchant.getNGOParams().getCurrencyLimits() != null
                    && !merchant.getNGOParams().getCurrencyLimits().isEmpty()) {

                if (!merchant.getNGOParams().getCurrencyLimits().values().stream()
                        .allMatch(value -> isInteger(value)))
                    merchant.getValidationErrors()
                            .add(ValidationError.builder().errorMessage("Currency Limits not a valid Number")
                                    .fieldName("currencyLimits").errorCode(ErrorName.INVALID_CURRENCY_LIMITS.name())
                                    .build());
            }


            if (merchant.getNGOParams().getUser() != null) {
                MerchantUser user = merchant.getNGOParams().getUser();

                if (StringUtils.isEmpty(user.getEmail()) || !user.getEmail().matches(EMAIL_REGEX)) {
                    merchant.getValidationErrors().add(ValidationError.builder()
                            .errorMessage("Invalid email for NGO user")
                            .fieldName("email").errorCode(ErrorName.INVALID_USER_EMAIL.name()).build());
                }

                if (StringUtils.isEmpty(user.getFirstName()) || !user.getFirstName().matches(NAME_REGEX)) {
                    merchant.getValidationErrors().add(ValidationError.builder()
                            .errorMessage("Invalid first name for NGO user")
                            .fieldName("firstName").errorCode(ErrorName.INVALID_USER_NAME.name()).build());
                }

                if (StringUtils.isEmpty(user.getLastName()) || !user.getLastName().matches(NAME_REGEX)) {
                    merchant.getValidationErrors().add(ValidationError.builder()
                            .errorMessage("Invalid last name for NGO user")
                            .fieldName("lastName").errorCode(ErrorName.INVALID_USER_NAME.name()).build());
                }

                if ((!StringUtils.isEmpty(user.getMobile())) && !user.getMobile().matches(MOBILE_REGX)) {
                    merchant.getValidationErrors().add(ValidationError.builder()
                            .errorMessage("Invalid Mobile Number")
                            .fieldName("mobile").errorCode(ErrorName.INVALID_USER_MOBILE.name()).build());
                }

            }

            if (merchant.getMerchantAddress() == null) {
                merchant.getValidationErrors().add(ValidationError.builder()
                        .errorMessage("Address not provided")
                        .fieldName("addresses").errorCode(ErrorName.ADDRESS_EMPTY.name()).build());
            } else {

                Address merchantAddress = merchant.getMerchantAddress();

                if (StringUtils.isEmpty(merchantAddress.getCountryCode())) {
                    merchant.getValidationErrors().add(ValidationError.builder()
                            .errorMessage("Address CountryCode Empty")
                            .fieldName("countryCode").errorCode(ErrorName.ADDRESS_COUNTRY_CODE_EMPTY.name()).build());
                }

                if (StringUtils.isEmpty(merchantAddress.getCity())) {
                    merchant.getValidationErrors().add(ValidationError.builder()
                            .errorMessage("Address City Empty")
                            .fieldName("city").errorCode(ErrorName.ADDRESS_CITY_EMPTY.name()).build());
                }

            }

            if (merchant.getNGOParams().getPaymentMethodCurrenciesMap() != null
                    && !merchant.getNGOParams().getPaymentMethodCurrenciesMap().isEmpty()) {
                Set<String> paymentMethods = merchant.getNGOParams().getPaymentMethodCurrenciesMap().keySet();
                boolean validPaymentMethods = paymentMethods.stream()
                        .allMatch(paymentMethod -> ngoConfigs.getPaymentMethods().contains(paymentMethod));
                if (!validPaymentMethods)
                    merchant.getValidationErrors()
                            .add(ValidationError.builder()
                                    .errorMessage("Merchant " + merchant.getMerchantId() + "," + merchant.getMerchantName()
                                            + " has invalid Payment Method")
                                    .fieldName("paymentMethodCurrencyMap")
                                    .errorCode(ErrorName.INVALID_PAYMENT_METHOD.name())
                                    .build());

            }


        }

        return merchant.getValidationErrors();
    }

    /**
     * validate if merchants contain at least one
     * NGOUser and make sure all NGO Users are unique
     *
     * @param app
     * @return
     */
    private boolean validateApplicationNGOUsers(Application app) {

        List<String> originalList = app.getMerchants().stream()
                .filter(merchant -> (ngOneUtils.isNGO(merchant) && merchant.getNGOParams().getUser() != null
                        && !StringUtils.isEmpty(merchant.getNGOParams().getUser().getEmail())))
                .map(m -> m.getNGOParams().getUser().getEmail()).collect(Collectors.toList());

        HashSet<String> uniqueSet = new HashSet<String>(originalList);

        return originalList.size() == uniqueSet.size();
    }


    private boolean isValidURL(String url) {

        if (url == null) {
            return false;
        }
        if (!url.toLowerCase().startsWith("http")) {
            url = "http://" + url;
        }
        try {
            new URL(url).toURI();
        } catch (MalformedURLException | URISyntaxException e) {
            return false;
        }
        return true;
    }

    private boolean isInteger(String value) {
        try {
            Integer.parseInt(value);

        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }

}
