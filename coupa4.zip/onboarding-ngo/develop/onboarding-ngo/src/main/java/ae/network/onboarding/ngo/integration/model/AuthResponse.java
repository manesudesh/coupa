package ae.network.onboarding.ngo.integration.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */
@Data
public class AuthResponse {
    @JsonProperty("access_token")
    private String accessToken;
}
