package ae.network.onboarding.ngo.model.application;

/**
 * @author Yousry
 * @version 1.0
 */

public enum AddressType {
    DEFAULT, STMT_ADDR, PAYM_ADDR, CORRESPONDING, TRADING
}
