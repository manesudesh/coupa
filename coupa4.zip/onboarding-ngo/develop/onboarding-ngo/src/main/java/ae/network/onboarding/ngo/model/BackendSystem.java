package ae.network.onboarding.ngo.model;

import ae.network.onboarding.ngo.rabbitmq.config.RabbitQueue;

/**
 * List of all onboarding backend systems
 */
public enum BackendSystem {
    NGO(RabbitQueue.NGO);

    private final RabbitQueue rabbitQueue;

    BackendSystem(RabbitQueue rabbitQueue) {
        this.rabbitQueue = rabbitQueue;
    }

    public RabbitQueue getRabbitQueue() {
        return rabbitQueue;
    }
}
