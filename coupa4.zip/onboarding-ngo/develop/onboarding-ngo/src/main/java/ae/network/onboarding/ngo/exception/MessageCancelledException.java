package ae.network.onboarding.ngo.exception;

/**
 * @author walid.sewaify
 * @since 2020-01-26
 */
public class MessageCancelledException extends MessageRejectionException {
    public MessageCancelledException(String applicationId) {
        super(applicationId, "No processing required");
    }
}
