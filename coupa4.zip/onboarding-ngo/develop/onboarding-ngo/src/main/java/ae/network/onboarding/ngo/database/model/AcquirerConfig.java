package ae.network.onboarding.ngo.database.model;

import ae.network.onboarding.ngo.integration.model.AuthRequest;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString(includeFieldNames = true)
@Document(collection = "ngo_acquirerConfig")
public class AcquirerConfig {
    @Id
    private String name;
    private String acquirerId;
    private String tenantReference;
    private String merchantUserRole;
    private AuthRequest authRequest;
}
