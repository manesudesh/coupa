package ae.network.onboarding.ngo.integration;

import ae.network.onboarding.ngo.config.NGOConfigs;
import ae.network.onboarding.ngo.database.model.AcquirerConfig;
import ae.network.onboarding.ngo.database.model.MerchantExecution;
import ae.network.onboarding.ngo.integration.model.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.stream.Collectors;

import org.springframework.util.StringUtils;

import static ae.network.onboarding.ngo.common.TextUtils.*;
import static org.springframework.util.StringUtils.isEmpty;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */
@Slf4j
@Data
@AllArgsConstructor
public class FlowExecutor {

    protected static final String DINERS_CLUB = "DINERS_CLUB_INTERNATIONAL";
    protected static final String SERVICE_CUP = "china-union-pay";
	protected static final String MERCHANT_TYPE_POS = "POS";
	protected static final String MERCHANT_TYPE_ECOM = "ECOM";
	protected static final String MERCHANT_APP_SERVICE = "merchant-app";
	protected static final String INVOICING_SERVICE = "invoicing";
	protected static final String NI_AUTH_SYSTEM = "NETWORK_INTERNATIONAL";
	protected static final String MPGS_AUTH_SYSTEM = "MPGS";
	protected static final String ACQUIRER_NI = "NI";
	protected static final String ACQUIRER_ID = "200";
	protected static final String BRIGHTERION_SERVICE_POST_AUTH = "brighterion-post-auth-fraud-check";
	protected static final String BRIGHTERION_SERVICE_PRE_AUTH = "brighterion-pre-auth-fraud-check";

    protected final ApiClient apiClient;
    protected final AcquirerConfig acquirerConfig;
    protected final MerchantData merchantData;
    protected final MerchantExecution merchantExecution;
    protected final NGOConfigs config;

    public ExecutionResult execute() throws IntegrationException {
        ApiTask currentTask = null;
        try {

        	boolean isChainIdAlreadyExist = checkChainAlreadyExists();

            currentTask = ApiTask.ADD_MERCHANT_ORG;
            if (acquirerConfig.getName().equalsIgnoreCase("TYME")
    				&& !StringUtils.isEmpty(merchantData.getExistingOrganizationRef()))
            	execTask(currentTask, () -> merchantExecution.setMerchantRef(merchantData.getExistingOrganizationRef()));
            else
            	execTask(currentTask, () -> merchantExecution.setMerchantRef(addMerchantOrg()));

            currentTask = ApiTask.ADD_MERCHANT_UNIT;
            if (acquirerConfig.getName().equalsIgnoreCase("TYME")
    				&& !StringUtils.isEmpty(merchantData.getExistingChainRef()))
            	execTask(currentTask, () -> merchantExecution.setMerchantUnitRef(merchantExecution.getMerchantRef()));
            else
            	execTask(currentTask, () -> merchantExecution.setMerchantUnitRef(addMerchantUnit()));

            currentTask = ApiTask.ADD_MERCHANT_OUTLET;
            execTask(currentTask, () -> merchantExecution.setOutletRef(addMerchantOutlet()));

            boolean isNIChainIdAlreadyExist = isChainIdAlreadyExist && acquirerConfig.getAcquirerId().equalsIgnoreCase(ACQUIRER_ID);
            log.info("NI level Chainid already exist {} at org unit {}", isNIChainIdAlreadyExist, merchantExecution.getMerchantUnitRef());
            
            currentTask = ApiTask.AMOUNT_LIMITS;
            execTask(currentTask, ()->setAmountLimits(isNIChainIdAlreadyExist));

            currentTask = ApiTask.ADD_CHAIN_ID;
            execTask(currentTask, () -> merchantExecution.setChainRef(addChainId()));

            currentTask = ApiTask.ADD_MID_TO_CHAIN;
            execTask(currentTask, () -> merchantExecution.setMidRef(addMidToChain()));

            currentTask = ApiTask.ADD_TID_TO_MID;
            execTask(currentTask, () -> merchantExecution.setTidReference(addTidToMid()));

            currentTask = ApiTask.ADD_TID_TO_OUTLET;
            execTask(currentTask, this::addTidToOutlet);

            currentTask = ApiTask.ADD_PAYMENT_CHANNEL;
            execTask(currentTask, () -> {
                for (Map.Entry<String, List<String>> entry : merchantData.getPaymentMethodCurrenciesMap().entrySet()) {
                    for (String currency : entry.getValue()) {
                        addPaymentChannel(entry.getKey(), currency);
                        if (entry.getKey().equalsIgnoreCase(DINERS_CLUB)) {
                            merchantExecution.setSendEmail(true);
                        }
                    }
                }
            });

            currentTask = ApiTask.ENABLE_3DS;
            if (merchantData.isEnable3DS()) {
                execTask(currentTask, this::enable3DS);
            }

            //NASSC-2500 start
            currentTask = ApiTask.ENABLE_3DS2;
            execTask(currentTask, this::enable3ds2);
            //NASSC-2500 end

            currentTask = ApiTask.ADD_USER;
            ContactDetails contactDetails = merchantData.getContactDetails();
            if (contactDetails != null && isEmpty(merchantData.getExistingChainRef())) {
                // create a user for new organizations
                execTask(currentTask, () -> addUser(contactDetails));
            }

            currentTask = ApiTask.ENABLE_SERVICE;
            List<String> propServices = merchantData.getPropositionServices();
            if (notEmpty(propServices)) {
                execTask(currentTask, () -> propServices.stream().forEachOrdered(this::enablePropositionService));
            }
            
			if (getMerchantData().isBrighterion()) {

				currentTask = ApiTask.ENABLE_BRIGHTERION;

				switch (getMerchantData().getBrighterionFraudScreening()) {
				case Both:
					execTask(currentTask, () -> {
						enableBrighterionService(BRIGHTERION_SERVICE_PRE_AUTH);
						enableBrighterionService(BRIGHTERION_SERVICE_POST_AUTH);
					});

					break;
				case PreAuth:
					execTask(currentTask, () -> {
						enableBrighterionService(BRIGHTERION_SERVICE_PRE_AUTH);
					});
					break;
				case PostAuth:
					execTask(currentTask, () -> {
						enableBrighterionService(BRIGHTERION_SERVICE_POST_AUTH);
					});
					break;
				}
			}

            currentTask = ApiTask.ADD_CUP_ACCOUNT;
            if (propServices != null && propServices.stream().anyMatch(SERVICE_CUP::equalsIgnoreCase)) {
                execTask(currentTask, this::addCupAccount);
            }

            currentTask = ApiTask.CONFIG_RISK_RULES;
            if (merchantData.isDisableCorporateCards() || merchantData.isDisablePaymentsNonGGC()
                    || notEmpty(merchantData.getBlacklistBinRanges()) || notEmpty(merchantData.getBlockedCountries())) {
                execTask(currentTask, ()->configRiskRules(isNIChainIdAlreadyExist));
            }

        } catch (IntegrationException e) {
            log.error("Exception while executing API calls for tasks {}", currentTask);
            ApiError error = e.getError();
            error.setCompletedTasks(merchantExecution.getCompletedTasks());
            error.setFailedTask(currentTask);
            log.error("API error: {}", error);
            throw e;
        }

        log.info("API calls completed, successful tasks {}", merchantExecution.getCompletedTasks());
        return new ExecutionResult(merchantExecution);
    }

	
    protected void enableBrighterionService(String serviceName) {
		log.info("enableService serviceName= {} on merchant level", serviceName);
		apiClient.enableServiceMerchantLevel(merchantExecution.getMerchantRef(), serviceName, new EnableRequest());
		String reference = merchantExecution.getMerchantUnitRef();
		apiClient.enableServiceOrgLevel(reference, serviceName, new EnableRequest());
	}

	public boolean checkIfMerchantUnitReferencekNeeded() {
		
		if(acquirerConfig.getName().equalsIgnoreCase("NI"))
			return true;
		
		if (acquirerConfig.getName().equalsIgnoreCase("TYME")
				&& merchantData.getMid().equals(merchantData.getChainId()))
			return true;
		
		return false;
	}

    protected boolean checkChainAlreadyExists() {
    	boolean flagIsAlreadyExist = false;
        String chainId = merchantData.getChainId();
        log.info("findByChainId chainId= {}", chainId);
        ItemsResponse chainQueryResponse = apiClient.findByChainId(acquirerConfig.getTenantReference(), chainId);
        if (!chainQueryResponse.getItems().isEmpty()) {
            String merchantRef = chainQueryResponse.getItems().get(0).getReference();
            log.info("organization {} already found for provided chain", merchantRef);
            flagIsAlreadyExist = true;
            ItemsResponse chainRef = apiClient.findChainRef(merchantRef);
            if (!chainRef.getItems().isEmpty()) {
                merchantData.setExistingOrganizationRef(merchantRef);
                merchantData.setExistingChainRef(chainRef.getItems().get(0).getReference());
                log.info("using existing chain {}", merchantData.getExistingChainRef());
            }
        }
        return flagIsAlreadyExist;
    }

    protected void addUser(ContactDetails user) {
        String merchantRef = merchantExecution.getMerchantRef();
        AddUserRequest addUserRequest = AddUserRequest.builder().email(user.getEmail()).firstName(user.getName())
                .lastName(user.getSurname()).role(acquirerConfig.getMerchantUserRole())
                .hierarchyRefs(Collections.singletonList(merchantRef)).build();
        log.info("addUserRequest midRef= {}, user= {}", merchantExecution.getMidRef(), user);
        apiClient.addUser(merchantRef, addUserRequest);

        log.info("addNotificationEmail merchantRef= {}, email= {}", merchantExecution.getMerchantRef(), user.getEmail());
        apiClient.addNotificationEmail(merchantRef, new NotificationEmailRequest(user.getEmail()));
    }

    protected void addPaymentChannel(String paymentMethod, String currency) {
        String midRef = merchantExecution.getMidRef();
        String name = paymentMethod.substring(0, 2) + "0" + currency;
        AddPaymentChannelRequest request = AddPaymentChannelRequest.builder().midRef(midRef)
                .paymentMethod(paymentMethod).currency(currency).name(name).enabled(true)
                .channel(merchantData.getChannelsList()).mccCode(merchantData.getMccCode()).build();
        log.info("addPaymentChannel midRef= {}, paymentMethod= {}, currency= {}", midRef, paymentMethod, currency);
        apiClient.addPaymentChannel(merchantExecution.getMerchantRef(), request);
    }

    protected List<String> addTidToMid() {
        String midRef = merchantExecution.getMidRef();
        String merchantRef = merchantExecution.getMerchantRef();
        AddTidToMidRequest request = new AddTidToMidRequest(merchantData.getTid());
        log.info("addTidToMid midRef= {}, merchantRef= {}", midRef, merchantRef);
        ItemsResponse itemsResponse = apiClient.addTidToMid(merchantRef, midRef, request);
        return itemsResponse.getItems().stream().map(ReferenceResponse::getReference).collect(Collectors.toList());
    }

    protected void addTidToOutlet() {
        String outletRef = merchantExecution.getOutletRef();
        AddTidToOutletRequest request = new AddTidToOutletRequest(merchantExecution.getTidReference());
        log.info("addTidOutlet outletRef= {}", outletRef);
        apiClient.addTidOutlet(outletRef, request);
    }

    protected String addMidToChain() {
        String chainRef = merchantExecution.getChainRef();
        String merchantRef = merchantExecution.getMerchantRef();
        AddMidToChainRequest request = AddMidToChainRequest.builder().mid(merchantData.getMid())
                .acquirerId(acquirerConfig.getAcquirerId()).channels(merchantData.getChannels()).build();
        log.info("addMidToChain chainRef= {}, merchantRef= {}", chainRef, merchantRef);
        return apiClient.addMidToChain(merchantRef, chainRef, request).getReference();
    }

    protected String addChainId() {
        String merchantRef = merchantExecution.getMerchantRef();
        if (isEmpty(merchantData.getExistingChainRef())) {
            log.info("addChainId merchantRef= {}", merchantRef);
            return apiClient.addChainId(merchantRef, new AddChainIdRequest(merchantData.getChainId())).getReference();
        }
        return merchantData.getExistingChainRef();
    }

    protected void setAmountLimits(boolean isChainExist) {
        HashMap<String, Integer> amountLimits = merchantData.getCurrencyLimits();
        if (amountLimits != null && !amountLimits.isEmpty()) {
        	 if(isChainExist) {
             	log.info("setAmountLimits amountLimits= {} for existing org unit ", amountLimits);
             	apiClient.setAmountLimitsAtOrgUnit(merchantExecution.getMerchantUnitRef(),
 	                    new AmountLimitsRequest(amountLimits));
             }else {
	            log.info("setAmountLimits amountLimits= {}", amountLimits);
	            apiClient.setAmountLimits(acquirerConfig.getTenantReference(), merchantExecution.getMerchantRef(),
                    new AmountLimitsRequest(amountLimits));
             }
        }
    }

    protected String addMerchantOrg() {
        if (isEmpty(merchantData.getExistingOrganizationRef())) {
            log.info("addMerchantOrganization orgName= {}", merchantData.getOrganizationName());
            return apiClient.addMerchantOrganization(acquirerConfig.getTenantReference(),
                    new MerchantOrganizationRequest(merchantData.getOrganizationName())).getReference();
        }
        return merchantData.getExistingOrganizationRef();
    }

    protected String addMerchantUnit() {
        String merchantRef = merchantExecution.getMerchantRef();
        log.info("addMerchantUnit merchantRef= {}", merchantRef);
        ReferenceResponse response = apiClient.addMerchantUnit(merchantRef,
                new MerchantOrganizationRequest(merchantData.getMerchantName()));

        log.info("addMerchantDetails merchantRef= {}", merchantRef);
        MerchantDetailsRequest request = MerchantDetailsRequest.builder()
                .name(merchantData.getMerchantName())
                .groupName(merchantData.getGroupName())
                .companyUrl(merchantData.getWebsite())
                .contactDetails(merchantData.getContactDetails())
                .addressDetails(merchantData.getAddressDetails()).build();
        apiClient.addMerchantDetails(merchantRef, request);
        return response.getReference();
    }

    protected String addMerchantOutlet() {
        
		String reference = merchantExecution.getMerchantUnitRef();
				
        ReferenceResponse response = apiClient.addMerchantOutlet(reference,
                new MerchantOrganizationRequest(merchantData.getMerchantName()));
        return response.getReference();
    }


    protected void enablePropositionService(String serviceName) {
        log.info("enableService serviceName= {} on merchant level", serviceName);
        apiClient.enableServiceMerchantLevel(merchantExecution.getMerchantRef(), serviceName, new EnableRequest());
        String reference = merchantExecution.getMerchantUnitRef();
       
        if (config.getOrgUnitServices().contains(serviceName)) {
            log.info("enableService serviceName= {} on organization level", serviceName);
			apiClient.enableServiceOrgLevel(reference, serviceName, new EnableRequest());
        }
    }

    protected void enable3DS() {
        String merchantRef = merchantExecution.getMerchantRef();
        log.info("enable3DS merchantRef= {}", merchantRef);
        apiClient.enable3DS(merchantRef, new EnableRequest());
    }
    
    
    /*
     * Enable 3ds2
     * /config/merchants/{merchantRef}/configs/3ds2/enable
     */
    protected void enable3ds2() {
    	String merchantRef = merchantExecution.getMerchantRef();
    	log.info("enable3DS2 merchantRef= {}", merchantRef);
    	apiClient.enable3DS2(merchantRef, new EnableRequest());
    }
    //NASSC-2500 end
    
    protected void configRiskRules(boolean isChainExist) {
        RiskConfigRequest request = new RiskConfigRequest();
        request.setCorporateCardFlag(merchantData.isDisableCorporateCards());
        request.setOutsideGccFlag(merchantData.isDisablePaymentsNonGGC());
        if (notEmpty(merchantData.getBlacklistBinRanges())) {
            request.setBinRangeBlacklist(merchantData.getBlacklistBinRanges());
        }
        
        if(isChainExist) {
        	log.info("adding risk rules request= {} for existing org unit", request);
            apiClient.configRiskRulesAtOrgUnit(merchantExecution.getMerchantUnitRef(), request);
        	for (String country : merchantData.getBlockedCountries()) {
 	            log.info("adding blocked country = {} for existing org unit ", country);
 	            apiClient.blockCountryAtOrgUnit(merchantExecution.getMerchantUnitRef(), new BlockCountryRequest(country));
 	        }
        }else {
        	log.info("adding risk rules request= {}", request);
            apiClient.configRiskRules(merchantExecution.getMerchantRef(), request);
	        if(acquirerConfig.getName().equals("NI"))
		        for (String country : merchantData.getBlockedCountries()) {
		            log.info("adding blocked country = {}", country);
		            apiClient.blockTenantCountry(acquirerConfig.getTenantReference(),merchantExecution.getMerchantRef(), new BlockCountryRequest(country));
		        }
	        else
	        	for (String country : merchantData.getBlockedCountries()) {
	 	            log.info("adding blocked country = {}", country);
	 	            apiClient.blockCountry(merchantExecution.getMerchantRef(), new BlockCountryRequest(country));
 	        }
        }
    }

    protected void addCupAccount() {
        String merchantRef = merchantExecution.getMerchantRef();
        UnionPayRequest request = new UnionPayRequest();
        request.setMerchantType(formatMcc(merchantData.getMccCode()));
        request.setAccountId(wrapLength(merchantData.getMid(), 15));
        request.setName(truncate(toAlphaNumeric(merchantData.getMerchantName()), 10));
        log.info("adding CUP account for merchant = {}", merchantRef);
        apiClient.addUnionPayAccountMerchantLevel(merchantRef, request);
    }


    protected void execTask(ApiTask apiTask, Runnable job) {
        if (!merchantExecution.getCompletedTasks().contains(apiTask)) {
            job.run();
            merchantExecution.getCompletedTasks().add(apiTask);
        }
    }

    protected boolean notEmpty(final Collection<?> c) {
        return c != null && !c.isEmpty();
    }
    
}
