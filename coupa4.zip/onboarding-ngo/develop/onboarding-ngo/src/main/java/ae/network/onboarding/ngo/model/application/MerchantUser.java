package ae.network.onboarding.ngo.model.application;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.ToString;

import static ae.network.onboarding.ngo.common.TextUtils.toAlphaNumeric;
import static ae.network.onboarding.ngo.common.TextUtils.truncate;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */
@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantUser {
    private String email;
    private String firstName;
    private String lastName;
    private String mobile;

    public String getFirstName() {
        return truncate(toAlphaNumeric(firstName), 24);
    }

    public String getLastName() {
        return truncate(toAlphaNumeric(lastName), 24);
    }
}
