package ae.network.onboarding.ngo.database.init;

import ae.network.onboarding.ngo.database.model.AcquirerConfig;
import ae.network.onboarding.ngo.integration.model.ApiKeyAuthRequest;
import ae.network.onboarding.ngo.integration.model.AuthRequest;
import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;

/**
 * @author : Yousry
 */
@ChangeLog(order = "002")
@Slf4j
public class MongoTymeAcquirer {
    @ChangeSet(order = "03", author = "ngo-adapter", id = "03-createUATConfigurationForTyme")
    public void createUATConfigurationForTyme(MongoTemplate mongoTemplate) {
        log.info("Mongo Initial Setup started");

        AuthRequest authRequest = ApiKeyAuthRequest.builder().baseUrl("https://api-gateway-uat.ngenius-payments.com")
                .apiKey("YWY2ZWZhZGMtY2I2MS00MTA2LWJkYjktOWRmYmIzZThiNjYyOjU0N2E2NDNhLTMyYWMtNDQ0Yy1hMzIzLWRkNTdhM2JlZWIyYQ==")
                .realmName("sandboxTymeBank").build();

        AcquirerConfig acquirerConfig = new AcquirerConfig();
        acquirerConfig.setAcquirerId("901");
        acquirerConfig.setName("TYME");
        acquirerConfig.setAuthRequest(authRequest);
        acquirerConfig.setMerchantUserRole("MERCHANT_ADMIN");
        acquirerConfig.setTenantReference("554c9b67-01bd-4813-b67d-dbbcb1bdc6e2");

        mongoTemplate.save(acquirerConfig);
    }

}
