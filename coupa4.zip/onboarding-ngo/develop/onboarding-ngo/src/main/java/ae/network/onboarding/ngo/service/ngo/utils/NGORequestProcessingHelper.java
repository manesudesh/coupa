package ae.network.onboarding.ngo.service.ngo.utils;

import ae.network.onboarding.ngo.model.*;
import lombok.extern.slf4j.Slf4j;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.stream.Collectors;

import org.springframework.util.StringUtils;

/**
 * Class contain the common used methods used across the project
 *
 * @author WaseemAARI
 */
@Slf4j
public class NGORequestProcessingHelper {

    public NGORequestProcessingHelper() {
        super();
    }

    /**
     * @param status
     * @param statusCode
     * @param response
     * @return
     */
    public static TaskHistory createTaskHistory(TaskStatus status, String statusCode, String response) {
        log.info("createTaskHistory method started... ");
        return TaskHistory.builder().createdDate(new Date()).lastModifiedDate(new Date()).statusCode(statusCode)
                .taskStatus(status).response(response).build();
    }


    /**
     * @param applicationRequest
     * @return
     */
    public static ApplicationUpdate createApplicationResponse(ApplicationRequest applicationRequest) {

    	AdditionalData additionalData = createAdditionalDataMap(applicationRequest); 
        return ApplicationUpdate.builder().applicationId(applicationRequest.getApplicationId())
                .backendSystem(BackendSystem.NGO)
                .additionalData(additionalData)
                .processingResult(ProcessingResult.builder().finalStatus(calculateFinalStatus(applicationRequest))
                        .tasks(applicationRequest.getTasks()).build())
                .build();
    }

    private static AdditionalData createAdditionalDataMap(ApplicationRequest applicationRequest) {
    	
		AdditionalData additionalData = new AdditionalData();
		applicationRequest.getPayload().getApplications()
				.forEach(application -> application.getMerchants().forEach(merchant -> {
					if (!StringUtils.isEmpty(merchant.getOutletReference()))
						additionalData.setDataMap(merchant.getMerchantId(), merchant.getOutletReference());
				}));
    	
		return additionalData;
	}

	/**
     * @param applicationRequest
     * @return
     */
    public static TaskStatus calculateFinalStatus(ApplicationRequest applicationRequest) {
        Collection<Task> tasks = applicationRequest.getTasks().stream()
                .filter(task -> !"VALIDATION".equalsIgnoreCase(task.getName())).collect(Collectors.toList());
        if (tasks.stream().allMatch(task -> task.getTaskStatus().equals(TaskStatus.FAILED))) {
            return TaskStatus.FAILED;
        } else if (tasks.stream()
                .allMatch(task -> (task.getTaskStatus().equals(TaskStatus.COMPLETED)
                        || task.getTaskStatus().equals(TaskStatus.CANCELLED)))) {
            return TaskStatus.COMPLETED;
        } else {
            return TaskStatus.PARTIALLY_COMPLETED;
        }
    }

}
