package ae.network.onboarding.ngo.rabbitmq.consumer;

import ae.network.onboarding.ngo.model.ApplicationRequest;
import ae.network.onboarding.ngo.model.ApplicationUpdate;
import ae.network.onboarding.ngo.model.BackendSystem;
import ae.network.onboarding.ngo.model.ValidationError;
import org.springframework.amqp.core.MessageListener;
import org.springframework.util.ErrorHandler;

import java.util.Collection;
import java.util.Optional;

/**
 * @author Success.Otto
 * @since 02/16/2020
 */
public interface Consumer extends MessageListener, ErrorHandler {

    /**
     * Validation of messages should be implemented here
     */
    Optional<Collection<ValidationError>> validateApplication(ApplicationRequest applicationRequest);

    /**
     * After a successful validation, the message is being
     * processed and if necessary stored in its corresponding
     * data store. Any thrown business exceptions will enforce rescheduling the message sometime later.
     */
    void processApplication(ApplicationRequest applicationRequest);

    /**
     * provided the type of backend system you work on
     */
    BackendSystem getBackendSystem();

    /**
     * check whether the incoming request is supported or not.
     */
    boolean isRequestSupported(ApplicationRequest applicationRequest);

    default Optional<ApplicationUpdate> druRun(ApplicationRequest applicationRequest) {
        return Optional.empty();
    }
}
