package ae.network.onboarding.ngo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.data.mongodb.config.EnableMongoAuditing;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@SpringBootApplication
@FeignClient
@EnableMongoAuditing
public class NGeniusOnboardingApplication {

    public static void main(String[] args) {
        SpringApplication.run(NGeniusOnboardingApplication.class, args);
    }
}
