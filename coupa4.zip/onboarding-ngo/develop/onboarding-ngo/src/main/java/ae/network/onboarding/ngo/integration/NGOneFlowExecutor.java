package ae.network.onboarding.ngo.integration;

import static org.springframework.util.StringUtils.isEmpty;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.util.StringUtils;

import ae.network.onboarding.ngo.config.MPGSConfig;
import ae.network.onboarding.ngo.config.NGOConfigs;
import ae.network.onboarding.ngo.database.model.AcquirerConfig;
import ae.network.onboarding.ngo.database.model.MerchantExecution;
import ae.network.onboarding.ngo.integration.model.AddMidToChainRequest;
import ae.network.onboarding.ngo.integration.model.AddPaymentChannelRequest;
import ae.network.onboarding.ngo.integration.model.AddTidToOutletRequest;
import ae.network.onboarding.ngo.integration.model.ApiError;
import ae.network.onboarding.ngo.integration.model.ApiTask;
import ae.network.onboarding.ngo.integration.model.ContactDetails;
import ae.network.onboarding.ngo.integration.model.EnableMPGSRequest;
import ae.network.onboarding.ngo.integration.model.EnableRequest;
import ae.network.onboarding.ngo.integration.model.ExecutionResult;
import ae.network.onboarding.ngo.integration.model.MerchantData;
import ae.network.onboarding.ngo.integration.model.MerchantDetailsRequest;
import ae.network.onboarding.ngo.integration.model.MerchantMPANRequest;
import ae.network.onboarding.ngo.integration.model.MerchantOrganizationRequest;
import ae.network.onboarding.ngo.integration.model.ReferenceResponse;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Waseem.Ismail	
 * @since 2023-05-06
 */
@Slf4j
public class NGOneFlowExecutor extends FlowExecutor{

	private MPGSConfig mpgsConfig;

	public NGOneFlowExecutor(ApiClient apiClient, AcquirerConfig acquirerConfig, MerchantData merchantData,
			MerchantExecution merchantExecution, NGOConfigs config,MPGSConfig mpgsConfig) {
		super(apiClient, acquirerConfig, merchantData, merchantExecution, config);
		this.mpgsConfig = mpgsConfig;
    }


	@Override
    public ExecutionResult execute() throws IntegrationException {
        ApiTask currentTask = null;
        try {

            checkChainAlreadyExists();

            currentTask = ApiTask.ADD_MERCHANT_ORG;
           	execTask(currentTask, () -> getMerchantExecution().setMerchantRef(addMerchantOrg()));

            currentTask = ApiTask.ADD_MERCHANT_UNIT;
           	execTask(currentTask, () -> getMerchantExecution().setMerchantUnitRef(addMerchantUnit()));

           	currentTask = ApiTask.ADD_MERCHANT_DETAILS;
           	execTask(currentTask, this::addMerchantDetails);
           	
           	
            currentTask = ApiTask.ADD_MERCHANT_OUTLET;
            execTask(currentTask, () -> getMerchantExecution().setOutletRef(addMerchantOutlet()));

            currentTask = ApiTask.AMOUNT_LIMITS;
            execTask(currentTask, ()->setAmountLimits(false));

            currentTask = ApiTask.ADD_CHAIN_ID;
            execTask(currentTask, () -> getMerchantExecution().setChainRef(addChainId()));
            
            currentTask = ApiTask.ENABLE_MPGS_ROUTING;
            execTask(currentTask, this::enableMPGSRouting);

            currentTask = ApiTask.ADD_MID_TO_CHAIN;
            execTask(currentTask, () -> getMerchantExecution().setMidRef(addMidToChain()));

            currentTask = ApiTask.ADD_TID_TO_MID;
            execTask(currentTask, () -> getMerchantExecution().setTidReference(addTidToMid()));
            
			if (isMPGSProcessor()) {
				currentTask = ApiTask.ENABLE_MPGS_ON_MID;
				execTask(currentTask, this::enableMPGSOnMID);
			}
			
            currentTask = ApiTask.ADD_TID_TO_OUTLET;
            execTask(currentTask, this::addTidToOutlet);
            
			if (getMerchantData().isQrPay() && !StringUtils.isEmpty(merchantData.getVisaMPAN())) {
	            currentTask =  ApiTask.ADD_MERCHANT_MPAN;
            	execTask(currentTask, this::addMerchantMPAN);
            }
           
			if (merchantData.isQrPay() || merchantData.isSoftpos()) {
				currentTask = ApiTask.ENABLE_VISA_PUSH_PAYMENT;
				execTask(currentTask, this::enableVisaPushPayment);
			}
                         		
            currentTask = ApiTask.ADD_PAYMENT_CHANNEL;
            execTask(currentTask, () -> {
                configurePaymentChannels();
            });            


            if (getMerchantData().isEcomMerchant() && getMerchantData().isEnable3DS()) {
                currentTask = ApiTask.ENABLE_3DS;
                execTask(currentTask, this::enable3DS);
            }

            
			if (getMerchantData().isEcomMerchant()) {
				currentTask = ApiTask.ENABLE_3DS2;
				execTask(currentTask, this::enable3ds2);
			}

            if(getMerchantData().isEcomMerchant() &&  getMerchantData().isPayByLink()) {
				currentTask =  ApiTask.ENABLE_PAY_BY_LINK;
				execTask(currentTask, this::enablePayByLink);
			}
            
            if(getMerchantData().isTabToPay()) {
				currentTask =  ApiTask.ENABLE_TAB_TO_PAY;
				execTask(currentTask, this::enableMerchantApp);
			}
			
            currentTask = ApiTask.ADD_USER;
            ContactDetails contactDetails = getMerchantData().getContactDetails();
            if (contactDetails != null && isEmpty(getMerchantData().getExistingChainRef())) {
                // create a user for new organizations
                execTask(currentTask, () -> addUser(contactDetails));
            }

            currentTask = ApiTask.ENABLE_SERVICE;
            List<String> propServices = getMerchantData().getPropositionServices();
            if (notEmpty(propServices)) {
                execTask(currentTask, () -> propServices.stream().parallel().forEach(this::enablePropositionService));
            }

			if (getMerchantData().isBrighterion()) {
				
				currentTask = ApiTask.ENABLE_BRIGHTERION;
				
				switch (getMerchantData().getBrighterionFraudScreening()) {
				case Both:
					execTask(currentTask, () -> {
						enableBrighterionService(BRIGHTERION_SERVICE_PRE_AUTH);
						enableBrighterionService(BRIGHTERION_SERVICE_POST_AUTH);
					});

					break;
				case PreAuth:
					execTask(currentTask, () -> {
						enableBrighterionService(BRIGHTERION_SERVICE_PRE_AUTH);
					});
					break;
				case PostAuth:
					execTask(currentTask, () -> {
						enableBrighterionService(BRIGHTERION_SERVICE_POST_AUTH);
					});
					break;
				}
			}
            	
            currentTask = ApiTask.ADD_CUP_ACCOUNT;
            if (propServices != null && propServices.stream().anyMatch(SERVICE_CUP::equalsIgnoreCase)) {
                execTask(currentTask, this::addCupAccount);
            }

            currentTask = ApiTask.CONFIG_RISK_RULES;
            if (getMerchantData().isDisableCorporateCards() || getMerchantData().isDisablePaymentsNonGGC()
                    || notEmpty(getMerchantData().getBlacklistBinRanges()) || notEmpty(getMerchantData().getBlockedCountries())) {
                execTask(currentTask, ()->configRiskRules(false));
            }

        } catch (IntegrationException e) {
            log.error("Exception while executing API calls for tasks {}", currentTask);
            ApiError error = e.getError();
            error.setCompletedTasks(getMerchantExecution().getCompletedTasks());
            error.setFailedTask(currentTask);
            log.error("API error: {}", error);
            throw e;
        }

        log.info("API calls completed, successful tasks {}", getMerchantExecution().getCompletedTasks());
        return new ExecutionResult(getMerchantExecution());
    }


	public void configurePaymentChannels() {
		for (Map.Entry<String, List<String>> entry : getMerchantData().getPaymentMethodCurrenciesMap().entrySet()) {
		    for (String currency : entry.getValue()) {
				if (isMPGSProcessor()) {
					
					addPaymentChannel(entry.getKey(), currency, MPGS_AUTH_SYSTEM);// to be set as MPGS_AUTH_SYSTEM once the issue of MPGS is resolved.
					
				} else {
					addPaymentChannel(entry.getKey(), currency, NI_AUTH_SYSTEM);
				}
				
		        if (entry.getKey().equalsIgnoreCase(DINERS_CLUB)) {
		            getMerchantExecution().setSendEmail(true);
		        }
		    }
		}
	}
	
	protected void enablePayByLink() {
		log.info("enableService serviceName= {} on merchant level", "Pay By Link");
		String serviceName = INVOICING_SERVICE;
		apiClient.enableServiceMerchantLevel(merchantExecution.getMerchantRef(), serviceName, new EnableRequest());
		String reference = merchantExecution.getMerchantUnitRef();
		apiClient.enableServiceOrgLevel(reference, serviceName, new EnableRequest());

	}
	
	protected void enableMerchantApp() {
		log.info("enableService serviceName= {} on merchant level", MERCHANT_APP_SERVICE);
		String serviceName = MERCHANT_APP_SERVICE;
		apiClient.enableServiceMerchantLevel(merchantExecution.getMerchantRef(), serviceName, new EnableRequest());
		String reference = merchantExecution.getMerchantUnitRef();
		apiClient.enableServiceOrgLevel(reference, serviceName, new EnableRequest());

	}
	
	protected void enableMPGSRouting() {
		log.info("enable MPGS Routing");
		String reference = merchantExecution.getMerchantRef();
		apiClient.enableMPGSRouting(reference, new EnableRequest());

	}
	
	protected void enableMPGSOnMID() {
		log.info("enable MPGS On MID");
		String merchantReference = merchantExecution.getMerchantRef();
		EnableMPGSRequest request = EnableMPGSRequest.builder().apiKey(mpgsConfig.getApiKey())
				.subDomain(mpgsConfig.getSubdomain()).midReference(merchantExecution.getMidRef()).build();
		apiClient.enableMPGS(merchantReference, request);

	}

	protected void addPaymentChannel(String paymentMethod, String currency,String processor) {
        String midRef = merchantExecution.getMidRef();
        String name = paymentMethod.substring(0, 2) + "0" + currency;
        AddPaymentChannelRequest request = AddPaymentChannelRequest.builder().midRef(midRef)
                .paymentMethod(paymentMethod).currency(currency).name(name).paymentProcessor(processor).enabled(true)
                .channel(merchantData.getChannelsList()).mccCode(merchantData.getMccCode()).build();
        log.info("addPaymentChannel midRef= {}, paymentMethod= {}, currency= {}", midRef, paymentMethod, currency);
        apiClient.addPaymentChannel(merchantExecution.getMerchantRef(), request);
    }
	
	protected void addMerchantMPAN() {
		String merchantRef = merchantExecution.getMerchantRef();
		log.info("addMerchantMPAN merchantRef= {}, SCHEME ={}, VISA MPAN = {}", merchantRef, "VISA",
				merchantData.getVisaMPAN());
		if (!StringUtils.isEmpty(merchantData.getVisaMPAN())) {
			apiClient.addMerchantMPAN(merchantRef, MerchantMPANRequest.builder().mid(merchantData.getMid())
					.mPan(merchantData.getVisaMPAN()).scheme("VISA").build());
		} else {
			log.info("addMerchantMPAN for Visa skipped");
		}

		if (!StringUtils.isEmpty(merchantData.getMcMPAN())) {
			log.info("addMerchantMPAN merchantRef= {}, SCHEME ={}, MASTERCARD MPAN = {}", merchantRef, "MasterCard",
					merchantData.getMcMPAN());
			apiClient.addMerchantMPAN(merchantRef, MerchantMPANRequest.builder().mid(merchantData.getMid())
					.mPan(merchantData.getMcMPAN()).scheme("MASTERCARD").build());
		} else {
			log.info("addMerchantMPAN for MASTERCARD skipped");
		}
	}
	 
	@Override
	protected String addMerchantUnit() {
		
		if (isEmpty(merchantData.getExistingMerchantUnitRef())) {
			
			String merchantRef = merchantExecution.getMerchantRef();
			log.info("addMerchantUnit merchantRef= {}", merchantRef);
			ReferenceResponse response = apiClient.addMerchantUnit(merchantRef,
					new MerchantOrganizationRequest(merchantData.getMerchantName()));
			return response.getReference();
			
		} else {
			
			return merchantData.getExistingMerchantUnitRef();
		}
	}
	
	@Override
	protected String addMerchantOutlet() {

		if (isEmpty(merchantData.getExistingOutletRef())) {
			String reference = merchantExecution.getMerchantUnitRef();

			ReferenceResponse response = apiClient.addMerchantOutlet(reference,
					new MerchantOrganizationRequest(merchantData.getMerchantName()));
			return response.getReference();
		} else {
			return merchantData.getExistingOutletRef();
		}
	}
	
	protected void addMerchantDetails() {
		String merchantRef = merchantExecution.getMerchantRef();
		log.info("addMerchantDetails merchantRef= {}", merchantRef);
		MerchantDetailsRequest request = MerchantDetailsRequest.builder().name(merchantData.getMerchantName())
				.groupName(merchantData.getGroupName()).companyUrl(merchantData.getWebsite())
				.contactDetails(merchantData.getContactDetails()).addressDetails(merchantData.getAddressDetails())
				.build();
		apiClient.addMerchantDetails(merchantRef, request);
	}
	
	protected void enableVisaPushPayment() {
		String merchantRef = merchantExecution.getMerchantRef();
		log.info("VisaPushPayment merchantRef= {}", merchantRef);
		String reference = merchantExecution.getMerchantUnitRef();

		
		apiClient.enableServiceMerchantLevel(merchantExecution.getMerchantRef(), "visa-push-payment-app", new EnableRequest());
		apiClient.enableServiceOrgLevel(reference, "visa-push-payment-app", new EnableRequest());
		
		apiClient.enableServiceMerchantLevel(merchantExecution.getMerchantRef(), "visa-push-payment", new EnableRequest());
		apiClient.enableServiceOrgLevel(reference, "visa-push-payment", new EnableRequest());
	}
	
	@Override
	protected void addTidToOutlet() {
		String outletRef = merchantExecution.getOutletRef();
		ArrayList<String> terminalReferences = new ArrayList<>();
		terminalReferences.addAll(merchantExecution.getTidReference());
		terminalReferences.addAll(getMerchantData().getExistingTerminalReferences());
		AddTidToOutletRequest request = new AddTidToOutletRequest(terminalReferences);
		log.info("addTidOutlet outletRef= {}", outletRef);
		apiClient.addTidOutlet(outletRef, request);
	}
	
	protected String addMidToChain() {
        String chainRef = merchantExecution.getChainRef();
        String merchantRef = merchantExecution.getMerchantRef();
        AddMidToChainRequest request = AddMidToChainRequest.builder().mid(merchantData.getMid())
                .acquirerId(acquirerConfig.getAcquirerId()).channels(merchantData.getChannels()).build();
       
        if (isMPGSProcessor()) {
        	
        	request.setMpgsConfig(mpgsConfig);
		}
        
        log.info("addMidToChain chainRef= {}, merchantRef= {}", chainRef, merchantRef);
        return apiClient.addMidToChain(merchantRef, chainRef, request).getReference();
    }
	
	protected boolean isMPGSProcessor() {
		return (merchantData.getMerchantType().equalsIgnoreCase(MERCHANT_TYPE_ECOM)
				&& merchantData.getEcomAuthSystem().equals(MPGS_AUTH_SYSTEM))
				|| (merchantData.getMerchantType().equalsIgnoreCase(MERCHANT_TYPE_POS)
						&& merchantData.getSoftPosAuthSystem().equals(MPGS_AUTH_SYSTEM));
	}
}
