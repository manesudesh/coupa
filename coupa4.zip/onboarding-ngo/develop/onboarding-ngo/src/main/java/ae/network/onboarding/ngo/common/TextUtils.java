package ae.network.onboarding.ngo.common;

import java.text.DecimalFormat;

/**
 * @author walid.sewaify
 * @since 2021-01-19
 */
public class TextUtils {

    public static String truncate(String str, int maxLen) {
        if (str == null) {
            return null;
        }
        int maxLength = Math.min(str.length(), maxLen);
        return str.substring(0, maxLength);
    }

    public static String toAlphaNumeric(String str) {
        if (str == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (char c : str.toCharArray()) {
            if (Character.isDigit(c) || Character.isLetter(c) || Character.isSpaceChar(c)) {
                sb.append(c);
            }
        }
        return sb.toString();
    }


    public static String formatMcc(Integer mcc) {
        if (mcc == null) return null;
        return new DecimalFormat("0000").format(mcc);
    }

    public static String wrapLength(String str, int requiredSize) {
        if (str == null || str.length() >= requiredSize) {
            return str;
        }
        int sizeDiff = requiredSize - str.length();
        return new String(new char[sizeDiff]).replace('\0', '0') + str;
    }

}
