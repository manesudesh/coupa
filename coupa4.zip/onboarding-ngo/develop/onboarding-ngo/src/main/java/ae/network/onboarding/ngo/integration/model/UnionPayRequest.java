package ae.network.onboarding.ngo.integration.model;

import lombok.Data;

import java.util.Collections;
import java.util.List;

/**
 * @author walid.sewaify
 * @since 2021-02-07
 */
@Data
public class UnionPayRequest {
    private String name;
    private String accountId;
    private String merchantType;
    private final List<String> channel = Collections.singletonList("Ecom");
}
