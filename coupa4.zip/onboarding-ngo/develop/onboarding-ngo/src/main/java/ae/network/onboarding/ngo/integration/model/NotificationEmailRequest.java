package ae.network.onboarding.ngo.integration.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

/**
 * @author walid.sewaify
 * @since 2021-02-03
 */
@Getter
public class NotificationEmailRequest {

    private final String email;

    public NotificationEmailRequest(String email) {
        this.email = email;
        emails = new ArrayList<>();
        emails.add(new Address(email, true));
    }

    private List<Address> emails;

    @Getter
    @AllArgsConstructor
    private static class Address {
        private String address;
        private boolean enabled;
    }
}

