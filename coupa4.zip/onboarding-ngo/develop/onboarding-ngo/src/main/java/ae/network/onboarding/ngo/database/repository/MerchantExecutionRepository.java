package ae.network.onboarding.ngo.database.repository;

import ae.network.onboarding.ngo.database.model.MerchantExecution;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Date;
import java.util.List;

public interface MerchantExecutionRepository extends MongoRepository<MerchantExecution, String> {
    List<MerchantExecution> findByCreatedDateBetweenAndSendEmail(Date from, Date to, boolean sendEmail);
}
