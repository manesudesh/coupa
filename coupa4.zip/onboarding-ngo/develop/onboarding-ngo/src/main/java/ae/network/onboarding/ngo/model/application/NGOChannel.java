package ae.network.onboarding.ngo.model.application;

public enum NGOChannel {
    ECOM, MOTO,MoTo,APP,App,STATIC_QR,POS,USSD
}
