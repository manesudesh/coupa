package ae.network.onboarding.ngo.rabbitmq.rpc;

public interface LookupService {
    /**
     * @param countryCode alpha3 country code that should be mapped to alpha2 code
     * @return mapped value if exists, or else null
     */
    String countryCodeToAlpha2(String countryCode);
}