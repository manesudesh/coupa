package ae.network.onboarding.ngo.service.ngo.utils;

import ae.network.onboarding.ngo.config.DinersConfig;
import ae.network.onboarding.ngo.database.model.MerchantExecution;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

/**
 * @author WaseemAARI
 */
@Slf4j
@Component
public class NGOExcelFileHelper {

    private DinersConfig dinersConfig;
    private ResourceLoader resourceLoader;

    public NGOExcelFileHelper(DinersConfig dinersConfig, ResourceLoader resourceLoader) {
        this.dinersConfig = dinersConfig;
        this.resourceLoader = resourceLoader;
    }

    public byte[] exportMerchantExcel(List<MerchantExecution> merchantExecutions) throws IOException, InvalidFormatException {

        log.info("Start exporting merchantData to Excel");

        try (InputStream inputStream = createTemplateExcelFile(); ByteArrayOutputStream bout = new ByteArrayOutputStream()) {
            Workbook workbook = WorkbookFactory.create(inputStream);

            Sheet sheet = workbook.getSheet("Sheet1");

            merchantExecutions.forEach(merchantExecution -> {
                Row row = sheet.createRow(sheet.getLastRowNum() + 1);
                row.createCell(0).setCellValue(dinersConfig.getAcquirerId());
                row.createCell(1).setCellValue(merchantExecution.getMid());
                row.createCell(2).setCellValue(merchantExecution.getName());
            });

            workbook.write(bout);
            byte[] excelByteContent = bout.toByteArray();
            workbook.close();
            return excelByteContent;
        }
    }

    String getCurrentExcelFile() {
        //Copy of MID Enrollment_DDth_MM-YYYY.xlsx
        Calendar cal = Calendar.getInstance();
        String currentFileName = "MID Enrollment_" + new SimpleDateFormat("dd-MMM-yyyy").format(cal.getTime()) + ".xlsx";
        log.info("Current File Name : {}", currentFileName);
        return currentFileName;
    }

    private InputStream createTemplateExcelFile() throws IOException {

        Resource resource = resourceLoader.getResource("classpath:templates/excel_template.xlsx");
        return resource.getInputStream();
    }
}
