package ae.network.onboarding.ngo.common;

/**
 * @author walid.sewaify
 * @since 2020-01-26
 */
public interface DateFormat {
    String FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
}
