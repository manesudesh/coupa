package ae.network.onboarding.ngo.model.application;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class QRServiceParam extends MerchantService {

	
	@Builder.Default
    private boolean visaQR = true;
	
	@Builder.Default
	private boolean masterQR = false;
	
	
}
