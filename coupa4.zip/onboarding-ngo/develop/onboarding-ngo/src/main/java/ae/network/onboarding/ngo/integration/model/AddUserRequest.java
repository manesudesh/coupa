package ae.network.onboarding.ngo.integration.model;

import lombok.Builder;
import lombok.Data;

import java.util.Collection;

/**
 * @author walid.sewaify
 * @since 2020-09-23
 */
@Data
@Builder
public class AddUserRequest {
    private String email;
    private String firstName;
    private String lastName;
    private String role;
    private Collection<String> hierarchyRefs;
}
