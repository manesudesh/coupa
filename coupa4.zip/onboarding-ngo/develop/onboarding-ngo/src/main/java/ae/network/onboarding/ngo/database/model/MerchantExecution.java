package ae.network.onboarding.ngo.database.model;

import ae.network.onboarding.ngo.integration.model.ApiTask;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author walid.sewaify
 * @since 2021-01-10
 */
@Document("ngo_executions")
@Data
public class MerchantExecution implements Serializable {
    @Id
    private String mid;
    private String name;
    private String merchantRef;
    private String merchantUnitRef;
    private String chainRef;
    private String midRef;
    private String outletRef;
    private List<String> tidReference;
    private List<ApiTask> completedTasks = new ArrayList<>();
    private boolean diners3ds;
    private boolean sendEmail;

    @CreatedDate
    private Date createdDate = new Date();

    @LastModifiedDate
    private Date lastModifiedDate = new Date();
}

