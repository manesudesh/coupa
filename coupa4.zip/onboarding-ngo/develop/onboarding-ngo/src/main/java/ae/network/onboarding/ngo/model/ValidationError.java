package ae.network.onboarding.ngo.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class ValidationError {
    private String fieldName;
    private String errorMessage;
    private String errorCode;
}
