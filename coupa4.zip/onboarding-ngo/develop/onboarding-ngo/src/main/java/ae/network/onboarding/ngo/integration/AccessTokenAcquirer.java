package ae.network.onboarding.ngo.integration;

import ae.network.onboarding.ngo.integration.model.ApiKeyAuthRequest;
import ae.network.onboarding.ngo.integration.model.AuthRequest;
import ae.network.onboarding.ngo.integration.model.AuthResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;

/**
 * @author walid.sewaify
 * @since 2020-09-16
 */
@Slf4j
public class AccessTokenAcquirer {
    private static final String IDENTITY_CONTENT_TYPE = "application/vnd.ni-identity.v1+json";
    private static final String path = "/identity/auth/access-token";

    public String getAccessToken(AuthRequest authRequest) {
        log.info("Requesting access token for realm {}", authRequest.getRealmName());

        MediaType mediaType = MediaType.valueOf(IDENTITY_CONTENT_TYPE);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(mediaType);
        headers.setAccept(Collections.singletonList(mediaType));
        // set api key if required
        if (authRequest instanceof ApiKeyAuthRequest) {
            headers.setBasicAuth(((ApiKeyAuthRequest) authRequest).getApiKey());
        }

        String body = toJson(authRequest);

        HttpEntity<String> request = new HttpEntity<>(body, headers);

        ResponseEntity<AuthResponse> response = new RestTemplate().postForEntity(authRequest.getBaseUrl() + path,
                request, AuthResponse.class);
        return response.getBody() == null ? null : response.getBody().getAccessToken();
    }


    private String toJson(Object c) {
        try {
            return new ObjectMapper().writeValueAsString(c);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("JSON serialization error");
        }
    }
}
