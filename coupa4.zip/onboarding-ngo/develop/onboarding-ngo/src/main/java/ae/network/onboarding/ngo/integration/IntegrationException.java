package ae.network.onboarding.ngo.integration;

import ae.network.onboarding.ngo.integration.model.ApiError;
import feign.FeignException;

/**
 * Non-recoverable exception, wraps API error response
 *
 * @author walid.sewaify
 * @since 2020-05-07
 */
public class IntegrationException extends FeignException {
    private final ApiError error;

    public IntegrationException(ApiError error) {
        super(error.getCode(), error.getMessage());
        this.error = error;
    }

    public ApiError getError() {
        return error;
    }
}
