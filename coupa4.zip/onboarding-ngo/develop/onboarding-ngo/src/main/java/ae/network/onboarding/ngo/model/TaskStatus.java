package ae.network.onboarding.ngo.model;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
public enum TaskStatus {
    COMPLETED, IN_PROGRESS, PARTIALLY_COMPLETED, FAILED, CANCELLED
}
