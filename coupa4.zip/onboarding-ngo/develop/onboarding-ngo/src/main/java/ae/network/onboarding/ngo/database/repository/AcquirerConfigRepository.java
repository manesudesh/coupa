package ae.network.onboarding.ngo.database.repository;

import ae.network.onboarding.ngo.database.model.AcquirerConfig;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

/**
 * @author Waseem
 */
public interface AcquirerConfigRepository extends MongoRepository<AcquirerConfig, String> {

    Optional<AcquirerConfig> findByName(String name);
}