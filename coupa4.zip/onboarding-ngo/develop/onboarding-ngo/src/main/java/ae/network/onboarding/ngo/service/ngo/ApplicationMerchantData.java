package ae.network.onboarding.ngo.service.ngo;

import java.util.ArrayList;

import lombok.Data;

@Data
public class ApplicationMerchantData {

	StringBuffer chainRef = new StringBuffer("");
	StringBuffer orgRef = new StringBuffer("");
	StringBuffer unitRef = new StringBuffer("");
	StringBuffer outletRef = new StringBuffer("");
	ArrayList<String> terminalReferences = new ArrayList<String>();

	public ApplicationMerchantData() {

		chainRef = new StringBuffer("");
		orgRef = new StringBuffer("");
		unitRef = new StringBuffer("");
		outletRef = new StringBuffer("");
		terminalReferences = new ArrayList<String>();

	}

}
