package ae.network.onboarding.ngo.model.application;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Waseem
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BrighterionServiceParam extends MerchantService {
	
	@Builder.Default
	private BrighterionAuthType brighterionFraudScreening = BrighterionAuthType.Both;
    private String merchantTurnoverLimit;
    private String merchantAccountType;
}
