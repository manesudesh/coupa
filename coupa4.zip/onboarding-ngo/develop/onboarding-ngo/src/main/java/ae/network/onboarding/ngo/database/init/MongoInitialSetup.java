package ae.network.onboarding.ngo.database.init;

import ae.network.onboarding.ngo.database.model.AcquirerConfig;
import ae.network.onboarding.ngo.integration.model.ApiKeyAuthRequest;
import ae.network.onboarding.ngo.integration.model.AuthRequest;
import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;

/**
 * Creating mongodb initial data
 *
 * @author walid.sewaify
 * @author Success.Otto
 * @author WaseemAARI
 * @since 12-02-2020
 */
@ChangeLog(order = "001")
@Slf4j
public class MongoInitialSetup {

    @ChangeSet(order = "01", author = "ngo-adapter", id = "01-createUATConfiguration")
    public void createUATConfiguration(MongoTemplate mongoTemplate) {
        createConfigRecord(mongoTemplate, "NIUAT");
    }

    @ChangeSet(order = "02", author = "ngo-adapter", id = "02-createNIConfiguration")
    public void createNIConfiguration(MongoTemplate mongoTemplate) {
        createConfigRecord(mongoTemplate, "NI");
    }

    private void createConfigRecord(MongoTemplate mongoTemplate, String acquirer) {
        log.info("Mongo Initial Setup started");

        AuthRequest authRequest = ApiKeyAuthRequest.builder().baseUrl("https://api-gateway-uat.ngenius-payments.com")
                .apiKey("NWM0MTMxOTgtNjdlZi00YmUzLWIxY2ItNjc2NmViZWVhNTc5OjkyOGE2NGU5LTNjODktNGNhMS1iN2E1LTBjYWE5MGU2OTE1Yw==")
                .realmName("ni").build();

        AcquirerConfig acquirerConfig = new AcquirerConfig();
        acquirerConfig.setAcquirerId("200");
        acquirerConfig.setName(acquirer);
        acquirerConfig.setAuthRequest(authRequest);
        acquirerConfig.setMerchantUserRole("MERCHANT_ADMIN");
        acquirerConfig.setTenantReference("08c6e5b3-4158-4432-9974-0a27288a43d5");

        mongoTemplate.save(acquirerConfig);
    }

}