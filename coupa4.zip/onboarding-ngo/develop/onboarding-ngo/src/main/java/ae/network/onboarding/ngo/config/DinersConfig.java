package ae.network.onboarding.ngo.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Data
@Configuration
@ConfigurationProperties(prefix = "ngo.diners")
public class DinersConfig {
    private String acquirerId;
    private String emailFrom;
    private List<String> toList;
    private List<String> ccList;
    private String attachmentContentType;
    private boolean enabled;
}
