package ae.network.onboarding.ngo.rabbitmq.config;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
public enum RabbitExchange {
    ONBOARDING("onboarding-exchange"),
    ONBOARDING_RETRY("onboarding-delayed-exchange");

    private final String exchangeName;

    RabbitExchange(String exchangeName) {
        this.exchangeName = exchangeName;
    }

    public String getExchangeName() {
        return exchangeName;
    }
}
