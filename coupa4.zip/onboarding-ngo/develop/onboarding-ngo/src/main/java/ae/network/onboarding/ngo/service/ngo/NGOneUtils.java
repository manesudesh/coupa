package ae.network.onboarding.ngo.service.ngo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ae.network.onboarding.ngo.config.NGOConfigs;
import ae.network.onboarding.ngo.model.application.Merchant;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor

public class NGOneUtils {

	private static final String NI = "NI";
	private static final String POS = "POS";
	private static final String SOFTPOS = "SOFTPOS";
	private static final String QRPAY = "QRPAY";
	private static final String ECOM = "ECOM";
	private static final String NGO = "NGO";
	
	@Autowired
	NGOConfigs ngoConfigs;

	public boolean isNGOneMerchant(Merchant merchant, String acquirer) {
		
		if(!isNGOServiceAvailable(merchant) || !acquirer.equals(NI)) {
			return false;
		}
		
		if (isSOFTPOS(merchant) || isTabToPay(merchant) || isPayByLink(merchant) || isPayByQR(merchant)) {
			return true;
		}
		
		return false;
	}

	public boolean isTabToPay(Merchant merchant) {

		if (Long.parseLong(ngoConfigs.getTabToPayIds().get(0)) <= Long.parseLong(merchant.getMerchantId())
				&& Long.parseLong(ngoConfigs.getTabToPayIds().get(1)) >= Long.parseLong(merchant.getMerchantId())) {
			return true;
		}

		return false;
	}

	public boolean isPayByLink(Merchant merchant) {
		
		if (Long.parseLong(ngoConfigs.getPayByLinkIds().get(0)) <= Long.parseLong(merchant.getMerchantId())
				&& Long.parseLong(ngoConfigs.getPayByLinkIds().get(1)) >= Long.parseLong(merchant.getMerchantId())) {
			return true;
		}

		return false;
	}

	public boolean isPayByQR(Merchant merchant) {

		if (Long.parseLong(ngoConfigs.getPayByQrIds().get(0)) <= Long.parseLong(merchant.getMerchantId())
				&& Long.parseLong(ngoConfigs.getPayByQrIds().get(1)) >= Long.parseLong(merchant.getMerchantId())) {
			return true;
		}
		
		if (isQRPay(merchant)) {
			return true;
		}
		
		return false;
	}
	
	 /**
     * checks if the merchant has NGO option or not
     *
     * @return true/false
     */
    public boolean isNGO(Merchant merchant) {

        return isEComMerchant(merchant) && merchant.getServices() != null && merchant.getServices().stream()
                .anyMatch(merchantService -> NGO.equalsIgnoreCase(merchantService.getServiceType()));
    }
    
    public boolean isNGOServiceAvailable(Merchant merchant) {
    	
    	 return merchant.getServices() != null && merchant.getServices().stream()
                .anyMatch(merchantService -> NGO.equalsIgnoreCase(merchantService.getServiceType()));
    }

    private boolean isEComMerchant(Merchant merchant) {
        return ECOM.equalsIgnoreCase(merchant.getMerchantType());
    }
    
	public boolean isQRPay(Merchant merchant) {
        return merchant.getServices() != null && merchant.getServices().stream()
                .anyMatch(merchantService -> QRPAY.equalsIgnoreCase(merchantService.getServiceType()));
	}
	
	public boolean isSOFTPOS(Merchant merchant) {

        return isPOSMerchant(merchant) && merchant.getServices() != null && merchant.getServices().stream()
                .anyMatch(merchantService -> SOFTPOS.equalsIgnoreCase(merchantService.getServiceType()));
    }

	private boolean isPOSMerchant(Merchant merchant) {
		 return POS.equalsIgnoreCase(merchant.getMerchantType());
	}
}