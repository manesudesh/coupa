package ae.network.onboarding.ngo.database.service;

import ae.network.onboarding.ngo.database.model.AcquirerConfig;

import java.util.Optional;

public interface AcquirerConfigService {

    Optional<AcquirerConfig> findByName(String name);
}
