package ae.network.onboarding.ngo.integration.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MerchantMPANRequest {
	private String mid;
	
	@JsonProperty("mPan")
	private String mPan;
	private String scheme;
}
