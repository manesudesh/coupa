package ae.network.onboarding.ngo.validation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

/**
 * @author : yousry
 * @version : 1.0
 */
@Data
@AllArgsConstructor
@Builder
@ToString(includeFieldNames = false)
public class ValidationResult {

    private boolean passed;
    private String code;
    private String message;
}
