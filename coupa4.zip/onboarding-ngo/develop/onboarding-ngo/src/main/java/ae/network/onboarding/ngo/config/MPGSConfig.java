package ae.network.onboarding.ngo.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Configuration
@NoArgsConstructor
@ConfigurationProperties(prefix = "ngo.mpgs")
public class MPGSConfig {
    private String apiKey;
    private String subdomain;
    private String reference;
}
