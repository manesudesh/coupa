package ae.network.onboarding.ngo.integration.model;

import java.util.List;

import lombok.Builder;
import lombok.Data;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */
@Data
@Builder
public class AddMidToChainRequest {
    private String mid;
    private String acquirerId;
	private boolean overrideMerchantDetails; 
	private MerchantDetailsRequest merchantDetails;      
	private List<Channel> channels;
	private MPGSConfig mpgsConfig;
	
	

	public void setMpgsConfig(ae.network.onboarding.ngo.config.MPGSConfig mpgsConfig2) {
		mpgsConfig = MPGSConfig.builder().apiKey(mpgsConfig2.getApiKey()).subdomain(mpgsConfig2.getSubdomain())
				.reference(mpgsConfig2.getReference()).build();
	}
}
