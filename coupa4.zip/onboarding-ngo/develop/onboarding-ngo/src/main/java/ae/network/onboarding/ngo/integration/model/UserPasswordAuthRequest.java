package ae.network.onboarding.ngo.integration.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Builder;
import lombok.Data;

/**
 * @author walid.sewaify
 * @since 2020-09-24
 */
@Data
@Builder
public class UserPasswordAuthRequest implements AuthRequest {
    private String userName;
    private String password;
    private String clientId;
    private String grantType;
    private String realmName;
    @JsonIgnore
    private String baseUrl;
}
