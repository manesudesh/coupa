package ae.network.onboarding.ngo.integration.model;

import lombok.Data;

/**
 * @author walid.sewaify
 * @since 2020-05-19
 * Dummy body for put requests
 */
@Data
public class EnableRequest {
    public EnableRequest() {
		this.enabled = true;
	}

	private boolean enabled;
}
