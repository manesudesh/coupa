package ae.network.onboarding.ngo.model;

public enum TaskName {
    VALIDATION,
    SEND_APP_REQUEST,
    RECEIVE_APP_RESPONSE,
    ONBOARDING_MERCHANT
}
