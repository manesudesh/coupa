package ae.network.onboarding.ngo.integration.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MPGSConfig {
    private String apiKey;
    private String subdomain;
    private String reference;
}
