/**
 *
 */
package ae.network.onboarding.ngo.database.service;

import ae.network.onboarding.ngo.database.model.AcquirerConfig;
import ae.network.onboarding.ngo.database.repository.AcquirerConfigRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * @author Waseem
 *
 */

@Service
public class AcquirerConfigServiceImpl implements AcquirerConfigService {

    private AcquirerConfigRepository acquirerConfigRepository;

    /**
     * @param acquirerConfigRepository
     */
    public AcquirerConfigServiceImpl(AcquirerConfigRepository acquirerConfigRepository) {
        this.acquirerConfigRepository = acquirerConfigRepository;
    }

    @Override
    public Optional<AcquirerConfig> findByName(String name) {
        return acquirerConfigRepository.findByName(name);
    }

}
