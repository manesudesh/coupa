package ae.network.onboarding.ngo.model.application;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import lombok.Data;

/**
 * @author Yousry
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "serviceType", visible = true, defaultImpl = MerchantService.class)
@JsonSubTypes(
	{
		@Type(value = NGOServiceParam.class, name = "NGO"),
		@Type(value = QRServiceParam.class, name = "QRPAY"),
		@Type(value = BrighterionServiceParam.class, name = "BRIGHTERION"),
		@Type(value = SOFTPOSServiceParam.class, name = "SOFTPOS")
	})
@Data
public class MerchantService {

    @JsonProperty("serviceType")
    protected String serviceType;
}
