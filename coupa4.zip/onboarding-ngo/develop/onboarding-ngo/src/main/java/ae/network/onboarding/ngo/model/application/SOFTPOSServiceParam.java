package ae.network.onboarding.ngo.model.application;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Builder
@EqualsAndHashCode(callSuper = false)
public class SOFTPOSServiceParam extends MerchantService{

}
