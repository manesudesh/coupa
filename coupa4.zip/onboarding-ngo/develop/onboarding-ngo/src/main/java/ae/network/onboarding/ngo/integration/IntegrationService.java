package ae.network.onboarding.ngo.integration;

import ae.network.onboarding.ngo.config.MPGSConfig;
import ae.network.onboarding.ngo.config.NGOConfigs;
import ae.network.onboarding.ngo.database.model.AcquirerConfig;
import ae.network.onboarding.ngo.database.model.MerchantExecution;
import ae.network.onboarding.ngo.database.repository.MerchantExecutionRepository;
import ae.network.onboarding.ngo.integration.model.ApiError;
import ae.network.onboarding.ngo.integration.model.ExecutionResult;
import ae.network.onboarding.ngo.integration.model.MerchantData;
import ae.network.onboarding.ngo.service.ngo.NGOneUtils;
import feign.Contract;
import feign.Feign;
import feign.Logger;
import feign.codec.Decoder;
import feign.codec.Encoder;
import feign.slf4j.Slf4jLogger;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringDecoder;
import org.springframework.cloud.openfeign.support.SpringEncoder;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.stereotype.Service;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class IntegrationService {
    private final MerchantExecutionRepository repository;
    private final ObjectFactory<HttpMessageConverters> messageConverters;
    private final NGOConfigs configs;
    private final MPGSConfig mpgsConfigs;
    
    public ExecutionResult onboardMerchant(AcquirerConfig acquirerConfig, MerchantData merchantData)
            throws IntegrationException {
        FeignRequestInterceptor requestInterceptor = new FeignRequestInterceptor(acquirerConfig.getAuthRequest());

        ApiClient apiClient = Feign.builder().contract(feignContract())
                .encoder(feignEncoder()).decoder(feignDecoder())
                .logger(feignLogger()).logLevel(Logger.Level.FULL)
                .requestInterceptor(requestInterceptor).errorDecoder(new FeignExceptionErrorDecoder())
                .target(ApiClient.class, acquirerConfig.getAuthRequest().getBaseUrl());


        MerchantExecution execution = repository.findById(merchantData.getMid())
                .orElseGet(() -> newMerchantExecution(merchantData));
        log.info("Executing API calls for merchant {}", merchantData.getMid());
        try {
			
        	if (merchantData.isNgOneMerchant()) {
				return new NGOneFlowExecutor(apiClient, acquirerConfig, merchantData, execution, configs, mpgsConfigs).execute();
			}else {
				return new FlowExecutor(apiClient, acquirerConfig, merchantData, execution, configs).execute();
			}
        	
        } catch(Exception e){
        	log.error("Exception while executing Flow:",e);
        	ApiError error = new ApiError();
        	error.setMessage(e.getMessage());
			throw new IntegrationException(error);
        }
        finally {
            repository.save(execution);
        }
    }

    private Contract feignContract() {
        return new SpringMvcContract();
    }

    private Decoder feignDecoder() {
        return new ResponseEntityDecoder(new SpringDecoder(messageConverters));
    }

    private Encoder feignEncoder() {
        return new SpringEncoder(messageConverters);
    }

    private Slf4jLogger feignLogger() {
        return new Slf4jLogger(this.getClass());
    }

    private MerchantExecution newMerchantExecution(MerchantData merchantData) {
        log.info("Creating new merchant execution context");
        MerchantExecution newMerchantExecution = new MerchantExecution();
        newMerchantExecution.setMid(merchantData.getMid());
        newMerchantExecution.setName(merchantData.getMerchantName());
        merchantData.setMerchantName(merchantData.getMerchantName());
        return newMerchantExecution;
    }
}
