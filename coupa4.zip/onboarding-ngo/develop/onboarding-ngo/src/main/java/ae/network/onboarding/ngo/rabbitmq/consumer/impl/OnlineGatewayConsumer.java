package ae.network.onboarding.ngo.rabbitmq.consumer.impl;

import ae.network.onboarding.ngo.model.*;
import ae.network.onboarding.ngo.model.application.Merchant;
import ae.network.onboarding.ngo.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.ngo.rabbitmq.consumer.AbstractConsumer;
import ae.network.onboarding.ngo.rabbitmq.service.RabbitService;
import ae.network.onboarding.ngo.service.ngo.NGOneUtils;
import ae.network.onboarding.ngo.service.processor.DryRun;
import ae.network.onboarding.ngo.service.processor.NGORequestProcessor;
import ae.network.onboarding.ngo.validation.ValidationResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@Slf4j
public class OnlineGatewayConsumer extends AbstractConsumer {

    private final NGORequestProcessor ngoRequestProcessor;
    private final DryRun dryRun;
    private NGOneUtils ngOneUtils;

    OnlineGatewayConsumer(NGORequestProcessor ngoRequestProcessor, RabbitService rabbitService, DryRun dryRun,NGOneUtils ngOneUtils) {
        super(RabbitQueue.NGO, rabbitService);
        this.ngoRequestProcessor = ngoRequestProcessor;
        this.dryRun = dryRun;
        this.ngOneUtils = ngOneUtils;
    }


    @Override
    public void processApplication(ApplicationRequest applicationRequest) {
        ngoRequestProcessor.processApplication(applicationRequest);
    }


    @Override
    public Optional<Collection<ValidationError>> validateApplication(ApplicationRequest applicationRequest) {
        log.info("ValidateApplication Started for Request: {}", applicationRequest.getRequestId());

        List<ValidationResult> validationResult = ngoRequestProcessor.validateRequest(applicationRequest);
        ngoRequestProcessor.updateRequestWithValidationStatus(validationResult, applicationRequest);

        boolean validationPassed = validationResult.stream().allMatch(ValidationResult::isPassed);

        if (validationPassed) {
            return Optional.empty();
        } else {
            return Optional.of(validationResult.stream()
                    .map(validation -> ValidationError.builder().errorCode(validation.getCode())
                            .errorMessage(validation.getMessage()).fieldName("*").build())
                    .collect(Collectors.toList()));
        }
    }

    @Override
    public BackendSystem getBackendSystem() {
        return BackendSystem.NGO;
    }

    @Override
    public boolean isRequestSupported(ApplicationRequest applicationRequest) {
        boolean hasValidNGOMerchants = applicationRequest.getPayload().getApplications()
                .stream().flatMap(app -> app.getMerchants().stream()).anyMatch(merchant -> ngOneUtils.isNGO(merchant));
        
		boolean hasValidNGOneMerchants = applicationRequest.getPayload().getApplications().stream()
				.flatMap(app -> app.getMerchants().stream())
				.anyMatch(merchant -> ngOneUtils.isNGOneMerchant(merchant, applicationRequest.getAcquirer()));
        
        return applicationRequest.getRequestType() == RequestType.ONBOARDING && (hasValidNGOMerchants || hasValidNGOneMerchants);
    }

    @Override
    public Optional<ApplicationUpdate> druRun(ApplicationRequest applicationRequest) {
        return Optional.ofNullable(dryRun.process(applicationRequest));
    }
}
