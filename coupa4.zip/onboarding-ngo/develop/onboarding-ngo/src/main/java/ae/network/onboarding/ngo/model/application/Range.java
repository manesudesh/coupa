package ae.network.onboarding.ngo.model.application;

import lombok.Data;

@Data
public class Range {
    private String start;
    private String end;
}