package ae.network.onboarding.ngo.integration;

import ae.network.onboarding.ngo.integration.model.ApiError;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;

import java.nio.charset.StandardCharsets;

import static feign.FeignException.errorStatus;

/**
 * Wrap API error into IntegrationException
 */
@Slf4j
public class FeignExceptionErrorDecoder implements ErrorDecoder {

    @Override
    public Exception decode(String methodKey, Response response) {

        FeignException exception = errorStatus(methodKey, response);

        String responseContent;
        try {
            responseContent = new String(exception.responseBody().get().array(), StandardCharsets.UTF_8);
            log.error("error response {}", responseContent);
            ApiError error = new ObjectMapper().readValue(responseContent, ApiError.class);
            return new IntegrationException(error);
        } catch (Exception e) {
            log.error("Could not wrap API error", e);
            return exception;
        }
    }
}
