package ae.network.onboarding.ngo.integration.model;

import ae.network.onboarding.ngo.database.model.MerchantExecution;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-06-07
 */
@RequiredArgsConstructor
@Getter
public class ExecutionResult {
    private final MerchantExecution merchantExecution;

    public List<ApiTask> getTasks() {
        return merchantExecution.getCompletedTasks();
    }

    public String getChainRef() {
        return merchantExecution.getChainRef();
    }

    public String getOrganizationRef() {
        return merchantExecution.getMerchantRef();
    }
    
    public MerchantExecution getMerchantExecution() {
    	return merchantExecution;
    }
}
