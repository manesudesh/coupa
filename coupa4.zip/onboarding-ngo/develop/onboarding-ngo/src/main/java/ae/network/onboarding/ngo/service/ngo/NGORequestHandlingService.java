package ae.network.onboarding.ngo.service.ngo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.xml.crypto.Data;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import ae.network.onboarding.ngo.database.model.AcquirerConfig;
import ae.network.onboarding.ngo.database.repository.ApplicationRequestRepository;
import ae.network.onboarding.ngo.database.service.AcquirerConfigService;
import ae.network.onboarding.ngo.integration.IntegrationException;
import ae.network.onboarding.ngo.integration.IntegrationService;
import ae.network.onboarding.ngo.integration.model.AddressDetails;
import ae.network.onboarding.ngo.integration.model.ApiError;
import ae.network.onboarding.ngo.integration.model.ApiErrorDetails;
import ae.network.onboarding.ngo.integration.model.ApiTask;
import ae.network.onboarding.ngo.integration.model.Channel;
import ae.network.onboarding.ngo.integration.model.ContactDetails;
import ae.network.onboarding.ngo.integration.model.ExecutionResult;
import ae.network.onboarding.ngo.integration.model.MerchantData;
import ae.network.onboarding.ngo.integration.model.RiskConfigRequest;
import ae.network.onboarding.ngo.model.AdditionalData;
import ae.network.onboarding.ngo.model.ApplicationRequest;
import ae.network.onboarding.ngo.model.Task;
import ae.network.onboarding.ngo.model.TaskHistory;
import ae.network.onboarding.ngo.model.TaskName;
import ae.network.onboarding.ngo.model.TaskStatus;
import ae.network.onboarding.ngo.model.application.Address;
import ae.network.onboarding.ngo.model.application.Application;
import ae.network.onboarding.ngo.model.application.Merchant;
import ae.network.onboarding.ngo.model.application.MerchantConfig;
import ae.network.onboarding.ngo.model.application.MerchantUser;
import ae.network.onboarding.ngo.model.application.NGOChannel;
import ae.network.onboarding.ngo.model.application.NGOServiceParam;
import ae.network.onboarding.ngo.model.application.Range;
import ae.network.onboarding.ngo.model.application.Terminal;
import ae.network.onboarding.ngo.rabbitmq.rpc.LookupService;
import ae.network.onboarding.ngo.service.ngo.utils.NGORequestProcessingHelper;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class NGORequestHandlingService {


	private AcquirerConfigService acquirerConfigService;
    private IntegrationService integrationService;
    private ApplicationRequestRepository applicationRequestRepository;
    private LookupService lookupService;
    private NGOneUtils ngOneUtils;

	public NGORequestHandlingService(AcquirerConfigService acquirerConfigService, IntegrationService integrationService,
                                     ApplicationRequestRepository applicationRequestRepository, LookupService lookupService,NGOneUtils ngOneUtils) {

        this.acquirerConfigService = acquirerConfigService;
        this.integrationService = integrationService;
        this.applicationRequestRepository = applicationRequestRepository;
        this.lookupService = lookupService;
        this.ngOneUtils = ngOneUtils;
        
    }

    private static String filterChars(String merchantName) {
        // ignore any special characters
        return merchantName.replaceAll("[^a-zA-Z0-9 ]+", "");
    }

    public void handleRequest(ApplicationRequest applicationRequest) {

        ApplicationMerchantData appCommonReferences = new ApplicationMerchantData();
        
        applicationRequest.getPayload().getApplications().forEach(application -> {

            if (application.getChain() != null) {
                application.getMerchants().forEach(merchant -> {
                    if (ngOneUtils.isNGO(merchant) || ngOneUtils.isNGOneMerchant(merchant, applicationRequest.getAcquirer())) {
                        ExecutionResult executionResult = processMerchant(applicationRequest, application, merchant, appCommonReferences);
                        
                        if(executionResult!=null && executionResult.getMerchantExecution()!=null && executionResult.getMerchantExecution().getOutletRef()!=null)
                        	merchant.setOutletReference(executionResult.getMerchantExecution().getOutletRef());

                        if (executionResult != null) {
                        	 extractApplicationCommonData(executionResult,appCommonReferences);

                        }
                    }
                });
			} else {

					HashMap<String, List<Merchant>> merchantGroups = new HashMap<>();
					application.getMerchants().forEach(merchant -> {
						if (ngOneUtils.isNGO(merchant) || ngOneUtils.isNGOneMerchant(merchant, applicationRequest.getAcquirer())) {
							
							if (merchantGroups.containsKey(getOrganizationName(application, merchant))) {
	
								merchantGroups.get(getOrganizationName(application, merchant)).add(merchant);
	
							} else {
	
								ArrayList<Merchant> merchantList = new ArrayList<Merchant>();
								merchantList.add(merchant);
								merchantGroups.put(getOrganizationName(application, merchant), merchantList);
							}
						}
					});
	
					merchantGroups.keySet().forEach(orgName -> {

						List<Merchant> merchantGroup = merchantGroups.get(orgName);
	
						merchantGroup.forEach(merchant -> {
	
							ExecutionResult executionResult = processMerchant(applicationRequest, application, merchant, appCommonReferences);
	
							merchant.setOutletReference(executionResult.getMerchantExecution().getOutletRef());
	
							if (executionResult != null) {
								 extractApplicationCommonData(executionResult,appCommonReferences);
	
						}

					});

				});
			}
		});

	}


	/**
	 * @param executionResult
	 * @param appCommonReferences2 
	 * @return
	 */
	protected void extractApplicationCommonData(ExecutionResult executionResult, ApplicationMerchantData appCommonReferences) {
		
		if(executionResult==null || appCommonReferences==null)
			return;
		
		appCommonReferences.getChainRef().setLength(0);
		appCommonReferences.getOrgRef().setLength(0);
		
		appCommonReferences.getChainRef().append(executionResult.getChainRef());
		appCommonReferences.getOrgRef().append(executionResult.getOrganizationRef());

		appCommonReferences.getUnitRef().setLength(0);
		appCommonReferences.getUnitRef().append(executionResult.getMerchantExecution().getMerchantUnitRef());
		
		appCommonReferences.getOutletRef().setLength(0);
		appCommonReferences.getOutletRef().append(executionResult.getMerchantExecution().getOutletRef());
		
		appCommonReferences.getTerminalReferences().addAll(executionResult.getMerchantExecution().getTidReference());
	}

    /**
     * Validate if Merchant is ECOM merchant Build MerchantData Object, Load
     * AcquirerConfig dispatch the call to the Integration Service attach related
     * Tasks for that specific Merchant (Cancelled - Merchant is not ECOM) (Failed -
     * in case of any failure at the integrations service side) (Completed - if
     * procession that merchant completed successfully)
     * @param outletRef 
     * @param terminalReferences 
     */
    private ExecutionResult processMerchant(ApplicationRequest applicationRequest, Application application,
                                            Merchant merchant, ApplicationMerchantData appCommonData) {

        ExecutionResult executionResult = null;
        MerchantData merchantData = buildMerchantData(applicationRequest, application, merchant,appCommonData);

        String acquirer = applicationRequest.getAcquirer();
        Optional<AcquirerConfig> acquirerConfigOptional = acquirerConfigService.findByName(acquirer);

        Task onboardingMerchantRequestTask = Task.builder().entityId(merchant.getMerchantId())
                .taskStatus(TaskStatus.IN_PROGRESS).name(TaskName.ONBOARDING_MERCHANT.name())
                .taskHistory(new ArrayList<>()).build();

        applicationRequest.getTasks().add(onboardingMerchantRequestTask);

        try {

            executionResult = integrationService.onboardMerchant(acquirerConfigOptional.get(), merchantData);

            List<ApiTask> apiTasks = executionResult.getTasks();

            onboardingMerchantRequestTask.setTaskStatus(TaskStatus.COMPLETED);
            if (apiTasks != null && !apiTasks.isEmpty()) {

                apiTasks.forEach(apiTask -> {
                    onboardingMerchantRequestTask.getTaskHistory().add(NGORequestProcessingHelper.createTaskHistory(
                            TaskStatus.COMPLETED, "OK", "ONBoarding Merchant Completed on Task :" + apiTask));
                });

            }

        } catch (IntegrationException ie) {

            log.error("IntegrationException while executing API calls for tasks {}", ie);
            onboardingMerchantRequestTask.setTaskStatus(TaskStatus.FAILED);

            populateIntegrationErrorTasks(onboardingMerchantRequestTask, ie);

        } catch (Exception exception) {

            log.error("Exception while executing API calls for tasks {}", exception);
            onboardingMerchantRequestTask.getTaskHistory().add(NGORequestProcessingHelper.createTaskHistory(
                    TaskStatus.FAILED, "ERROR", "ONBoarding Merchant Failed due to :" + exception.getMessage()));
            onboardingMerchantRequestTask.setTaskStatus(TaskStatus.FAILED);
        }

        applicationRequestRepository.save(applicationRequest);
        return executionResult;
    }

    /**
     * This Method assume the Merchant Object to be ECOM and the NGOServiceParam is
     * provided prior validation and filtration should be completed on earlier
     * stage.
     * @param applicationRequest 
     * @param unitRef 
     * @param terminalReferences 
     * @param ngOneMerchant 
     */
    private MerchantData buildMerchantData(ApplicationRequest applicationRequest, Application application,
                                           Merchant merchant, ApplicationMerchantData appCommonData) {

        NGOServiceParam ngoServiceParam = merchant.getNGOParams();
        MerchantData merchantData = new MerchantData();

        merchantData.setExistingChainRef(appCommonData.getChainRef().toString());

        merchantData.setExistingOrganizationRef(appCommonData.getOrgRef().toString());
        
        merchantData.setExistingMerchantUnitRef(appCommonData.getUnitRef().toString());
        
        merchantData.setExistingOutletRef(appCommonData.getOutletRef().toString());
        
        merchantData.setExistingTerminalReferences(appCommonData.getTerminalReferences());
        
		if (merchant.getMerchantType().equals(NGOServiceConstants.ECOM)) {
			merchantData.setEcomMerchant(true);
		} else {
			merchantData.setEcomMerchant(false);
		}

        if (application.getChain() != null)
            merchantData.setChainId(application.getChain().getChainId());
        else
            merchantData.setChainId(merchant.getMerchantId());

        merchantData.setMerchantName(merchant.getMerchantName());

        merchantData.setGroupName(filterChars(merchant.getMerchantName()));

        merchantData.setWebsite(merchant.getWebsite());

        merchantData.setMccCode(merchant.getMcc());

        merchantData.setMid(merchant.getMerchantId());

        merchantData.setTid(getEcomTerminalId(merchant));

        merchantData.setOrganizationName(getOrganizationName(application, merchant));

        merchantData.setChannels(getNGOChannels(ngoServiceParam,merchant,applicationRequest.getAcquirer()));

        merchantData.setPaymentMethodCurrenciesMap(generateMethodCurrenciesMap(merchant));

        merchantData.setCurrencyLimits(generateCurrencyLimitsMap(merchant));

        merchantData.setPropositionServices(merchant.getNGOParams().getPropositionServices());

        merchantData.setEnable3DS(merchant.getNGOParams().isEnable3DS());

        merchantData.setContactDetails(getUserDetails(ngoServiceParam.getUser()));

        merchantData.setAddressDetails(getMerchantAddressDetails(merchant));

        /*New Fields*/
        merchantData.setBlacklistBinRanges(populateRanges(merchant.getNGOParams().getBlacklistBinRanges()));
        merchantData.setDisableCorporateCards(merchant.getNGOParams().isDisableCorporateCards());
        merchantData.setDisablePaymentsNonGGC(merchant.getNGOParams().isDisablePaymentsNonGGC());
        merchantData.setBlockedCountries(getBlockedCountriesList(merchant.getNGOParams().getBlockedCountries()));

        merchantData.setBrighterion(merchant.isBrighterion());
		if (merchant.isBrighterion()) {
			merchantData.setBrighterionFraudScreening(merchant.getBrighterionParams().getBrighterionFraudScreening());
		}
		
		if (ngOneUtils.isNGOneMerchant(merchant, applicationRequest.getAcquirer())) {
			populateNGOneData(applicationRequest, merchant, merchantData);
        }

        return merchantData;
    }

    @SuppressWarnings("unchecked")
	private void populateMPANDetails(MerchantData merchantData, Merchant merchant,
			ApplicationRequest applicationRequest) {

		if (!ngOneUtils.isPayByQR(merchant))
			return;

		merchantData.setQrPay(true);

		if (!CollectionUtils.isEmpty(applicationRequest.getAdditionalDataMap())) {
			AdditionalData way4AdditionalData = applicationRequest.getAdditionalDataMap().get(NGOServiceConstants.WAY4_BACKEND_SYSTEM);

			if (way4AdditionalData != null) {

				HashMap<String, Object> dataMap = (HashMap<String, Object>) way4AdditionalData.getDataMap();

				for (String key : dataMap.keySet()) {

					if (key.equals(NGOServiceConstants.DATA_MAP)) {						
						HashMap<String, ArrayList<String>> merchantMPans = (HashMap<String, ArrayList<String>>) dataMap
								.get(NGOServiceConstants.DATA_MAP);						
						if (merchantMPans != null) {
							ArrayList<String> merchantMPANDetails = merchantMPans.get(merchant.getMerchantId());

							if (!CollectionUtils.isEmpty(merchantMPANDetails)) {

								populateMPANSDetails(merchantData, merchantMPANDetails);
							}
						}
					}
					
					if (key.equals(merchant.getMerchantId())) {
						ArrayList<String> merchantMPANDetails = (ArrayList<String>) dataMap.get(key);
						if (!CollectionUtils.isEmpty(merchantMPANDetails)) {
						
							populateMPANSDetails(merchantData, merchantMPANDetails);
						}
					}

				}
			}
		}

	}

	protected void populateMPANSDetails(MerchantData merchantData, ArrayList<String> merchantMPANDetails) {
		if (!StringUtils.isEmpty(merchantMPANDetails.get(0))) {
			merchantData.setVisaMPAN(merchantMPANDetails.get(0));
		}

		if (merchantMPANDetails.size() > 1 && !StringUtils.isEmpty(merchantMPANDetails.get(1))) {
			merchantData.setMcMPAN(merchantMPANDetails.get(1));
		}
	}

	// Map merchant user details for contact details
    private ContactDetails getUserDetails(MerchantUser merchantUser) {
        if (merchantUser == null) {
            return null;
        }
        ContactDetails userDetails = new ContactDetails();
        userDetails.setEmail(merchantUser.getEmail());
        userDetails.setMobile(merchantUser.getMobile());
        userDetails.setName(merchantUser.getFirstName());
        userDetails.setSurname(merchantUser.getLastName());
        return userDetails;
    }

    /**
     * Transform the Map to HashMap, or return an empty Hashmap if its null
     */
    private HashMap<String, Integer> generateCurrencyLimitsMap(Merchant merchant) {

        NGOServiceParam ngoServiceParam = merchant.getNGOParams();
        final Map<String, Integer> currencyLimits = (ngoServiceParam.getCurrencyLimits() == null)
                ? new HashMap<String, Integer>()
                : convertCurrencyLimitsMap(ngoServiceParam.getCurrencyLimits());
        Map<String, List<String>> paymentMethodCurrenciesMap = ngoServiceParam.getPaymentMethodCurrenciesMap();

        if (currencyLimits.isEmpty()) {

            if (paymentMethodCurrenciesMap != null
                    && !paymentMethodCurrenciesMap.isEmpty()) {

                Set<String> paymentMethodCurrencies = getPaymentMethodCurrencies(
                        paymentMethodCurrenciesMap);

                paymentMethodCurrencies
                        .forEach(currency -> currencyLimits.put(currency, 0));

            }

        } else if (paymentMethodCurrenciesMap != null
                && !paymentMethodCurrenciesMap.isEmpty()) {

            Set<String> paymentMethodCurrencies = new HashSet<String>();
            paymentMethodCurrenciesMap.values().forEach(paymentMethodList -> paymentMethodCurrencies.addAll(paymentMethodList));

            paymentMethodCurrencies.forEach(currency -> {
                if (!currencyLimits.containsKey(currency)) {
                    currencyLimits.put(currency, 0);
                }
            });
        }

        if (merchant.getMerchantCurrency() != null && !merchant.getMerchantCurrency().isEmpty()
                && !currencyLimits.containsKey(merchant.getMerchantCurrency()))
            currencyLimits.put(merchant.getMerchantCurrency(), 0);

        return new HashMap<>(currencyLimits);
    }

    private HashMap<String, Integer> convertCurrencyLimitsMap(Map<String, String> currencyLimits) {
        HashMap<String, Integer> currencyLimitsIntegers = new HashMap<String, Integer>();
        currencyLimits.keySet()
                .forEach(key -> currencyLimitsIntegers.put(key, Integer.parseInt(currencyLimits.get(key))));

        return currencyLimitsIntegers;
    }

    /**
     * return a HashMap instead of Map element.
     */
    private HashMap<String, List<String>> generateMethodCurrenciesMap(Merchant merchant) {

        NGOServiceParam ngoServiceParam = merchant.getNGOParams();
        ArrayList<String> currencyList = new ArrayList<String>();

        Map<String, List<String>> paymentMethodCurrenciesMap = ngoServiceParam.getPaymentMethodCurrenciesMap() == null
                ? new HashMap<String, List<String>>()
                : ngoServiceParam.getPaymentMethodCurrenciesMap();

        if (paymentMethodCurrenciesMap.isEmpty()) {

            if (ngoServiceParam.getCurrencyLimits() != null && !ngoServiceParam.getCurrencyLimits().isEmpty()) {
                currencyList.addAll(ngoServiceParam.getCurrencyLimits().keySet());

            }

            if (!StringUtils.isEmpty(merchant.getMerchantCurrency())
                    && !currencyList.contains(merchant.getMerchantCurrency()))
                currencyList.add(merchant.getMerchantCurrency());

            paymentMethodCurrenciesMap.put(NGOServiceConstants.VISA, currencyList);
            paymentMethodCurrenciesMap.put(NGOServiceConstants.MASTERCARD, currencyList);

        } else if (ngoServiceParam.getCurrencyLimits() != null && !ngoServiceParam.getCurrencyLimits().isEmpty()) {

            HashMap<String, List<String>> newPaymentMethodsMap = new HashMap<String, List<String>>();
            currencyList.addAll(ngoServiceParam.getCurrencyLimits().keySet());
            paymentMethodCurrenciesMap.keySet().forEach(paymentMethod ->
            {
                Set<String> paymentMethodCurrencies = new HashSet<String>(paymentMethodCurrenciesMap.get(paymentMethod));
                paymentMethodCurrencies.addAll(currencyList);
                if (!StringUtils.isEmpty(merchant.getMerchantCurrency())
                        && !paymentMethodCurrencies.contains(merchant.getMerchantCurrency()))
                    paymentMethodCurrencies.add(merchant.getMerchantCurrency());

                newPaymentMethodsMap.put(paymentMethod, new ArrayList<String>(paymentMethodCurrencies));
            });

            return newPaymentMethodsMap;
        }

        if (!StringUtils.isEmpty(merchant.getMerchantCurrency())) {
            paymentMethodCurrenciesMap.keySet().forEach(paymentMethod -> {
                if (!paymentMethodCurrenciesMap.get(paymentMethod).contains(merchant.getMerchantCurrency()))
                    paymentMethodCurrenciesMap.get(paymentMethod).add(merchant.getMerchantCurrency());
            });
        }

        return new HashMap<>(paymentMethodCurrenciesMap);

    }

    /**
     * Transform the Request Channel values to Integration Channel
     * @param merchant 
     * @param acquirer 
     */
    private List<Channel> getNGOChannels(NGOServiceParam ngoServiceParam, Merchant merchant, String acquirer) {

        ArrayList<Channel> channelsList = new ArrayList<>();

		if (ngoServiceParam.getChannels() == null || ngoServiceParam.getChannels().isEmpty()
				|| ngoServiceParam.getChannels().stream().allMatch(channel -> channel == null)) {
			channelsList.add(Channel.Ecom);
		} else {
			
			for (NGOChannel ngoChannel : ngoServiceParam.getChannels()) {
				if(ngoChannel==null) {
					continue;
				}
				switch (ngoChannel) {
				case ECOM:
					channelsList.add(Channel.Ecom);
					break;
				case MOTO:
				case MoTo:
					channelsList.add(Channel.MoTo);
					break;
				case APP:
				case App:
					channelsList.add(Channel.App);
					break;
				case STATIC_QR: 
					channelsList.add(Channel.STATIC_QR);
					break;
				case POS:
					channelsList.add(Channel.POS);
					break;
				case USSD: 
					channelsList.add(Channel.USSD);
					break;
				default:
					log.error("Unknown NGO Channel type:" + ngoChannel.name());
				}
			}
		}
        
        if(ngOneUtils.isNGOneMerchant(merchant, acquirer)) {
        	
        	if(ngOneUtils.isPayByQR(merchant)) {
        		channelsList.add(Channel.App);
        		channelsList.add(Channel.STATIC_QR);
        	}
        	
        	if(ngOneUtils.isSOFTPOS(merchant)) {
        		channelsList.add(Channel.App);
        	}
        	
        	if(ngOneUtils.isPayByLink(merchant)) {
        		channelsList.add(Channel.Ecom);
        	}
        }
        
        return channelsList.stream().distinct().collect(Collectors.toList());
    }

    /**
     * Extract the ID of the terminal in the terminals list since its ECOM Merchant
     */
    private List<String> getEcomTerminalId(Merchant merchant) {
        List<Terminal> terminalsList = merchant.getTerminals();
        ArrayList<String> terminalIds = new ArrayList<>();

        terminalsList.forEach(terminal -> terminalIds.add(terminal.getTerminalId()));
        return terminalIds;
    }

    /**
     * if Organization Name not provided as part of the NGOService then we will use
     * the Chain ID, and if it chain ID is not available we will use Merchant Id
     */
    private String getOrganizationName(Application application,
                                       Merchant merchant) {
        NGOServiceParam ngoServiceParam = merchant.getNGOParams();

        if (application.getChain() != null && !StringUtils.isEmpty(application.getChain().getOrganizationName()))
            return application.getChain().getOrganizationName();

        if (application.getChain() != null && !StringUtils.isEmpty(application.getChain().getChainName()))
            return application.getChain().getChainName();

        if (!StringUtils.isEmpty(ngoServiceParam.getOrganizationName()))
            return ngoServiceParam.getOrganizationName();

        return merchant.getMerchantName();
    }

    /**
     * Generate Detailed Error Message to attached in the Tasks
     */
    private String createErrorMessage(ApiError error) {
        StringBuilder stringBuilder = new StringBuilder();
        List<ApiErrorDetails> apiErrors = error.getErrors();
        stringBuilder.append("Error Code :").append(error.getCode());
        stringBuilder.append("\nError Message :").append(error.getMessage());
        stringBuilder.append("\nFailedTask :").append(error.getFailedTask());

        if (apiErrors != null && !apiErrors.isEmpty()) {

            apiErrors.forEach(apiError -> {
                stringBuilder.append("\n\nApi Error : \n\tError Domain :").append(apiError.getDomain());
                stringBuilder.append("\n\tError Code :").append(apiError.getErrorCode());
                stringBuilder.append("\n\tError Message ").append(apiError.getMessage());
            });

        }

        return stringBuilder.toString();
    }

    /**
     * extract the unique set of currencies used by payment methods
     */
    private Set<String> getPaymentMethodCurrencies(Map<String, List<String>> paymentMethodCurrenciesMap) {
        Set<String> paymentCurrencies = new HashSet<>();
        Collection<List<String>> values = paymentMethodCurrenciesMap.values();
        values.forEach(paymentCurrencies::addAll);
        return paymentCurrencies;
    }

    private void populateIntegrationErrorTasks(Task onboardingMerchantRequestTask, IntegrationException ie) {
        ApiError error = ie.getError();

        List<ApiTask> completedTasks = error.getCompletedTasks();

        if (completedTasks != null && !completedTasks.isEmpty()) {

            completedTasks.forEach(apiTask -> {
                onboardingMerchantRequestTask.getTaskHistory().add(NGORequestProcessingHelper.createTaskHistory(
                        TaskStatus.COMPLETED, "OK", "ONBoarding Merchant Completed on Task :" + apiTask));
            });

        }

        String errorMessage = createErrorMessage(error);

        TaskHistory failedTaskHistory = NGORequestProcessingHelper.createTaskHistory(TaskStatus.FAILED,
                error.getCode() + "", errorMessage);

        onboardingMerchantRequestTask.getTaskHistory().add(failedTaskHistory);
    }

    private AddressDetails getMerchantAddressDetails(Merchant merchant) {
        Address merchantAddress = merchant.getMerchantAddress();
        AddressDetails addressDetails = new AddressDetails();
        addressDetails.setCountry(lookupService.countryCodeToAlpha2(merchantAddress.getCountryCode()));
        addressDetails.setCity(merchantAddress.getCity());
        addressDetails.setState(StringUtils.isEmpty(merchantAddress.getState()) ?
                merchantAddress.getCity() : merchantAddress.getState());

        return addressDetails;
    }

    private List<RiskConfigRequest.Range> populateRanges(List<Range> blacklistBinRanges) {
        List<RiskConfigRequest.Range> ranges = new ArrayList<>();
        if (CollectionUtils.isEmpty(blacklistBinRanges))
            return ranges;

        ranges = blacklistBinRanges.stream().map(blackListRange -> {
            RiskConfigRequest.Range range = new RiskConfigRequest.Range();
            range.setEnd(blackListRange.getEnd());
            range.setStart(blackListRange.getStart());
            return range;
        }).collect(Collectors.toList());

        return ranges;
    }

    /**
     * generate a list of country codes (2 characters instead of the passed 3
     * chars) compatible with NGenius
     *
     * @param blockedCountries
     * @return
     */
    private List<String> getBlockedCountriesList(List<String> blockedCountries) {
        ArrayList<String> country2CharsCodeList = new ArrayList<>();

        if (CollectionUtils.isEmpty(blockedCountries))
            return country2CharsCodeList;

        blockedCountries.forEach(countryCode -> country2CharsCodeList.add(lookupService.countryCodeToAlpha2(countryCode)));

        return country2CharsCodeList;
    }
    
	/**
	 * @param applicationRequest
	 * @param merchant
	 * @param merchantData
	 */
	private void populateNGOneData(ApplicationRequest applicationRequest, Merchant merchant, MerchantData merchantData) {
		merchantData.setNgOneMerchant(true);  
		populateMPANDetails(merchantData,merchant,applicationRequest);
		MerchantConfig merchantConfig = merchant.getConfigurations();
		merchantData.setMerchantType(merchant.getMerchantType());
		merchantData.setTabToPay(ngOneUtils.isTabToPay(merchant));
		merchantData.setPayByLink(ngOneUtils.isPayByLink(merchant));
		merchantData.setQrPay(ngOneUtils.isPayByQR(merchant));
		merchantData.setSoftpos(ngOneUtils.isSOFTPOS(merchant));
		merchantData.setEcomAuthSystem(merchantConfig.getEcomAuthSystem());
		merchantData.setSoftPosAuthSystem(merchantConfig.getSoftPosAuthSystem());
		if (StringUtils.isEmpty(merchantConfig.getGatewayType()) || merchantConfig.getGatewayType().equals(NGOServiceConstants.NI)) {
			merchantData.setPaymentProcessor(NGOServiceConstants.NETWORK_INTERNATIONAL);}
		else {
			merchantData.setPaymentProcessor(NGOServiceConstants.MPGS);
		}
		merchantData.setPaymentProcessor(merchantConfig.getGatewayType());
	}
	
	private static class NGOServiceConstants{
		private static final String NETWORK_INTERNATIONAL = "NETWORK_INTERNATIONAL";
		private static final String NI = "NI";
		private static final String WAY4_BACKEND_SYSTEM = "WAY4";
	    private static final String MASTERCARD = "MASTERCARD";
		private static final String VISA = "VISA";
		private static final String DATA_MAP = "dataMap";
		private static final String ECOM = "ECOM";
		private static final String MPGS = "MPGS";
	}
 }