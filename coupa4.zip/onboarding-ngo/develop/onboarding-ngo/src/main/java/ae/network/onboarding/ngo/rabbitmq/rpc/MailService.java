package ae.network.onboarding.ngo.rabbitmq.rpc;

public interface MailService {

    /**
     * @param emailAsJson
     */
    void sendHtmlEmail(String emailAsJson);
}