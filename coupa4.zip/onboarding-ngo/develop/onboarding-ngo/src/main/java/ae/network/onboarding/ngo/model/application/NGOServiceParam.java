package ae.network.onboarding.ngo.model.application;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Waseem
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NGOServiceParam extends MerchantService {

    private String organizationName;
    private List<NGOChannel> channels;
    private Map<String, String> currencyLimits;
    private Map<String, List<String>> paymentMethodCurrenciesMap;
    private List<String> propositionServices;
    private boolean enable3DS;
    private MerchantUser user;
    private boolean disableCorporateCards;
    private boolean disablePaymentsNonGGC;
    private List<Range> blacklistBinRanges;
    private List<String> blockedCountries;
} 
