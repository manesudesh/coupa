package ae.network.onboarding.ngo.integration.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */
@Data
@Builder
public class AddPaymentChannelRequest {
	private String currency;
	private String paymentMethod;
	private String name;
	private String paymentProcessor;
	private boolean enabled;
	private List<String> channel;
    private String midRef;

    @JsonProperty("merchantType")
    private int mccCode;
}