package ae.network.onboarding.ngo.service.processor;

import ae.network.onboarding.ngo.database.model.AcquirerConfig;
import ae.network.onboarding.ngo.database.service.AcquirerConfigService;
import ae.network.onboarding.ngo.integration.AccessTokenAcquirer;
import ae.network.onboarding.ngo.integration.model.AuthRequest;
import ae.network.onboarding.ngo.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Optional;

/**
 * @author walid.sewaify
 * @since 2020-09-16
 */
@Service
@Slf4j
public class DryRun {
    private final AcquirerConfigService acquirerConfigService;

    public DryRun(AcquirerConfigService acquirerConfigService) {
        this.acquirerConfigService = acquirerConfigService;
    }

    public ApplicationUpdate process(ApplicationRequest applicationRequest) {

        TaskStatus taskStatus = successfulLogin(applicationRequest.getAcquirer()) ?
                TaskStatus.COMPLETED : TaskStatus.FAILED;
        Task loginTask = new Task();
        loginTask.setName("authenticate-apis");
        loginTask.setTaskStatus(taskStatus);
        ProcessingResult result = ProcessingResult.builder().finalStatus(taskStatus)
                .tasks(Collections.singletonList(loginTask)).build();
        return ApplicationUpdate.builder().applicationId(applicationRequest.getApplicationId())
                .backendSystem(BackendSystem.NGO).processingResult(result).build();
    }

    private boolean successfulLogin(String acquirer) {
        Optional<AcquirerConfig> acquirerConfigOptional = acquirerConfigService.findByName(acquirer);
        if (acquirerConfigOptional.isPresent()) {
            AuthRequest authRequest = acquirerConfigOptional.get().getAuthRequest();
            AccessTokenAcquirer accessTokenAcquirer = new AccessTokenAcquirer();
            try {
                return accessTokenAcquirer.getAccessToken(authRequest) != null;
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                return false;
            }
        }
        return false;
    }
}
