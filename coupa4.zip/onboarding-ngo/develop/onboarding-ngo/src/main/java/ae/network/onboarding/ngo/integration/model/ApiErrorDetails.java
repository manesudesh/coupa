package ae.network.onboarding.ngo.integration.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.ToString;

/**
 * @author walid.sewaify
 * @since 2020-05-07
 */
@Data
@ToString
@JsonIgnoreProperties
public class ApiErrorDetails {
    private String message;
    private String localizedMessage;
    private String errorCode;
    private String domain;
}

