package ae.network.onboarding.ngo.service.processor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import ae.network.onboarding.ngo.database.repository.ApplicationRequestRepository;
import ae.network.onboarding.ngo.model.ApplicationRequest;
import ae.network.onboarding.ngo.model.Task;
import ae.network.onboarding.ngo.model.TaskName;
import ae.network.onboarding.ngo.model.TaskStatus;
import ae.network.onboarding.ngo.model.application.Chain;
import ae.network.onboarding.ngo.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.ngo.rabbitmq.service.RabbitService;
import ae.network.onboarding.ngo.service.ngo.NGORequestHandlingService;
import ae.network.onboarding.ngo.service.ngo.utils.NGORequestProcessingHelper;
import ae.network.onboarding.ngo.validation.NGOValidator;
import ae.network.onboarding.ngo.validation.ValidationResult;
import lombok.extern.slf4j.Slf4j;

/**
 * @author WaseemAARI
 */
@Slf4j
@Service
public class NGORequestProcessor {

    private static final String SUCCESS_CODE = "OK";
    private static final String ERROR_CODE = "ERROR";

    private NGORequestHandlingService ngoRequestHandlingService;
    private NGOValidator ngoValidator;
    private ApplicationRequestRepository applicationRequestRepository;

    private RabbitService rabbitService;

    public NGORequestProcessor(NGORequestHandlingService ngoRequestHandlingService, NGOValidator ngoValidator,
                               ApplicationRequestRepository applicationRequestRepository, RabbitService rabbitService) {

        this.ngoRequestHandlingService = ngoRequestHandlingService;
        this.ngoValidator = ngoValidator;
        this.applicationRequestRepository = applicationRequestRepository;
        this.rabbitService = rabbitService;
    }

    public void processApplication(ApplicationRequest applicationRequest) {

        log.info("Application Request received {})", applicationRequest.getApplicationId());

        ngoRequestHandlingService.handleRequest(applicationRequest);

        log.info("Application {}, Boarded successfully.", applicationRequest.getApplicationId());

        applicationRequestRepository.save(applicationRequest);

        rabbitService.sendMessage(RabbitQueue.UPDATES,
                NGORequestProcessingHelper.createApplicationResponse(applicationRequest));

    }

    public List<ValidationResult> validateRequest(ApplicationRequest applicationRequest) {
    	
        log.info("validateRequest method started for Request : {}", applicationRequest.getApplicationId());
        log.info("RequestType : {}", applicationRequest.getRequestType());
        
        if (applicationRequest.getAcquirer().toUpperCase().contains("TYME")) {
        	applicationRequest.getPayload().getApplications().forEach(application -> updateChain(application.getChain()));        	
        }
        
        ArrayList<ValidationResult> errorsList = new ArrayList<>();
        errorsList.add(ngoValidator.validate(applicationRequest));
        return errorsList;
    }

    public void updateRequestWithValidationStatus(List<ValidationResult> validationResults,
                                                  ApplicationRequest applicationRequest) {

        log.info("updateRequestWithValidationStatus method started for Request : {}",
                applicationRequest.getApplicationId());

        log.info("ValidationResults :\n{}", validationResults);

        boolean validationPassed = validationResults.stream().allMatch(ValidationResult::isPassed);

        Task validationTask = Task.builder().taskStatus(validationPassed ? TaskStatus.COMPLETED : TaskStatus.FAILED)
                .name(TaskName.VALIDATION.name())
                .taskHistory(Arrays.asList(NGORequestProcessingHelper.createTaskHistory(
                        validationPassed ? TaskStatus.COMPLETED : TaskStatus.FAILED,
                        validationPassed ? SUCCESS_CODE : ERROR_CODE, Arrays.toString(validationResults.toArray()))))
                .build();

        if (applicationRequest.getTasks() == null)
            applicationRequest.setTasks(new ArrayList<>());

        applicationRequest.getTasks().add(validationTask);

        log.info("updateRequestWithValidationStatus method completed for Request : {}",
                applicationRequest.getApplicationId());

        applicationRequestRepository.save(applicationRequest);

    }

	private void updateChain(Chain chain) {

		if (chain != null) {

			if (StringUtils.isEmpty(chain.getChainId()))
				chain.setChainId(chain.getChainId2());

			if (StringUtils.isEmpty(chain.getChainName()))
				chain.setChainName(chain.getChainName2());
		}
	}
}