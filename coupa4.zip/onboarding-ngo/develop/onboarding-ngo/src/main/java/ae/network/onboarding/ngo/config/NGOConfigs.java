package ae.network.onboarding.ngo.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Data
@Configuration
@ConfigurationProperties(prefix = "ngo")
public class NGOConfigs {

    private List<String> paymentMethods;
    private List<String> alternativePaymentMethods;
    private List<String> orgUnitServices;
    private List<String> payByQrIds;
    private List<String> payByLinkIds;
    private List<String> tabToPayIds;
}
