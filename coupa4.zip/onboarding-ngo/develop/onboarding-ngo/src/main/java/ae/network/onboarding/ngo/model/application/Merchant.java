package ae.network.onboarding.ngo.model.application;


import ae.network.onboarding.ngo.model.ValidationError;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author Yousry
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Merchant {

	private static final String NGO = "NGO";
	private static final String BRIGHTERION="BRIGHTERION";

	private String merchantId;

    private String merchantName;

    private String merchantType;

    private String website;

    private Integer mcc;

    private String merchantCurrency;
    
    private String outletReference;

    private List<Terminal> terminals;

    private List<Address> addresses;

    private List<MerchantService> services;

    private ArrayList<ValidationError> validationErrors;
    
    private MerchantConfig configurations;
    
    private String businessLine;


    /**
     * get the NGO service parameters
     *
     * @return
     */
    public NGOServiceParam getNGOParams() {

        Optional<MerchantService> servOp = services.stream()
                .filter(merchantService -> NGO.equalsIgnoreCase(merchantService.getServiceType())).findFirst();

        return (NGOServiceParam) servOp.get();

    }

    public Address getMerchantAddress() {

        if (addresses == null || addresses.isEmpty())
            return null;

        Optional<Address> addressOpional = addresses.stream()
                .filter(address -> address.getAddressType().equals(AddressType.DEFAULT)).findFirst();
        return addressOpional.orElseGet(() -> addresses.get(0));

    }

	public boolean isBrighterion() {
		Optional<MerchantService> servOp  = services.stream()
				.filter(merchantService -> BRIGHTERION.equalsIgnoreCase(merchantService.getServiceType())).findFirst();

		if (servOp != null && servOp.isPresent()) {
			return true;
		} else {
			return false;
		}
	}
	
	 /**
     * get the BRIGHTERION service parameters
     *
     * @return
     */
    public BrighterionServiceParam getBrighterionParams() {

    	if(!isBrighterion()) {
    		return null;
    	}
    	
        Optional<MerchantService> servOp = services.stream()
                .filter(merchantService -> BRIGHTERION.equalsIgnoreCase(merchantService.getServiceType())).findFirst();

        return (BrighterionServiceParam) servOp.get();
    }
}
