package ae.network.onboarding.ngo.model.application;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class MerchantConfig {


	//@NASSC-2762
	@Builder.Default
	private String ecomAuthSystem = "MPGS";
	
	@Builder.Default
	private String softPosAuthSystem ="MPGS";
	
	private String gatewayType;
	
}
