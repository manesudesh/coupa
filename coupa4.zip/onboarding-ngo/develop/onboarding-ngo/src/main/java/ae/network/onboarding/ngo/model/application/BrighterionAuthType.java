package ae.network.onboarding.ngo.model.application;

public enum BrighterionAuthType {
	Both,PreAuth,PostAuth;
}
