package ae.network.onboarding.ngo.integration.model;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */
public enum Channel {
	Ecom,ECOM, MoTo,MOTO, App,APP, STATIC_QR,USSD,POS;	
	
}
