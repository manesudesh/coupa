package ae.network.onboarding.ngo.integration.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EnableMPGSRequest {

	private String midReference;
	private String apiKey;
	private String subDomain;
}
