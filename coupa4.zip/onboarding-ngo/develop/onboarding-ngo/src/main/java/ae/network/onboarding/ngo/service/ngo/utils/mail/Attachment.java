package ae.network.onboarding.ngo.service.ngo.utils.mail;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.io.Serializable;

/**
 * @author walid.sewaify
 * @since 2020-05-14
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Attachment implements Serializable {
    private String fileName;

    private String contentType;

    private byte[] content;
}
