package ae.network.onboarding.ngo.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import ae.network.onboarding.ngo.model.application.OnboardingRequest;
import ae.network.onboarding.ngo.rabbitmq.message.QueueMessage;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Document(collection = "ngo_request")
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationRequest implements QueueMessage {

    @Id
    private String id;

    /**
     * Partner acquirer
     */
    @NotNull(message = "acquirer can not be null.")
    private String acquirer;

    /**
     * Request type (Create-update-close)
     */
    @JsonProperty(required = true)
    private RequestType requestType;

    /**
     * unique global id
     */
    @NotNull(message = "applicationId can not be null.")
    private String applicationId;

    /**
     * acquirer request id (unique across each acquirer)
     */
    @NotNull(message = "requestId can not be null.")
    private String requestId;

    /**
     * application content
     */
    @NotNull(message = "Payload can not be null.")
    @Valid
    private OnboardingRequest payload;

    /**
     * enable dry run
     */
    private boolean dryRun;

    private Collection<Task> tasks = new ArrayList<Task>();
    
    private Map<String, AdditionalData> additionalDataMap = new HashMap<>();
}
