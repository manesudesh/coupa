package ae.network.onboarding.ngo.integration.model;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */
public interface AuthRequest {
    String getRealmName();

    String getBaseUrl();
}
