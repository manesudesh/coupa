package ae.network.onboarding.ngo.service.ngo.utils;

import ae.network.onboarding.ngo.config.DinersConfig;
import ae.network.onboarding.ngo.config.FreeMarkerConfig;
import ae.network.onboarding.ngo.database.model.MerchantExecution;
import ae.network.onboarding.ngo.database.repository.MerchantExecutionRepository;
import ae.network.onboarding.ngo.rabbitmq.rpc.MailService;
import ae.network.onboarding.ngo.service.ngo.utils.mail.Attachment;
import ae.network.onboarding.ngo.service.ngo.utils.mail.Email;
import com.fasterxml.jackson.databind.ObjectMapper;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Slf4j
@ConditionalOnProperty(prefix = "ngo.diners", name = "enabled")
@EnableScheduling
@Component
@AllArgsConstructor
public class NGOEmailSenderJob {

    private static final String SUBJECT = "Diners 3DS enrollment";

    private MerchantExecutionRepository merchantExecutionRepository;
    private NGOExcelFileHelper ngoExcelFileHelper;
    private DinersConfig dinersConfig;
    private MailService mailService;
    private FreeMarkerConfig freeMarkerConfig;

    @Scheduled(cron = "${ngo.diners.cron.file-export-time}")
    public void loadMerchantExecutionsAndSendEmail() throws Exception {

        log.info("Loading Merchant Executions from Repository");

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        Date from = cal.getTime();

        cal.add(Calendar.DATE, 1);
        Date to = cal.getTime();

        List<MerchantExecution> dinersExecutions = merchantExecutionRepository
                .findByCreatedDateBetweenAndSendEmail(from, to, true);

        if (dinersExecutions == null || dinersExecutions.isEmpty()) {
            log.info("No Merchant Diners available");
            return;
        }

        String emailContent = getEmailContent();

        Email email = buildEmailObject(ngoExcelFileHelper.exportMerchantExcel(dinersExecutions),
                ngoExcelFileHelper.getCurrentExcelFile(), dinersConfig.getAttachmentContentType(),
                dinersConfig.getEmailFrom(), emailContent, dinersConfig.getToList(), dinersConfig.getCcList());


        mailService.sendHtmlEmail(new ObjectMapper().writeValueAsString(email));

        dinersExecutions.forEach(merchantExecution -> {
            merchantExecution.setDiners3ds(true);
            merchantExecutionRepository.save(merchantExecution);
        });

    }

    private Email buildEmailObject(byte[] excelFileContent, String currentExcelFile, String contentType, String from,
                                   String emailContent, List<String> toList, List<String> ccList) {

        Email email = new Email();
        Attachment attachment = new Attachment();
        ArrayList<Attachment> attachments = new ArrayList<Attachment>();
        attachments.add(attachment);
        attachment.setContent(excelFileContent);
        attachment.setFileName(currentExcelFile);
        attachment.setContentType(contentType);
        email.setAttachments(attachments);
        email.setFrom(from);
        email.setTo(toList);
        email.setCc(ccList);
        email.setEmailContent(emailContent);
        email.setSubject(SUBJECT);
        return email;
    }

    private String getEmailContent() throws IOException, TemplateException {

        Template template = freeMarkerConfig.freeMarkerConfigurer().getTemplate("email_content.ftl");

        StringWriter stringWriter = new StringWriter();
        template.process(new Object(), stringWriter);
        return stringWriter.toString();


    }
}
