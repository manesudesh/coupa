package ae.network.onboarding.ngo.integration;

import ae.network.onboarding.ngo.integration.model.*;
import org.springframework.web.bind.annotation.*;

/**
 * @author walid.sewaify
 * @since 2020-05-05
 */
public interface ApiClient {

    @GetMapping("/config/tenants/{tenantRef}/merchants")
    ItemsResponse findByChainId(@PathVariable("tenantRef") String tenantReference, @RequestParam("chainId") String chainId);

    @GetMapping("/config/merchants/{merchantRef}/configs/chainIds")
    ItemsResponse findChainRef(@PathVariable("merchantRef") String merchantReference);

    @PostMapping("/config/tenants/{tenantRef}/merchants")
    ReferenceResponse addMerchantOrganization(@PathVariable("tenantRef") String tenantReference,
                                              MerchantOrganizationRequest request);

    @PostMapping("/config/merchants/{merchantRef}/organisation-units")
    ReferenceResponse addMerchantUnit(@PathVariable("merchantRef") String merchantReference,
                                      MerchantOrganizationRequest request);

    @PutMapping("/config/merchants/{merchantRef}/configs/details")
    void addMerchantDetails(@PathVariable("merchantRef") String merchantReference,
                            MerchantDetailsRequest detailsRequest);

    @PostMapping("/config/organisation-units/{merchantUnitRef}/outlets")
    ReferenceResponse addMerchantOutlet(@PathVariable("merchantUnitRef") String merchantUnitRef,
                                        MerchantOrganizationRequest request);


    @PutMapping("/risk/tenants/{tenantRef}/merchants/{merchantRef}/configs/amount-limits")
    void setAmountLimits(@PathVariable("tenantRef") String tenantReference,
                         @PathVariable("merchantRef") String merchantReference, AmountLimitsRequest request);

    @PutMapping("/risk/organisation-units/{orgUnitReference}/configs/amount-limits")
    void setAmountLimitsAtOrgUnit(@PathVariable("orgUnitReference") String orgUnitReference, 
    					AmountLimitsRequest request);
    
    @PostMapping("/config/merchants/{merchantRef}/configs/chainIds")
    ReferenceResponse addChainId(@PathVariable("merchantRef") String merchantReference, AddChainIdRequest request);

    @PostMapping("/config/merchants/{merchantRef}/configs/chainIds/{chainRef}/mids")
    ReferenceResponse addMidToChain(@PathVariable("merchantRef") String merchantReference,
                                    @PathVariable("chainRef") String chainReference, AddMidToChainRequest request);

    @PostMapping("/config/merchants/{merchantRef}/configs/mids/{midRef}/tids")
    ItemsResponse addTidToMid(@PathVariable("merchantRef") String merchantReference,
                              @PathVariable("midRef") String midRef, AddTidToMidRequest request);

    @PutMapping("/config/outlets/{outletRef}/merchant-terminal-details")
    void addTidOutlet(@PathVariable("outletRef") String outletRef, AddTidToOutletRequest request);

    @PostMapping("/config/merchants/{merchantRef}/configs/accounts")
    void addPaymentChannel(@PathVariable("merchantRef") String merchantReference, AddPaymentChannelRequest request);

    @PutMapping("/config/merchants/{merchantRef}/configs/proposition-services/{serviceName}/enable")
    void enableServiceMerchantLevel(@PathVariable("merchantRef") String merchantReference,
                                    @PathVariable("serviceName") String serviceName, EnableRequest body);

    @PutMapping("/config/organisation-units/{merchantUnitRef}/configs/proposition-services/{serviceName}/enable")
    void enableServiceOrgLevel(@PathVariable("merchantUnitRef") String merchantUnitRef,
                               @PathVariable("serviceName") String serviceName, EnableRequest body);

    @PutMapping("/config/merchants/{merchantRef}/configs/3ds/enable")
    void enable3DS(@PathVariable("merchantRef") String merchantReference, EnableRequest body);
    
    //NASSC-2500 start
    @PutMapping("/config/merchants/{merchantRef}/configs/3ds2/enable")
    void enable3DS2(@PathVariable("merchantRef") String merchantReference, EnableRequest body);
    //NASSC-2500 end

    @PostMapping("/identity/merchants/{merchantRef}/users")
    void addUser(@PathVariable("merchantRef") String merchantReference, AddUserRequest request);

    @PutMapping("/risk/merchants/{merchantRef}/configs/gatewayrisk")
    void configRiskRules(@PathVariable("merchantRef") String merchantReference, RiskConfigRequest request);
    
    @PutMapping("/risk/organisation-units/{orgUnitReference}/configs/gatewayrisk")
    void configRiskRulesAtOrgUnit(@PathVariable("orgUnitReference") String orgUnitReference, RiskConfigRequest request);

    @PostMapping("/config/merchants/{merchantRef}/configs/accounts/cup")
    void addUnionPayAccountMerchantLevel(@PathVariable("merchantRef") String merchantRef, UnionPayRequest request);

    @PostMapping("/risk/merchants/{merchantRef}/lists/countryBlacklist")
    void blockCountry(@PathVariable("merchantRef") String merchantReference, BlockCountryRequest request);

    @PostMapping("/risk/organisation-units/{orgUnitReference}/lists/countryBlacklist")
    void blockCountryAtOrgUnit(@PathVariable("orgUnitReference") String orgUnitReference, BlockCountryRequest request);

    @PostMapping("/risk/tenants/{tenantRef}/merchants/{merchantRef}/lists/countryBlacklist")
    void blockTenantCountry(@PathVariable("tenantRef") String tenantReference,
    						@PathVariable("merchantRef") String merchantReference, BlockCountryRequest request);
    
    @PutMapping("/config/merchants/{merchantRef}/configs/email-notification-settings")
    void addNotificationEmail(@PathVariable("merchantRef") String merchantReference, NotificationEmailRequest request);
    
    @PostMapping("/config/merchants/{merchantRef}/configs/merchant-pan")
    void addMerchantMPAN(@PathVariable("merchantRef") String merchantReference,MerchantMPANRequest request);
    
    @PutMapping("/config/merchants/{merchantRef}/configs/proposition-services/mpgs-routing/enable")
    void enableMPGSRouting(@PathVariable("merchantRef") String merchantReference, EnableRequest body);
    
    @PostMapping("/config/merchants/{merchantRef}/configs/mpgs")
    void enableMPGS(@PathVariable("merchantRef") String merchantReference, EnableMPGSRequest body);
    
}
