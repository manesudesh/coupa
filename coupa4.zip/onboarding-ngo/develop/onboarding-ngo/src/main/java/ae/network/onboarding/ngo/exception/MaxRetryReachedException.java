package ae.network.onboarding.ngo.exception;

/**
 * @author walid.sewaify
 * @since 2020-01-26
 */
public class MaxRetryReachedException extends MessageRejectionException {
    public MaxRetryReachedException(String applicationId) {
        super(applicationId, "Maximum retries reached");
    }
}
