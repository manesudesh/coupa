package ae.network.onboarding.ngo.integration.model;

import lombok.Data;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */
@Data
public class ReferenceResponse {
    private String reference;
}
