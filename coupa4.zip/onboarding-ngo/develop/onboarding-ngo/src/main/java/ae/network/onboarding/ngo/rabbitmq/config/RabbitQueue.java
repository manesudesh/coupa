package ae.network.onboarding.ngo.rabbitmq.config;

import java.util.Arrays;
import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
public enum RabbitQueue {
    // Working Queue
    NGO("ngo", "routing.backend.integration"),
    // RPC Queues
    UTILS("utils", "routing.utils"),
    // Reply Queue
    UPDATES("updates", "routing.updates");

    private final String queueName;
    private final String[] routingKeys;

    RabbitQueue(String queueName, String... routingKeys) {
        this.queueName = queueName;
        this.routingKeys = routingKeys;
    }

    public String getQueueName() {
        return queueName;
    }

    public List<String> getRoutingKeys() {
        return Arrays.asList(routingKeys);
    }
}
