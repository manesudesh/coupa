package ae.network.onboarding.ngo.integration.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Map;

/**
 * @author walid.sewaify
 * @since 2020-05-06
 */
@Data
@AllArgsConstructor
public class AmountLimitsRequest {
    private Map<String, Integer> amountLimits;
}
