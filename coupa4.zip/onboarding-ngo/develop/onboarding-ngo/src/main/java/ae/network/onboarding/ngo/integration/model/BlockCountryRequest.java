package ae.network.onboarding.ngo.integration.model;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author walid.sewaify
 * @since 2021-02-07
 */
@Data
@AllArgsConstructor
public class BlockCountryRequest {
    private String value;
}
