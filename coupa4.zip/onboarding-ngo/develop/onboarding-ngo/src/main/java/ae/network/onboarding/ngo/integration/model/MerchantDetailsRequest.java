package ae.network.onboarding.ngo.integration.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import static ae.network.onboarding.ngo.common.TextUtils.truncate;

/**
 * @author walid.sewaify
 * @since 2020-11-01
 */
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MerchantDetailsRequest {
    private String name;
    private String groupName;
    private String companyUrl;
    private AddressDetails addressDetails;
    private ContactDetails contactDetails;

    public String getName() {
        return truncate(name, 50);
    }

    public String getGroupName() {
        return truncate(groupName, 50);
    }
}
