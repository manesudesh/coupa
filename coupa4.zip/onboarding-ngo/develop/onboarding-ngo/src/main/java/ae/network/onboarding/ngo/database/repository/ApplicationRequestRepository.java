package ae.network.onboarding.ngo.database.repository;

import ae.network.onboarding.ngo.model.ApplicationRequest;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;


public interface ApplicationRequestRepository extends MongoRepository<ApplicationRequest, String> {

    Optional<ApplicationRequest> findFirstByApplicationId(String applicationId);
    Optional<ApplicationRequest> findByApplicationId(String applicationId);
}
