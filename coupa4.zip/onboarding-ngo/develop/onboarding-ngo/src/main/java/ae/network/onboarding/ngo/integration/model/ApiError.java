package ae.network.onboarding.ngo.integration.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.ToString;

import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-05-07
 */
@Data
@ToString
@JsonIgnoreProperties
public class ApiError {
    private String message;
    private int code;
    private List<ApiErrorDetails> errors;
    @JsonIgnore
    private List<ApiTask> completedTasks;
    @JsonIgnore
    private ApiTask failedTask;
}
