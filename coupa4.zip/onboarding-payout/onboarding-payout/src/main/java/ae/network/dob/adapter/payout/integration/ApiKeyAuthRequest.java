package ae.network.dob.adapter.payout.integration;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApiKeyAuthRequest implements AuthRequest {
    private String realmName;
    @JsonIgnore
    private String apiKey;
    @JsonIgnore
    private String baseUrl;
}