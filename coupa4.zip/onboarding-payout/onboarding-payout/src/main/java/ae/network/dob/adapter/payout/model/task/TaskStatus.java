package ae.network.dob.adapter.payout.model.task;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public enum TaskStatus {
    COMPLETED, PARTIALLY_COMPLETED, FAILED, CANCELLED
}
