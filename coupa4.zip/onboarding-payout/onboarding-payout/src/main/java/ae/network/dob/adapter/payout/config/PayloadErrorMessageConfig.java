package ae.network.dob.adapter.payout.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import ae.network.dob.adapter.payout.model.errors.AdapterError;
import lombok.Data;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Component
@Data
@EnableConfigurationProperties



@ConfigurationProperties(prefix = "errormessages")
public class PayloadErrorMessageConfig {

    private List<AdapterError> messages = new ArrayList<AdapterError>();

}
