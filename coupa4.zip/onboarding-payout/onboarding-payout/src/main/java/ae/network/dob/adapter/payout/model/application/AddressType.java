package ae.network.dob.adapter.payout.model.application;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public enum AddressType {
    DEFAULT, STMT_ADDR, PAYM_ADDR, CORRESPONDING, TRADING, 
    BIZZ
}
