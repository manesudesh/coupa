package ae.network.dob.adapter.payout.api.db;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import ae.network.dob.adapter.payout.api.response.APIResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchAPIData {
	
	private String payoutId;
	private APIResponse apiResponse;
}
