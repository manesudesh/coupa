package ae.network.dob.adapter.payout.model.application.payout;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class FeeParameter {
	 private Integer maximumApplicableFee;
	 private Integer minimumApplicableFee;
	 private Integer transactionFeePercentage;
	 private Integer subscriptionFee;
	 private Integer fixedFeeValue;
	 private String recoveryFrequency;
}
