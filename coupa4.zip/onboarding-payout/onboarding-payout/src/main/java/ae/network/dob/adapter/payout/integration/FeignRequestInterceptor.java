package ae.network.dob.adapter.payout.integration;

import org.springframework.cloud.security.oauth2.client.feign.OAuth2FeignRequestInterceptor;
import org.springframework.security.oauth2.client.DefaultOAuth2ClientContext;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordResourceDetails;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;

import feign.RequestTemplate;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public class FeignRequestInterceptor extends OAuth2FeignRequestInterceptor {
    private static final String IDENTITY_CONTENT_TYPE = "application/vnd.ni-identity.v1+json";
    private static final String CONFIG_CONTENT_TYPE = "application/vnd.ni-config.v1+json";
    private static final String RISK_CONTENT_TYPE = "application/vnd.ni.gateway-risk.v1+json";

    private final AuthRequest authRequest;

    private OAuth2AccessToken accessToken;

    public FeignRequestInterceptor(AuthRequest authRequest) {
        super(new DefaultOAuth2ClientContext(), new ResourceOwnerPasswordResourceDetails());
        this.authRequest = authRequest;
    }

    @Override
    public OAuth2AccessToken getToken() {
        if (accessToken == null) {
            AccessTokenAcquirer accessTokenAcquirer = new AccessTokenAcquirer();
            accessToken = new DefaultOAuth2AccessToken(accessTokenAcquirer.getAccessToken(authRequest));
        }
        return accessToken;
    }

    @Override
    public void apply(RequestTemplate template) {
        super.apply(template);
        String contentType = "Content-Type";
        String url = template.request().url();
        if (url.startsWith("/identity")) {
            template.removeHeader(contentType);
            template.header(contentType, IDENTITY_CONTENT_TYPE);
        } else if (url.startsWith("/config")) {
            template.removeHeader(contentType);
            template.header(contentType, CONFIG_CONTENT_TYPE);
        } else if (url.startsWith("/risk")) {
            template.removeHeader(contentType);
            template.header(contentType, RISK_CONTENT_TYPE);
        }
    }
}
