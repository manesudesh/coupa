package ae.network.dob.adapter.payout.integration;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
public class AuthResponse {
    @JsonProperty("access_token")
    private String accessToken;
}
