package ae.network.dob.adapter.payout.service.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import ae.network.dob.adapter.payout.api.db.APIData;
import ae.network.dob.adapter.payout.api.response.APIResponse;
import ae.network.dob.adapter.payout.model.application.Merchant;
import ae.network.dob.adapter.payout.model.application.payout.Participant;
import ae.network.dob.adapter.payout.model.reply.ApplicationUpdate;
import ae.network.dob.adapter.payout.model.reply.ProcessingResult;
import ae.network.dob.adapter.payout.model.reply.ValidationError;
import ae.network.dob.adapter.payout.model.request.ApplicationRequest;
import ae.network.dob.adapter.payout.model.task.AdditionalData;
import ae.network.dob.adapter.payout.model.task.BackendSystem;
import ae.network.dob.adapter.payout.model.task.Task;
import ae.network.dob.adapter.payout.model.task.TaskHistory;
import ae.network.dob.adapter.payout.model.task.TaskName;
import ae.network.dob.adapter.payout.model.task.TaskStatus;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Service
public class ProcessingHelper {
	
    public ProcessingHelper() {
        super();
    }

    public Task createTask(TaskName taskName, TaskStatus status) {
		Task task = Task.builder()
        .name(taskName.name())
        .taskStatus(status)
        .taskHistory(new ArrayList<TaskHistory>())
        .build();
		return task;
	}
    
	public TaskHistory createTaskHistory(TaskStatus status, String response, String statusCode) {
        TaskHistory taskHistory = new TaskHistory();
        final Date now = new Date();
        taskHistory.setCreatedDate(now);
        taskHistory.setLastModifiedDate(now);
        taskHistory.setTaskStatus(status);
        taskHistory.setResponse(response);
        taskHistory.setStatusCode(statusCode);
        return taskHistory;
    }
	    
	public Task assignValidationErrorTaskHistory(Collection<ValidationError> validationErrors, Task task) {
		List<TaskHistory> taskHistoryList = validationErrors.stream().map(
					e->  createTaskHistory(task.getTaskStatus(), e.getFieldName() + " : " + e.getErrorMessage(), e.getErrorCode()) )
				.collect(Collectors.toList());
        task.setTaskHistory(taskHistoryList);
        return task;
	}

	public static ApplicationUpdate createApplicationResponse(ApplicationRequest applicationRequest) {
    	AdditionalData additionalData = createAdditionalDataMap(applicationRequest); 
        return ApplicationUpdate.builder().applicationId(applicationRequest.getApplicationId())
                .backendSystem(BackendSystem.PAYOUT)
                .additionalData(additionalData)
                .processingResult(ProcessingResult.builder().finalStatus(calculateFinalStatus(applicationRequest))
                        .tasks(applicationRequest.getTasks()).build())
                .build();
    }
	
    public Task handleAPIResponseTask(APIResponse apiResponse, TaskName taskName, String participantId) {
    	Task task;
    	if( apiResponse != null && apiResponse.getMessage() != null && apiResponse.getMessage().equalsIgnoreCase("success") )
        {
    		task = createTask(taskName, TaskStatus.COMPLETED);
 			task.getTaskHistory().add(createTaskHistory(TaskStatus.COMPLETED, "API Response success for Participant Id "+participantId, "OK") ) ;

        } else 
        {
        	task =	createTask(taskName, TaskStatus.FAILED);
            task.getTaskHistory().add(createTaskHistory(TaskStatus.COMPLETED, "API Response Fail "+apiResponse.getMessage()+" for participantId "+participantId, "FAILED") ) ;
        } 
    	return task;
    }
    
    public void handleAPIDataTask(APIData apiData, ApplicationRequest entity, TaskName taskName, String participantId) {
    	if(apiData != null )
    	{
    		if(apiData.getCreateUpdateAPIData() != null && apiData.getCreateUpdateAPIData().getApiResponse() != null)
    		{
    			entity.getTasks().add (  handleAPIResponseTask(apiData.getCreateUpdateAPIData().getApiResponse(), TaskName.RECEIVE_API_CREATEUPDATE_RESPONSE, participantId) );
    			if("success" == apiData.getCreateUpdateAPIData().getApiResponse().getMessage() ) {
    				Task taskReq = createTask(taskName, TaskStatus.COMPLETED );
    		        taskReq.getTaskHistory().add( createTaskHistory(TaskStatus.COMPLETED, " ParticipantId : "+participantId +" "+taskName, "OK") );
    		        entity.getTasks().add(taskReq);
    			}
    		}
    	}
    }
    
	/**
    * @param applicationRequest
    * @return
    */
    public static TaskStatus calculateFinalStatus(ApplicationRequest applicationRequest) {
       Collection<Task> tasks = applicationRequest.getTasks().stream()
               .filter(task -> !"VALIDATION".equalsIgnoreCase(task.getName())).collect(Collectors.toList());
       if (tasks.stream().allMatch(task -> task.getTaskStatus().equals(TaskStatus.FAILED))) {
           return TaskStatus.FAILED;
       } else if (tasks.stream()
               .allMatch(task -> (task.getTaskStatus().equals(TaskStatus.COMPLETED)
                       || task.getTaskStatus().equals(TaskStatus.CANCELLED)))) {
           return TaskStatus.COMPLETED;
       } else {
           return TaskStatus.PARTIALLY_COMPLETED;
       }
    }
	
   /**
    * @param applicationRequest
    * @return
    */
	private static AdditionalData createAdditionalDataMap(ApplicationRequest applicationRequest) {
		AdditionalData additionalData = new AdditionalData();
		applicationRequest.getPayload().getApplications().forEach(application -> {
			if (!StringUtils.isEmpty(application.getParticipant())) {
				additionalData.setDataMap(application.getParticipant().getParticipantId(),
						application.getParticipant().getParticipantDBAName());
			}

		});

		return additionalData;
	}
    
    /**
	 * @param applicationRequest
	 * @return
	 */
	public List<Merchant> getValidMerchants(ApplicationRequest applicationRequest) {
    	List<Merchant> merchants = (List<Merchant>) applicationRequest.getPayload().getApplications().stream()
                .flatMap(app -> app.getMerchants().stream())
                .collect(Collectors.toList());
    	return merchants; 
    }
	
	public List<Merchant> getValidAmendmentMerchants(ApplicationRequest applicationRequest) {
    	List<Merchant> merchants = (List<Merchant>) applicationRequest.getPayload().getApplications().stream()
                .flatMap(app -> app.getMerchants().stream())
                .collect(Collectors.toList());
    	return merchants; 
    }
	
	public List<Participant> getValidParticipant(ApplicationRequest entity) {
        List<Participant> participantList = (List<Participant>) entity.getPayload().getApplications().stream()
                .map(app -> app.getParticipant())
                .collect(Collectors.toList());
		return participantList;
	}
}
