package ae.network.dob.adapter.payout.rabbitmq.service;

import org.springframework.amqp.core.Message;

import ae.network.dob.adapter.payout.rabbitmq.config.RabbitQueue;
import ae.network.dob.adapter.payout.rabbitmq.message.QueueMessage;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public interface RabbitService {
    /**
     * Send a message to exchange queue that is stored in JSON format
     *
     * @param queue   receiving queue
     * @param message content
     */
    void sendMessage(RabbitQueue queue, QueueMessage message);

    /**
     * retry sending message to same queue after a period of time
     *
     * @param message original message
     * @param seconds time in seconds
     */
    void retryMessage(Message message, int seconds);
}
