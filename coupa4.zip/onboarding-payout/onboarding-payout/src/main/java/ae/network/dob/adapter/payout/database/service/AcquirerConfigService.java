package ae.network.dob.adapter.payout.database.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ae.network.dob.adapter.payout.database.AcquirerConfig;
import ae.network.dob.adapter.payout.database.repository.AcquirerConfigRepository;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Service
@NoArgsConstructor
@AllArgsConstructor
public class AcquirerConfigService {

	@Autowired private AcquirerConfigRepository repository;
	
	public Optional<AcquirerConfig> findByName(String name) {
        return repository.findByName(name);
    }
}
