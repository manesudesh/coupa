package ae.network.dob.adapter.payout.model.task;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public enum TaskName {
    VALIDATION,
    SEND_APP_REQUEST,
    RECEIVE_API_CREATEUPDATE_RESPONSE,
    RECEIVE_API_APPROVE_RESPONSE,
    ONBOARDING_PAYOUT,
    AMENDMENT_PAYOUT
}
