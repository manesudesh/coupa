package ae.network.dob.adapter.payout.api.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@SuperBuilder
@JsonIgnoreProperties(ignoreUnknown = true)
public class APICreateUpdateRequest extends APIRequest implements Serializable {
    
//    @JsonProperty(required = true)
//    private APIPayout apiPayout;
}
