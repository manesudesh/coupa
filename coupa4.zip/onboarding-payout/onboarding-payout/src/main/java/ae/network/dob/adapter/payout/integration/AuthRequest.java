package ae.network.dob.adapter.payout.integration;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public interface AuthRequest {
    String getRealmName();

    String getBaseUrl();
}
