package ae.network.dob.adapter.payout.model.application;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Chain {

    @NotNull
    private String chainId;
    
    private String chainName;

    private String groupCode;
    
    private String chainLevelReportRequired;
    
    private String groupLevelReportingRequired;
	
    private boolean alreadyExist;
    
    private String organizationName;
}
