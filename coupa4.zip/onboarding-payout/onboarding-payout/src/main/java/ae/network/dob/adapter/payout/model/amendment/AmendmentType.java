package ae.network.dob.adapter.payout.model.amendment;

import java.util.stream.Stream;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public enum AmendmentType {
    MERCHANT_NAME,
    LEGAL_NAME,
    MCC,
    ADDRESS,
    COUNTRY_ORIGIN;
    
    public static boolean isAmendmentType(String amendStr) {
        return Stream.of(AmendmentType.values()).anyMatch(a -> a.toString().equals(amendStr)); 
    }
}
