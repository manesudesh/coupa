package ae.network.dob.adapter.payout.integration;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import ae.network.dob.adapter.payout.model.application.payout.Participant;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@FeignClient
public interface APIFeignClient {
	
	@PostMapping("/tenants/{tenantRef}/payout-participants")
	void createPayout(@PathVariable String tenantRef, Participant reqBody);
	
	@PutMapping("/tenants/{tenantRef}/payout-participants")
	void amendPayout(@PathVariable String tenantRef, Participant reqBody);
	}
