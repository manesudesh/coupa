package ae.network.dob.adapter.payout.database;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import ae.network.dob.adapter.payout.integration.ApiKeyAuthRequest;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString(includeFieldNames = true)
@Document(collection = "ngo_acquirerConfig")
public class AcquirerConfig {
    @Id
    private String name;
    private String acquirerId;
    private String tenantReference;
    private String merchantUserRole;
    private ApiKeyAuthRequest authRequest;
}
