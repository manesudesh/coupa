package ae.network.dob.adapter.payout.model.application;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public enum ActionType {
    Add, Update, AddOrUpdate, CLOSURE
}