package ae.network.dob.adapter.payout.model.application;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OnboardingRequest {

    @NotEmpty(message = "applications can not be empty")
    @Valid
    private List<Application> applications;
}
