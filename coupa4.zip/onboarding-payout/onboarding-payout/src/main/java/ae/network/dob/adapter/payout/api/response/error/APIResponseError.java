package ae.network.dob.adapter.payout.api.response.error;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class APIResponseError implements Serializable{
	@JsonProperty("Missing Mandatory Fields")
	private List<String> missing_mandatory_fields;

	@JsonProperty("Length Check Failures")
	private List<String> length_check_failures;
		 
	@JsonProperty("Format Check Failures")
	private List<String> format_check_failures;
		 
	@JsonProperty("Onboarding Check Failures")
	private List<String> onboarding_check_failures;
		 
	private String message;
	
	private int code;
		 
}
