package ae.network.dob.adapter.payout.service.validate;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public interface ValidationRule<T> {
    ValidationResult validate(T entity);
}
