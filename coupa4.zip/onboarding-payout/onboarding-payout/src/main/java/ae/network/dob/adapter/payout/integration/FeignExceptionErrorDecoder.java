package ae.network.dob.adapter.payout.integration;

import java.io.Reader;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.io.CharStreams;

import ae.network.dob.adapter.payout.api.response.APIResponse;
import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Sudesh_Mane
 * @since

 * Wrap API error into IntegrationException
 */

@Slf4j
@Service
public class FeignExceptionErrorDecoder implements ErrorDecoder {

	@Override
    public Exception decode(String methodKey, Response response) {
		
        try {
        	Reader reader = response.body().asReader();
			String responseContent = CharStreams.toString(reader);
            log.error("error response {}", responseContent);
            APIResponse apIResponseError = new ObjectMapper().readValue(responseContent, APIResponse.class);
            apIResponseError.getErrors().setCode(response.status());
            return new IntegrationException(apIResponseError.getErrors());
        } catch (Exception e) {
            log.error("Could not wrap API error", e);
            return new Exception();
        }
    }
}
