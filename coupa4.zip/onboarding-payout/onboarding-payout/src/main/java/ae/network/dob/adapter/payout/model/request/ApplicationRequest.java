package ae.network.dob.adapter.payout.model.request;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import ae.network.dob.adapter.payout.api.db.APIData;
import ae.network.dob.adapter.payout.model.AbstractAuditingEntity;
import ae.network.dob.adapter.payout.model.application.OnboardingRequest;
import ae.network.dob.adapter.payout.model.task.Task;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@NoArgsConstructor
@Data
@ToString(includeFieldNames = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "payout_request")
public class ApplicationRequest extends AbstractAuditingEntity {

    @Id
    private String id;

    @NotNull(message = "acquirer can not be null.")
    private Acquirer acquirer;

    @JsonProperty(required = true)
    private RequestType requestType;

    @NotNull(message = "applicationId can not be null.")
    private String applicationId;

    @NotNull(message = "requestId can not be null.")
    private String requestId;

    @NotNull(message = "Payload can not be null.")
    @Valid
    private OnboardingRequest payload;

    private boolean dryRun;
    
    private Collection<APIData> apiDatas = new ArrayList<APIData>();
    
    private Collection<Task> tasks = new ArrayList<Task>();
    
    private boolean skipCallback;
    
}
