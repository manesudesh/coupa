package ae.network.dob.adapter.payout.config;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Component
@Data
@ConfigurationProperties(prefix = "payout")
public class APIConfig {
	
	private Map<String, ServiceConfig> apiConfig;
	
	@Data
	@Component
	public static class ServiceConfig {
		private String url;
		private String userName;
		private String userPass;
	    
	}
}
