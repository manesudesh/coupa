package ae.network.dob.adapter.payout.api.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.experimental.SuperBuilder;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@SuperBuilder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class APIRequest {

	
}
