package ae.network.dob.adapter.payout.model.task;

import ae.network.dob.adapter.payout.rabbitmq.config.RabbitQueue;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public enum BackendSystem {
    PAYOUT(RabbitQueue.PAYOUT);

    private final RabbitQueue rabbitQueue;

    BackendSystem(RabbitQueue rabbitQueue) {
        this.rabbitQueue = rabbitQueue;
    }

    public RabbitQueue getRabbitQueue() {
        return rabbitQueue;
    }
}
