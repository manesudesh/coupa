package ae.network.dob.adapter.payout.model.reply;

import lombok.Builder;
import lombok.Data;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@Builder
public class ValidationError {
    private String fieldName;
    private String errorMessage;
    private String errorCode;
}
