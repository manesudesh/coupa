package ae.network.dob.adapter.payout.model;

import static ae.network.dob.adapter.payout.common.DateFormat.FORMAT;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
public abstract class AbstractAuditingEntity implements Serializable {
    @CreatedDate
    @JsonFormat(pattern = FORMAT)
    @DateTimeFormat(pattern = FORMAT)
    private Date createdDate = new Date();
    @LastModifiedDate
    @JsonFormat(pattern = FORMAT)
    @DateTimeFormat(pattern = FORMAT)
    private Date lastModifiedDate = new Date();
}