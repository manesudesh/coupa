package ae.network.dob.adapter.payout.rabbitmq.consumer;

import java.util.Collection;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.dob.adapter.payout.model.reply.ValidationError;
import ae.network.dob.adapter.payout.model.request.ApplicationRequest;
import ae.network.dob.adapter.payout.model.request.RequestType;
import ae.network.dob.adapter.payout.model.task.BackendSystem;
import ae.network.dob.adapter.payout.rabbitmq.config.RabbitQueue;
import ae.network.dob.adapter.payout.rabbitmq.service.RabbitService;
import ae.network.dob.adapter.payout.service.RequestProcessor;
import ae.network.dob.adapter.payout.service.utils.ProcessingHelper;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Component
@Slf4j
public class PayoutConsumer extends AbstractConsumer {

	@Autowired
    private RequestProcessor requestProcessor;


    protected PayoutConsumer(RabbitService rabbitService, @Value("${octopus.consumer.error-retry-in-seconds}") int retryPeriod, RequestProcessor requestProcessor, ObjectMapper mapper) {
        super(RabbitQueue.PAYOUT, retryPeriod, rabbitService, mapper);
        this.requestProcessor = requestProcessor ;
    }

    @Override
    public boolean isRequestSupported(ApplicationRequest applicationRequest) {
		boolean isRequestSupportedFlag = false;
		final RequestType requestType = applicationRequest.getRequestType();

		if (requestType == RequestType.PAYOUT_ONBOARDING) {
			isRequestSupportedFlag = requestProcessor.isAnyMerchantValid(applicationRequest);
			log.info("Request Type Payout Onboarding is supported for Application: {} {}",
					applicationRequest.getApplicationId(), isRequestSupportedFlag);
			return isRequestSupportedFlag;
		} else if (requestType == RequestType.PAYOUT_AMENDMENT) {
			isRequestSupportedFlag = true;
			log.info("Request Type Amendment is supported for Application: {} {}",
					applicationRequest.getApplicationId(), isRequestSupportedFlag);
			isRequestSupportedFlag = requestProcessor.isAnyAmendmentApplicationValid(applicationRequest);
			return isRequestSupportedFlag;
		} else {
			requestProcessor.saveApplicatioRequest(applicationRequest);
			isRequestSupportedFlag = false;
			log.error("Unsupported Request Type: {} for Application: {} {}", requestType,
					applicationRequest.getApplicationId(), isRequestSupportedFlag);
			return isRequestSupportedFlag;
		}
    }

    @Override
    public Optional<Collection<ValidationError>> validateApplication(ApplicationRequest applicationRequest) {
    	return requestProcessor.validateApplication(applicationRequest);
    }
    
  
    @Override
    public void processApplication(ApplicationRequest applicationRequest) {
        requestProcessor.process(applicationRequest);
        
        sendUpdate(ProcessingHelper.createApplicationResponse(applicationRequest));
        
    }

    @Override
    public BackendSystem getBackendSystem() {
        return BackendSystem.PAYOUT;
    }
    
}
