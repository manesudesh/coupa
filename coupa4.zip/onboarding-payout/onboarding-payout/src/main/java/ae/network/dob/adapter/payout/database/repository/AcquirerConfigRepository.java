package ae.network.dob.adapter.payout.database.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import ae.network.dob.adapter.payout.database.AcquirerConfig;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public interface AcquirerConfigRepository extends MongoRepository<AcquirerConfig, String> {

    Optional<AcquirerConfig> findByName(String name);
}