package ae.network.dob.adapter.payout.rabbitmq.message;

import java.io.Serializable;

/**
 * 
 * @author Sudesh_Mane
 * @since
 * Marker interface for message sent to rabbit queues
 */
public interface QueueMessage extends Serializable {

    String getApplicationId();
}
