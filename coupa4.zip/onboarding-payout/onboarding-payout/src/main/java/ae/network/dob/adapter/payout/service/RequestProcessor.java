package ae.network.dob.adapter.payout.service;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.dob.adapter.payout.api.db.APIData;
import ae.network.dob.adapter.payout.api.db.CreateUpdateAPIData;
import ae.network.dob.adapter.payout.api.response.APIResponse;
import ae.network.dob.adapter.payout.api.response.error.APIResponseError;
import ae.network.dob.adapter.payout.config.CacheService;
import ae.network.dob.adapter.payout.database.AcquirerConfig;
import ae.network.dob.adapter.payout.database.service.AcquirerConfigService;
import ae.network.dob.adapter.payout.database.service.PayoutRequestDBService;
import ae.network.dob.adapter.payout.exception.MessageCancelledException;
import ae.network.dob.adapter.payout.integration.APIFeignClient;
import ae.network.dob.adapter.payout.integration.IntegrationException;
import ae.network.dob.adapter.payout.model.application.Application;
import ae.network.dob.adapter.payout.model.application.Merchant;
import ae.network.dob.adapter.payout.model.application.payout.Participant;
import ae.network.dob.adapter.payout.model.reply.ValidationError;
import ae.network.dob.adapter.payout.model.request.ApplicationRequest;
import ae.network.dob.adapter.payout.model.request.RequestType;
import ae.network.dob.adapter.payout.model.task.Task;
import ae.network.dob.adapter.payout.model.task.TaskName;
import ae.network.dob.adapter.payout.model.task.TaskStatus;
import ae.network.dob.adapter.payout.service.utils.ProcessingHelper;
import ae.network.dob.adapter.payout.service.validate.ValidationExecutor;
import ae.network.dob.adapter.payout.service.validate.ValidationResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class RequestProcessor {

	@Autowired
	private ValidationExecutor validationExecutor;

	@Autowired
	private ProcessingHelper processingHelper;

	@Autowired
	private PayoutHelper payoutHelper;

	@Autowired
	CacheService cacheService;
	
	@Autowired
	AcquirerConfigService acquirerConfigService;

	@Autowired
	private PayoutRequestDBService appRequestDB;

	public void process(ApplicationRequest entity) {
		if (entity.getRequestType() == RequestType.PAYOUT_ONBOARDING) {
			List<Merchant> merchantList = processingHelper.getValidMerchants(entity);
			// validate if changes required
			if (CollectionUtils.isEmpty(merchantList)) {
				log.error("Total number of valid merchants " + merchantList.size());
				saveApplicatioRequest(entity);
				throw new MessageCancelledException("No Merchant Available");
			}
			log.info("Total number of valid merchants " + merchantList.size());

			onboardPayoutDetail(entity);
		} else if (entity.getRequestType() == RequestType.PAYOUT_AMENDMENT) {

			amendmentPayoutDetail(entity);

		}
		saveApplicatioRequest(entity);
	}

	private void onboardPayoutDetail(ApplicationRequest entity) {
		log.info("calling create Payout application {} ", entity.getApplicationId());

		String acquirer = entity.getAcquirer().name();

		List<Application> applications = entity.getPayload().getApplications().stream().collect(Collectors.toList());

		applications.forEach(app -> {

			APIData apiData = APIData.builder().participantId(app.getParticipant().getParticipantId()).build();

			Participant apiPayout = payoutHelper.buildApiParticipant(app);

			CreateUpdateAPIData requestAPIData = CreateUpdateAPIData.builder().apiRequest(apiPayout).build();

			apiData.setCreateUpdateAPIData(requestAPIData);

			entity.getApiDatas().add(apiData);

			Optional<AcquirerConfig> acquirerConfigOptional = acquirerConfigService.findByName(acquirer);

			invokeCreateUpdateEndpoint(RequestType.PAYOUT_ONBOARDING, apiPayout, apiData, acquirerConfigOptional.get());

			processingHelper.handleAPIDataTask(apiData, entity, TaskName.ONBOARDING_PAYOUT,
					app.getParticipant().getParticipantId());
		});
	}

	private void amendmentPayoutDetail(ApplicationRequest entity) {
		log.info("calling create Payout application {} ", entity.getApplicationId());

		String acquirer = entity.getAcquirer().name();

		List<Application> applications = entity.getPayload().getApplications().stream().collect(Collectors.toList());

		applications.forEach(app -> {

			APIData apiData = APIData.builder().participantId(app.getParticipant().getParticipantId()).build();

			Participant apiPayout = payoutHelper.buildApiParticipant(app);

			CreateUpdateAPIData requestAPIData = CreateUpdateAPIData.builder().apiRequest(apiPayout).build();

			apiData.setCreateUpdateAPIData(requestAPIData);

			entity.getApiDatas().add(apiData);

			Optional<AcquirerConfig> acquirerConfigOptional = acquirerConfigService.findByName(acquirer);

			invokeCreateUpdateEndpoint(RequestType.PAYOUT_AMENDMENT, apiPayout, apiData, acquirerConfigOptional.get());

			processingHelper.handleAPIDataTask(apiData, entity, TaskName.AMENDMENT_PAYOUT,
					app.getParticipant().getParticipantId());
		});
	}

	private void invokeCreateUpdateEndpoint(RequestType reqType, Participant apiPayout, APIData apiData,
			AcquirerConfig acqConfig) {
		log.info("calling invokeCreateUpdateEndpoint()");
		try {

			APIFeignClient apiFeignClient = cacheService.buildFeignClient(acqConfig);

			ObjectMapper mapper = new ObjectMapper();
			String strPayoutObject = mapper.writeValueAsString(apiPayout);
			log.info(strPayoutObject);
			if (reqType == RequestType.PAYOUT_ONBOARDING) {
				apiFeignClient.createPayout(acqConfig.getTenantReference(), apiPayout);
			} else if (reqType == RequestType.PAYOUT_AMENDMENT) {
				apiFeignClient.amendPayout(acqConfig.getTenantReference(), apiPayout);
			}
			apiData.getCreateUpdateAPIData().setApiResponse(APIResponse.builder().message("success").build());
		} catch (IntegrationException e) {
			log.error("Exception occurred while invoking CreateUpdate Endpoint " + e.getMessage());
			apiData.getCreateUpdateAPIData().setApiResponse(APIResponse.builder().errors(e.getError()).build());
		} catch (Exception e) {
			log.error("Exception occurred while invoking CreateUpdate Endpoint " + e.getMessage());
			APIResponse apiResponse = APIResponse.builder().errors(APIResponseError.builder()
					.message("Exception occurred while invoking CreateUpdate Endpoint").build()).build();
			apiData.getCreateUpdateAPIData().setApiResponse(apiResponse);
		}
	}

	public Optional<Collection<ValidationError>> validateApplication(ApplicationRequest applicationRequest) {
		log.info("calling validateApplication()");
		ValidationResult validationResult = validationExecutor.execute(applicationRequest);
		if (validationResult.isPassed()) {
			log.info("validation passed successfully.");
			Task task = processingHelper.createTask(TaskName.VALIDATION, TaskStatus.COMPLETED);
			task.getTaskHistory().add(processingHelper.createTaskHistory(TaskStatus.COMPLETED,
					"validationResult success " + applicationRequest.getApplicationId(), "OK"));
			applicationRequest.getTasks().add(task);
			return Optional.empty();
		} else {
			return handleInvalidValidationErrors(applicationRequest, validationResult);
		}
	}

	public boolean isAnyMerchantValid(ApplicationRequest applicationRequest) {
		log.info("calling isAnyMerchantValid()");
		ValidationResult validationResult = validationExecutor.isAnyMerchantValid(applicationRequest);
		if (validationResult.isPassed()) {
			return true;
		} else {
			log.error("No single merchant is valid in payload");
			handleInvalidValidationErrors(applicationRequest, validationResult);
			return false;
		}
	}

	public boolean isAnyAmendmentApplicationValid(ApplicationRequest applicationRequest) {
		log.info("calling isAnyAmendmentApplicationValid()");
		ValidationResult validationResult = validationExecutor.isAnyAmendmentApplicationValid(applicationRequest);
		if (validationResult.isPassed()) {
			return true;
		} else {
			log.error("No any AmendmentList Application is valid in payload");
			handleInvalidValidationErrors(applicationRequest, validationResult);
			return false;
		}
	}

	public boolean isAmendmentMerchantValid(ApplicationRequest applicationRequest) {
		log.info("calling isAmendmentMerchantValid()");
		ValidationResult validationResult = validationExecutor.execute(applicationRequest);
		if (validationResult.isPassed()) {
			return true;
		} else {
			log.warn("No single merchant is valid in payload");
			handleInvalidValidationErrors(applicationRequest, validationResult);
			return false;
		}
	}

	private Optional<Collection<ValidationError>> handleInvalidValidationErrors(ApplicationRequest applicationRequest,
			ValidationResult validationResult) {
		log.info("validation errors found for this request {} : {}", applicationRequest.getApplicationId(),
				validationResult);
		List<ValidationError> validationErrorList = Arrays
				.asList(ValidationError.builder().errorCode(validationResult.getCode())
						.errorMessage(validationResult.getMessage()).fieldName("*").build());

		Task task = processingHelper.createTask(TaskName.VALIDATION, TaskStatus.FAILED);
		processingHelper.assignValidationErrorTaskHistory(validationErrorList, task);

		applicationRequest.getTasks().add(task);
		saveApplicatioRequest(applicationRequest);

		return Optional.of(validationErrorList);
	}

	public void saveApplicatioRequest(ApplicationRequest applicationRequest) {
		appRequestDB.save(applicationRequest);
	}

}