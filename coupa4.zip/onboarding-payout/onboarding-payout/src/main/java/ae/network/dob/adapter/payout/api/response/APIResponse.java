package ae.network.dob.adapter.payout.api.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import ae.network.dob.adapter.payout.api.response.error.APIResponseError;
import ae.network.dob.adapter.payout.model.application.payout.Participant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class APIResponse implements Serializable{

	private String participantId;
	private String correlationId;
//	private int code;
	
	private APIResponseError errors;	
	private String message;
	
	private Participant payoutSearchResponse;	
}
