package ae.network.dob.adapter.payout.service;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import ae.network.dob.adapter.payout.api.request.APIRequestMerchant;
import ae.network.dob.adapter.payout.model.application.Application;
import ae.network.dob.adapter.payout.model.application.Merchant;
import ae.network.dob.adapter.payout.model.application.payout.Participant;
import ae.network.dob.adapter.payout.model.dto.PayoutApiClientKey;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PayoutHelper {

	public Participant buildApiParticipant(Application application) {
		log.info("building Payout details");
		Participant participant = buildParticipant(application);
		return participant;
	}

	public PayoutApiClientKey buildFeignKey(String url, String userName, String credential) {
		PayoutApiClientKey feignKey = new PayoutApiClientKey(url, userName, credential);
		return feignKey;
	}

	private Participant buildParticipant(Application app) {
		log.info("calling buildParticipant()");
		Participant participant = app.getParticipant();
		participant.setChainId(app.getChain().getChainId());
		participant.setMidDetails(tranferMerchantDetails(app.getMerchants()));
		return participant;
	}

	private List<APIRequestMerchant> tranferMerchantDetails(List<Merchant> merchants) {
		List<APIRequestMerchant> apiMerchantList = merchants.stream().map(
				mer -> APIRequestMerchant.builder().mid(mer.getMerchantId()).midName(mer.getMerchantName()).build())
				.collect(Collectors.toList());

		return apiMerchantList;
	}
}