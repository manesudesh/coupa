package ae.network.dob.adapter.payout.exception;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public class MaxRetryReachedException extends MessageRejectionException {
    public MaxRetryReachedException(String applicationId) {
        super(applicationId, "Maximum retries reached");
    }
}
