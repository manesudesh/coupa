package ae.network.dob.adapter.payout.rabbitmq.service.impl;

import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.dob.adapter.payout.rabbitmq.config.RabbitExchange;
import ae.network.dob.adapter.payout.rabbitmq.config.RabbitQueue;
import ae.network.dob.adapter.payout.rabbitmq.message.QueueMessage;
import ae.network.dob.adapter.payout.rabbitmq.service.RabbitService;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Service
@Slf4j
public class RabbitServiceImpl implements RabbitService {
    private final RabbitTemplate rabbitTemplate;

    public RabbitServiceImpl(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    @Override
    public void sendMessage(RabbitQueue queue, QueueMessage message) {
        logQueueMessage(queue, message);
        MessagePostProcessor corrIdSetter = m -> {
            m.getMessageProperties().setCorrelationId(message.getApplicationId());
            return m;
        };
        rabbitTemplate.convertAndSend(RabbitExchange.ONBOARDING.getExchangeName(), getDefaultRoutingKey(queue), message, corrIdSetter);
    }

    @Override
    public void retryMessage(Message message, int seconds) {
        MessageProperties messageProperties = message.getMessageProperties();
        messageProperties.setDelay(seconds * 1000);
        log.info("Scheduling retry to message {} in {} seconds", message, seconds);
        rabbitTemplate.send(RabbitExchange.ONBOARDING_RETRY.getExchangeName(), messageProperties.getReceivedRoutingKey(), message);
    }

    private void logQueueMessage(RabbitQueue queue, QueueMessage message) {
        try {
            log.info("Sending to queue {} message {}", queue.getQueueName(), new ObjectMapper().writeValueAsString(message));
        } catch (JsonProcessingException ignored) {
        }
    }

    private String getDefaultRoutingKey(RabbitQueue queue) {
        if (queue.getRoutingKeys().isEmpty()) {
            throw new AmqpException("Invalid destination");
        }
        return queue.getRoutingKeys().get(0);
    }
}
