package ae.network.dob.adapter.payout.model.application.payout;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import ae.network.dob.adapter.payout.api.request.APIRequestMerchant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Participant {

	private String participantId ;
	private String participantDBAName ;
	private String participantLegalName ;
	private ParticipantAddress participantAddressDetails;
	private String tradeLicenseNumber ;
	private String tradeLicenseExpiry ;
	private List<ParticipantAddress> authorizedSignatories;
	private List<ParticipantAddress> owners;
	private String currency; 
	private BankDetail payoutAccount;
	private BankDetail participantKnownAccount;
	private String chainId;
	private List<APIRequestMerchant> midDetails;
	private ParticipantAddress payoutAdmin;
	private NIRM niRM;
	private VatDetail vatDetails;
	private String participantIndicator;
	private String participantOnly; 
	private FeeParameter feeParameters;
	private ControlParameter controlParameters;
}
