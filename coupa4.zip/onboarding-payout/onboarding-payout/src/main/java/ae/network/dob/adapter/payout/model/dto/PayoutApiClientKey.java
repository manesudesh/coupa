package ae.network.dob.adapter.payout.model.dto;

import lombok.EqualsAndHashCode;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@EqualsAndHashCode
public final class PayoutApiClientKey {
	
	 private final String url;
	 private final String userName;
	 private final String password;
	 
	 public PayoutApiClientKey(String url, String userName, String password) {
		 this.url = url;
		 this.userName = userName;
		 this.password = password;
	 }
	 
	 public String getUrl() {
		 return url;
	 }
	 
	 public String getUserName() {
		 return userName;
	 }
	 
	 public String getPassword() {
		 return password;
	 }
	 
}
