package ae.network.dob.adapter.payout.rabbitmq.config;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public enum RabbitExchange {
    ONBOARDING("onboarding-exchange"),
    ONBOARDING_RETRY("onboarding-delayed-exchange");

    private final String exchangeName;

    RabbitExchange(String exchangeName) {
        this.exchangeName = exchangeName;
    }

    public String getExchangeName() {
        return exchangeName;
    }
}
