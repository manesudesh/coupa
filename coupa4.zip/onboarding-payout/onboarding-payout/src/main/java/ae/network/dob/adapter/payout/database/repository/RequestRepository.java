package ae.network.dob.adapter.payout.database.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import ae.network.dob.adapter.payout.model.request.ApplicationRequest;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public interface RequestRepository extends MongoRepository<ApplicationRequest, String> {

    /**
     * fond the application request by its application Id
     *
     * @param applicationId
     * @return ApplicationRequest
     */
    Optional<ApplicationRequest> findFirstByApplicationId(String applicationId);

}
