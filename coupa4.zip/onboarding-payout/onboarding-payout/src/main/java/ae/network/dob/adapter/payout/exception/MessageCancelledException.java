package ae.network.dob.adapter.payout.exception;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public class MessageCancelledException extends MessageRejectionException {
    public MessageCancelledException(String applicationId) {
        super(applicationId, "No processing required");
    }
}
