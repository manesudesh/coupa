package ae.network.dob.adapter.payout.exception;

import org.springframework.amqp.AmqpRejectAndDontRequeueException;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public class MessageRejectionException extends AmqpRejectAndDontRequeueException {
    private final String applicationId;

    public MessageRejectionException(String applicationId, String message) {
        super(message);
        this.applicationId = applicationId;
    }

    public MessageRejectionException(String applicationId, String message, Throwable cause) {
        super(message, cause);
        this.applicationId = applicationId;
    }

    public String getApplicationId() {
        return applicationId;
    }
}
