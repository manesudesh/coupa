package ae.network.dob.adapter.payout.model.request;

import java.util.Collection;

import ae.network.dob.adapter.payout.model.task.TaskHistory;
import ae.network.dob.adapter.payout.model.task.TaskStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Task {
    private Long id;
    private String name;
    private String entityId;
    private TaskStatus taskStatus;
    private Collection<TaskHistory> taskHistory;
}
