package ae.network.dob.adapter.payout.integration;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@ToString
@Builder
@JsonIgnoreProperties
public class ApiError {
    private String message;
    private int code;
}
