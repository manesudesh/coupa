package ae.network.dob.adapter.payout.exception;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public class AcquirerDoesNotExistException extends MessageRejectionException {

    public AcquirerDoesNotExistException(String acquirerName) {
        super(acquirerName, "Acquirer :".concat(acquirerName).concat(" Dose Not Exist in Payout Adapter configurations"));
    }
}
