package ae.network.dob.adapter.payout.integration;

import ae.network.dob.adapter.payout.api.response.error.APIResponseError;
import feign.FeignException;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public class IntegrationException extends FeignException {
    private final APIResponseError error;

    public IntegrationException(APIResponseError error) {
        super(error.getCode(), error.toString());
        this.error = error;
    }

    public APIResponseError getError() {
        return error;
    }
}
