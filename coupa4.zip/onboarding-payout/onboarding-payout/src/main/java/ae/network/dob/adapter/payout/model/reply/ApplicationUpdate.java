package ae.network.dob.adapter.payout.model.reply;

import ae.network.dob.adapter.payout.model.task.AdditionalData;
import ae.network.dob.adapter.payout.model.task.BackendSystem;
import ae.network.dob.adapter.payout.rabbitmq.message.QueueMessage;
import lombok.Builder;
import lombok.Data;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@Builder
public class ApplicationUpdate implements QueueMessage {
    private String applicationId;
    private BackendSystem backendSystem;
    private ProcessingResult processingResult;
    private AdditionalData additionalData;
}
