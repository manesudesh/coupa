package ae.network.dob.adapter.payout.rabbitmq.consumer;

import java.util.Collection;
import java.util.Optional;

import org.springframework.amqp.core.MessageListener;
import org.springframework.util.ErrorHandler;

import ae.network.dob.adapter.payout.model.reply.ApplicationUpdate;
import ae.network.dob.adapter.payout.model.reply.ValidationError;
import ae.network.dob.adapter.payout.model.request.ApplicationRequest;
import ae.network.dob.adapter.payout.model.task.BackendSystem;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public interface Consumer extends MessageListener, ErrorHandler {

    /**
     * Validation of messages should be implemented here
     */
    Optional<Collection<ValidationError>> validateApplication(ApplicationRequest applicationRequest);

    /**
     * After a successful validation, the message is being
     * processed and if necessary stored in its corresponding
     * data store. Any thrown business exceptions will enforce rescheduling the message sometime later.
     */
    void processApplication(ApplicationRequest applicationRequest);

    /**
     * provided the type of backend system you work on
     */
    BackendSystem getBackendSystem();

    /**
     * check whether the incoming request is supported or not.
     */
    boolean isRequestSupported(ApplicationRequest applicationRequest);

    default Optional<ApplicationUpdate> druRun(ApplicationRequest applicationRequest) {
        return Optional.empty();
    }
}
