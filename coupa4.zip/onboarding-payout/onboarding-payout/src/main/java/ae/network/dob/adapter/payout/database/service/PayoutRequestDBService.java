package ae.network.dob.adapter.payout.database.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import ae.network.dob.adapter.payout.database.repository.RequestRepository;
import ae.network.dob.adapter.payout.model.request.ApplicationRequest;
import lombok.AllArgsConstructor;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Service
@AllArgsConstructor
public class PayoutRequestDBService {

    private final RequestRepository repository;

    public synchronized ApplicationRequest save(ApplicationRequest payoutApplicationReq) {
        return repository.save(payoutApplicationReq);
    }
    
    public Optional<ApplicationRequest> findByAppReqId(String appReqId) {
        return repository.findFirstByApplicationId(appReqId);
    }

}
