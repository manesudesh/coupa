package ae.network.dob.adapter.payout.service.validate;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@AllArgsConstructor
@Builder
@ToString(includeFieldNames = false)
public class ValidationResult {
    private boolean passed;
    private String code;
    private String message;
}
