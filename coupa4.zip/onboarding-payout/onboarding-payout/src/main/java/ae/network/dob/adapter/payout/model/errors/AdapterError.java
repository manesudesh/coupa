package ae.network.dob.adapter.payout.model.errors;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@Builder
@ToString(includeFieldNames = true)
@AllArgsConstructor
@NoArgsConstructor
public class AdapterError {

    private String name;
    private String code;
    private String message;
}
