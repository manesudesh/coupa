package ae.network.dob.adapter.payout.common;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public interface DateFormat {
    String FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
}
