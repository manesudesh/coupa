package ae.network.dob.adapter.payout.database;


import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString(includeFieldNames = true)
@Document(collection = "payout_config")
@Slf4j
@Component
public class PayoutConfigDBEntity extends AbstractAuditingEntity {
    /**
     * Unique identifier of the document
     */
    @Id
    private String id;
    private String acquirer;

    private String apiBasicAuthNameJASYPTENC;
    private String apiPasswordJASYPTENC;
    private String certIdJASYPTENC;
    private String adminPasswordJASYPTENC;
	    
    public String getApiPasswordJASYPTENC(){
    	return decryptValue(apiPasswordJASYPTENC);
    }
	    
    public String getApiBasicAuthNameJASYPTENC(){
    	return decryptValue(apiBasicAuthNameJASYPTENC);
    }
	    
    public String getCertIdJASYPTENC(){
    	return decryptValue(certIdJASYPTENC);
    }
	    
    public String getAdminPasswordJASYPTENC(){
    	return decryptValue(adminPasswordJASYPTENC);
    }

      
    @Autowired
	public PayoutConfigDBEntity(Environment env) {
		encryptor = new PooledPBEStringEncryptor();
		SimpleStringPBEConfig config = new SimpleStringPBEConfig();
		config.setPassword(env.getProperty("jasypt.encryptor.password"));
		config.setAlgorithm(env.getProperty("jasypt.encryptor.algorithm"));
//		config.setPassword(env.getProperty("JASYPT_ENCRYPTOR_PASSWORD"));  
//		config.setAlgorithm(env.getProperty("algorithm"));
		config.setPoolSize("200");

		encryptor.setConfig(config);
	}
    
    static PooledPBEStringEncryptor encryptor;
    
    /**Method decrypt database value, if any exception then return same value
     * @param value
     * @return
     */
    private static String decryptValue(String value)
    {
    	try {
    		return encryptor.decrypt(value);
    	}catch(Exception e)
    	{
    		log.error("Excetion while decrypt "+e.getMessage());
    		return value;
    	}
    }
}

