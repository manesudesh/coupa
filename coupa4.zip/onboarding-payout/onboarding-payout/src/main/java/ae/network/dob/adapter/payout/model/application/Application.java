package ae.network.dob.adapter.payout.model.application;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import ae.network.dob.adapter.payout.model.application.payout.Participant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Application {

    private Chain chain;

    @NotNull(message = "merchant List can not be null")
    @NotEmpty(message = "merchant List can not be Empty")
    @Valid
    private List<Merchant> merchants;
    
    private Participant participant;

    // local usage
    private String subId;
}
