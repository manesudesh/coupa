package ae.network.dob.adapter.payout.model.reply;

import java.util.ArrayList;
import java.util.Collection;

import ae.network.dob.adapter.payout.model.task.Task;
import ae.network.dob.adapter.payout.model.task.TaskStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProcessingResult {
    private TaskStatus finalStatus;
    private Collection<Task> tasks = new ArrayList<>();
}
