package ae.network.dob.adapter.payout.rabbitmq.config;

import java.util.Arrays;
import java.util.List;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public enum RabbitQueue {
    // Working Queue
    PAYOUT("payout", "routing.backend.payout"),
    // Reply Queue
    UPDATES("updates", "routing.updates");

    private final String queueName;
    private final String[] routingKeys;

    RabbitQueue(String queueName, String... routingKeys) {
        this.queueName = queueName;
        this.routingKeys = routingKeys;
    }

    public String getQueueName() {
        return queueName;
    }

    public List<String> getRoutingKeys() {
        return Arrays.asList(routingKeys);
    }
}
