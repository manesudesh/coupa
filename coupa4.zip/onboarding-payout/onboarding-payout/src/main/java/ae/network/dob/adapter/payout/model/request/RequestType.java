package ae.network.dob.adapter.payout.model.request;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

public enum RequestType {
    PAYOUT_ONBOARDING, PAYOUT_AMENDMENT
}
