package ae.network.dob.adapter.payout.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Configuration
@Data
@ConfigurationProperties(prefix = "apifeigncache")
public class CacheProperties {
	public int expireAfterWrite;
	public int initialCapacity;

}
