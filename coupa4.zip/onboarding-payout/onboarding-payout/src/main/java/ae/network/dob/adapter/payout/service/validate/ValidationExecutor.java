package ae.network.dob.adapter.payout.service.validate;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ae.network.dob.adapter.payout.model.request.ApplicationRequest;
import ae.network.dob.adapter.payout.model.request.RequestType;

@Service
public class ValidationExecutor {

    @Autowired
    private BoardingValidationRule validationRule;

    @Autowired
    private AmendmentValidationRule amendmentValidationRule;

    public ValidationResult execute(ApplicationRequest request) {
        if (request.getRequestType() == RequestType.PAYOUT_ONBOARDING) {
            return validationRule.validate(request);
        } else if (request.getRequestType() == RequestType.PAYOUT_AMENDMENT) {
            return amendmentValidationRule.validate(request);
        }
        return ValidationResult.builder().passed(true).code("000").build();
    }
    
    public ValidationResult isAnyMerchantValid(ApplicationRequest request) {
    	return validationRule.isAnyMerchantValid(request);
    }
    
    public ValidationResult isAnyAmendmentApplicationValid(ApplicationRequest request) {
    	return amendmentValidationRule.isAnyAmendmentApplicationValid(request);
    }
}
