package ae.network.dob.adapter.payout.service.validate;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import ae.network.dob.adapter.payout.config.PayloadErrorMessageConfig;
import ae.network.dob.adapter.payout.database.repository.RequestRepository;
import ae.network.dob.adapter.payout.model.application.Application;
import ae.network.dob.adapter.payout.model.application.Merchant;
import ae.network.dob.adapter.payout.model.errors.AdapterError;
import ae.network.dob.adapter.payout.model.errors.ErrorName;
import ae.network.dob.adapter.payout.model.request.ApplicationRequest;
import ae.network.dob.adapter.payout.service.utils.ProcessingHelper;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AmendmentValidationRule implements ValidationRule<ApplicationRequest> {

    @Autowired private PayloadErrorMessageConfig errorMessageConfig;

    @Autowired private RequestRepository requestRepository;
    
    @Autowired private ProcessingHelper processingHelper;

    @Override
    public ValidationResult validate(ApplicationRequest request) {

        log.info("Amendment validator started.");
        AdapterError error;

        if (isApplicationIdExist(request.getApplicationId())) {
            log.info("ApplicationId {} is already Exist.", request.getApplicationId());
            error = getError(ErrorName.APPLICATION_EXIST);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }

        List<Merchant> validMerchantList = processingHelper.getValidAmendmentMerchants(request);
        if (validMerchantList.isEmpty()) {
            log.info("All Merchants are Invalid for applicationId {}",  request.getApplicationId());
            error = getError(ErrorName.ALL_MERCHANTS_INVALID);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }
        
        List <Application> applicationList = request.getPayload().getApplications();
        if (CollectionUtils.isEmpty(applicationList)) {
            error = getError(ErrorName.APPLICATION_LIST_EMPTY);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }
        
        for(Application application : applicationList) {
        	if(application == null) {
        		error = getError(ErrorName.APPLICATION_LIST_EMPTY);
                return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
           
        	}
        
	        List<Merchant> merchantList = application.getMerchants();
	        if(CollectionUtils.isEmpty(merchantList)) {
	        	 error = getError(ErrorName.MERCHANT_NULL);
		            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
	        }
	
	        ValidationResult validationResultAmendmentList = validateAmendmentList(application); 
	        if(validationResultAmendmentList != null) {
	        	return validationResultAmendmentList;
	        }
	    }
        return ValidationResult.builder().passed(true).code("000").message("Success").build();
    }

	private ValidationResult validateAmendmentList(Application application) {
		AdapterError error;
      
		List<Merchant> merchants = application.getMerchants();
		for(Merchant merchant : merchants) {
		
		    if (merchant == null || merchant.getMerchantId() == null) {
		        error = getError(ErrorName.MERCHANT_NULL);
		        return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
		    }
		}
		return null;
	}
	
	protected ValidationResult isAnyAmendmentApplicationValid(ApplicationRequest request)
	{
		AdapterError error;
		if(request==null || request.getPayload()==null || CollectionUtils.isEmpty(request.getPayload().getApplications())) {
			error = getError(ErrorName.APPLICATION_LIST_EMPTY);
		    return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
		}
		
		List<Merchant> validMerchantList = processingHelper.getValidAmendmentMerchants(request);
        if (validMerchantList.isEmpty()) {
            log.info("All Merchants are Invalid for applicationId {}",  request.getApplicationId());
            error = getError(ErrorName.ALL_MERCHANTS_INVALID);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }
		
		return ValidationResult.builder().passed(true).code("000").build();
	}

    private boolean isApplicationIdExist(String applicationId) {
        return requestRepository.findFirstByApplicationId(applicationId).isPresent();
    }

    private AdapterError getError(ErrorName error) {
        return errorMessageConfig.getMessages().stream()
                .filter(err -> err.getName().equals(error.name())).findFirst().get();
    }
}
