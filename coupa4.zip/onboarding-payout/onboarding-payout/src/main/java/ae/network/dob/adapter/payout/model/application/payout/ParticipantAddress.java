package ae.network.dob.adapter.payout.model.application.payout;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import ae.network.dob.adapter.payout.model.application.AddressType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class ParticipantAddress {

    private AddressType addressType;
    private String firstName;
    private String lastName;
    private String email;
    private String mobileNumber;
    private String state;
    private String city;
    private String postalCode;
    private String poBox;
    private String kycDate;
    private String kycStatus;
    private String address1;
    private String address2;
    
    private String nationality;
    private String country;
    
    
}
