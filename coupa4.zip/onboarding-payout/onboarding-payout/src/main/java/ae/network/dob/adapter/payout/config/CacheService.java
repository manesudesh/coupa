package ae.network.dob.adapter.payout.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import ae.network.dob.adapter.payout.database.AcquirerConfig;
import ae.network.dob.adapter.payout.integration.APIFeignClient;
import ae.network.dob.adapter.payout.integration.FeignExceptionErrorDecoder;
import ae.network.dob.adapter.payout.integration.FeignRequestInterceptor;
import feign.Contract;
import feign.Feign;
import feign.Logger.Level;
import feign.codec.Encoder;
import feign.slf4j.Slf4jLogger;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author Sudesh_Mane
 * @since
 */

@Service
@Slf4j
public class CacheService {

	@Cacheable(value = "PayoutAPIFeignCache")
	public APIFeignClient buildFeignClient(AcquirerConfig acqConfig) {
		log.info("building Api Feign client");
		APIFeignClient apiClient = Feign.builder().contract(feignContract).encoder(feignEncoder)
				.logger(feignLogger).logLevel(Level.FULL)
				.requestInterceptor(new FeignRequestInterceptor(acqConfig.getAuthRequest()))
				.errorDecoder(feignExceptionErrorDecoder).target(APIFeignClient.class, acqConfig.getAuthRequest().getBaseUrl());
		return apiClient;
	}
	
	
	@Autowired Contract feignContract;
	@Autowired Encoder feignEncoder;
	@Autowired Slf4jLogger feignLogger;
	@Autowired FeignExceptionErrorDecoder feignExceptionErrorDecoder;
}
