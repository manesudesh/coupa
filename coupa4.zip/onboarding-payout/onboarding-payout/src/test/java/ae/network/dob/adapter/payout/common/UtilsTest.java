package ae.network.dob.adapter.payout.common;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import ae.network.dob.adapter.payout.common.TextUtils;

public class UtilsTest {

	@Test
	void truncateTest (){
		String threeChars= TextUtils.truncate("123Test", 3);
		assertEquals(threeChars, "123");
		
		String morethanMax = TextUtils.truncate("123Test", 12);
		assertEquals(morethanMax, "123Test");
		
		String nullStr = TextUtils.truncate(null, 12);
		assertEquals(nullStr, null);
	}
	
	@Test
	void toAlphaNumericTest (){
		String alphaNumeric = TextUtils.toAlphaNumeric("%123 @&Test");
		assertEquals(alphaNumeric, "123 Test");
		
		String nullStr = TextUtils.toAlphaNumeric(null);
		assertEquals(nullStr, null);
	}
	
	@Test
	void formatMccTest (){
		String fourDigit = TextUtils.formatMcc(1234);
		assertEquals(fourDigit, "1234");
		
		String fourDigitWithZero = TextUtils.formatMcc(234);
		assertEquals(fourDigitWithZero, "0234");
		
		String nullStr = TextUtils.formatMcc(null);
		assertEquals(nullStr, null);
	}
}
