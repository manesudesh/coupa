package ae.network.onboarding.octopus.database.model.request;

public enum TargetSystem {
    // todo add more
    Base24, Way4, NGen_Gateway, SelfService
}
