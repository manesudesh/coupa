package ae.network.onboarding.octopus.database.model.request;

public enum RequestType {
    ONBOARDING, AMENDMENT, MERCHANT_CLOSURE, TERMINAL_CLOSURE
}
