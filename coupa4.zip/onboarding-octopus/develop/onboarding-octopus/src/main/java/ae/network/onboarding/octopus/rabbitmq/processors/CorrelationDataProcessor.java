package ae.network.onboarding.octopus.rabbitmq.processors;

import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.UUID;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@Component
public class CorrelationDataProcessor implements MessagePostProcessor {
    private final String appName;

    public CorrelationDataProcessor(@Value("${spring.application.name}") String appName) {
        this.appName = appName;
    }

    @Override
    public Message postProcessMessage(Message message) throws AmqpException {
        MessageProperties messageProperties = message.getMessageProperties();
        String correlationId = messageProperties.getCorrelationId();
        if (correlationId == null) {
            messageProperties.setCorrelationId(UUID.randomUUID().toString());
        }
        if (messageProperties.getAppId() != null) {
            messageProperties.setAppId(appName);
        }
        if (messageProperties.getTimestamp() == null) {
            messageProperties.setTimestamp(new Date());
        }
        if (messageProperties.getContentType() == null) {
            messageProperties.setContentType(MessageProperties.CONTENT_TYPE_JSON);
        }
        return message;
    }
}
