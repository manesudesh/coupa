package ae.network.onboarding.octopus.security;

/**
 * List of all onboarding backend systems
 */
public enum BackendSystem {
    WAY4, BASE24
}
