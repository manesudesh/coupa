package ae.network.onboarding.octopus.security;

import ae.network.onboarding.octopus.database.model.request.Acquirer;
import lombok.Data;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

import java.util.Collections;
import java.util.List;

/**
 * Model for storing JWT token user details (http-request level)
 *
 * @author walid.sewaify
 * @since 2020-02-10
 */
@Component
@RequestScope
@Data
public class UserDetails {
    private String username;
    private Acquirer acquirer;
    private List<BackendSystem> authorizedSystems = Collections.emptyList();
}
