package ae.network.onboarding.octopus.controller;

import ae.network.onboarding.octopus.database.model.reply.ApplicationUpdate;
import ae.network.onboarding.octopus.database.model.request.Acquirer;
import ae.network.onboarding.octopus.database.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.database.model.request.RequestStatus;
import ae.network.onboarding.octopus.database.model.request.RequestType;
import ae.network.onboarding.octopus.database.model.request.Source;
import ae.network.onboarding.octopus.database.model.request.TargetSystem;
import ae.network.onboarding.octopus.database.model.request.Task;
import ae.network.onboarding.octopus.database.model.request.TaskHistory;
import ae.network.onboarding.octopus.database.model.request.TaskStatus;
import ae.network.onboarding.octopus.database.service.ApplicationRequestService;
import ae.network.onboarding.octopus.rabbitmq.RabbitService;
import ae.network.onboarding.octopus.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.octopus.rabbitmq.service.RabbitServiceImpl;
import ae.network.onboarding.octopus.security.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.Date;
import java.util.UUID;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@RestController
@RequestMapping("/onboarding")
public class OnboardingController {

    private final RabbitService rabbitService;

    private final ApplicationRequestService applicationRequestService;

    private final UserDetails userDetails;

    public OnboardingController(RabbitServiceImpl rabbitService, ApplicationRequestService applicationRequestService, UserDetails userDetails) {
        this.rabbitService = rabbitService;
        this.applicationRequestService = applicationRequestService;
        this.userDetails = userDetails;
    }

    @GetMapping("/test")
    public boolean test() {
        System.out.println(userDetails.getUsername());
        ApplicationUpdate reply = new ApplicationUpdate();
        reply.setApplicationId("4d9779e9-acf4-4b64-8594-9b742072804d");
        reply.setTargetSystem(TargetSystem.Way4);
        Task a = new Task();
        a.setId(1L);
        a.setName("wella task");
        a.setTaskStatus(TaskStatus.COMPLETED);
        TaskHistory h = new TaskHistory();
        h.setCreatedDate(new Date());
        h.setLastModifiedDate(new Date());
        h.setResponse("way4 reposneded");
        h.setStatusCode("200");
        h.setTaskStatus(TaskStatus.COMPLETED);
        a.setTaskHistory(Arrays.asList(h));
        reply.setTasks(Arrays.asList(a));
        rabbitService.sendMessage(RabbitQueue.SELF_SERVICE, reply);
        return true;
    }

    @PostMapping("/application")
    public ApplicationRequest postApplication(String applicationData) {
        System.out.println(userDetails.getUsername());
        ApplicationRequest request = new ApplicationRequest();
        request.setApplicationId(UUID.randomUUID().toString());
        request.setAcquirer(Acquirer.TYME);
        request.setPayload(applicationData);
        request.setSource(Source.API);
        request.setRequestStatus(RequestStatus.IN_PROGRESS);
        request.setRequestId("bank_id");
        request.setRequestType(RequestType.ONBOARDING);
        applicationRequestService.createAndSendApplication(request);
        return request;
    }


}
