package ae.network.onboarding.octopus.event;

import ae.network.onboarding.octopus.database.model.request.ApplicationRequest;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
public class Way4Base24CompletedEvent extends OnboardingApplicationEvent {

    public Way4Base24CompletedEvent(ApplicationRequest applicationRequest) {
        super(applicationRequest);
    }
}
