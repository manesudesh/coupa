package ae.network.onboarding.octopus.database.model.request;

public enum Acquirer {
    NI, TYME
}
