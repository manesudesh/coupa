package ae.network.onboarding.octopus.rabbitmq;

import ae.network.onboarding.octopus.rabbitmq.config.RabbitQueue;
import org.springframework.amqp.core.Message;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
public interface RabbitService {
    /**
     * Send a message to exchange queue that is stored in JSON format
     *
     * @param queue   receiving queue
     * @param message content
     */
    void sendMessage(RabbitQueue queue, Object message);

    /**
     * retry sending message to same queue after a period of time
     *
     * @param message original message
     * @param seconds time in seconds
     */
    void retryMessage(Message message, int seconds);
}
