package ae.network.onboarding.octopus.event.listener;

import ae.network.onboarding.octopus.event.Way4Base24CompletedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
@Component
@Slf4j
public class Way4Base24CompletedListener implements ApplicationListener<Way4Base24CompletedEvent> {

    @Override
    public void onApplicationEvent(Way4Base24CompletedEvent event) {
        // todo
        log.info("Way4, Base24 completed for application {}, starting onboarding to other systems");
    }

}