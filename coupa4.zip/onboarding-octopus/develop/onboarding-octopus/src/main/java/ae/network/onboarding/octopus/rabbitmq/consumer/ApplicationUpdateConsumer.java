package ae.network.onboarding.octopus.rabbitmq.consumer;

import ae.network.onboarding.octopus.database.model.reply.ApplicationUpdate;
import ae.network.onboarding.octopus.database.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.database.model.request.RequestStatus;
import ae.network.onboarding.octopus.database.model.request.TargetSystem;
import ae.network.onboarding.octopus.database.service.ApplicationRequestService;
import ae.network.onboarding.octopus.event.ApplicationCompletedEvent;
import ae.network.onboarding.octopus.event.ApplicationFailedEvent;
import ae.network.onboarding.octopus.event.Way4Base24CompletedEvent;
import ae.network.onboarding.octopus.exception.ApplicationNotFoundException;
import ae.network.onboarding.octopus.exception.MessageRejectionException;
import ae.network.onboarding.octopus.rabbitmq.RabbitService;
import ae.network.onboarding.octopus.rabbitmq.config.RabbitQueue;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
//@Component
@Slf4j
public class ApplicationUpdateConsumer implements MessageListener {
    private static final int RETRY_DELAY_SECONDS = 30;

    private final ApplicationRequestService applicationRequestService;
    private final RabbitService rabbitService;
    private final ApplicationEventPublisher applicationEventPublisher;

    public ApplicationUpdateConsumer(ApplicationRequestService applicationRequestService, RabbitService rabbitService,
                                     ApplicationEventPublisher applicationEventPublisher) {
        this.applicationRequestService = applicationRequestService;
        this.rabbitService = rabbitService;
        this.applicationEventPublisher = applicationEventPublisher;
    }

    @Bean
    SimpleMessageListenerContainer replyListener(ConnectionFactory connectionFactory) {
        SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
        container.setConnectionFactory(connectionFactory);
        container.setQueueNames(RabbitQueue.UPDATES.getQueueName());
        container.setMessageListener(this);
        return container;
    }

    @Override
    public void onMessage(Message message) {
        String messageContent = new String(message.getBody());
        try {
            ApplicationUpdate reply = new ObjectMapper().readValue(messageContent, ApplicationUpdate.class);
            ApplicationRequest app = applicationRequestService.findByApplicationId(reply.getApplicationId())
                    .orElseThrow(ApplicationNotFoundException::new);

            if (app.getRequestStatus() == RequestStatus.COMPLETED) {
                throw new MessageRejectionException("application is already complete");
            }

            app.updateTasks(reply.getTargetSystem(), reply.getTasks());

            if (app.targetSystemFailed(reply.getTargetSystem())) {
                app.setRequestStatus(RequestStatus.FAILED);
                applicationEventPublisher.publishEvent(new ApplicationFailedEvent(app));
            } else if (app.allEligibleTargetSystemsCompleted()) {
                app.setRequestStatus(RequestStatus.COMPLETED);
                applicationEventPublisher.publishEvent(new ApplicationCompletedEvent(app));
            } else if (app.targetSystemCompleted(TargetSystem.Way4) && app.targetSystemCompleted(TargetSystem.Base24)) {
                applicationEventPublisher.publishEvent(new Way4Base24CompletedEvent(app));
            }

            applicationRequestService.saveOrUpdateApplication(app);
        } catch (MessageRejectionException | JsonProcessingException e) {
            log.error(e.getMessage(), e);
            throw new MessageRejectionException(e);
        } catch (Exception e) {
            rabbitService.retryMessage(message, RETRY_DELAY_SECONDS);
        }
    }
}
