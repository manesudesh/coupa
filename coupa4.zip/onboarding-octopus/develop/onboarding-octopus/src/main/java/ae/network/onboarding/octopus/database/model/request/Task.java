package ae.network.onboarding.octopus.database.model.request;

import lombok.Data;

import java.util.Collection;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
@Data
public class Task {
    private Long id;
    private String name;
    private String merchantId;
    private String chainId;
    private TaskStatus taskStatus;
    private Collection<TaskHistory> taskHistory;
}
