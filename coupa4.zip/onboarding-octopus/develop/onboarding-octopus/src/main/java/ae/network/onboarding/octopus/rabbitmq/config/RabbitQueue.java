package ae.network.onboarding.octopus.rabbitmq.config;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
public enum RabbitQueue {
    // Working Queues
    WAY4("way4", "routing.backend.way4"),
    BASE24("base24", "routing.backend.base24"),
    UPDATES("updates", "routing.updates"),
    SELF_SERVICE("self_service", "routing.self_service"),
    NOTIFICATIONS("notifications", "routing.notifications"),
    // Failure Queues
    FAILS("failures");

    private final String queueName;
    private final String[] routingKeys;

    RabbitQueue(String queueName, String... routingKeys) {
        this.queueName = queueName;
        this.routingKeys = routingKeys;
    }

    /**
     * @return all queues that bind to working exchanges (not failure)
     */
    public static List<RabbitQueue> getWorkingQueues() {
        return Arrays.stream(values()).filter(q -> q != FAILS).collect(Collectors.toList());
    }

    /**
     * @return list of backend systems that should be called first
     */
    public static List<RabbitQueue> getInitialWorkingQueues() {
        return Arrays.asList(WAY4, BASE24);
    }

    public String getQueueName() {
        return queueName;
    }

    public List<String> getRoutingKeys() {
        return Arrays.asList(routingKeys);
    }
}
