package ae.network.onboarding.octopus.event;

import ae.network.onboarding.octopus.database.model.request.ApplicationRequest;
import org.springframework.context.ApplicationEvent;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
public abstract class OnboardingApplicationEvent extends ApplicationEvent {
    OnboardingApplicationEvent(ApplicationRequest applicationRequest) {
        super(applicationRequest);
    }

    @Override
    public ApplicationRequest getSource() {
        return (ApplicationRequest) super.getSource();
    }
}
