package ae.network.onboarding.octopus.event.listener;

import ae.network.onboarding.octopus.database.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.event.ApplicationFailedEvent;
import ae.network.onboarding.octopus.rabbitmq.RabbitService;
import ae.network.onboarding.octopus.rabbitmq.config.RabbitQueue;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
@Component
@Slf4j
public class ApplicationFailedListener implements ApplicationListener<ApplicationFailedEvent> {
    private final RabbitService rabbitService;

    public ApplicationFailedListener(RabbitService rabbitService) {
        this.rabbitService = rabbitService;
    }

    @Override
    public void onApplicationEvent(ApplicationFailedEvent event) {
        ApplicationRequest source = event.getSource();
        log.info("application {} has failed", source.getApplicationId());
        rabbitService.sendMessage(RabbitQueue.NOTIFICATIONS, source);
    }

}