package ae.network.onboarding.octopus.database.model.request;

import ae.network.onboarding.octopus.database.model.AbstractAuditingEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Document("applications")
public class ApplicationRequest extends AbstractAuditingEntity {
    @Id
    @EqualsAndHashCode.Include
    private String id;
    /**
     * Partner acquirer
     */
    private Acquirer acquirer;
    /**
     * Request type (Create-update-close)
     */
    private RequestType requestType;
    /**
     * Default is API
     */
    private Source source;
    /**
     * Application status
     */
    private RequestStatus requestStatus;
    /**
     * unique global id
     */
    private String applicationId;
    /**
     * acquirer request id (unique across each acquirer)
     */
    private String requestId;
    /**
     * application content
     */
    private String payload; // todo replace with object model
    /**
     * List of tasks
     */
    private Map<TargetSystem, Collection<Task>> tasksMap = new HashMap<>();

    public static List<TargetSystem> eligibleTargetSystems() {
        // todo write logic
        return Arrays.asList(TargetSystem.Way4, TargetSystem.Base24, TargetSystem.NGen_Gateway);
    }

    public void updateTasks(TargetSystem targetSystem, Collection<Task> tasks) {
        tasksMap.put(targetSystem, tasks);
    }

    public boolean targetSystemCompleted(TargetSystem targetSystem) {
        Collection<Task> tasks = tasksMap.get(targetSystem);
        if (tasks == null || tasks.isEmpty()) return false;
        return tasks.stream().allMatch(task -> TaskStatus.COMPLETED.equals(task.getTaskStatus()));
    }

    public boolean targetSystemFailed(TargetSystem targetSystem) {
        Collection<Task> tasks = tasksMap.get(targetSystem);
        if (tasks == null || tasks.isEmpty()) return false;
        return tasks.stream().anyMatch(task -> TaskStatus.FAILED.equals(task.getTaskStatus()));
    }

    public boolean allEligibleTargetSystemsCompleted() {
        return eligibleTargetSystems().stream().allMatch(this::targetSystemCompleted);
    }

}
