package ae.network.onboarding.octopus.database.model.request;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
public enum TaskStatus {
    SCHEDULED, SENT_TO_TARGET, COMPLETED, COMPLETED_WITH_ERROR, FAILED, CANCELLED
}
