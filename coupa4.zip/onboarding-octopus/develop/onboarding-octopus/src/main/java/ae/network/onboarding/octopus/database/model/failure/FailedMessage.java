package ae.network.onboarding.octopus.database.model.failure;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.data.mongodb.core.mapping.Document;

import java.nio.charset.StandardCharsets;

/**
 * @author walid.sewaify
 * @since 2020-01-26
 */
@Data
@NoArgsConstructor
@Document("failures")
public class FailedMessage {
    private MessageProperties properties;
    private DBObject body;
    private String bodyString;

    public FailedMessage(Message message) {
        this.properties = message.getMessageProperties();
        this.bodyString = new String(message.getBody(), StandardCharsets.UTF_8);
        this.body = BasicDBObject.parse(bodyString);
    }
}
