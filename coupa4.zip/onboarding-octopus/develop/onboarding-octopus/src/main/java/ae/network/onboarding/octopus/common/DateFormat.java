package ae.network.onboarding.octopus.common;

/**
 * @author walid.sewaify
 * @since 2020-01-26
 */
public interface DateFormat {
    String FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
}
