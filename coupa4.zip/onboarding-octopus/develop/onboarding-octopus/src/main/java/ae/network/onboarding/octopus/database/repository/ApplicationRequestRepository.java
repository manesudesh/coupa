package ae.network.onboarding.octopus.database.repository;

import ae.network.onboarding.octopus.database.model.request.ApplicationRequest;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
public interface ApplicationRequestRepository extends MongoRepository<ApplicationRequest, String> {
    Optional<ApplicationRequest> findByApplicationId(String applicationId);
}
