package ae.network.onboarding.octopus.database.service;

import ae.network.onboarding.octopus.database.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.database.repository.ApplicationRequestRepository;
import ae.network.onboarding.octopus.rabbitmq.RabbitService;
import ae.network.onboarding.octopus.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.octopus.security.UserDetails;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
@Service
public class ApplicationRequestService {
    private final ApplicationRequestRepository repository;
    private final RabbitService rabbitService;
    private final UserDetails userDetails;

    public ApplicationRequestService(ApplicationRequestRepository repository, RabbitService rabbitService, UserDetails userDetails) {
        this.repository = repository;
        this.rabbitService = rabbitService;
        this.userDetails = userDetails;
    }


    public ApplicationRequest createAndSendApplication(ApplicationRequest request) {
        request = repository.save(request);
        sendApplicationToBackendWorkers(request);
        return request;
    }

    public void saveOrUpdateApplication(ApplicationRequest request) {
        repository.save(request);
    }

    private void sendApplicationToBackendWorkers(ApplicationRequest request) {
        // todo send app to way4, base23, or any other app
        // if update, resend failed tasks!
        for (RabbitQueue queue : RabbitQueue.getInitialWorkingQueues()) {
            rabbitService.sendMessage(queue, request);
        }
    }

    public Optional<ApplicationRequest> findByApplicationId(String applicationId) {
        return repository.findByApplicationId(applicationId);
    }
}
