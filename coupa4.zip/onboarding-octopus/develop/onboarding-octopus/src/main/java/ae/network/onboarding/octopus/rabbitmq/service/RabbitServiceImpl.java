package ae.network.onboarding.octopus.rabbitmq.service;

import ae.network.onboarding.octopus.rabbitmq.RabbitService;
import ae.network.onboarding.octopus.rabbitmq.config.RabbitQueue;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import static ae.network.onboarding.octopus.rabbitmq.config.RabbitExchange.ONBOARDING;
import static ae.network.onboarding.octopus.rabbitmq.config.RabbitExchange.ONBOARDING_RETRY;

@Service
@Slf4j
public class RabbitServiceImpl implements RabbitService {
    private final RabbitTemplate rabbitTemplate;

    public RabbitServiceImpl(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    @Override
    public void sendMessage(RabbitQueue queue, Object message) {
        log.info("Sending to queue {} message {}", queue.getQueueName(), message);
        rabbitTemplate.convertAndSend(ONBOARDING.getExchangeName(), getDefaultRoutingKey(queue), message);
    }

    @Override
    public void retryMessage(Message message, int seconds) {
        MessageProperties messageProperties = message.getMessageProperties();
        messageProperties.setDelay(seconds * 1000);
        log.info("Scheduling retry to message {} in {} seconds", message, seconds);
        rabbitTemplate.send(ONBOARDING_RETRY.getExchangeName(), messageProperties.getReceivedRoutingKey(), message);
    }

    private String getDefaultRoutingKey(RabbitQueue queue) {
        if (queue.getRoutingKeys().isEmpty()) {
            throw new AmqpException("Invalid destination");
        }
        return queue.getRoutingKeys().get(0);
    }
}
