package ae.network.onboarding.octopus.database.model.request;

public enum Source {
    API
}
