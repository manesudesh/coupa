package ae.network.onboarding.octopus.database.model.reply;

import ae.network.onboarding.octopus.database.model.request.TargetSystem;
import ae.network.onboarding.octopus.database.model.request.Task;
import lombok.Data;

import java.util.Collection;

/**
 * @author walid.sewaify
 * @since 2020-01-23
 */
@Data
public class ApplicationUpdate {
    private String applicationId;
    private TargetSystem targetSystem;
    private Collection<Task> tasks;
}
