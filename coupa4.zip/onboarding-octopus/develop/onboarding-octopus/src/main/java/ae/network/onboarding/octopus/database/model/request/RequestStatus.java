package ae.network.onboarding.octopus.database.model.request;

public enum RequestStatus {
    IN_PROGRESS, COMPLETED, FAILED
}
