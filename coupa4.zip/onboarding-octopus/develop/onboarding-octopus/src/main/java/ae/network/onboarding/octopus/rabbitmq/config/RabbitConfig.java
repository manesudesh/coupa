package ae.network.onboarding.octopus.rabbitmq.config;

import ae.network.onboarding.octopus.rabbitmq.processors.CorrelationDataProcessor;
import ae.network.onboarding.octopus.rabbitmq.processors.MaxRetryProcessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@Configuration
@EnableRabbit
public class RabbitConfig {

    private final CorrelationDataProcessor dataProcessor;
    private final MaxRetryProcessor maxRetryProcessor;

    public RabbitConfig(CorrelationDataProcessor dataProcessor, MaxRetryProcessor maxRetryProcessor) {
        this.dataProcessor = dataProcessor;
        this.maxRetryProcessor = maxRetryProcessor;
    }

    @Bean
    public AmqpAdmin rabbitAdmin(ConnectionFactory factory) {
        return new RabbitAdmin(factory);
    }

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory factory) {
        RabbitTemplate rabbitTemplate = new RabbitTemplate(factory);
        ObjectMapper jsonObjectMapper = new ObjectMapper();
        jsonObjectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        Jackson2JsonMessageConverter messageConverter = new Jackson2JsonMessageConverter(jsonObjectMapper);
        rabbitTemplate.setMessageConverter(messageConverter);
        rabbitTemplate.setBeforePublishPostProcessors(dataProcessor, maxRetryProcessor);
        return rabbitTemplate;
    }
}
