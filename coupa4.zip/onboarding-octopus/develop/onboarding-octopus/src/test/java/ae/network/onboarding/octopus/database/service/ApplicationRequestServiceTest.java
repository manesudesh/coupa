package ae.network.onboarding.octopus.database.service;

import ae.network.onboarding.octopus.DummyRabbit;
import ae.network.onboarding.octopus.database.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.database.model.request.RequestStatus;
import ae.network.onboarding.octopus.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.octopus.rabbitmq.service.RabbitServiceImpl;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.annotation.DirtiesContext;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

//@SpringBootTest
//@Import(DummyRabbit.class)
//@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class ApplicationRequestServiceTest {

    @Autowired
    ApplicationRequestService service;

    @MockBean
    RabbitServiceImpl rabbitService;

//    @Test
    void testCreateNewApplication() {
        ApplicationRequest request = new ApplicationRequest();
        String id = "id_1";
        request.setApplicationId(id);
        request = service.createAndSendApplication(request);
        assertEquals(service.findByApplicationId(id).orElse(null), request);
        Mockito.verify(rabbitService, times(RabbitQueue.getInitialWorkingQueues().size())).sendMessage(any(), any());
    }

//    @Test
    void testUpdate() {
        ApplicationRequest request = new ApplicationRequest();
        String id = "id_2";
        request.setApplicationId(id);
        request = service.createAndSendApplication(request);
        request.setRequestStatus(RequestStatus.COMPLETED);
        service.saveOrUpdateApplication(request);
        Optional<ApplicationRequest> found = service.findByApplicationId(id);
        assertTrue(found.isPresent());
        assertEquals(found.get().getRequestStatus(), RequestStatus.COMPLETED);
    }
}