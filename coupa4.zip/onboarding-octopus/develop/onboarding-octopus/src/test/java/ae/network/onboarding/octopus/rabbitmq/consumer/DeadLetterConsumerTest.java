package ae.network.onboarding.octopus.rabbitmq.consumer;

import ae.network.onboarding.octopus.DummyRabbit;
import ae.network.onboarding.octopus.database.model.failure.FailedMessage;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.core.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

//@SpringBootTest
//@Import(DummyRabbit.class)
class DeadLetterConsumerTest {

    @Autowired
    DeadLetterConsumer deadLetterConsumer;

    @Autowired
    MongoTemplate mongoTemplate;

//    @Test
    void onMessage() {
        Message message = new Message("{message: 'Hello'}".getBytes(), null);
        deadLetterConsumer.onMessage(message);
        List<FailedMessage> failedMessages = mongoTemplate.find(new Query(), FailedMessage.class);
        assertEquals(failedMessages.size(), 1);
    }
}