package ae.network.onboarding.octopus.rabbitmq.consumer;

import ae.network.onboarding.octopus.DummyRabbit;
import ae.network.onboarding.octopus.database.model.reply.ApplicationUpdate;
import ae.network.onboarding.octopus.database.model.request.*;
import ae.network.onboarding.octopus.database.service.ApplicationRequestService;
import ae.network.onboarding.octopus.event.ApplicationCompletedEvent;
import ae.network.onboarding.octopus.event.ApplicationFailedEvent;
import ae.network.onboarding.octopus.event.Way4Base24CompletedEvent;
import ae.network.onboarding.octopus.exception.MessageRejectionException;
import ae.network.onboarding.octopus.rabbitmq.service.RabbitServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.springframework.amqp.core.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Import;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;

import static ae.network.onboarding.octopus.database.model.request.TargetSystem.Base24;
import static ae.network.onboarding.octopus.database.model.request.TargetSystem.Way4;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

//@SpringBootTest
//@Import(DummyRabbit.class)
class ApplicationUpdateConsumerTest {

    private static final String APP_ID = "4d9779e9-acf4-4b64-8594-9b742072804d";

    private ApplicationUpdateConsumer updateConsumer;

    @MockBean
    private RabbitServiceImpl rabbitService;

    @Autowired
    private ApplicationRequestService requestService;

    @Mock
    private ApplicationEventPublisher applicationEventPublisher;

    @Captor
    private ArgumentCaptor<ApplicationEvent> publishEventCaptor;

//    @BeforeEach
    void init() {
        updateConsumer = new ApplicationUpdateConsumer(requestService, rabbitService, applicationEventPublisher);
        ApplicationRequest request = new ApplicationRequest();
        request.setId("1");
        request.setApplicationId(APP_ID);
        request.setRequestStatus(RequestStatus.IN_PROGRESS);
        requestService.saveOrUpdateApplication(request);
    }

//    @Test
    void testInvalidApplicationThrowsMessageRejection() throws JsonProcessingException {

        Message message = getUpdateMessage("ID_NOT_THERE", Way4, TaskStatus.COMPLETED);

        assertThrows(MessageRejectionException.class, () -> updateConsumer.onMessage(message));
    }

//    @Test
    void testInvalidJsonThrowsMessageRejection() {
        Message message = new Message("Invalid JSON".getBytes(), null);

        assertThrows(MessageRejectionException.class, () -> updateConsumer.onMessage(message));
    }

//    @Test
    void testCompletedApplicationThrowsMessageRejection() throws JsonProcessingException {
        ApplicationRequest request = requestService.findByApplicationId(APP_ID).orElse(new ApplicationRequest());
        request.setRequestStatus(RequestStatus.COMPLETED);
        requestService.saveOrUpdateApplication(request);
        Message message = getUpdateMessage(Base24, TaskStatus.COMPLETED);

        assertThrows(MessageRejectionException.class, () -> updateConsumer.onMessage(message));
    }

//    @Test
    void testApplicationUpdated() throws JsonProcessingException {
        Message message = getUpdateMessage(Base24, TaskStatus.COMPLETED);
        updateConsumer.onMessage(message);
        assertEquals(1, requestService.findByApplicationId(APP_ID).orElseThrow(IllegalStateException::new)
                .getTasksMap().get(Base24).size());
    }

    private Message getUpdateMessage(TargetSystem system, TaskStatus taskStatus) throws JsonProcessingException {
        return getUpdateMessage(APP_ID, system, taskStatus);
    }

    private Message getUpdateMessage(String applicationId, TargetSystem system, TaskStatus taskStatus) throws JsonProcessingException {
        ApplicationUpdate applicationUpdate = createApplicationUpdate(applicationId, system, taskStatus);

        ObjectMapper objectMapper = new ObjectMapper();
        String content = objectMapper.writeValueAsString(applicationUpdate);
        return new Message(content.getBytes(), null);
    }

//    @Test
    void testFailedEventPublished() throws JsonProcessingException {

        Message message = getUpdateMessage(Base24, TaskStatus.FAILED);

        updateConsumer.onMessage(message);
        verify(applicationEventPublisher, times(1)).publishEvent(publishEventCaptor.capture());
        assertTrue(publishEventCaptor.getValue() instanceof ApplicationFailedEvent);
    }

//    @Test
    void testCompletedBase24Way4EventPublished() throws JsonProcessingException {
        for (TargetSystem system : Arrays.asList(Way4, Base24)) {
            Message message = getUpdateMessage(system, TaskStatus.COMPLETED);
            updateConsumer.onMessage(message);
        }
        verify(applicationEventPublisher, times(1)).publishEvent(publishEventCaptor.capture());
        assertTrue(publishEventCaptor.getValue() instanceof Way4Base24CompletedEvent);
    }

//    @Test
    void testApplicationCompletedEventPublished() throws JsonProcessingException {
        for (TargetSystem system : ApplicationRequest.eligibleTargetSystems()) {
            Message message = getUpdateMessage(system, TaskStatus.COMPLETED);
            updateConsumer.onMessage(message);
        }
        verify(applicationEventPublisher, atLeastOnce()).publishEvent(publishEventCaptor.capture());
        assertTrue(publishEventCaptor.getValue() instanceof ApplicationCompletedEvent);
    }

//    @Test
    void testMessageRetryForRecoverableError() throws JsonProcessingException {
        ApplicationUpdateConsumer brokenConsumer = new ApplicationUpdateConsumer(null, rabbitService, applicationEventPublisher);
        Message message = getUpdateMessage(Way4, TaskStatus.COMPLETED);
        brokenConsumer.onMessage(message);
        verify(rabbitService, times(1)).retryMessage(any(), anyInt());
    }

    private ApplicationUpdate createApplicationUpdate(String applicationId, TargetSystem source, TaskStatus taskStatus) {
        ApplicationUpdate reply = new ApplicationUpdate();
        reply.setApplicationId(applicationId);
        reply.setTargetSystem(source);
        Task a = new Task();
        a.setId(1L);
        a.setName("some task");
        a.setTaskStatus(taskStatus);
        TaskHistory taskHistory = new TaskHistory();
        taskHistory.setCreatedDate(new Date());
        taskHistory.setLastModifiedDate(new Date());
        taskHistory.setResponse("backend responded");
        taskHistory.setStatusCode("200");
        taskHistory.setTaskStatus(taskStatus);
        a.setTaskHistory(Collections.singletonList(taskHistory));
        reply.setTasks(Collections.singletonList(a));
        return reply;
    }
}