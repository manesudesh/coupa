package ae.network.onboarding.octopus;

import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
//@TestConfiguration
public class DummyRabbit {
    @MockBean
    private AmqpAdmin rabbitAdmin;
}
