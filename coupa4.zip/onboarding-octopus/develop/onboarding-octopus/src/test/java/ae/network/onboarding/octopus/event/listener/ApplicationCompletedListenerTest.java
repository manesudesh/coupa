package ae.network.onboarding.octopus.event.listener;

import ae.network.onboarding.octopus.DummyRabbit;
import ae.network.onboarding.octopus.database.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.event.ApplicationCompletedEvent;
import ae.network.onboarding.octopus.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.octopus.rabbitmq.service.RabbitServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;

//@SpringBootTest
//@Import(DummyRabbit.class)
class ApplicationCompletedListenerTest {

    @Autowired
    private ApplicationCompletedListener listener;

    @MockBean
    private RabbitServiceImpl rabbitService;

//    @Test
    void testSendingNotification() {
        ApplicationRequest application = new ApplicationRequest();
        listener.onApplicationEvent(new ApplicationCompletedEvent(application));
        verify(rabbitService, atLeastOnce()).sendMessage(RabbitQueue.NOTIFICATIONS, application);
    }
}