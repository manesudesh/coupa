package ae.network.onboarding.octopus.rabbitmq.processors;

import ae.network.onboarding.octopus.DummyRabbit;
import ae.network.onboarding.octopus.exception.MessageRejectionException;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;

import static ae.network.onboarding.octopus.rabbitmq.processors.MaxRetryProcessor.MAX_RETRY_HEADER;
import static org.junit.jupiter.api.Assertions.*;

//@SpringBootTest
//@Import(DummyRabbit.class)
class MaxRetryProcessorTest {

    @Autowired
    private MaxRetryProcessor maxRetryProcessor;

//    @Test
    void testHeaderAddedForNewMessage() {
        Message message = new Message("Hi".getBytes(), new MessageProperties());
        message = maxRetryProcessor.postProcessMessage(message);
        assertNotNull(message.getMessageProperties().getHeader(MAX_RETRY_HEADER));
    }

//    @Test
    void testRetryAttemptsDecrement() {
        MessageProperties messageProperties = new MessageProperties();
        messageProperties.setHeader(MAX_RETRY_HEADER, 10);
        Message message = new Message("Hi".getBytes(), messageProperties);
        message = maxRetryProcessor.postProcessMessage(message);
        assertEquals(Integer.valueOf(9), message.getMessageProperties().getHeader(MAX_RETRY_HEADER));
    }

//    @Test
    void testNoRetryAfterReachingMax() {
        MessageProperties messageProperties = new MessageProperties();
        messageProperties.setHeader(MAX_RETRY_HEADER, 0);
        Message message = new Message("Hi".getBytes(), messageProperties);
        assertThrows(MessageRejectionException.class, () -> maxRetryProcessor.postProcessMessage(message));
    }
}