package ae.network.onboarding.octopus.rabbitmq.processors;

import ae.network.onboarding.octopus.DummyRabbit;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

//@SpringBootTest
//@Import(DummyRabbit.class)
class CorrelationDataProcessorTest {

    @Autowired
    private CorrelationDataProcessor dataProcessor;

//    @Test
    void testCorrelationIdAdded() {
        Message message = new Message("Hi".getBytes(), new MessageProperties());
        message = dataProcessor.postProcessMessage(message);
        assertNotNull(message.getMessageProperties().getCorrelationId());
    }

//    @Test
    void testCorrelationIdNotOverriden() {
        MessageProperties messageProperties = new MessageProperties();
        String correlationId = "id";
        messageProperties.setCorrelationId(correlationId);
        Message message = new Message("Hi".getBytes(), messageProperties);
        message = dataProcessor.postProcessMessage(message);
        assertEquals(correlationId, message.getMessageProperties().getCorrelationId());
    }
}