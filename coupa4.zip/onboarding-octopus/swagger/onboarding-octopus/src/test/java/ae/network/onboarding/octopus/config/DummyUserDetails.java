package ae.network.onboarding.octopus.config;

import ae.network.onboarding.octopus.model.request.BackendSystem;
import ae.network.onboarding.octopus.security.UserDetails;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;

import java.util.Arrays;

@TestConfiguration
public class DummyUserDetails {
    @Bean
    UserDetails getUserDetails() {
        final UserDetails userDetails = new UserDetails();
        userDetails.setAcquirer("NI");
        userDetails.setUsername("username");
        userDetails.setAuthorizedSystems(Arrays.asList(BackendSystem.WAY4, BackendSystem.BASE24));
        return userDetails;
    }

}
