package ae.network.onboarding.octopus.event.listener;

import ae.network.onboarding.octopus.event.ApplicationCompletedEvent;
import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.octopus.rabbitmq.service.RabbitServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ApplicationCompletedListenerTest {

    @Test
    void testSendingNotification(@Mock RabbitServiceImpl rabbitService) {
        ApplicationCompletedListener listener = new ApplicationCompletedListener(rabbitService);
        ApplicationRequest application = new ApplicationRequest();
        listener.onApplicationEvent(new ApplicationCompletedEvent(application));
        verify(rabbitService, atLeastOnce()).sendMessage(RabbitQueue.NOTIFICATIONS, application);
    }
}