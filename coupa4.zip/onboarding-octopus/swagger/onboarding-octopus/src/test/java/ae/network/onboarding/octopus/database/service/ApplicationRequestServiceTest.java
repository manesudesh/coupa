package ae.network.onboarding.octopus.database.service;

import ae.network.onboarding.octopus.database.repository.ApplicationRequestRepository;
import ae.network.onboarding.octopus.event.ApplicationReceivedEvent;
import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.model.request.BackendSystem;
import ae.network.onboarding.octopus.model.request.RequestStatus;
import ae.network.onboarding.octopus.security.UserDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.context.ApplicationEventPublisher;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

@DataMongoTest
class ApplicationRequestServiceTest {
    private final UserDetails userDetails = new UserDetails();
    @Autowired
    ApplicationRequestRepository repository;
    @Mock
    private
    ApplicationEventPublisher applicationEventPublisher;
    private ApplicationRequestService service;

    @BeforeEach
    void init() {
        service = new ApplicationRequestService(repository, applicationEventPublisher, getUserDetails());
    }

    private UserDetails getUserDetails() {
        userDetails.setAcquirer("NI");
        userDetails.setUsername("username");
        userDetails.setAuthorizedSystems(Arrays.asList(BackendSystem.WAY4, BackendSystem.BASE24));
        return userDetails;
    }

    @Test
    void testCreateNewApplication() {
        ApplicationRequest application = new ApplicationRequest();
        application.setRequestId("acquirer_id2");
        application = service.createApplication(application);
        assertEquals(service.findByApplicationId(application.getApplicationId()).orElse(null), application);
        assertEquals(userDetails.getUsername(), application.getUsername());
        assertEquals(userDetails.getAcquirer(), application.getAcquirer());
        assertEquals(userDetails.getAuthorizedSystems(), application.getAuthorizedSystems());
        Mockito.verify(applicationEventPublisher, times(1)).publishEvent(any(ApplicationReceivedEvent.class));
    }

    @Test
    void testUpdate() {
        ApplicationRequest request = new ApplicationRequest();
        request.setRequestId("acquirer_id3");
        request = service.createApplication(request);
        request.setRequestStatus(RequestStatus.COMPLETED);
        request = service.saveOrUpdateApplication(request);
        Optional<ApplicationRequest> found = service.findByApplicationId(request.getApplicationId());
        assertTrue(found.isPresent());
        assertEquals(found.get().getRequestStatus(), RequestStatus.COMPLETED);
    }

    @Test
    void testOpenApplications() {
        ApplicationRequest application = new ApplicationRequest();
        application.setRequestId("acquirer_open_request");
        Date twoHoursBefore = new Date(new Date().getTime() - 2 * 60 * 60000);
        application.setCreatedDate(twoHoursBefore);
        service.createApplication(application);
        List<ApplicationRequest> openApplicationOneHourBefore = service.findOpenApplications(1);
        assertEquals(0, openApplicationOneHourBefore.size());
        List<ApplicationRequest> openApplicationTwoHourBefore = service.findOpenApplications(2);
        assertEquals(0, openApplicationTwoHourBefore.size());
        List<ApplicationRequest> openApplicationThreeHoursBefore = service.findOpenApplications(3);
        assertEquals(1, openApplicationThreeHoursBefore.size());
    }
}