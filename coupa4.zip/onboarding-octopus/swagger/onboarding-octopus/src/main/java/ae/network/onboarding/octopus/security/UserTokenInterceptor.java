package ae.network.onboarding.octopus.security;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

/**
 * @author walid.sewaify
 * @since 2020-02-10
 */
@Component
@Slf4j
@Profile("security")
public class UserTokenInterceptor extends UserDetailsHandlerInterceptor {
    private static final String IP_HEADER = "X-Forwarded-For";

    private final UserDetails userDetails;
    private final JwtTokenProvider tokenProvider;

    public UserTokenInterceptor(UserDetails userDetails, JwtTokenProvider tokenProvider) {
        this.userDetails = userDetails;
        this.tokenProvider = tokenProvider;
    }

    @Override
    public void setUserDetails(HttpServletRequest request) throws IllegalAccessException {
        String token = tokenProvider.resolveToken(request);
        if (!tokenProvider.validateToken(token)) {
            throw new IllegalAccessException("User is not authorized");
        }

        // update request scoped user details
        UserDetails requestUserDetails = tokenProvider.getUserDetails(token);
        userDetails.setUsername(requestUserDetails.getUsername());
        userDetails.setAcquirer(requestUserDetails.getAcquirer());
        userDetails.setAuthorizedSystems(requestUserDetails.getAuthorizedSystems());
        userDetails.setIp(request.getHeader(IP_HEADER));
    }
}
