package ae.network.onboarding.octopus.controller;

import ae.network.onboarding.octopus.database.service.ApplicationRequestService;
import ae.network.onboarding.octopus.exception.ApplicationNotFoundException;
import ae.network.onboarding.octopus.model.dto.AcquirerRequest;
import ae.network.onboarding.octopus.model.dto.AcquirerResponse;
import ae.network.onboarding.octopus.model.dto.AmendmentRequest;
import ae.network.onboarding.octopus.model.dto.CreateOnboardingRequest;
import ae.network.onboarding.octopus.model.dto.MerchantClosureRequest;
import ae.network.onboarding.octopus.model.dto.ScreeningRequest;
import ae.network.onboarding.octopus.model.dto.ScreeningResponse;
import ae.network.onboarding.octopus.model.dto.TerminalClosureRequest;
import ae.network.onboarding.octopus.model.reply.Attachment;
import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.model.request.BackendSystem;
import ae.network.onboarding.octopus.model.request.RequestStatus;
import ae.network.onboarding.octopus.model.request.RequestType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static ae.network.onboarding.octopus.controller.OnboardingController.VER;


/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@Api(tags = OnboardingController.CONTROLLER_NAME)
@RestController
@RequestMapping({"/onboarding", "/onboarding/v" + VER})
public class OnboardingController extends AbstractController {
    static final String VER = "1";
    public static final String CONTROLLER_NAME = "Digital Onboarding Operations";
    public static final String CONTROLLER_DESCRIPTION = "Endpoints for Application creation, amendment, " +
            "merchant closure, terminal closure, screening, status probes, and reporting";

    public OnboardingController(ApplicationRequestService applicationRequestService) {
        super(applicationRequestService);
    }

    @PostMapping("/create")
    @ApiOperation(value = "Create new onboarding application")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Something went wrong"),
            @ApiResponse(code = 422, message = "Invalid username/password supplied")})
    public AcquirerResponse create(@Valid @RequestBody CreateOnboardingRequest request) {
        return submitGenericApplication(request, RequestType.ONBOARDING);
    }

    @ApiOperation(value = "Amend existing onboarding application")
    @PutMapping("/amend")
    public AcquirerResponse amend(@Valid @RequestBody AmendmentRequest request) {
        return submitGenericApplication(request, RequestType.AMENDMENT);
    }

    @ApiOperation(value = "Close existing merchant")
    @PostMapping("/closeMerchant")
    public AcquirerResponse closeMerchant(@Valid @RequestBody MerchantClosureRequest request) {
        return submitGenericApplication(request, RequestType.MERCHANT_CLOSURE);
    }

    @ApiOperation(value = "Close existing merchant terminal (device)")
    @PostMapping("/closeTerminal")
    public AcquirerResponse closeTerminal(@Valid @RequestBody TerminalClosureRequest request) {
        return submitGenericApplication(request, RequestType.TERMINAL_CLOSURE);
    }

    @ApiOperation(value = "Screen merchant")
    @PostMapping("/screenMerchant")
    public AcquirerResponse inspect(@Valid @RequestBody ScreeningRequest acquirerRequest) {
        return submitScreeningApplication(acquirerRequest);
    }

    @ApiOperation(value = "Check request status")
    @GetMapping("/checkStatus")
    public AcquirerResponse checkStatus(String requestId, Boolean detailed) {
        return getApplicationResponse(requestId, detailed);
    }

    @ApiOperation(value = "Check screening results")
    @GetMapping("/screenResults")
    public ScreeningResponse screenResults(String requestId) {
        Optional<ApplicationRequest> applicationRequest = super.findApplication(requestId);
        if (!applicationRequest.isPresent() || applicationRequest.get().getRequestType() != RequestType.SCREENING
                || applicationRequest.get().getRequestStatus() != RequestStatus.COMPLETED) {
            throw new ApplicationNotFoundException();
        }
        Map<BackendSystem, String> reportDownloadMap = new HashMap<>();
        for (Map.Entry<BackendSystem, Attachment> entry : applicationRequest.get().getAttachmentsMap().entrySet()) {
            if (entry.getValue() != null) {
                reportDownloadMap.put(entry.getKey(), getAttachmentLink(entry.getKey()));
            }
        }
        return new ScreeningResponse(applicationRequest.get().getScreeningMap(), reportDownloadMap);
    }

    @ApiOperation(value = "Download backend system report")
    @GetMapping(value = "/downloadReport/{backendSystem}")
    public void downloadReport(@PathVariable("backendSystem") String backendSystem,
                               String requestId, HttpServletResponse response) {
        // validate request
        if (!BackendSystem.contains(backendSystem)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid backend system");
        }
        Optional<ApplicationRequest> applicationRequest = super.findApplication(requestId);
        if (!applicationRequest.isPresent()) {
            throw new ApplicationNotFoundException();
        }
        Attachment attachment = applicationRequest.get().getAttachmentsMap().get(BackendSystem.valueOf(backendSystem));
        if (attachment == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No files founds");
        }

        // add attachment to response
        response.setContentType(attachment.getContentType());
        try {
            IOUtils.copy(new ByteArrayInputStream(attachment.getContent()), response.getOutputStream());
            response.flushBuffer();
        } catch (IOException ex) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Corrupted file");
        }
    }

    private AcquirerResponse submitScreeningApplication(ScreeningRequest request) {
        ApplicationRequest applicationRequest = super.buildApplicationRequest(request, RequestType.SCREENING);
        String screeningResult = getScreeningLink(applicationRequest.getRequestId());
        applicationRequest.setScreeningResult(screeningResult);
        applicationRequest = super.submitApplication(applicationRequest);
        return new AcquirerResponse(applicationRequest);
    }

    private String getScreeningLink(String requestId) {
        return ServletUriComponentsBuilder.fromCurrentRequest().replacePath("/onboarding/screenResults").scheme("https")
                .replaceQuery(null).queryParam("requestId", requestId).build().toString();
    }

    private String getAttachmentLink(BackendSystem system) {
        return ServletUriComponentsBuilder.fromCurrentRequest()
                .replacePath("/onboarding/downloadReport/" + system.name()).scheme("https").build().toString();
    }

    private AcquirerResponse submitGenericApplication(AcquirerRequest request, RequestType requestType) {
        ApplicationRequest applicationRequest = super.buildApplicationRequest(request, requestType);
        applicationRequest.setPayloadVersion(VER);
        applicationRequest = super.submitApplication(applicationRequest);
        return new AcquirerResponse(applicationRequest);
    }
}
