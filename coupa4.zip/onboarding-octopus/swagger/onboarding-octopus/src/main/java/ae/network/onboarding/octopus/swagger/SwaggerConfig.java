package ae.network.onboarding.octopus.swagger;

import ae.network.onboarding.octopus.controller.OnboardingController;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.Tag;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

import java.util.Collections;
import java.util.Optional;

/**
 * @author walid.sewaify
 * @since 2020-08-03
 */
@Configuration
public class SwaggerConfig {
    @Bean
    public Docket api() {
        ApiKey apiKey = new ApiKey("Bearer %token", "Authorization", "Header");
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.any())
                .paths(s -> s.contains("/onboarding"))
                .build()
                .apiInfo(metadata())
                .useDefaultResponseMessages(false)
                .securitySchemes(Collections.singletonList(apiKey))
                .tags(new Tag(OnboardingController.CONTROLLER_NAME, OnboardingController.CONTROLLER_DESCRIPTION))
                .genericModelSubstitutes(Optional.class);
    }

    private ApiInfo metadata() {
        return new ApiInfoBuilder()
                .title("Network International Digital Onboarding")
                .description(
                        "APIs for managing onboarding workflow (Creation, Amendment, or Closure of merchants)")
                .version("1.0.0")
                .build();
    }

}
