package ae.network.onboarding.octopus.rabbitmq.consumer;

import ae.network.onboarding.octopus.common.MdcUtils;
import ae.network.onboarding.octopus.database.service.ApplicationRequestService;
import ae.network.onboarding.octopus.event.ApplicationCompletedEvent;
import ae.network.onboarding.octopus.event.ApplicationFailedEvent;
import ae.network.onboarding.octopus.event.OnboardingApplicationEvent;
import ae.network.onboarding.octopus.event.StageOneCompletedEvent;
import ae.network.onboarding.octopus.exception.ApplicationNotFoundException;
import ae.network.onboarding.octopus.exception.MessageRejectionException;
import ae.network.onboarding.octopus.model.reply.ApplicationUpdate;
import ae.network.onboarding.octopus.model.reply.ProcessingResult;
import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.model.request.BackendSystem;
import ae.network.onboarding.octopus.model.request.RequestStatus;
import ae.network.onboarding.octopus.model.request.TaskStatus;
import ae.network.onboarding.octopus.rabbitmq.RabbitService;
import ae.network.onboarding.octopus.rabbitmq.config.RabbitQueue;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import static ae.network.onboarding.octopus.common.LogEvent.backendUpdate;
import static ae.network.onboarding.octopus.common.LogEvent.elapsed;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@Component
@Slf4j
public class ApplicationUpdateConsumer implements MessageListener {
    private final ApplicationRequestService applicationRequestService;
    private final RabbitService rabbitService;
    private final ApplicationEventPublisher applicationEventPublisher;

    public ApplicationUpdateConsumer(ApplicationRequestService applicationRequestService, RabbitService rabbitService,
                                     ApplicationEventPublisher applicationEventPublisher) {
        this.applicationRequestService = applicationRequestService;
        this.rabbitService = rabbitService;
        this.applicationEventPublisher = applicationEventPublisher;
    }

    @Bean
    SimpleMessageListenerContainer replyListener(ConnectionFactory connectionFactory) {
        SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
        container.setConnectionFactory(connectionFactory);
        container.setQueueNames(RabbitQueue.UPDATES.getQueueName());
        container.setMessageListener(this);
        return container;
    }

    @Override
    public void onMessage(Message message) {
        MdcUtils.setCorrId(message.getMessageProperties().getCorrelationId());

        String messageContent = new String(message.getBody());
        log.info("Received update message {}", messageContent);

        try {
            ApplicationUpdate reply = new ObjectMapper().readValue(messageContent, ApplicationUpdate.class);
            ApplicationRequest app = applicationRequestService.findByApplicationId(reply.getApplicationId())
                    .orElseThrow(ApplicationNotFoundException::new);

            RequestStatus currentRequestStatus = app.getRequestStatus();
            log.info("current request status before updates: {}", currentRequestStatus);

            // check if application is already completed
            if (currentRequestStatus == RequestStatus.COMPLETED) {
                throw new MessageRejectionException("application is already completed");
            }

            // check if backend system already completed the job
            BackendSystem backendSystem = reply.getBackendSystem();
            ProcessingResult existingResults = app.getResultsMap().get(backendSystem);
            if (existingResults != null && existingResults.getFinalStatus() == TaskStatus.COMPLETED) {
                throw new MessageRejectionException("backend system already posted completed status");
            }

            ProcessingResult newResult = reply.getProcessingResult();
            app.updateTasks(backendSystem, newResult);
            app.addAttachment(backendSystem, reply.getAttachment());
            app.addScreeningResult(backendSystem, reply.getScreeningResults());
            app.addAdditionalData(backendSystem, reply.getAdditionalData());

            RequestStatus newApplicationStatus = app.getRequestStatus();
            applicationRequestService.saveOrUpdateApplication(app);

            if (newApplicationStatus == currentRequestStatus || newResult.getFinalStatus() == TaskStatus.IN_PROGRESS) {
                // no events triggered, save the tasks and return
                log.info("application still waiting for more updates");
                return;
            }

            log.info("Received backend system final update", backendUpdate(reply), elapsed(app.getElapsedTime()));

            OnboardingApplicationEvent event = null;
            if (RequestStatus.FAILED.equals(newApplicationStatus)) {
                event = new ApplicationFailedEvent(app);
            } else if (RequestStatus.COMPLETED.equals(newApplicationStatus)) {
                event = new ApplicationCompletedEvent(app);
            } else if (RequestStatus.STAGE_ONE_COMPLETED.equals(newApplicationStatus)) {
                event = new StageOneCompletedEvent(app);
            }
            if (event != null) {
                applicationEventPublisher.publishEvent(event);
            }
        } catch (MessageRejectionException | JsonProcessingException e) {
            log.error(e.getMessage(), e);
            throw new MessageRejectionException(e);
        } catch (Exception e) {
            log.error("Error at processing the message, retrying later..", e);
            rabbitService.retryMessage(message);
        }
    }
}
