package ae.network.onboarding.octopus.model.dto;

import ae.network.onboarding.octopus.model.reply.ScreeningResult;
import ae.network.onboarding.octopus.model.request.BackendSystem;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @author walid.sewaify
 * @since 2020-03-01
 */
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ScreeningResponse {

    private Set<EntityScreening> entities = new HashSet<>();

    public ScreeningResponse(Map<BackendSystem, Collection<ScreeningResult>> resultsMap,
                             Map<BackendSystem, String> reportDownloadMap) {
        resultsMap.forEach((backendSystem, screeningResults) -> {
            for (ScreeningResult screeningResult : screeningResults) {
                String entityId = screeningResult.getEntityId();
                EntityScreening entityScreening = entities.stream()
                        .filter(entity -> entityId != null && entityId.equals(entity.getEntityId()))
                        .findAny().orElse(new EntityScreening());
                entityScreening.setEntityId(entityId);
                entityScreening.getScreeningResult().put(backendSystem, screeningResult);
                if (reportDownloadMap.containsKey(backendSystem)) {
                    screeningResult.setDownloadReport(reportDownloadMap.get(backendSystem));
                }
                entities.add(entityScreening);
            }
        });
    }
}
