package ae.network.onboarding.octopus.security;

import ae.network.onboarding.octopus.model.request.BackendSystem;
import io.jsonwebtoken.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.util.Base64;
import java.util.stream.Collectors;

import static java.util.Arrays.stream;

@Component
@Slf4j
@Profile("security")
public class JwtTokenProvider {

    private static final String SYSTEMS_KEY = "authBackend";
    private static final String ACQUIRER_KEY = "acquirer";

    @Value("${security.jwt.token.secret-key:secret-key}")
    private String secretKey;

    @PostConstruct
    protected void init() {
        secretKey = Base64.getEncoder().encodeToString(secretKey.getBytes());
    }

    public UserDetails getUserDetails(String token) {
        Claims claims = getClaims(token);
        UserDetails userDetails = new UserDetails();
        userDetails.setUsername(claims.getSubject());
        userDetails.setAcquirer(claims.get(ACQUIRER_KEY, String.class));
        String[] authSys = claims.get(SYSTEMS_KEY, String.class).split(",");
        userDetails.setAuthorizedSystems(stream(authSys).map(BackendSystem::valueOf).collect(Collectors.toList()));
        return userDetails;
    }

    private Claims getClaims(String token) {
        return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody();
    }

    public String resolveToken(HttpServletRequest request) {
        String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (authHeader == null) {
            throw new SecurityException("Security token not provided");
        }
        if (authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }
        return null;
    }

    public boolean validateToken(String authToken) {
        try {
            Jwts.parser().setSigningKey(secretKey).parseClaimsJws(authToken);
            return true;
        } catch (SignatureException | MalformedJwtException e) {
            log.info("Invalid JWT signature.");
            log.trace("Invalid JWT signature trace: {}", e);
        } catch (ExpiredJwtException e) {
            log.info("Expired JWT token.");
            log.trace("Expired JWT token trace: {}", e);
        } catch (UnsupportedJwtException e) {
            log.info("Unsupported JWT token.");
            log.trace("Unsupported JWT token trace: {}", e);
        } catch (IllegalArgumentException e) {
            log.info("JWT token compact of handler are invalid.");
            log.trace("JWT token compact of handler are invalid trace: {}", e);
        }
        return false;
    }

}