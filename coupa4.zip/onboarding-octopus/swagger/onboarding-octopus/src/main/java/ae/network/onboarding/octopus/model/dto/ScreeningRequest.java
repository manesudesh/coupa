package ae.network.onboarding.octopus.model.dto;

import ae.network.onboarding.octopus.controller.validation.ValidScreeningPayload;
import ae.network.onboarding.octopus.model.request.BackendSystem;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-03-01
 */
@Data
public class ScreeningRequest implements AcquirerRequest {
    @NotNull
    @Size(min = 6, max = 64)
    @Pattern(regexp = "[a-zA-Z0-9\\-_]*")
    private String requestId;
    @Pattern(regexp = "^$|https?://[^\\s/$.?#].[^\\s]{0,30}")
    private String callbackUrl;
    @Email
    private String callbackEmail;
    @ValidScreeningPayload
    private JsonNode payload;
    // filter authorized systems
    private List<BackendSystem> backendSystems;
    private boolean dryRun;
    private boolean retry;
}
