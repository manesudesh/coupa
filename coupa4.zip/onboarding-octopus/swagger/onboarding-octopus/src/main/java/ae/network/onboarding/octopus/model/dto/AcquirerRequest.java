package ae.network.onboarding.octopus.model.dto;

import ae.network.onboarding.octopus.model.request.BackendSystem;
import com.fasterxml.jackson.databind.JsonNode;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-05-19
 */
public interface AcquirerRequest {
    @ApiModelProperty(value = "Acquirer unique ID used for tracking applications")
    String getRequestId();

    @ApiModelProperty(value = "Acquirer endpoint for receiving application updates")
    String getCallbackUrl();

    @ApiModelProperty(value = "Email for receiving application updates")
    String getCallbackEmail();

    // this is implementation specific (creation, amendment, closure, etc.)
    JsonNode getPayload();

    @ApiModelProperty(value = "Optional list of backend systems targeted for this application")
    List<BackendSystem> getBackendSystems();

    boolean isDryRun();

    boolean isRetry();
}
