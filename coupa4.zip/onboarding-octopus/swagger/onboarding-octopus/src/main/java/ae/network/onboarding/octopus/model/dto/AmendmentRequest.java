package ae.network.onboarding.octopus.model.dto;

import ae.network.onboarding.octopus.swagger.ApiModelExamples;
import com.fasterxml.jackson.databind.JsonNode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value = "AmendmentRequest", description = "Request for merchant amendment")
public class AmendmentRequest extends OnboardingRequest {

    @ApiModelProperty(dataType = "om.fasterxml.jackson.databind.JsonNode",
            value = "Application Payload JSON",
            example = ApiModelExamples.AMEND_APPLICATION)
    @Override
    public JsonNode getPayload() {
        return super.getPayload();
    }
}
