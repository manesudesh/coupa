package ae.network.onboarding.octopus.rabbitmq.config;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
public enum RabbitQueue {
    // Backend Queues
    WAY4("way4", "routing.backend.way4"),
    BASE24("base24", "routing.backend.base24"),
    NGO("ngo", "routing.backend.ngo"),
    NGT("ngt", "routing.backend.ngt"),
    MCSEC("mcsec", "routing.backend.mcsec"),
    PP("pp", "routing.backend.pp"),
    MCP("mcp", "routing.backend.mcp"),
    FXCO("fxco", "routing.backend.fxco"),
    POSINV("posinv", "routing.backend.posinv"),
    SS("ss", "routing.backend.ss"),
    ALIPAY("alipay", "routing.backend.alipay"),
    QRPAY("qrpay", "routing.backend.qrpay"),
    WECHAT("wechat", "routing.backend.wechat"),
    G2("g2", "routing.backend.g2"),
    LOYALTY("loyalty", "routing.backend.loyalty"),
    VERIFONE("verifone", "routing.backend.verifone"),
    // Screening Queues
    MATCH("mcmatch", "routing.backend.mcmatch"),
    FISERV("fiserv", "routing.backend.fiserv"),
    TRUSTWAVE("trustwave", "routing.backend.trustwave"),
    // processing queues
    UPDATES("updates", "routing.updates"),
    NOTIFICATIONS("notifications", "routing.notifications"),
    // RPC Queues
    UTILS("utils", "routing.utils"),
    // Testing Queues
    TEST("test", "routing.backend.test"),
    // Failure Queues
    FAILS("failures");

    private final String queueName;
    private final String[] routingKeys;

    RabbitQueue(String queueName, String... routingKeys) {
        this.queueName = queueName;
        this.routingKeys = routingKeys;
    }

    /**
     * @return all queues that bind to working exchanges (not failure)
     */
    public static List<RabbitQueue> getWorkingQueues() {
        return Arrays.stream(values()).filter(q -> q != FAILS).collect(Collectors.toList());
    }

    public String getQueueName() {
        return queueName;
    }

    public List<String> getRoutingKeys() {
        return Arrays.asList(routingKeys);
    }
}
