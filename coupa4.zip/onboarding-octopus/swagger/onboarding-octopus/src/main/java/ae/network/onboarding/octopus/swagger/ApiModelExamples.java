package ae.network.onboarding.octopus.swagger;

public class ApiModelExamples {

    public static final String CREATE_APPLICATION = "{\n" +
            "    \"applications\": [{\n" +
            "            \"merchants\": [{\n" +
            "                    \"merchantName\": \"MerchantTypePOS\",\n" +
            "                    \"legalName\": \"AABC\",\n" +
            "                    \"statementDay\": 28,\n" +
            "                    \"kyc\": true,\n" +
            "                    \"merchantId\": \"200485197358\",\n" +
            "                    \"debitAccountNumOrIban\": \"A27384474\",\n" +
            "                    \"creditAccountNumOrIban\": \"A12321584\",\n" +
            "                    \"merchantCurrency\": \"AED\",\n" +
            "                    \"merchantType\": \"POS\",\n" +
            "                    \"mcc\": 5814,\n" +
            "                    \"paymentMode\": \"EQ\",\n" +
            "                    \"statementDeliveryType\": \"Email\",\n" +
            "                    \"statementFrequency\": \"WEEKLY\",\n" +
            "                    \"addresses\": [{\n" +
            "                            \"pobox\": \"644973\",\n" +
            "                            \"city\": \"Dubai\",\n" +
            "                            \"phone\": \"12345678900\",\n" +
            "                            \"addressType\": \"DEFAULT\",\n" +
            "                            \"countryCode\": \"ARE\",\n" +
            "                            \"postalCode\": \"0000000784\",\n" +
            "                            \"state\": \"DXB\",\n" +
            "                            \"email\": \"farah@4maat.com\",\n" +
            "                            \"latitude\": \"25.2044464\",\n" +
            "                            \"longitude\": \"55.3418550\",\n" +
            "                            \"addressLines\": [\n" +
            "                                \"addressLine1\"\n" +
            "                            ]\n" +
            "                        }\n" +
            "                    ],\n" +
            "                    \"configurations\": {\n" +
            "                        \"overrideDefaultSchemesMcc\": false,\n" +
            "                        \"commissionSettlement\": \"NEXT_STTLM\",\n" +
            "                        \"acceptedCardSchemes\": [{\n" +
            "                                \"cardScheme\": \"VISA\",\n" +
            "                                \"tariffRate\": 1.5\n" +
            "                            }, {\n" +
            "                                \"cardScheme\": \"MC\",\n" +
            "                                \"tariffRate\": 1.5\n" +
            "                            }\n" +
            "                        ],\n" +
            "                        \"fees\": [{\n" +
            "                                \"reOccurrenceFrequency\": \"DAILY\",\n" +
            "                                \"feeTypeName\": \"MIS\",\n" +
            "                                \"feeValue\": 0.38\n" +
            "                            }, {\n" +
            "                                \"reOccurrenceFrequency\": \"DAILY\",\n" +
            "                                \"feeTypeName\": \"TRANS_FEE\",\n" +
            "                                \"feeValue\": 0.36\n" +
            "                            }, {\n" +
            "                                \"reOccurrenceFrequency\": \"DAILY\",\n" +
            "                                \"feeTypeName\": \"REFUND_FEE\",\n" +
            "                                \"feeValue\": 0.23\n" +
            "                            }\n" +
            "                        ]\n" +
            "                    },\n" +
            "                    \"terminals\": [{\n" +
            "                            \"terminalModel\": \"VX680\",\n" +
            "                            \"fees\": [{\n" +
            "                                    \"feeType\": \"SIM_FEE\",\n" +
            "                                    \"feeValue\": 0\n" +
            "                                }, {\n" +
            "                                    \"feeType\": \"GPRS_FEE\",\n" +
            "                                    \"feeValue\": 0\n" +
            "                                }, {\n" +
            "                                    \"feeType\": \"RENTAL_FEE\",\n" +
            "                                    \"feeValue\": 0\n" +
            "                                }, {\n" +
            "                                    \"feeType\": \"INSURANCE_FEE\",\n" +
            "                                    \"feeValue\": 0\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"allowedOperations\": {\n" +
            "                                \"preAuthorization\": false,\n" +
            "                                \"standardFunction\": true,\n" +
            "                                \"cashAdvance\": false,\n" +
            "                                \"tips\": false,\n" +
            "                                \"keyEntry\": false,\n" +
            "                                \"refund\": false\n" +
            "                            },\n" +
            "                            \"communicationMethod\": \"SG\",\n" +
            "                            \"maker\": \"NGINX\",\n" +
            "                            \"terminalId\": \"1928372\",\n" +
            "                            \"dccEnabled\": false,\n" +
            "                            \"terminalType\": \"PC\"\n" +
            "                        }\n" +
            "                    ]\n" +
            "                }\n" +
            "            ]\n" +
            "        }\n" +
            "    ]\n" +
            "}\n";

    public static final String AMEND_APPLICATION = "{\n" +
            "    \"applications\": [{\n" +
            "            \"merchants\": [{\n" +
            "                    \"amendmentList\": [\n" +
            "                        \"MERCHANT_NAME\",\n" +
            "                        \"LEGAL_NAME\",\n" +
            "                        \"MCC\",\n" +
            "                        \"ADDRESS\"\n" +
            "                    ],\n" +
            "                    \"merchantId\": \"200600144554\",\n" +
            "                    \"merchantName\": \"POS4prod0119 Mer NameChange\",\n" +
            "                    \"legalName\": \"POS4prod0118 Legal name change\",\n" +
            "                    \"mcc\": 3501,\n" +
            "                    \"merchantCurrency\": \"AED\",\n" +
            "                    \"addresses\": [{\n" +
            "                            \"addressType\": \"STMT_ADDR\",\n" +
            "                            \"countryCode\": \"ARE\",\n" +
            "                            \"state\": \"AUH\",\n" +
            "                            \"city\": \"Abu Dhabi\",\n" +
            "                            \"phone\": \"9835468976\",\n" +
            "                            \"postalCode\": \"0000000784\",\n" +
            "                            \"pobox\": \"700016\",\n" +
            "                            \"name\": \"Kamalakar\",\n" +
            "                            \"lastName\": \"Nalla\",\n" +
            "                            \"email\": \"kamalakar.nalla@network.global\",\n" +
            "                            \"addressLines\": [\n" +
            "                                \"Testing Add Line1\"\n" +
            "                            ]\n" +
            "                        }\n" +
            "                    ],\n" +
            "                    \"services\": [{\n" +
            "                            \"serviceType\": \"DCC\",\n" +
            "                            \"dccProvider\": \"PP\"\n" +
            "                        }\n" +
            "                    ]\n" +
            "                }\n" +
            "            ]\n" +
            "        }\n" +
            "    ]\n" +
            "}\n";

    public static final String CLOSE_MERCHANT = "{\n" +
            "    \"applications\": [{\n" +
            "            \"merchants\": [{\n" +
            "                    \"merchantId\": \"200600144554\",\n" +
            "                    \"merchantName\": \"POS4prod0119 Mer NameChange\",\n" +
            "                    \"merchantType\": \"POS\",\n" +
            "                    \"services\": [{\n" +
            "                            \"serviceType\": \"DCC\",\n" +
            "                            \"dccProvider\": \"PP\"\n" +
            "                        }\n" +
            "                    ]\n" +
            "                }\n" +
            "            ]\n" +
            "        }\n" +
            "    ]\n" +
            "}\n";

    public static final String CLOSE_TERMINAL = "{\n" +
            "    \"applications\": [{\n" +
            "            \"merchants\": [{\n" +
            "                    \"amendmentList\": [\n" +
            "                        \"CLOSURE\"\n" +
            "                    ],\n" +
            "                    \"merchantId\": \"200600144554\",\n" +
            "                    \"merchantName\": \"POS4prod0119 Mer NameChange\",\n" +
            "                    \"merchantType\": \"POS\",\n" +
            "                    \"merchantCurrency\": \"AED\",\n" +
            "                    \"terminals\": [{\n" +
            "                            \"terminalId\": \"1928372\"\n" +
            "                        }\n" +
            "                    ]\n" +
            "                }\n" +
            "            ]\n" +
            "        }\n" +
            "    ]\n" +
            "}\n";
}
