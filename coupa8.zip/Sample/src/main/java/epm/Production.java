package epm;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

public class Production {

	
	
	public static void main(String[] args) throws ParseException {
		
		List <Transaction> inputs = new ArrayList<Transaction>();
		inputs.add(new Transaction("01/01/2023 $100.44 FitnessClub (Exercise)"));

        inputs.add(new Transaction("05/07/2022 $50.25 Xerox (Instrument)"));

        inputs.add(new Transaction("09/01/2021 $70.55 Apple (Food)"));
        
        TQuery.sortByVendor(inputs);
        List<Transaction> filterComboList = TQuery.filterByCombo(inputs, "Xerox", "(Instrument)");
        List<Transaction> filterDateList =  TQuery.filterByDate(inputs, LocalDate.now().minusMonths(44), LocalDate.now().minusMonths(4));
        
        System.out.println(filterDateList);
	}
}
