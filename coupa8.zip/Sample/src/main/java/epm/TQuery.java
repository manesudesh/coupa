package epm;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class TQuery {
	
	public static List<Transaction> filterByDate(List<Transaction> list, LocalDate from, LocalDate to){
		return list.stream().filter(e -> e.getDate().isAfter(from) && e.getDate().isBefore(to)).collect(Collectors.toList());
	}
	
	
	public static List<Transaction> filterByVendor(List<Transaction> list, String vendor){
		return list.stream().filter(e -> e.getVendor().equalsIgnoreCase(vendor)).collect(Collectors.toList());
	}

	
	public static List<Transaction> filterByCategory(List<Transaction> list, String category){
		return list.stream().filter(e -> e.getCategory().equalsIgnoreCase(category)).collect(Collectors.toList());
	}
	
	public static List<Transaction> filterByCombo(List<Transaction> list /*, LocalDate from, LocalDate to */, String vendor, String category){
		return list.stream().filter(e -> (
				/*e.getDate().isAfter(from) && e.getDate().isBefore(to) &&*/
				(category ==null || category != null && e.getCategory().equalsIgnoreCase(category))
				&& (vendor ==null || vendor != null && e.getVendor().equalsIgnoreCase(vendor))
				)).collect(Collectors.toList());
	}
	
	public static List<Transaction> sortByVendor(List<Transaction> list) {
		Collections.sort(list, com);
		return list;
	}
	
	
	static Comparator<Transaction> com = (Transaction t1, Transaction t2) 
			->  t1.getVendor().compareTo(t2.getVendor())		;
			
}

