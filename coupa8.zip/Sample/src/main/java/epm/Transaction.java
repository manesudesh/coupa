package epm;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Currency;
import java.util.Locale;

public final class Transaction {
	private final String str;
	private final LocalDate date;
	private final Number rate;
	private final String vendor;
	private final String category;
	
	public Transaction(String str) throws ParseException {
		this.str = str;
		String [] strArr = str.split(" ");
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		this.date = LocalDate.parse(strArr[0], formatter);
		
		NumberFormat usdFormatter = NumberFormat.getCurrencyInstance(Locale.US);
		rate = usdFormatter.parse(strArr[1]);
		
		this.vendor = strArr[2];
		this.category = strArr[3];
	}
	
	public LocalDate getDate() {
		return date;
	}

	public Number getRate() {
		return rate;
	}

	public String getVendor() {
		return vendor;
	}

	public String getCategory() {
		return category;
	}

	@Override
	public String toString() {
		return this.str;
	}
}
