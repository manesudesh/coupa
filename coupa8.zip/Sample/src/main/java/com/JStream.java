package com;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class JStream {
	
	public static void computeStream() {
	Stream<String> streamOfString =
			  Pattern.compile(", ").splitAsStream("a, b, c d e");
	 streamOfString.collect(Collectors.toList()).forEach(System.out::println);;
	 
	 Pattern p = Pattern.compile("[a-d][m-s]");
	 Matcher m = p.matcher("abcdasd");
//	 System.out.println(m.find() +"  "+ m.group());
	 while(m.find()) {
		 System.out.println(m.group());
		 
	 }
	}
	
	
	public static void main(String[] args) {
		computeStream();
		Optional<String> emptyOpt = Optional.empty();
		String str = "";
		Optional<String> nonEmptyOpt = Optional.of(str);
		Optional<String> nullableOpt = Optional.ofNullable(null);
		
		System.out.println(nullableOpt.orElseGet(()->"Sude"));
		
		List<Person> employees = Arrays.asList(
                new Person("Alice",  50000),
                new Person("David",  60000),
                new Person("Charlie", 50000),
               // null,
                new Person("David", 80000),
                new Person("Alice", 90000)
        );
		
		 Map<String, Optional<Person>> aa = employees.stream().filter(Objects::nonNull)
	            .collect(Collectors.groupingBy(Person::getName, 
	                   Collectors.reducing((a,b)-> {System.out.println(b.getName());return new Person (a.getName(), a.getAge()+b.getAge());}
	                		   )));
		 
		 Map<String, Optional<Person>> aa22 = employees.stream().filter(Objects::nonNull)
		            .collect(Collectors.groupingBy(Person::getName, 
		                   Collectors.reducing((a,b)-> {System.out.println(b.getName());return new Person (a.getName(), a.getAge()+b.getAge());}
		                		   )));
		 
		 Map<String, Integer> bb = employees.stream().filter(Objects::nonNull)
		            .collect(Collectors.groupingBy(Person::getName, 
		                   Collectors.summingInt(Person::getAge)
		                		   ));
		 
		
		List list =  employees.stream().filter(p-> p!=null).collect(Collectors.toList());
		
		Map<String, Optional<Person>>map = employees.stream().filter(Objects::nonNull).collect(Collectors.groupingBy(
				Person::getName, Collectors.maxBy(Comparator.comparingInt(Person::getAge))
				));
		
		
		map.put("", Optional.ofNullable(null));
	map.forEach((a,b)->System.out.println(b.orElseGet( ()-> new Person("Sude", 10))));
	}

}
