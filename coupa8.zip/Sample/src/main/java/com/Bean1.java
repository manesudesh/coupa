package com;

public class Bean1 {

}
