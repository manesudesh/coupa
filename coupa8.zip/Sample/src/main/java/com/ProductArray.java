package com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

public class ProductArray {

	public static void main(String[] args) {
		ProductArray pp = new ProductArray();
		int[] nums = {2,1,5,4,6,7};
//		pp.productExceptSelf(nums);
//		pp.increasingTriplet(nums);
//		pp.compress(null);
		pp.maxOperations(null,0);
	}

	public int[] productExceptSelf(int[] nums) {
		int[] retArr = new int[nums.length];
		long size = Arrays.stream(nums).filter(s -> s == 0).count();
		int cnt = 0;
		if (size > 1) {
			cnt = 0;
			return retArr;
		} else {
			cnt = Arrays.stream(nums).filter(s -> {
				if (s == 0)
					retArr[0] = 10;
				return s != 0;
			}).reduce(1, (a, b) -> a * b);
		}

		boolean flag = retArr[0] == 10;

		for (int i = 0; i < retArr.length; i++) {
			if (flag) {
				if (nums[i] != 0) {
					retArr[i] = 0;
				} else {
					retArr[i] = cnt;
				}
			} else {
				retArr[i] = cnt / nums[i];
			}

		}
		Arrays.stream(retArr).forEach(System.out::println);
		return retArr;
	}

	public boolean increasingTriplet(int[] nums2) {
		int [] nums = {2,1,5,4,6,7};
		
		int small = Integer.MAX_VALUE;
        int big = Integer.MAX_VALUE;

        for (int num : nums) {
            if (num <= small) {
                small = num; // update small to be the smallest value
            } else if (num <= big) {
                big = num; // update big to be the second smallest value
            } else {
                return true; // found a number greater than both small and big
            }
        }
        return false;
	}
	
	
	
	public int compress(char[] charssss) {
		char [] chars = {'a','a','b'};
        /*char f = chars[0];
       int cnt = 1;
       String ret = "";
       for(int i=1; i< chars.length; i++){
           if(chars[i]==chars[i-1]){
               cnt ++;
               
           }else{
               ret = ret + String.valueOf(chars[i-1])+cnt;
               cnt = 1;
           }
           if(i==chars.length-1) {ret = ret + String.valueOf(chars[i])+cnt;}
       
       }
       return ret.length();
       */

		Map<Character, Integer> map = new String(chars).chars().boxed().collect(Collectors.toMap(c->Character.valueOf((char)(int)c), v->1, Integer::sum, LinkedHashMap::new));
		String str = "";
		for(Entry<Character, Integer> entry : map.entrySet()) {
			 String strV = entry.getValue()==1 ? "" : String.valueOf(entry.getValue()) ;
			 str = str + entry.getKey()+strV;
			
		}
		System.out.println(str);
		//       Map<char[], Long> map= Stream.of(chars).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
   
//       System.out.println(map);
       
       return 0;
	}
	
	
	public int maxOperations(int[] nums, int k) {
		nums = new int[]{2,5,4,4,1,3,4,4,1,4,4,1,2,1,2,2,3,2,4,2};
        k = 3;
        Map<Integer, Integer> countMap = new HashMap<>();
        int operations = 0;
/*
        for (int num : nums) {
            int complement = k - num;
            if (countMap.getOrDefault(complement, 0) > 0) {
                operations++;
                countMap.put(complement, countMap.get(complement) - 1);
            } else {
                countMap.put(num, countMap.getOrDefault(num, 0) + 1);
            }
        }
*/
        List<Integer> arrL = Arrays.stream(nums).boxed().collect(Collectors.toList());
         operations = 0;
        for (int num : nums) {
        	int complement  = k - num;
        	int currIndex = arrL.indexOf(num);
        	int index = arrL.lastIndexOf(complement);
        	if(index > currIndex && index >= 0 && currIndex >= 0) {
        		
        		arrL.remove(index);
        		arrL.remove(currIndex);
        		operations ++;
        	}
        }
        return operations;
    }

}
