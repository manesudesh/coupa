package com;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalField;
import java.time.temporal.WeekFields;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Stream;

class Alpha 
{ 
   public String type = "a "; 
   public Alpha() { System.out.print("alpha "); } 
}

public class Beta extends Alpha 
{ 

   public Beta() { System.out.print("beta "); }
   
   public String compress(char[] chars) {
       char f = chars[0];
       int cnt = 1;
       String ret = "";
       for(int i=1; i< chars.length; i++){
           if(chars[i]==chars[i-1]){
               cnt ++;
               
           }else{
               ret = ret + String.valueOf(chars[i-1])+cnt;
               cnt = 1;
           }
           if(i==chars.length-1) {ret = ret + String.valueOf(chars[i])+cnt;}
       }
       System.err.println( ret);
       return ret; 
   }

   public int maxVowels(String s, int k) { //s = "leetcode", k = 3 output =2 "lee", "eet" and "ode" contain 2 vowels
       char [] cArr = s.toCharArray();
       int cnt = 0;
       int max = 0;
       for(int i=0; i<cArr.length - (k-1); i++){
            for(int j=0; j<k; j++){
                if(cArr[i+j]=='a' || cArr[i+j]=='e' || cArr[i+j]=='i' || cArr[i+j]=='o' ||cArr[i+j]=='u') {
                    cnt = cnt + 1;
                    max = Math.max(cnt,max);
                }
                
            }
            cnt = 0;
       }
       return max;
    }
   
   public void verifyTreeMap() {
	   TreeSet<Employee> empTree = new TreeSet<>(Comparator.naturalOrder());
	   empTree.add(new Employee(1, "Alice", 30));
	   empTree.add(new Employee(1, "Bob", 25));
	   System.out.println("Size of TreeSet: " + empTree.size());
	   
	   HashMap<Employee,String> empMap = new HashMap<>();
       empMap.put(new Employee(1, "Alice", 30), "1");
       empMap.put(new Employee(1, "Bob", 25), "2");
       System.out.println("Size of Map: " + empMap.size());
       
       ZonedDateTime dd = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
       System.out.println(dd.getLong(ChronoField.HOUR_OF_DAY));
   }
   
   
   public ListNode oddEvenList(ListNode head) {
	   Stream<List<Integer>> stream = Stream.of(
	            Arrays.asList(8, 3),
	            Arrays.asList(7, 4) // 8 3 7 4
	        );
	  Integer[] arrInt = stream.flatMap(a->a.stream()).toArray(Integer[]::new);
	   
       ListNode tempeven = new ListNode();
       ListNode tempodd = new ListNode();
       
       boolean flag = false;
       ListNode even = tempeven;
       ListNode odd = tempodd;
       int cnt =1;
       while(head != null){
           ListNode node = new ListNode(head.val);
           
           if(flag){
        	   if(cnt == 2) {even.val = node.val;}
        	   else {
        		   even.next = node; 
        		   even = even.next; 
               }
               flag = false;
           }else{
        	   if(cnt == 1) {odd.val = node.val;}
        	   else {
        		   odd.next = node; 
        		   odd = odd.next; 
               } 
               flag = true;
              
           }
            
           if( head.next == null){
               if(cnt == 1) {
//            	   odd = tempeven; 
            	   return tempodd;
               }
               else  {
            	   odd.next = tempeven; //retNode = retNode.next;
            	   return tempodd;
               }
           }
           cnt++;
           head = head.next;
       }

       return null;

   }
   
   
   void go() 
   { 
       this.type = "b "; 
       String ss = "sud";
       char [] cc = ss.toCharArray();
       char temp = 46;
       char curr = 46;
       char next = 46;
       for(int i=cc.length-1;i > 0; i--) {
    	   
    	   
    	   
    	   temp = cc[i];
       }
       String s = "a good   example";
       String rev = "";
       String [] sArr = s.split(" ");
       for(int i=sArr.length-1; i>=0; i-- ){
           if(sArr[i].equals("")) continue;
           if(i==0) rev = rev  +sArr[i].trim();
           else rev = rev  +sArr[i].trim() +" ";
       }
       System.err.println( rev.trim());
       
       System.out.print(this.type + super.type); 
   }

   public static void main(String[] args) 
   { 
	   char [] chars = {'a','a','b','b','c','c','c'};
	   ListNode head = new ListNode(1);
	   ListNode temp = head;
	   temp.next = new ListNode(2); temp = temp.next;
	   temp.next = new ListNode(3); temp = temp.next;
	   temp.next = new ListNode(4); temp = temp.next;
	   temp.next = new ListNode(5); temp = temp.next;
//       new Beta().oddEvenList(head); 
       new Beta().verifyTreeMap();
   } 
} 

class ListNode {
    int val;
    ListNode next;
    ListNode() {}
    ListNode(int val) { this.val = val; }
    ListNode(int val, ListNode next) { this.val = val; this.next = next; }
}

class Employee implements Comparable<Employee>
{
	int id; String name; int age;
	Employee(int id, String name, int age){
		this.id = id;
		this.name = name;
		this.age = age;
	}
	
	@Override
	public int compareTo(Employee o) {
		return Integer.compare(this.id, o.id);
	}
	
}