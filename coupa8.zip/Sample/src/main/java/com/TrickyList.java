package com;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class TrickyList {
    public static void main(String[] args) {
//    	List<String> paths = Arrays.asList("c:/", "C:\\app\\octopus\\onboarding-way4\\inout\\out\\R1.xml");
//    	List<List<String>> fileContents = paths.stream()
//    	        .map(path -> Paths.get(path))
//    	        .map(path -> {
//    	            try {
//    	                return Files.readAllLines(path);
//    	            } catch (IOException e) {
//    	                throw new RuntimeException(e);
//    	            }
//    	        })
    	
        List<String> list1 = new ArrayList<>();
        list1.add("A");
        list1.add("B");
        list1.add("C");
 
        List<String> list2 = list1;
        list1.add("D");
 
        modifyList(list1);
 
        System.out.println("List 1: " + list1);
        System.out.println("List 2: " + list2);
    }
 
    public static void modifyList(List<String> list) {
        list = new ArrayList<>();
        list.add("X");
        list.add("Y");
    }
}