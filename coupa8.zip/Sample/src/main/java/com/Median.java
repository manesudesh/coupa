package com;

class Median {
	public static void main(String[] args) {
		int [] nums1 = {1,3};
		int [] nums2 = {2};
		findMedianSortedArrays(nums1, nums2);
		
		int numRows = 4;
		String s = "PAYPALISHIRING"; 
		char [] cArr = s.toCharArray();
	       int len = cArr.length;
	       int i=0;
	       for(;len > 0; i++){
	        if(len <= numRows-2){
	                i = i + 1;
	                break;
	           }

	            len = len - numRows;
	           
	           if(len < numRows){
	                i = i + len;
	                break;
	           }
	           len = len - (numRows - 2);
	           i = i+2;
	 
	       }
	       
	       String ss ="";
	       for(int j=0; j<cArr.length; j++) {
//	    	   ss = ss+ 
	       }
	       
	}
    public static double findMedianSortedArrays(int[] nums1, int[] nums2) {
        int len1 = nums1.length;
        int len2 = nums2.length;
        int [] nums3 = new int [len1 + len2];
        for(int i=0; i<len1;i++){
            nums3[i]=nums1[i];
        }
        for(int i=0; i<len2;i++){
            nums3[len1 + i] = nums2[i];
        }

        int temp = 0;
        for(int i =0; i<nums3.length-1; i++){
            int curr = nums3[i];
             int next = nums3[i+1];
            temp = nums3[i];
            if(curr > next)    {
            	nums3[i] = next;
            	nums3[i+1] = temp;
            }
        }
        int len = nums3.length ;
        double med = 0;
        if( len % 2 == 0)
        {
            med = (double)(nums3[(len / 2) - 1] +  nums3[(len / 2) ]) / 2;
        }else{
           med =  nums3[len %2 ];
        }
        System.out.println(med);
        return med;
    }
}