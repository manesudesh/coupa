package com;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Spliterator;
import java.util.StringJoiner;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;


public class TapRain {

	
	public static void main(String[] args) {
		int [] arr = {2,4,5,2,1,7,4,8,3};
		int prev=arr[0];
		int output =0;
		int tempSum = 0;
		for(int i=0;i<arr.length;i++) {
			
			int curr =arr[i];
//			tempSum = tempSum - curr + prev; 
			if(prev > curr) {
//				output = output - curr + prev;
				tempSum = tempSum - curr + prev;
				
			}else {
				prev = curr;
				output = output +tempSum;
				tempSum =0;
			}
		}
		System.out.println(output);
		
		String [] input = {
			"dr apj abdul kalam",
			"pratibha patil",
			"pranab mukherjee",
			"ram nath kovind",
			"droupadi murmu"
		};
		
		 Map<Object, Long> map =  Arrays.stream(input).collect(Collectors.joining()).chars().boxed()
		.map(c->(char)(int)c)//.forEach(System.out::println);
		.collect(Collectors.groupingBy( Function.identity(), Collectors.counting()));
				
		 Map<Object, Long> map22 = 
				 Arrays.stream(input).flatMap(s-> s.chars().boxed()).map(c->(char)(int)c)//.forEach(System.out::println);
			.collect(Collectors.groupingBy( Function.identity(), Collectors.counting()));
//		.collect(Collectors.toMap(c->(char)(int)c, v->1, Integer::sum,  LinkedHashMap::new));
		 
		 System.out.println(map);
//		 List<Integer> numbers = Arrays.asList(1, 2, 3, 4); 
		 List<Integer> numbers = Arrays.asList(1, 2, 3, 4,5,5,5,5); // 32 46
		 int sum = numbers.parallelStream().reduce(2, Integer::sum);      
		 System.out.println(sum);
		
		IntStream.range(0, input.length).mapToObj(a-> input[a] ).toArray( String [] ::new );
		
		Spliterator<String> aaa = Arrays.spliterator(input);
		aaa.forEachRemaining(a-> System.out.println(a));
	}
}
