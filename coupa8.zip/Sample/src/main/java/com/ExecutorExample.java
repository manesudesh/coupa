package com;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ExecutorExample {
    public static void main(String[] args) throws InterruptedException, ExecutionException {
        ExecutorService executor = Executors.newFixedThreadPool(10); // Create a custom thread pool
        ExecutorService executor11 = Executors.newCachedThreadPool(); // Create a custom thread pool
        ExecutorService executor22 = Executors.newSingleThreadExecutor(); // Create a custom thread pool
//        ScheduledExecutorService executor33 = Executors.newScheduledThreadPool(2); // Create a custom thread pool
//        ScheduledFuture aaaa = executor33.scheduleAtFixedRate( ()->System.out.print("aff") , 100l, 100l, TimeUnit.MILLISECONDS);

        Future<Integer> ee = executor.submit(()-> {System.out.println("in a executor"); return 10;});
        Integer ii = ee.get();
        
         ExecutorService aa = Executors.newSingleThreadExecutor();
        
        Supplier<String> supp = () -> {System.out.println("Print Task1");return "Task 1";};
        CompletableFuture.supplyAsync(()->10).thenApply((i)->{System.out.println("aa "+i); return i;}).thenAccept((i)->{System.out.print("aaa "+i);});
        CompletableFuture<String> future1 = CompletableFuture.supplyAsync(()-> {throw new RuntimeException("Something went wrong!");}, executor);
        CompletableFuture<String> future2 = CompletableFuture.supplyAsync(supp);
        CompletableFuture<String> future3 = CompletableFuture.supplyAsync(supp);
        CompletableFuture<CompletableFuture<String>> aaa = future2.thenCompose( i -> {
    	    return CompletableFuture.supplyAsync(() -> {
    	    	System.out.println("supplyAsnc");
    	         return "5";
    	    });
    	     }).thenApply( i -> {
    	    	    return CompletableFuture.supplyAsync(() -> {
    	    	    	System.out.println("thenapply");
    	    	         return "10";
    	    	    });
    	    	     });
        
        CompletableFuture [] compleArr = {future1, future2};
        CompletableFuture<Void> allFutures = CompletableFuture.allOf(future1, future2);
//       Arrays.stream(compleArr).map(c->c.join()).forEach(System.out::println);
        
//        
//        allFutures.thenRun(() -> {
//            System.out.println("All tasks completed!");
//        });

//        allFutures.join();

//         CompletableFuture<String> resultFutures222 = allFutures.thenCompose(v -> Stream.of(future1, future2, future3)
//        		.collect(Collectors.toList()));
//                .map(CompletableFuture::join)
//                .collect(Collectors.toList()));
        

        CompletableFuture<List<String>> resultFutures = allFutures.thenApply(v -> Stream.of(future1, future2, future3)
            .map(CompletableFuture::join)
            .collect(Collectors.toList()));

        resultFutures.thenAccept(result -> result.forEach((str)->{System.out.println(str);} ));
//        
        executor.shutdown(); executor11.shutdown(); executor22.shutdown();
        
    }
}
