package com;

import java.io.Externalizable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Objects;

public class Person implements Externalizable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String name ;
	private Integer age ;
	private String add ;

	
	public Person() {
	}
	
	public Person(String name, Integer age) {

		if(this.age == null) { return;}
		this.name = name;
		this.age = age;
	}
	
	
	public Person(Object object, int i) {
		this.name = (String) object;
		this.age = i;
	}


	public static void main(String args[]) throws IOException, ClassNotFoundException{
		Person p = new Person();
//		try(FileOutputStream fos = new FileOutputStream("aa.ser");
//				ObjectOutputStream oos = new ObjectOutputStream(fos)) {
//				oos.writeObject(p);			
//		}
		
		
		FileInputStream fis = new FileInputStream("aa.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Object rp = ois.readObject();
		
//		HashMap<Person, Integer> map = new HashMap<>();
//		for(int j=0; j<3;j++)
//		{
//			for (int i = 0; i < 12; i++) {
//				String str = "jon"+i+j+"ss";
//				String str22 = i+j+"jon";
//				map.put(new Person(str), 1);
//			}
//			
//		}
//		
//		System.out.println(Math.getExponent(252));
//		System.out.println(map.size()/16);
	}
	

	@Override
	public int hashCode() {
		int hash = Objects.hash(name);
//		System.out.println(hash);
		return hash;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
		{
			System.out.println(getClass() +"    "+obj.getClass());
			return false;
		}Person other = (Person) obj;
		System.out.println(Objects.equals(name, other.name));
		return Objects.equals(name, other.name);
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name + age;
	}
	
	public void writeExternal(ObjectOutput out) throws IOException {
//		out.writeObject(this);
//		out.writeObject("Sudesh");
		out.writeInt(43);
//		out.writeObject("Sudesh");
	}
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
//		System.out.println((Person)in.readObject());
		
//		System.out.println(in.readObject());
		System.out.println(in.readInt());
//		System.out.println(in.readObject());		
	}
	public int getAge() {
		return this.age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
