package com;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class Utility {

	Node head;
	Node node;
	static class Node{
		Node next;
		int i;
		Node(int i, Node node){
			this.i = i;
			next = node;
		}
	}
	public void insert(Node insNode) {
		if(node == null) {
			head = insNode;
			node = head;
		}else {
			while(node.next != null) {
				node = node.next;
			}
			node.next = insNode;
		}
	}
	
	public void printNode(){
		for( int i = 0; i<5; i++) {
			Node node = new Node(i, null);
			insert(node);
		}
		
		Node nodetoappend = head.next.next;
		Node nodetoappendNext = nodetoappend.next;
		for( int i = 11; i<15; i++) {
//			while(nodetoappend.next != null) {
//				nodetoappend = nodetoappend.next;
//			}
			nodetoappend.next = new Node(i, null);
			nodetoappend = nodetoappend.next;	
		}
		nodetoappend.next = nodetoappendNext;
		Node node = head;
		while(node != null) {
			System.out.println(node.i);
			node = node.next;
		}
	}
	
	public static void main(String[] args) {
		int[][] tarr =  {{0,1},{0,0}};
		
		highestPeak(tarr);
		new Utility().printNode();
		int ii = 12;
		StringBuilder ss = new StringBuilder(String.valueOf(ii));
		int iii = Integer.valueOf(ss.reverse().toString());
		double rac =  Math.pow(ii, 2);
		System.out.println(ss.reverse()+" aa "+rac);
		
		int [] arr = {0,1,0,0,1,0,1,0};
		
		int max=0;
		for(int i=0; i<arr.length;i++) {
			int count=0;
			
			for(int next=i; next<arr.length;next++) {
				if(arr[next]==0) {
					count++;
					max = Math.max(max, count);
				}else {
					break;
				}
			}
		}
		System.out.println(max);
		
		String str = "sudesh";
		Map<Character, Long> mm = str.chars().boxed().map(i->Character.valueOf((char)(int)i)).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
	
	 Map<Character, Integer> vv = str.chars().boxed().map(i->Character.valueOf((char)(int)i)).collect(Collectors.toMap(s->s, v->1, Integer::sum));
Map<Character, Integer>	ww =	vv.entrySet().stream().sorted(Collections.reverseOrder(Map.Entry.comparingByKey())).collect(Collectors.toMap(e->e.getKey(), e->e.getValue(), (e1,e2)->e2, ConcurrentSkipListMap::new));
	 System.out.println(ww);
	}
	
	
	
	 public static void highestPeak(int[][] isWater) {
		 
		 int [][] matrix = new int[isWater.length][isWater[0].length];
		 
			for (int mi = 0; mi < matrix.length; mi++) {
				int[] mrow = matrix[mi];
				for (int mj = 0; mj < mrow.length; mj++) {
					boolean flag = false;
					for (int i = 0; i < isWater.length; i++) {
						if (isWater[mj][i] == 1) {
							Math.abs(i-mi);
//							break;
						}
						}
						int[] row = isWater[mi];
						for (int j = 0; j < row.length; j++) {
							if (isWater[mi][j] == 1) {
								//matrix[mi][mj]=Math.min(Math.abs(j-mj)+Math.abs(i-mi),0);
								Math.abs(j-mi);
								flag =true;
								break;
							}
						}
					}
				}
		   	}
//			System.out.println(matrix);
	    }

