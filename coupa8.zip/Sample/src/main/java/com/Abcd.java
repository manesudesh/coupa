package com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Abcd<T>{

	public static void removeIndex() {
		String[] strArr = new String[] { "1", "2", "3", "4", "5", "6", "7", "8" };

		int m = 2, n = 5;
		List list = IntStream.range(0, strArr.length).filter(i -> i < m || i > n).mapToObj(i -> strArr[i])
				.collect(Collectors.toList());
		System.out.println(list);
		
		List ll= new ArrayList(Arrays.asList(strArr));
		for(int i=5; i>=2; i--)
		ll.remove(i);
		System.out.println(ll);
		
	}
	

	public static void main22(String[] args) {
		String str = "abcpqrabcabcdabc";
		
		Set<String> set = nonRep(str, str);
		Comparable com = (o)-> o.hashCode();
		String nonRepstr = set.stream().filter(o -> o!=null).sorted((o1,o2)->Integer.valueOf(o2.length()).compareTo(Integer.valueOf(o1.length()))).collect(Collectors.toList()).get(0);
		System.out.println("Longest non repeat------> "+nonRepstr);

	}
	
	public static Set<String> nonRep(String str, String strMain) {
		Set <String> set = new HashSet<>();
		for (int i = 0; i < str.length(); i++) {
			String subStr = str.substring(0, i);
			Pattern pp = Pattern.compile(subStr);
			Matcher match = pp.matcher(strMain);

			int count = 0;
			while (match.find()) {
				count++;
			}
			
			//break the string if repeated char found in substr
			if (  subStr.contains(str.charAt(i) + "")) {
				str = str.substring(i); //continue string from this index
				i = 0;
				if (count == 1) { // if match found only one means no duplicate string found
					System.out.println("non Repeated-- "+subStr);
					set.add(subStr);
				}
			}
		}
		return set;
	}
	
	public static boolean isRep(String str) {
		for(int i=0;i<str.length();i++) {
			String subStr = str.substring(0,i+1);
			Pattern pp=Pattern.compile(subStr);
			Matcher match = pp.matcher(str);
			if( match.find(i)) {
				
//				System.out.println(str.substring(0,i));
//				nonRep( str.substring(0,i));
				return true;
			}
		}
		return false;
	}
	public static  void main(String[] args) {
		removeIndex();
		String str = "abcpqrabcabcdabc";
		nonRep(str, str);
		
		String[] strArr = {"One","Two","Three"};
		final LinkedList<String> list = new LinkedList<>(Arrays.asList(strArr)) ;
		ListIterator<String> listI = list.listIterator();
		while(listI.hasNext()) {
			listI.add("Four");
			listI.next();
			listI.forEachRemaining(a-> System.out.println("   hi "+a));
		}
		list.add("five");
		
	        ConcurrentHashMap<Integer, String> chm
	            = new ConcurrentHashMap<>();
//	 chm.put(null, str);
//        java.util.Hashtable<Integer, String> chm
//      = new Hashtable<>();
		
//	        HashMap<Integer, String> chm
//            = new HashMap<>();
		
	        
	        chm.put(65, "A");
	        chm.put(66, "B");
	 
	        chm.putIfAbsent(67, "C");
	        chm.putIfAbsent(68, "D");
	 
//	        System.out.println(chm);
	 
//	        chm.remove(68, "D");
	 
	        
	        System.out.println(chm);
	 
	        Iterator <Entry<Integer, String>> it =  chm.entrySet().iterator();
	        while(it.hasNext()) {
	        	 Entry<Integer, String> e = it.next();
//	        	 chm.remove(e.getKey());
	        	 it.remove();
	        }
//	        chm.replace(66, "B", "E");
	 
	        System.out.println(chm);
	 
	}



	
}
