package com;

import java.util.concurrent.atomic.AtomicInteger;

class TicketBooking {
    private int availableTickets;
 
    public TicketBooking(int availableTickets) {
    	this.availableTickets = availableTickets;
//    	 this.availableTickets = new AtomicInteger(availableTickets);
    }
 
    public synchronized void bookTicket(int inttickets) {
//    	AtomicInteger tickets = new AtomicInteger(inttickets);
    	int tickets = inttickets; 
			
		
//    	 if (availableTickets.get() >= tickets.get()) {
        if (availableTickets >= tickets) {
    		  {
            
//            	availableTickets -= tickets;
            synchronized (this) {
            	System.out.println(Thread.currentThread().getName()+"   "+availableTickets + " tickets booked successfully.");
            	availableTickets = getAvailableTickets(tickets);
			}
            
//            System.out.println("      "+Thread.currentThread().getName()+"   "+availableTickets + " tickets booked successfully.");
    		 }
        } else {
            System.out.println(Thread.currentThread().getName()+"   "+"Not enough tickets available.");
        }	
    }
 
    public int getAvailableTickets(int tickets) {
//        availableTickets.addAndGet(-tickets.get());
    	availableTickets -= tickets;
        return availableTickets;
    }
    
    public int getAvailableTickets() {
        return availableTickets;
    }
}
 
public class BookingSystem {
    public static void main(String[] args) {
        TicketBooking booking = new TicketBooking(10);
 
        Runnable bookingTask = () -> {
            for (int i = 0; i < 5; i++) {
                booking.bookTicket(3);
            }
        };
 
        Thread thread1 = new Thread(bookingTask);
        Thread thread2 = new Thread(bookingTask);
 
        thread1.start();
        thread2.start();
 
		/*
		 * try { thread1.join(); thread2.join(); } catch (InterruptedException e) {
		 * e.printStackTrace(); }
		 */
 
        System.out.println("Final available tickets: " + booking.getAvailableTickets());
    }
}
