package com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class PosNeg {

	public static void sortPosNeg(int [] arr) {
//				Output:[9, -7, 8, -3, 5, -1, 2, 4, 6]
		List <Integer>list = Arrays.stream(arr).boxed().sorted().collect(Collectors.toList());

		//		List listRight = new ArrayList<>();
//		List listLeft = new ArrayList<>();
		List<Integer> listLeft = IntStream.range(0, list.size() / 2).mapToObj(a -> list.get(a))
				.sorted().collect(Collectors.toList());

		List<Integer> listRight = IntStream.range(list.size() / 2, list.size() ).mapToObj(a -> list.get(a))
				.sorted(Collections.reverseOrder()).collect(Collectors.toList());
		System.out.println(listLeft);
		System.out.println(listRight);
	}
	
	public static void main(String[] args) {
		int [] arr = {-1, 3, -2, -4, 7, -5};
		sortPosNeg(arr);
	}
}
