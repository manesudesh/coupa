package com;


import java.util.*;
import java.util.concurrent.*;
import java.util.function.Function;
import java.util.stream.*;

public class CustomerMap{

public static void main(String [] args)
{
String aa = "Sudesh mane Sudesh siddh chick";
String [] arr  = aa.split(" ");
//ConcurrentHashMap<String, Integer> cMap = Stream.of(arr).map(s->s.toUpperCase()).collect(Collectors.toMap(v -> v, s->1, Integer::sum, ConcurrentHashMap::new ));
Map<String, Long> map = Stream.of(arr).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
ConcurrentHashMap<String, Long> cMap = new ConcurrentHashMap<>(map);
cMap.entrySet().stream().forEach(e -> System.out.println(e.getKey()+" "+e.getValue()));

}


}