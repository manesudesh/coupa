package com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ArrayUtility {

//	int[] arr = {2,3,5,7} int input =9 
			 
	private static Integer[] getIndexes( int[] in, int sumVal) {
		ArrayList< Integer> retArr = new ArrayList<>();
		int lengthArr = in.length ;
		for(int i=0; i<lengthArr; i++) { 
			for(int j=i+1; j<lengthArr ; j++) {
				if (sumVal == in[i]+in[j]) {
					retArr.add(i);
					retArr.add(j);
					System.out.println(i+"  "+j);
					break;
				}
			}
		}
		int aa = Arrays.stream(in).reduce(0,(a1,a2)-> a1-a2);
		
		String [] sarr = {"11","22"};
		List<String> aaa = Arrays.stream(sarr).collect(Collectors.toList());
		 List<String> bbb = Stream.of(sarr).sorted(Collections.reverseOrder()).collect(Collectors.toList());
		
		
		Stack<String> stack = new Stack<>(); stack.add("11");stack.add("22");
		stack.pop();
		ArrayList<String> list = new ArrayList<>(Arrays.asList("11","22"));
		String ss= list.remove(1);
		LinkedList<String> list22 = new LinkedList<>(Arrays.asList("11","22"));
		String ss22 = list22.poll();
		
		
		StringBuilder s1 = new StringBuilder("Java"); 
		s1.substring(1,3);
        String s2 = "Love"; 
        s1.append(s2); 
        s1.substring(4); 
        int foundAt = s1.indexOf(s2); 
        System.out.println(foundAt); 
        
        int [] array = {1,30,5,70,10,14,19};
        Arrays.fill(array,3,5,11);
        System.out.println(array);
        
        String sstr = "ab 1cd 2ebcc".replaceAll("[0-9]","vv");
       System.out.println(sstr);
        double dd = 10.49;
        int ii = (int)dd;
        System.out.println(Math.round(dd));System.out.println(Math.floor(10.0));
        
		return retArr.toArray(new Integer[retArr.size()]);
	}
	
	private static List getIndexes22( int[] in, int sumVal) {
		Map<Integer, Integer> map = new HashMap<>();
        List<Integer> retArr = new ArrayList<>();
        
		for (int i = 0; i < in.length; i++) {
            int complement = sumVal - in[i];
            if (map.containsKey(complement)) {
                retArr.add(map.get(complement));
                retArr.add(i);
                System.out.println(map.get(complement) + "  " + i);
                break;
            }
            map.put(in[i], i);
		}
        
        return retArr;
	}
	
	 static void printPermutn(String str, String ans)
	    {
	        // If string is empty
	        if (str.length() == 0) {
	            System.out.println(ans + " ");
	            return;
	        }
	        for (int i = 0; i < str.length(); i++) {
	            // ith character of str
	            char ch = str.charAt(i);
	            // Rest of the string after excluding
	            String ros = str.substring(0, i) +
	                        str.substring(i + 1);
	            // Recursive call
//	            System.out.println(ros+"   " +ans+ch);
	            printPermutn(ros, ans + ch);
//	            printPermutn(ros+ ch);
	        }
	    }
	 
	public static void main(String args[]) {
		int [] arr = new int[] {2,7,1,4,7};
		ArrayUtility.getIndexes(arr, 10);
//		printPermutn("abc", "");
	}
}
