package com;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.JacksonTester;


public class JacksonSub <T extends Number & Comparable> extends JacksonTester {
	 byte sh = 127;
	
   public static void main(String args[]) throws IOException {
	   JacksonSub sub = new JacksonSub();
	   sub.test();
	   sub.longestCommonSubsequence("sudeshmaneasd", "Mane");
   }

    public Object test()  {
//	System.out.println(longestCommonSubsequence("Sudesh", "ManSueshd"));
	return sh;
}
    
    public static <E extends Number> void printArray(E[] array) {
    	for (E element : array) {
            System.out.printf("%s ", element);
        }
    }
    public  void printArray(Object[] array) {
        for (Object element : array) {
            System.out.printf("%s ", element);
        }
    }
    public  <T extends Number> String returnType(T argument) { 
        return "argument"; 
    }
    
    public    int    longestCommonSubsequence(   String    text1,    String    text2) {
    	printArray(new Number[]{1,2});
    	List<? super String> list = new ArrayList<String>();
    	list.add("10");
            int n1 = text1.length();
            int n2 = text2.length();
            int[][] dp = new int[n1+1][n2+1];
     
            Map<Character, Integer> mapp = text1.chars().boxed().collect(Collectors.toMap(k->Character.valueOf((char)k.intValue()), v->1, Integer::sum));
            Map<Integer, Long> obj = text1.chars().boxed().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
            Map<Object, Integer> linkedmapp = mapp.entrySet().stream().sorted(Map.Entry.comparingByKey((e1,e2)->e1.compareTo(e2))).collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue(), (e1,e2)->e2, LinkedHashMap :: new));
            
            for(int i = 0 ; i <= n1 ; i++){
                for(int j = 0 ; j <= n2 ; j++){
                    if(i == 0 || j == 0){
                        dp[i][j] = 0;
                    }
                    else if(text1.charAt(i-1) == text2.charAt(j-1)){
                        dp[i][j] = dp[i-1][j-1]+1;
                    }else{
                        dp[i][j] = Math.max(dp[i-1][j],dp[i][j-1]);
                    }
                }
            }
            return dp[n1][n2];
                }
}
