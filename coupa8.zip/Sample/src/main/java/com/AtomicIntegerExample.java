package com;

import java.util.concurrent.atomic.AtomicInteger;

class Counter {
    private AtomicInteger count = new AtomicInteger(0);
//	private int count = 0;

    public void increment() {
        count.incrementAndGet();
//    	count++;
    }

    public int getCount() {
        return count.get();
//    	return count;
    }
}

public class AtomicIntegerExample {
	public static void main(String[] args) throws InterruptedException {
        Counter counter = new Counter();
        Thread t1 = new Thread(() -> {
            for (int i = 0; i < 1000; i++) {
                counter.increment();
                
            }
        });

        Thread t2 = new Thread(() -> {
            for (int i = 0; i < 1000; i++) {
                counter.increment();
            }
        });

        t1.start();
        t2.start();

//        t1.join();
        t2.join();
        System.out.println("Final Count is : " + counter.getCount());
    }
}
