package org;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Interview {

	public static void main(String[] args) {
		String[] strArr = {"cat","dog","cat"};
		
	
		Map<Object, Long> mapGrp = Arrays.stream(strArr).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println("counting using  Collectors. groupingBy");
		mapGrp.entrySet().stream().forEach(e -> System.out.println("     "+e.getKey()+"  "+e.getValue()));

		Map<Object, Integer> mapTo = Arrays.stream(strArr).collect(Collectors.toMap(s-> s.intern(), v->1, Integer::sum, LinkedHashMap::new));
		System.out.println("\n\n counting using  Collectors. toMap");
		mapTo.entrySet().stream().forEach(e -> System.out.println("     "+e.getKey()+"  "+e.getValue()));
	}

}
