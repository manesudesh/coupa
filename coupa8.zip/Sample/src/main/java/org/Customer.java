package org;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Customer implements IFirst{
	
/*
	 boolean  flag = false;
	 public <T> String containElements(T t) {
		List<Integer> ii = new ArrayList<Integer>();
		ii.add(55);ii.add(66); ii.add(77);
		

		List<Integer> pp = new ArrayList<Integer>();
		pp.add(770);pp.add(550); pp.add(660);
		
		
		long count = ii.stream().takeWhile(i-> !pp.contains(i)).count() ;
		System.out.print(count);
		return "Class";
	}

	*/
	
	
	
	public int addTwoNumber(int a, int d) {
//	char q = 'e';	
//	String ss = "Sudesh Mane ";
		int g = a + d;
//		ss = "Abcd";
		
		 int amount = 1000;
		 
		
		return g;
		
	}
	
	String name ;
	String bankName ;
	int balanceAmount ;
	
	
	public int deductBalance( int ded) {
		if(balanceAmount >= ded) {
			balanceAmount = balanceAmount - ded;
		}
		return balanceAmount;
	}
	
	public int depositBalance( int credit) {
		if(credit > 0 || credit < 500 ) {
			balanceAmount = balanceAmount + credit;
		}
			return balanceAmount;
		}
	
	public static void main(String[] args) {
		
		List list  = new ArrayList<>();
		list.add("Sudesh"); list.add("Mane");
		Iterator<String> it = list.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		list.forEach(System.out::println);
		
		Customer cust1 = new Customer();
		cust1.name = "Chicku";
		cust1.balanceAmount = 1000;
		
		Customer sud = new Customer();
		sud.name = "Sudesh";
		sud.balanceAmount = 3000;
		
		sud.deductBalance(300);
		sud.deductBalance(500);
		cust1.deductBalance(200);
		
		System.out.println(sud.name + "    current balance "+sud.balanceAmount);
		System.out.println(cust1.name + "    current balance "+cust1.balanceAmount);
		
		
//		dd.containElements(Integer.class);
	}
	
	@Override
	public String getStr() {
		// TODO Auto-generated method stub
		return IFirst.super.getStr();
	}
	@Override
	public void method2() {
		// TODO Auto-generated method stub
		 IFirst.super.getStr();
	}

	@Override
	public void abc() {
		// TODO Auto-generated method stub
		
	}
}
