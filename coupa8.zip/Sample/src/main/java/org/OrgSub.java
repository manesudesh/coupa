package org;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


public class OrgSub extends JacksonTester {
	 Integer sh = 22;
	 String ss ;
	 public OrgSub() {
		 
	 }
		public OrgSub(Integer str) {
//			sh = str;
			System.out.println(sh);
		}

		public static void main(String args[]) throws IOException {
			OrgSub jack1 =  new OrgSub();
//			jack1.test("sud");
//			OrgSub sub2 = new OrgSub(20);
//			sub1 = sub2;
//			sub2 = null;
			System.out.println("JacksonTester sh "+jack1.sh);
			jack1.m1(jack1);
			
//			jack1.maxArea();
//			jack1.maxOperations();
			jack1.longestSubarray();
		}

		public String m1(JacksonTester tt) throws ArithmeticException {
			System.out.println("sub class");
			return "";
		}
		
		public Integer test(Object str)  throws NullPointerException
		{
			System.out.println("in sub test "+sh);
			return sh;
		}
		
		public int maxArea() {
			int [] height = {1,8,6,2,5,4,8,3,7};
			
			int maxArea = 0;
			
			int left = 0; // Left pointer
			int right = height.length - 1;
			
			while (left < right) {
				int width = right - left;  // Calculate width of the container
	            int minHeight = Math.min(height[left], height[right]);  // Find the shorter line
	            maxArea = Math.max(maxArea, width * minHeight);
				
				if (height[left] < height[right]) {
					left++;
				} else {
					right--;
				}
			}
			return maxArea;
		}
		
		public int longestSubarray() {
			int[] nums = {0,1,1,1,0,1,1,0,1};
	        int max = 0;
	        for (int i = 0; i < nums.length; i++ ){
	            if(nums[i] == 1){
	                int m = i;
	                while(m < nums.length){
	                    if(nums[m] == 0){ break;}
	                    m++;
	                }
	                max = Math.max(max, m-i-1);
	            }
	            int counter = 0;
	            if(nums[i] == 0){
	                int l = i-1;
	                while(l>0){
	                	
	                	if(nums[l]==1){
	                        counter ++;
	                    }
	                	else if(nums[l]==0){
	                        break;
	                    }
	                	l--;
	                     System.out.println("Counter "+counter);
	                }

	                int r = i+1;
	                while(r<nums.length - 1){
	                    r++;
	                    if(nums[r]==1){
	                        counter ++ ;
	                    }
	                    else if(nums[r]==0){
	                        break;
	                    }
	                    
	                }
	                max = Math.max(max, counter);
	            }
	        }
	        System.out.println("Max "+max);
	        return max;
	    }
		
		public int maxOperations() {
			int[] nums = {1,2,3,4};
			int k = 5;
			
			Map<Integer, Integer> countMap = new HashMap<>();
	        int operations = 0;

	        for (int num : nums) {
	            int complement = k - num;
	            if(countMap.getOrDefault(complement, 0) > 0) {
	            	countMap.put(num, countMap.getOrDefault(complement, 0) - 1);
	            	operations++;
	            }else {
	            	countMap.put(num, countMap.getOrDefault(complement, 0) + 1);
	            }
	        }

	        return operations;
		}
}
