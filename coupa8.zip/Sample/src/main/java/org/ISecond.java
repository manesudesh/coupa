package org;


@FunctionalInterface
public interface ISecond {

	public void method2() ;
	default String getStr22() {
		return "Second";
	}
	
}
