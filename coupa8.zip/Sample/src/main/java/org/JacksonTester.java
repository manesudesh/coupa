package org;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.rmi.RemoteException;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.databind.ObjectMapper;


public class JacksonTester {
	 Integer sh = 127;
	
	 public JacksonTester() {
		 
	 }
	 
   public static void main(String args[]) throws IOException, InterruptedException {
	  Shape shape = new Circle("CustomCircle", 1.0);
	  // Shape shape = new Circle("CustomCircle", 1.0);
      String result = new ObjectMapper()
    	         .writerWithDefaultPrettyPrinter()
    	         .writeValueAsString(shape);
    	      System.out.println(result);  
      System.out.println(result);   
      String json = "{\"name22\":\"CustomCircle\",\"radius\":1.0, \"type22\":\"circle\"}";
      Circle circle = new ObjectMapper().readerFor(Shape.class).readValue(json);
      System.out.println(circle.name22);
      JacksonTester ss = new SubClass();
      System.out.println(ss.sh +" "+ss.test(""));
      JacksonTester ss22 = new SubClass();
      System.out.println(ss22.sh +" "+ss22.test("aaa"));
      
      Runnable r= ()->{
    	  for(int i=0;i<1;i++)
    		  { 
    		  System.out.println(Thread.currentThread().getName()+" "+i);
    		  try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    		  }
    	  };
      Thread t1 = new Thread(r, "ONE");
      Thread t2 = new Thread(r, "TWO");
      Thread t3 = new Thread(r, "THREE");
      Thread t4 = new Thread(r, "FOUR");
      t1.start(); t2.start(); t3.start(); 
      System.out.println("BEFOREE");
      t3.join();
      System.out.println("AFTERRRR");
      t4.start();
   }

   public String m1(JacksonTester tt) throws NullPointerException{
	   System.out.println("sup class");
	   if(tt.equals(""))throw new NullPointerException(); 
	   return "";
   }

    public Integer test(Object str)  //throws Exception
    {
    	System.out.println(sh+"in super class");
    	return sh;
    }
}

class SubClass extends JacksonTester{
	Integer sh = 10;
//	 static int a = m1();
	 int m1() {
        System.out.println("from m1");
        return 20;
    }
	static {
		System.out.println("static initiliased");
	}
	{
		System.out.println("instance initiliased");
	}
	public SubClass() {
//		super();
		this(5);
	}
	
	SubClass(int aa){
		
	}
	
	 public Integer test(String str)  {
		System.out.println(sh+"in subclass");
		return sh;
	}	
}


@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, 
include = As.PROPERTY, property = "type22", visible = true) @JsonSubTypes({

@JsonSubTypes.Type(value = Square.class, name = "square"),
@JsonSubTypes.Type(value = Circle.class, name = "circle")
})
@JsonIgnoreProperties(ignoreUnknown = true)
 class Shape {
 //@JsonProperty("name2233")
 public String name22; 
 
// public String name;    
public Shape(String name){
   this.name22 = name;
}
}


@JsonTypeName("square")
@JsonIgnoreProperties(ignoreUnknown = true)
 class Square extends Shape {
	 public double length;
   Square(){
      this(null,0.0);
   }
   Square(String name, double length){
      super(name);
      this.length = length;
   }
}

//@JsonTypeName("circle22000")
@JsonIgnoreProperties(ignoreUnknown = true)
class Circle extends Shape {
	@JsonIgnoreProperties
	public double radius;

	Circle() {
		this(null, 0.0);
	}

	Circle(String name, double radius) {
		super(name);
		this.radius = radius;
	}
}