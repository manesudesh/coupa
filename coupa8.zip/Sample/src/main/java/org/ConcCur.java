package org;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ConcCur {
	static ConcurrentHashMap<Integer, Integer> cc = new ConcurrentHashMap<>();
	
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		
		CompletableFuture<String> ccf =  CompletableFuture.supplyAsync(()->{
			return "Hi";
		}, executor);
		
		CompletableFuture<Integer> ccfhhh = ccf.thenCompose(e ->
			CompletableFuture.supplyAsync(() ->  {return 10;})
		);
		executor.shutdown();
		System.out.println(ccfhhh.get());
		
		double d1 = 1.0;//Double.NaN;
		double d2 = 1;//Double.NaN;
		System.out.println("Test "+(d1==d2));
		
//		HashMap <Integer, Integer> cc = new HashMap<>();
		cc.put(1, 10);		cc.put(11, 20);		cc.put(311, 30);
		cc.put(11, 11);		cc.put(21, 21);		cc.put(31, 31);
		System.out.println(cc);
		cc.put(11, 12);		cc.put(21, 22);		cc.put(31, 32);
		cc.put(12, 13);		cc.put(22, 23);		cc.put(32, 33);
		cc.put(13, 11);		cc.put(23, 22);		cc.put(33, 33);
		cc.put(14, 11);		cc.put(24, 22);		cc.put(34, 33);
		
//		cc.entrySet().stream().forEachOrdered(e->System.out.println(e.getKey()+" "+e.getValue()));
		
		//for(int i=0; i<cc.size(); i++)
		Iterator it =  cc.entrySet().iterator() ;
		while (it.hasNext())
		{
			System.out.println(it.next());
			//cc.put(4, 44);
		}
		
		try(FileOutputStream fi = new FileOutputStream(new File("C:\\Users\\Sudesh_Mane\\Downloads\\flatten12.jpeg")); ) {
			fi.close();
			fi.close();
			System.out.print("sadasdsa");
		}catch(Exception e) {
			System.out.print(e);
		}finally {
			
		}
		List<String> list = new ArrayList<>();
		String [] aaa = {"","",""};
		Arrays.asList(aaa);
		list.add("Nikhil");list.add("Nitin");list.add("Abcd");list.add("Pqr");list.add("Xyz");
		
		list.stream().filter(e-> {System.out.println("In Predicate "+e); return e.startsWith("N"); })	
		.forEach(e->System.out.println("For Each "+e));
		

		//filter() - intermediate method
		//forEach () - terminal
		
	}
	

}
