package org;

public class Bean1 {

}
