package org;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream; 

public class Java8 {



		public static void main(String[] args) { 

			String strr ="aa bb cc aa bb aa";
			String arrarr [] = strr.split(" ");
			
			ConcurrentHashMap <String, Integer> ccmap = Stream.of(arrarr).collect(Collectors.toMap(s->s.toString(), v->1, Integer::sum, ConcurrentHashMap::new));
			
			String[] strArr = {"d","b","c","b","c","a"};
			int k = 2;
			
		Map<Object, Integer> a2 = Arrays.stream(strArr).collect(Collectors.toMap(s-> s.intern(), v->1, Integer::sum, LinkedHashMap::new));
		
			ConcurrentMap<String, Integer>  map22 =Arrays.stream(strArr).collect(Collectors.toConcurrentMap(s->s.toUpperCase(), v->1, Integer::sum));
			map22.entrySet().stream().filter(m-> m.getValue()==1).forEach(System.out::print);
			
			Map<String, Integer> map = new HashMap<>(); 

			map.put("Abrar", 20000); 
			map.put("Chand", 35000); 
			map.put("Kalam", 45000); 
			map.put("Raheem", 35000); 
			map.put("Kiran", 50000); 
			map.put("Esa", 45000); 

			int n = 3; 

			Entry<String, Integer> aa = map.entrySet() 
			.stream() 
			.sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
			.collect(Collectors.toList())
			.get(2);
			
			 Map<Integer, List<Entry<String, Integer>>> aa22 = map.entrySet() 
				.stream().collect(Collectors.groupingBy(e-> e.getValue()));
				
			  Integer higest = aa22.keySet().stream().sorted( Collections.reverseOrder()).collect(Collectors.toList()).get(2);
				aa22.get(higest);
			System.out.println(" aa  "+aa22.get(higest)+"   ");
			Map.Entry<Integer, List<String>> res
			 = getDynamicNthHighestSalary(map, n); 

			System.out.println(res); 
			
			List <String> list = Arrays.asList("suDEsh","","", "mane", "abcd", "pqr");
			
			List aaaa = list.stream().map(a->swap(a)).collect(Collectors.toList());
			
			 Map<?, ?> mmm = list.stream()
			.filter(s -> s!= null  || ! s.isEmpty())
			.filter(Objects::nonNull)
			.collect(Collectors.groupingBy(s-> s.startsWith("m") ? "m" : "non-M",  Collectors.maxBy(Comparator.naturalOrder())));
//			.collect(Collectors.partitioningBy(s->s.startsWith("m")));
//			 mmm.get("m")
			
			 System.out.println(mmm);
			 
				String[][] arr = new String[][] { { "1", "2", "3" }, { "4", "3", "4" } };
List list22 = Arrays.stream(arr).flatMap(a->Stream.of(a)).collect(Collectors.toList());
	System.out.println("FlatMap "+list22);			
//				Arrays.stream(arr).max((o1, o2) -> o1.compareTo(o2));
//				Map<Object, Integer> vvva = Arrays.stream(arr)
//						.collect(Collectors.toMap(c -> c, v -> 1, Integer::sum, LinkedHashMap::new));
////		
//				Map<String, Long> vvvab = Arrays.stream(arr)
//						.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
//				System.out.println("vvvb  "+vvva);
	 Entry<String, Integer> ss = map.entrySet().stream().sorted((s1,s2)->s1.getValue().compareTo(s2.getValue())).collect(Collectors.toList()).get(3);
//			collect(Collectors.toMap(e->e.getKey(), e2->e2.getValue()));
		System.out.println(ss);
		
		Map<String, Integer> mmmmm = list.stream().distinct().collect(Collectors.toMap(s->s, s->s.length(), (e1,e2)->e2, LinkedHashMap::new));
		Map<String, Long> mmmmm22 = list.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		StringBuilder sb = new StringBuilder("Hi");
		sb.append(" Bye"); sb.substring(3, 5);
		
		LinkedList<String> strLinkedList = new LinkedList(Arrays.asList(list));
		List mm2 = list.stream()
				
		
				.filter(s -> s!= null  || ! s.isEmpty())
				.filter(Objects::nonNull).flatMap(i->i.chars().boxed()).collect(Collectors.toList());
//				.collect(Collectors.groupingBy(s-> s.startsWith("m") ? "m" : "non-M", Collectors.counting() ));
				System.out.println(" mm2 "+mm2);
				
				int[][] score = { {1,2,3},{1,4,5},{2,4,3}};
				List<int[]> cc = Arrays.asList(score);
				LinkedHashMap<Object, Double> bb = Arrays.asList(score).stream().collect(Collectors.toMap(a->a, b->Arrays.stream(b).boxed().mapToInt(Integer::intValue).average().getAsDouble(), (e1,e2)->e2, LinkedHashMap::new));

				
				 Map<Object, Long> mm3 = list.stream()
						.filter(s -> s!= null  || ! s.isEmpty())
						.filter(Objects::nonNull)
						.collect(Collectors.groupingBy(s-> s.startsWith("m") ? "m" : "non-M", Collectors.counting() ));
						System.out.println(" mm3 "+mm2);
						
						
						
						List<String> paths = Arrays.asList("/home/file1", "/home/file2");

						List<List<String>> fileContents = paths.stream()
						        .map(path -> Paths.get(path))
						        .map(path -> { try{return Files.readAllLines(path);}catch(Exception e) { return null;}})
						        .collect(Collectors.toList());
		} 

		public static Map.Entry<Integer, List<String>> getDynamicNthHighestSalary(Map<String, Integer> employeeSalaries, int n) { 
			return employeeSalaries.entrySet() 
					.stream() 
					.collect(Collectors.groupingBy( 
							Map.Entry::getValue, // Group by salary 
							Collectors.mapping(e->e.getKey(), Collectors.toList()) // Collect employee names as a list for each salary 
					)) 
					.entrySet() 
					.stream() 
					.sorted(Collections.reverseOrder(Map.Entry.comparingByKey())) 
					.collect(Collectors.toList()) 
					.get(n - 1); 
		} 
		
		
		public static String swap(String str) {
			System.out.println(str.toCharArray());
			String aa =  str.chars().boxed().map(b -> {
				  int a = b;
				if((int)a > 96 && (int)a <123) {a = a-32;}
				else if((int)a > 64 && (int)a <91) {a = a+32;}
				return (String.valueOf((char)a));
			}).collect(Collectors.joining(" "));  
			 System.out.println(String.valueOf(aa));
//			list.forEach(a -> System.out.println(a));
			 gg(Long.getLong("10"));
			return "";
		}
		
		public static <T extends Number> void gg(T t) {
			
		}
		
		public static <T extends Number> void pp(List<? extends Number> t) {
			
		}
		
		

				
	} 


