package org;

 class Generics <T extends Number>{
	T t;
	
	public Generics(T b) {
		t = b;
	}
	public  void setValue(T a) {
		t = a;
	}
	
	public  T getValue() {
		return t;
	}

	
}

 public class GenericsMain{
	 public static void main(String[] args) {
		Generics<Integer> gen = new Generics<Integer>(20);
		gen.setValue(10);
		System.out.println(gen.getValue());
	}
 }