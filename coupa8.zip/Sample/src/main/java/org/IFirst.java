package org;

@FunctionalInterface
public interface IFirst extends ISecond {
	
	void abc();
	
	@Override
	default public void method2() {
		// TODO Auto-generated method stub
		
	}
	
	default String getStr() {
		return "First";
	}
}
