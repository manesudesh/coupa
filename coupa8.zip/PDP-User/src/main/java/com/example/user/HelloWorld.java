package com.example.user;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Data;

@Data
public class HelloWorld implements Serializable {
  private String merchantId;
    private String accountNumber;
    private String ibanNumber;
    
    public static void main(String[] args) throws JsonProcessingException {
       
    
    
      List  titol = new ArrayList();
      HelloWorld h = new HelloWorld();
      h.merchantId ="789123456123";
      h.accountNumber ="123456";
      h.ibanNumber ="ibanwer" ;
      
      titol.add(h);
      
      ObjectMapper mapper = new ObjectMapper();
     String str =  mapper.writeValueAsString(titol);
  
//      System.out.println("\nEncode a JSON Object - Preserving Order");
//      System.out.print(str);
      
      
      
      	String strLine = "mS ork z seve ae G aS ,\r\n"
      	+ "UNITED ARAB EMIRATES ama) fei stliccsiraliesite<\r\n"
      	+ "FEDERAL AUTHORITY FOR IDENTITY & i 2 ay er aS) ear\r\n"
      	+ "CITZENSHIP-CUSTOMS &PORTSECURITY — Mi i SAO aiptnatig2 ttl,\r\n"
      	+ "Resigent Identity Card Voy ship Gh\r\n"
      	+ "\\ IDNumber/ i 543) 33 me\r\n"
      	+ "784-1985-1613242-4\r\n"
      	+ "SPP pine ine Sl tl]\r\n"
      	+ "Name: Sudhakar Sesetti Sesetti Malleswararaa\r\n"
      	+ "Date of Birth: 02/06/1985 Oka fae\r\n"
      	+ "Spl Atal\r\n"
      	+ "Nationality: India\r\n"
      	+ "issuing Date /,!osa! fu %3 ;\r\n"
      	+ "WSR ees 20/02/2023 Spall\r\n"
      	+ "Signature / sts) Expiry Date /siyiivi &y 6 ,\r\n"
      	+ "19/02/2025 os";
      	
      	String regex = "(3[01]"
                + "|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}"; 
//      	regex = "(0?[1-9]|[12][0-9]|3[01])[/|-](0?[1-9]|1[0-2])[/|-][0-9]{4}";
 Pattern pattern = Pattern.compile(regex); 
 Matcher matcher = pattern.matcher((CharSequence)strLine); 
 while(matcher.find()) {
     System.out.println(matcher.group());
  }
 
  regex = "Name:.*|784.*"; 
 pattern = Pattern.compile(regex); 
 matcher = pattern.matcher((CharSequence)strLine); 
while(matcher.find()) {
System.out.println(matcher.group());
}
      	
//      	Stream.of(strLineArr).flatMap(line -> {Matcher m=pattern.matcher(line);
//        return m.find()? Stream.of(m.toMatchResult()): null;})
//.forEach(mr -> System.out.println(mr.group(1)));
    }
}