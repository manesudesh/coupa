package com.example.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.user.entity.UsersEntity;
import com.example.user.repository.UsersRepository;

@Service
public class UserService {
	
//	@Autowired
	 UsersRepository userRepository ;
	
	
	
	public List<UsersEntity> getList(){
//		return userRepository.findAll();
		return null;
	}

	public UsersEntity getUser(int id){
//		return (UsersEntity) userRepository.getById(id);
		return null;
	}

	public UsersEntity addUser(UsersEntity user){
//		userRepository.saveAndFlush(user);
//		return user;
		return null;
	}

	public UsersEntity update(UsersEntity user) {
//		userRepository.saveAndFlush(user);
		return null;
	}

	public void deleteById(int userId) {
//		userRepository.delete(getUser(userId));
	}

}
