package com.example.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.example.user.entity.Bean1;

@Component
@ConfigurationProperties("server2")
@RefreshScope
public class PConfiguration {
	
//	@Autowired
//	public com.example.user.entity.Bean1 entityBean;
	
//	@Autowired
//	public com.example.user.model.Bean1 modelBean;
	
//@Bean
//@Qualifier("entitye")
//	public com.example.user.entity.Bean1 entityBean(){
//		return new com.example.user.entity.Bean1();
//	}
//class Coo extends com.example.user.model.Bean1{
//	
//}
//	
//	@Bean
//	@Qualifier("modele")
//	public Coo modelBean(){
//		return new C();
//	}

    private String port2;

	public String getPort2() {
		return port2;
	}

	public void setPort2(String port2) {
		this.port2 = port2;
	}

	

  
}