package com.example.user.entity;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

//@Component
//@Configuration
public class Bean1 {
	
//	@Bean(name = "eb")
//	public Bean1 bean2() {
//		return new Bean1();
//	}

}
