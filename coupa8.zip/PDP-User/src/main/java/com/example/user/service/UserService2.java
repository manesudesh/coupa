package com.example.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.user.entity.UsersEntity;
import com.example.user.repository.UsersRepository;

@Service
public class UserService2 {
	
	
	public List<UsersEntity> getList(){
		return null;
	}

	public UsersEntity getUser(int id){
		return new UsersEntity();//(UsersEntity) userRepository.findById(id).orElseGet(()-> new UsersEntity());
	}

	public UsersEntity addUser(UsersEntity user){
//		userRepository.save(user);
		return null;//user;
	}

	public UsersEntity update(UsersEntity user) {
//		userRepository.save(user);
		return null;
	}

	public void deleteById(int userId) {
//		userRepository.delete(getUser(userId));
	}

}
