package com.example.user.repository;

import org.springframework.stereotype.Service;

@Service
public  interface UsersRepository //extends JpaRepository<UsersEntity, Integer>
{
	
}