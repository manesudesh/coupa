package com.example.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.EventListener;
import org.springframework.web.client.RestTemplate;

import com.example.user.controller.PConfiguration;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;


@SpringBootApplication
@RefreshScope
//@EnableAutoConfiguration
//@ComponentScan(basePackages={"com.example.user"})
//@EnableTransactionManagement
//@EntityScan(basePackages="com.example.user.entity")
//@EnableJpaRepositories(
//  entityManagerFactoryRef = "entityManagerFactory",
//  basePackages = { "com.example.user.repository" }
//)
@EnableEncryptableProperties
public class UserApplication {
	
	@Value("${secret-key}")
    private String defaultSecret;
	
	@Autowired
	PConfiguration pf;
	
	public static void main(String [] args) {
		SpringApplication.run(UserApplication.class, args);
	}
	
@Bean
@LoadBalanced
	public RestTemplate getTemplate() {
		return new RestTemplate();
	}
	
@EventListener({
	ApplicationReadyEvent.class,
	RefreshScopeRefreshedEvent.class
})
public void onRefreshEvent(ApplicationEvent re) {
	System.out.println(pf.getPort2()+" On Refresh EVENNENT");
}





}
