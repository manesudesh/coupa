package com.example.user.model;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;


//@Component
//@Configuration
public class Bean1 {
	
//	@Bean(name = "mb")
//	public Bean1 bean1() {
//		return new Bean1();
//	}

}
