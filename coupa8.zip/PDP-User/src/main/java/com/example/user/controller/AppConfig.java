package com.example.user.controller;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    @Bean(name = "modelBean1")
    public com.example.user.model.Bean1 modelBean1() {
        return new com.example.user.model.Bean1();
    }

    @Bean(name = "entityBean1")
    public com.example.user.entity.Bean1 entityBean1() {
        return new com.example.user.entity.Bean1();
    }
}
