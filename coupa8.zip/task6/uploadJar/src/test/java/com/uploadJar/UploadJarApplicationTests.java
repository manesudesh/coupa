package com.uploadJar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadJarApplicationTests {

	@Test
	void contextLoads() {
	}

}
