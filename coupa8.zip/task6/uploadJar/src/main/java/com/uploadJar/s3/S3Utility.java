package com.uploadJar.s3;

import java.nio.file.Paths;

import org.springframework.stereotype.Service;

import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;

@Service
public class S3Utility {
	
	public void upload()
	{
		// Replace with your AWS access key and secret key
        String accessKey = "AKIAYHJANCWHV3BGPYCU";
        String secretKey = "I9e08DuwOsCjNbrIIsk/UIsvDAW2CdHKr/BwQCRI";
        String bucketName = "sudeshmane-bucket2";
        String keyName = "task6";
        String filePath = "c:/Users/Sudesh_Mane/eclipse-workspace/task6/webApp/target/webApp-0.0.1-SNAPSHOT.jar";

        // Create AWS credentials
        AwsBasicCredentials awsCreds = AwsBasicCredentials.create(accessKey, secretKey);

        // Create S3 client
        S3Client s3 = S3Client.builder()
                .region(Region.US_EAST_1) // Replace with your region
                .credentialsProvider(StaticCredentialsProvider.create(awsCreds))
                .build();

        // Create PutObjectRequest
        PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                .bucket(bucketName)
                .key(keyName)
                .build();

        // Upload the file
        PutObjectResponse response = s3.putObject(putObjectRequest, RequestBody.fromFile(Paths.get(filePath)));

        // Print response details
        System.out.println("File uploaded successfully. ETag: " + response.eTag());
	}

}
