package com.uploadJar.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uploadJar.s3.S3Utility;

@RestController
public class JarController {
	
	@Autowired
	S3Utility s3;
	
	@GetMapping("/upload")
	public void getEc2Regions() {
		s3.upload();
	}

}
