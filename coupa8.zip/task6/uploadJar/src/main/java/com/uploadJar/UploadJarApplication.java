package com.uploadJar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadJarApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadJarApplication.class, args);
	}

}
