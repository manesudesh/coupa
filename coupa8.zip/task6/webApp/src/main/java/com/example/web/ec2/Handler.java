package com.example.web.ec2;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Scanner;

import org.springframework.stereotype.Service;

import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.AvailabilityZone;
import com.amazonaws.services.ec2.model.DescribeAvailabilityZonesResult;
import com.amazonaws.services.ec2.model.DescribeRegionsResult;
import com.amazonaws.services.ec2.model.Region;

@Service
public class Handler {

    
 public List<Region> getEC2Region() {
	 final AmazonEC2 ec2 = AmazonEC2ClientBuilder.defaultClient();

	 DescribeRegionsResult regions_response = ec2. describeRegions();

     for (Region region : regions_response.getRegions()) {
         System.out.printf(
                 "Found region %s " +
                         "with endpoint %s",
                 region.getRegionName(),
                 region.getEndpoint());
     }
     return regions_response.getRegions();
 }
 
	public String getCurrentInfo() {
		String region = getMetadata("placement/region");

		String availabilityZone = getMetadata("placement/availability-zone");

		return region + "  " + availabilityZone;
	}

	private String getMetadata(String path) {
		URL url;
		Scanner scanner = null;
		try {
			url = new URL("http://169.254.169.254/latest/meta-data/" + path);

			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			scanner = new Scanner(conn.getInputStream());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return scanner.hasNext() ? scanner.nextLine() : null;
	}

	public List<AvailabilityZone> getEC2AZones() {
		final AmazonEC2 ec2 = AmazonEC2ClientBuilder.defaultClient();

		DescribeAvailabilityZonesResult zones_response = ec2.describeAvailabilityZones();

		for (AvailabilityZone zone : zones_response.getAvailabilityZones()) {
			System.out.printf("Found availability zone %s " + "with status %s " + "in region %s", zone.getZoneName(),
					zone.getState(), zone.getRegionName());
		}
		return zones_response.getAvailabilityZones();
	}

}
