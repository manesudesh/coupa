package com.example.web;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.web.ec2.Handler;

@RestController
public class Controller {
	
	@Autowired
	Handler handler;
	
	@GetMapping("/ec2Regions")
	public List<String> getEc2Regions() {
		return handler.getEC2Region().stream().map(r -> r.getRegionName()+ " "+r.getEndpoint()).collect(Collectors.toList());
	}
	
	@GetMapping("/ec2Info")
	public String getEcInfo() {
		return handler.getCurrentInfo();
	}
	
	@GetMapping("/ec2AZones")
	public List<String> getEc2Azones() {
		return handler.getEC2AZones().stream().map(zone -> zone.getZoneName()+"  "
				+" "+zone.getState() +" "+ zone.getRegionName()).collect(Collectors.toList());
	}

}
