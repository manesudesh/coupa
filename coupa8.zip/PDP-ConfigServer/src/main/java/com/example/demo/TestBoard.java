package com.example.demo;

public class TestBoard {

	public static void main(String[] args) {
		Board aa = new Board();
		Board bb = new Board();
		
		aa.height = 90; aa.width=60; aa.color = "Yellow";
		aa.display();
		
		bb.height = 70; bb.width=60; bb.color = "Black";
		bb.display();
	}

}
