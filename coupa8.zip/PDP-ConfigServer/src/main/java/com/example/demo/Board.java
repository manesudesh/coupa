package com.example.demo;

public class Board {

	int height;
	int width;
	String color;
	
	void display() {
		for(int ii=1; ii<=3; ii++) {
			height = height + 10;
			
			if(height > 80) {
				System.out.println(height+" Display Horizontally "+color);
			}
			else {
				System.out.println(height+" Display Vertically "+color);
			}
		}
		
	}
}
