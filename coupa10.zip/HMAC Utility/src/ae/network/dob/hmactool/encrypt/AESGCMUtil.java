package ae.network.dob.hmactool.encrypt;

import java.security.GeneralSecurityException;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/***
 * <p>
 * Crypto utility for AES GCM encryption and decryption.
 * </p>
 * 
 * @author
 * @version 1.0.0
 */
public class AESGCMUtil {
	public static final int AES_KEY_SIZE = 256;
	public static final int GCM_IV_LENGTH = 12;
	public static final int GCM_TAG_LENGTH = 16;

	private AESGCMUtil() {
	}

	public static String encrypt(String plainText, String secKey, String ivData) throws GeneralSecurityException {
		Cipher cipher = buildCipher(secKey, ivData, Cipher.ENCRYPT_MODE);
		byte[] cipherText = cipher.doFinal(plainText.getBytes());
		return byteToHexString(cipherText);
	}

	public static String decrypt(String encHexString, String secKey, String ivData) throws GeneralSecurityException {
		Cipher cipher = buildCipher(secKey, ivData, Cipher.DECRYPT_MODE);
		byte[] decryptedText = cipher.doFinal(hexToByteArray(encHexString));
		return new String(decryptedText);
	}

	private static Cipher buildCipher(String secretKey, String ivData, int cipherMode) throws GeneralSecurityException {
		SecretKeySpec keySpec = new SecretKeySpec(hexToByteArray(secretKey), "AES");
		GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(GCM_TAG_LENGTH * 8,
				hexToByteArray(ivData));
		Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
		cipher.init(cipherMode, keySpec, gcmParameterSpec);
		return cipher;
	}

	private static String byteToHexString(byte[] byteData) {
		StringBuilder stringBuilder = new StringBuilder(byteData.length * 2);
		for (byte hashByte : byteData) {
			stringBuilder.append(String.format("%02x", hashByte));
		}
		return stringBuilder.toString().toUpperCase();
	}

	private static byte[] hexToByteArray(String hexString) {
		int len = hexString.length();
		byte[] data = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			data[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4)
					+ Character.digit(hexString.charAt(i + 1), 16));
		}
		return data;
	}
	
	public static String computeHMAC(String message, String signatureKey, String algorithm) throws GeneralSecurityException {
		byte[] signatureKeyInByteArray = hexStringToByteArray(signatureKey);
		SecretKeySpec secretKeySpec = new SecretKeySpec(signatureKeyInByteArray, algorithm);
		Mac mac = Mac.getInstance(algorithm);
		mac.init(secretKeySpec);
		return Base64.getEncoder().encodeToString(mac.doFinal(message.getBytes()));
	}
	
	private static byte[] hexStringToByteArray(String hexString) {
		int len = hexString.length();
		byte[] data = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			data[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4)
					+ Character.digit(hexString.charAt(i + 1), 16));
		}
		return data;
	}
	
}