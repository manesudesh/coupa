package ae.network.dob.hmactool.ui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import ae.network.dob.hmactool.encrypt.AESGCMUtil;

public class APIPostPanel extends JPanel{

	private JTextArea plainPayloadText;
	
	private JTextArea encPayloadText;
	
	private JTextArea requestedHmacPayloadText;

	private JTextField clientIDTextfield;

	private JTextField dateTimeTextfield;

	private JCheckBox copyReqBodyCheckBox;

	private JCheckBox copyHmacDataCheckBox;

	private JCheckBox copyDateTimeCheckBox;
	
	public APIPostPanel(){
		this.setBounds(10,57,1020,500); 
		this.setLayout(null);
		this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		this.setBackground(Color.lightGray); 
		
		createEncryptJpanel(); 
		createDateTimePanel();
	    createHMACJpanel(); 
	}

	private void createEncryptJpanel( ) {
		JPanel encryptPanel = new JPanel(null);
		encryptPanel.setBounds(10,10,1000,190);
		encryptPanel.setBackground(Color.yellow);
		encryptPanel.setBorder(BorderFactory.createLineBorder(Color.black));
		encryptPanel.setVisible(true);
	    this.add(encryptPanel);
		
		JLabel plainPayloadLabel = new JLabel("PLAIN PAYLOAD"); 
		plainPayloadLabel.setBounds(150, 160, 150, 20);
		encryptPanel.add(plainPayloadLabel);
	    
	    plainPayloadText = new JTextArea();
	   
	    
	   
	    /* try(Stream<String> lines = Files.lines(Paths.get("./src/SamplePayload.txt"))){
	    	String linesSampleFile = String.join("\n", lines.collect(Collectors.toList()));
	    	plainPayloadText.setText(linesSampleFile);
	    } catch(Exception exe) {System.out.println("Exception while reading sample request file "+exe.getMessage());}
	   */
	    
	    try(BufferedReader streamReader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream("/SamplePayload.txt"))) )
	    {
	    	String line = "", concanateLine ="" ;
	    	 while(( line=streamReader.readLine())!=null){
	    		 concanateLine = concanateLine+line+"\n";
	    	 }    
	    	 plainPayloadText.setText(concanateLine);
	    }catch(Exception exe) {System.out.println("Exception while reading sample request file "+exe.getMessage());}
	   
	    
	    plainPayloadText.setLineWrap(true);
//	    plainPayloadText.setBounds(10, 10, 390, 150);
	    JScrollPane scrollablePlainPayloadText = new JScrollPane(plainPayloadText, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);  
	    scrollablePlainPayloadText.setBounds(10, 10, 390, 150);
	    encryptPanel.add(scrollablePlainPayloadText);
	    
	    JLabel encPayloadLabel = new JLabel("ENCRPYTED PAYLOAD"); 
	    encPayloadLabel.setBounds(750, 160, 150, 20);
	    encryptPanel.add(encPayloadLabel);
	    
	    encPayloadText = new JTextArea("");
	    encPayloadText.setLineWrap(true);
//	    encPayloadText.setBounds(590, 10, 400, 150);
	    JScrollPane scrollableEncPayloadText = new JScrollPane(encPayloadText, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);  
	    scrollableEncPayloadText.setBounds(590, 10, 400, 150);
	    encryptPanel.add(scrollableEncPayloadText);
	    
	    JButton encryptPayloadButton=new JButton("ENCRYPT ===>");  
	    encryptPayloadButton.setBounds(430,50,150,20);  
	    encryptPanel.add(encryptPayloadButton);
	    
	    encryptPayloadButton.addActionListener(new ActionListener(){  
	    	public void actionPerformed(ActionEvent event){
	    		try {
	    			String encryptedString = AESGCMUtil.encrypt(plainPayloadText.getText().trim(), KeyPanel.encSecretText.getText().trim(), KeyPanel.nonceText.getText().trim()) ;
	    			encPayloadText.setText(" ");
	    			encPayloadText.setText(
	    				encryptedString
	    	    		);  
	    			
	    			String clientIDStr = clientIDTextfield.getText().trim();
	    			requestedHmacPayloadText.setText(" ");
	    			String currentDatetimeStr = dateTimeTextfield.getText().trim();
	    			
	    			requestedHmacPayloadText.setText(""
//	    					clientIDStr+""+currentDatetimeStr
	    				+"{  \"clientId\": \""+clientIDStr+"\","
    					+ "\"encRequestMsg\": "
    					+"\""+encryptedString+"\""
    					+ "}"
    	    		); 
	    			encPayloadText.select(0, 1);
	    			requestedHmacPayloadText.select(0, 1);
	    		}catch(Exception exe) {System.out.println(exe.getMessage()); encPayloadText.setText("Decrypted Text not Valid");}
	        }  
	    }); 
	    
	 
	    JButton plainPayloadButton = new JButton("<=== PLAIN");  
	    plainPayloadButton.setBounds(430,100,150,20);  
	    encryptPanel.add(plainPayloadButton);
	    
	    plainPayloadButton.addActionListener(new ActionListener(){  
	    	public void actionPerformed(ActionEvent event){
	    		try {
	    			plainPayloadText.setText(" ");
	    			plainPayloadText.setText(
	    	    		AESGCMUtil.decrypt(encPayloadText.getText().trim(), KeyPanel.encSecretText.getText().trim(), KeyPanel.nonceText.getText().trim()) 
	    	    		+ "");  
	    			plainPayloadText.select(0, 1);
	    		}catch(Exception exe) {System.out.println(exe.getMessage()); plainPayloadText.setText("Encrypted Text not Valid");}
	        }  
	    });
	}
	
	
	private void createDateTimePanel() {
		JPanel dateTimePanel = new JPanel(null);
		dateTimePanel.setBounds(10,215,1000,50);
		dateTimePanel.setBackground(Color.yellow);
		dateTimePanel.setBorder(BorderFactory.createLineBorder(Color.black));
		dateTimePanel.setVisible(true);
	    this.add(dateTimePanel);
	    
		JLabel clientIdLabel = new JLabel("Client Id"); clientIdLabel.setBounds(10, 10, 50, 20); dateTimePanel.add(clientIdLabel);
	    JLabel dateTimeLabel = new JLabel("Date Time"); dateTimeLabel.setBounds(300, 10, 100, 20); dateTimePanel.add(dateTimeLabel);
	     
	    Long currentDatetime = new Date().getTime();
	    
	    clientIDTextfield = new JTextField(KeyPanel.clientIdText.getText()); clientIDTextfield.setBounds(70, 10, 100, 20);  dateTimePanel.add(clientIDTextfield);
	    dateTimeTextfield = new JTextField(String.valueOf(currentDatetime)); dateTimeTextfield.setBounds(400, 10, 200, 20);  dateTimePanel.add(dateTimeTextfield);
	
	    copyDateTimeCheckBox = new JCheckBox("Copy DateTime");
	    copyDateTimeCheckBox.setBounds(600, 10, 150, 20);  dateTimePanel.add(copyDateTimeCheckBox);
	    copyDateTimeCheckBox.setBackground(dateTimePanel.getBackground());
	    copyDateTimeCheckBox.addItemListener(new ItemListener() {    
	        public void itemStateChanged(ItemEvent e) {  
	        	if(e.getStateChange() == 1 ) {
	        		dateTimeTextfield.selectAll();
	        		dateTimeTextfield.copy();
	        		
	        		copyReqBodyCheckBox.setSelected(false);
	        		copyHmacDataCheckBox.setSelected(false);
	        	} 
	        }    
	     });  
	    
	    JButton resetButton=new JButton(" Reset DateTime");  
	    resetButton.setBounds(800,10,200,30);
	    dateTimePanel.add(resetButton);
	    
	    resetButton.addActionListener(new ActionListener(){  
	    	public void actionPerformed(ActionEvent event){
	    		try {
	    			String encryptedString = AESGCMUtil.encrypt(plainPayloadText.getText().trim(), KeyPanel.encSecretText.getText().trim(), KeyPanel.nonceText.getText().trim()) ;
	    			encPayloadText.setText(" ");
	    			encPayloadText.setText(	encryptedString	);  
	    			
	    			String clientID = clientIDTextfield.getText().trim();
	    			clientIDTextfield.setText(clientID);
	    			
	    			Long currentDatetime = new Date().getTime();
	    			dateTimeTextfield.setText(currentDatetime+"");
	    			
	    			requestedHmacPayloadText.setText(" ");
	    			requestedHmacPayloadText.setText(""
	    				+"{  \"clientId\": \""+clientID+"\","
    					+ "\"encRequestMsg\": "
    					+"\""+encryptedString+"\""
    					+ "}"
    	    		); 
	    			encPayloadText.select(0, 1);
	    			requestedHmacPayloadText.select(0, 1);
	    		}catch(Exception exe) {System.out.println(exe.getMessage()); encPayloadText.setText("Decrypted Text not Valid");}
	        }  
	    }); 
	}
	
	private void createHMACJpanel( ) {
		JPanel hmacPanel = new JPanel(null);
	    hmacPanel.setBounds(10,280,1000,190);
	    hmacPanel.setBackground(Color.ORANGE);
	    hmacPanel.setBorder(BorderFactory.createLineBorder(Color.black));
	    hmacPanel.setVisible(true);
	    this.add(hmacPanel);
	    
	    requestedHmacPayloadText = new JTextArea("NI + DATETIME + {\r\n"
	    		+ "    \"clientId\": \"NI\","
	    		+ "    \"encRequestMsg\": \"1343D51A9D0072A5416892284058CAE18\""
	    		+ "}");
	    requestedHmacPayloadText.setLineWrap(true);
//	    requestedHmacPayloadText.setBounds(590, 10, 400, 150);
	    JScrollPane scrollableRequestedHmacPayloadText = new JScrollPane(requestedHmacPayloadText, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);  
	    scrollableRequestedHmacPayloadText.setBounds(10, 10, 400, 150);
	    hmacPanel.add(scrollableRequestedHmacPayloadText);
	    
	    JLabel requestedHmacPayloadLabel = new JLabel("REQUESTED BODY"); 
	    requestedHmacPayloadLabel.setBounds(150, 160, 150, 20);
	    hmacPanel.add(requestedHmacPayloadLabel);
	    
	    copyReqBodyCheckBox = new JCheckBox("Copy Body");
	    copyReqBodyCheckBox.setBounds(300, 160, 100, 20);  hmacPanel.add(copyReqBodyCheckBox);
	    copyReqBodyCheckBox.setBackground(hmacPanel.getBackground());
	    copyReqBodyCheckBox.addItemListener(new ItemListener() {    
	        public void itemStateChanged(ItemEvent e) {  
	        	if(e.getStateChange() == 1 ) {
	        		requestedHmacPayloadText.selectAll();
	        		requestedHmacPayloadText.copy();
	        		
	        		copyDateTimeCheckBox.setSelected(false);
	        		copyHmacDataCheckBox.setSelected(false);
	        	} 
	        }    
	     });  
	    
	    JTextArea hmacPayloadText = new JTextArea(" ");
	    hmacPayloadText.setLineWrap(true);
//	    hmacPayloadText.setBounds(10, 10, 400, 150);
	    JScrollPane scrollableHmacPayloadText = new JScrollPane(hmacPayloadText, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);  
	    scrollableHmacPayloadText.setBounds(590, 10, 400, 150);
	    hmacPanel.add(scrollableHmacPayloadText);
	    
	    JLabel hmacPayloadLabel = new JLabel("HMAC PAYLOAD"); 
	    hmacPayloadLabel.setBounds(750, 160, 150, 20);
	    hmacPanel.add(hmacPayloadLabel);
	    
	    copyHmacDataCheckBox = new JCheckBox("Copy HMAC Value");
	    copyHmacDataCheckBox.setBounds(850, 160, 140, 20);  hmacPanel.add(copyHmacDataCheckBox);
	    copyHmacDataCheckBox.setBackground(hmacPanel.getBackground());
	    copyHmacDataCheckBox.addItemListener(new ItemListener() {    
	        public void itemStateChanged(ItemEvent e) {  
	        	if(e.getStateChange() == 1 ) {
	        		hmacPayloadText.selectAll();
	        		hmacPayloadText.copy();
	        		
	        		copyDateTimeCheckBox.setSelected(false);
	        		copyReqBodyCheckBox.setSelected(false);
	        	} 
	        }    
	     }); 
	    
	    JButton hmacPayloadButton=new JButton("HMAC ===>");  
	    hmacPayloadButton.setBounds(430,50,150,50);
	    hmacPanel.add(hmacPayloadButton);
	    
	    JLabel hmacDescriptionLabel = new JLabel("(Id + Date Time + requested body) ");  
	    hmacDescriptionLabel.setBounds(420,80,250,50);
	    hmacPanel.add(hmacDescriptionLabel);
	    
	    hmacPayloadButton.addActionListener(new ActionListener(){  
	    	public void actionPerformed(ActionEvent event){
	    		try {
	    			System.out.println( KeyPanel.hmacSecretText.getText().trim() );
	    			System.out.println( KeyPanel.hmacAlgoText.getText().trim() );
	    			String tobeHmacStr = 
	    					clientIDTextfield.getText().trim() + dateTimeTextfield.getText().trim() + requestedHmacPayloadText.getText().trim();

	    			String hmacPayloadStr = AESGCMUtil.computeHMAC(tobeHmacStr, KeyPanel.hmacSecretText.getText().trim(), KeyPanel.hmacAlgoText.getText().trim()); 
	    					System.out.println( hmacPayloadStr);
	    			hmacPayloadText.setText(" ");
	    			hmacPayloadText.setText(
//	    				+ "\"clientId\": \"NI\",\r\n"
//	    	    		+ "    \r\n"
//	    	    		+ "    \"encRequestMsg\": "+ 
	    					hmacPayloadStr
//	    	    		+"\r\n"
//	    	    		+ "}\r\n"
	    	    		+ "");  
	    			hmacPayloadText.select(0, 1);
	    		}catch(Exception exe) {System.out.println(exe.getMessage()); hmacPayloadText.setText("HMAC Text not Valid");}
	        }  
	    });
	}
}
