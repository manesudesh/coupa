package ae.network.dob.hmactool.ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;

public class ToolScreen {
	public static void main(String[] args) { 
		
		
	    
		JFrame frame = new JFrame(" Mosambee Tool"); 
		frame.setLayout(null);
		KeyPanel keyPanel = new KeyPanel(); frame.add(keyPanel);
		APIQueryPanel queryAPIPanel = new APIQueryPanel(); frame.add(queryAPIPanel);
		APIPostPanel postAPIPanel = new APIPostPanel(); frame.add(postAPIPanel);
		keyPanel.setVisible(false);		queryAPIPanel.setVisible(false);		postAPIPanel.setVisible(false);
		
		JButton keyPanelButton=new JButton("TOKEN KEYS");  
		keyPanelButton.setBounds(150,0,150,50);  
		frame.add(keyPanelButton);
		keyPanelButton.addActionListener(new ActionListener(){  
	    	public void actionPerformed(ActionEvent event){  
	    		keyPanel.setVisible(true);
	    		queryAPIPanel.setVisible(false);
	    		postAPIPanel.setVisible(false);
	        }  
	    }); 
		
		JButton postAPIPanelButton=new JButton("POST API");  
		postAPIPanelButton.setBounds(450,0,150,50);  
		frame.add(postAPIPanelButton);
		postAPIPanelButton.addActionListener(new ActionListener(){  
	    	public void actionPerformed(ActionEvent event){  
	    		keyPanel.setVisible(false);
	    		queryAPIPanel.setVisible(false);
	    		postAPIPanel.setVisible(true);
	        }  
	    }); 
		
		JButton queryAPIPanelButton=new JButton("QUERY API");  
		queryAPIPanelButton.setBounds(750,0,150,50);  
		frame.add(queryAPIPanelButton);
		queryAPIPanelButton.addActionListener(new ActionListener(){  
	    	public void actionPerformed(ActionEvent event){  
	    		keyPanel.setVisible(false);
	    		queryAPIPanel.setVisible(true);
	    		postAPIPanel.setVisible(false);
	        }  
	    }); 
	    
			    
		frame.addWindowListener(new WindowAdapter() {
	    	public void windowClosing(WindowEvent e) {
	            System.exit(0);
	          }
	    });
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		frame.setSize(1050,600);  
		frame.setLayout(null);  
		frame.setVisible(true); 
	    
	}  
}

