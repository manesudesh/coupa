package ae.network.dob.hmactool.ui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class KeyPanel extends JPanel{

	public static JTextField encSecretText;
	public static JTextField nonceText;
	public static JTextField hmacSecretText;
	public static JTextField hmacAlgoText;
	public static JTextField clientIdText;
	
	KeyPanel(){
		super();
		this.setBounds(100,100,800,350); 
		this.setLayout(null);
		this.setBackground(Color.orange); 
		this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
	
	Properties properties = new Properties();
    Map<String, String> myMap = new HashMap<String, String>();
    try {
    	InputStream in =  this.getClass().getResourceAsStream("/Tokens.txt");
//    	FileInputStream in = new FileInputStream( "./src/Tokens.txt");
    		properties.load(in);
    		for (Map.Entry<Object, Object> entry : properties.entrySet()) {
    			myMap.put((String) entry.getKey(), (String) entry.getValue());
    		}
    		in.close();
    		System.out.print(myMap);
    }catch(Exception e) {System.out.print("Exception "+e.getMessage());}
    
	JLabel encSecretLabel = new JLabel("Encrypt Secret Token : "); 
	encSecretLabel.setBounds(50, 50, 150, 20);
	this.add(encSecretLabel);
	
	encSecretText = new JPasswordField();  
    encSecretText.setBounds(200, 50, 550, 20); 
    encSecretText.setText(myMap.get("encrptSecret"));
    encSecretText.setEditable(false);
    this.add(encSecretText);
    JCheckBox jcEncSecretText = new JCheckBox();
    jcEncSecretText.addItemListener(new ItemListener() {    
        public void itemStateChanged(ItemEvent e) {  
        	if(e.getStateChange() == 1 ) {
        		encSecretText.setEditable(true); 
        		((JPasswordField) encSecretText).setEchoChar('\u0000');
        	} else{ 
        			encSecretText.setEditable(false);
        		((JPasswordField) encSecretText).setEchoChar('*');
        	}
        }    
     });   
    jcEncSecretText.setBounds(180,50, 20,20); 
    this.add(jcEncSecretText);
    
    JLabel nonceLabel = new JLabel("Nonce Secret Token : "); 
    nonceLabel.setBounds(50, 100, 150, 20);
    this.add(nonceLabel);
    
    nonceText = new JPasswordField();  
    nonceText.setBounds(200, 100, 550, 20); 
    nonceText.setText(myMap.get("nonce"));
    nonceText.setEditable(false);
    this.add(nonceText);
    JCheckBox jcNonceText = new JCheckBox();
    jcNonceText.addItemListener(new ItemListener() {    
        public void itemStateChanged(ItemEvent e) {  
        	if(e.getStateChange() == 1 ) {
        		nonceText.setEditable(true); 
        		((JPasswordField) nonceText).setEchoChar('\u0000');
        	} else{ 
        		nonceText.setEditable(false);
        		((JPasswordField) nonceText).setEchoChar('*');
        	}
        }    
     });   
    jcNonceText.setBounds(180,100, 20,20); 
    this.add(jcNonceText);
    
    JLabel hmacSecretLabel = new JLabel("HMAC Secret Token : "); 
    hmacSecretLabel.setBounds(50, 150, 150, 20);
    this.add(hmacSecretLabel);
    
    hmacSecretText = new JPasswordField();  
    hmacSecretText.setBounds(200, 150, 550, 20);
    hmacSecretText.setText(myMap.get("hmacSecret"));
    hmacSecretText.setEditable(false);
    this.add(hmacSecretText);
    JCheckBox jcHmacSecretText = new JCheckBox();
    jcHmacSecretText.addItemListener(new ItemListener() {    
        public void itemStateChanged(ItemEvent e) {  
        	if(e.getStateChange() == 1 ) {
        		hmacSecretText.setEditable(true); 
        		((JPasswordField) hmacSecretText).setEchoChar('\u0000');
        	} else{ 
        		hmacSecretText.setEditable(false);
        		((JPasswordField) hmacSecretText).setEchoChar('*');
        	}
        }    
     });   
    jcHmacSecretText.setBounds(180,150, 20,20); 
    this.add(jcHmacSecretText);
    
    JLabel hmacAlgoLabel = new JLabel("HMAC Algorithm : "); 
    hmacAlgoLabel.setBounds(50, 200, 300, 20);
    this.add(hmacAlgoLabel);
    
    hmacAlgoText = new JPasswordField();  
    hmacAlgoText.setBounds(200, 200, 550, 20);
    hmacAlgoText.setText(myMap.get("hmacAlgorithm"));
    hmacAlgoText.setEditable(false);
    this.add(hmacAlgoText);
    JCheckBox jcHmacAlgoText = new JCheckBox();
    jcHmacAlgoText.addItemListener(new ItemListener() {    
        public void itemStateChanged(ItemEvent e) {  
        	if(e.getStateChange() == 1 ) {
        		hmacAlgoText.setEditable(true); 
        		((JPasswordField) hmacAlgoText).setEchoChar('\u0000');
        	} else{ 
        		hmacAlgoText.setEditable(false);
        		((JPasswordField) hmacAlgoText).setEchoChar('*');
        	}
        }    
     });   
    jcHmacAlgoText.setBounds(180,200, 20,20); 
    this.add(jcHmacAlgoText);
    
    JLabel clientIdLabel = new JLabel("Client Id"); 
    clientIdLabel.setBounds(50, 250, 150, 20);
    this.add(clientIdLabel);
    
    clientIdText = new JPasswordField();  
    clientIdText.setBounds(200, 250, 550, 20); 
    clientIdText.setText(myMap.get("clientId"));
    clientIdText.setEditable(false);
    this.add(clientIdText);
    JCheckBox jcClientIdText = new JCheckBox();
    jcClientIdText.addItemListener(new ItemListener() {    
        public void itemStateChanged(ItemEvent e) {  
        	if(e.getStateChange() == 1 ) {
        		clientIdText.setEditable(true); 
        		((JPasswordField) clientIdText).setEchoChar('\u0000');
        	} else{ 
        			clientIdText.setEditable(false);
        			((JPasswordField) clientIdText).setEchoChar('*');
        	}
        }    
     });   
    jcClientIdText.setBounds(180,250, 20,20); 
    this.add(jcClientIdText);
    
    JButton updateTokenButton = new JButton("Update Tokens");  
    updateTokenButton.setBounds(20,300,130,30);  
    
    updateTokenButton.addActionListener(new ActionListener(){  
    	public void actionPerformed(ActionEvent event){  
//    		try(FileOutputStream out = new FileOutputStream( "./src/Tokens.txt")){
    		try(FileOutputStream out = new FileOutputStream(this.getClass().getResource("/Tokens.txt").getPath())){
    			properties.setProperty("hmacSecret", hmacSecretText.getText().trim());
    			properties.setProperty("clientId", clientIdText.getText().trim());
    			properties.setProperty("hmacAlgorithm", hmacAlgoText.getText().trim());
    			properties.setProperty("encrptSecret", encSecretText.getText().trim());
	    		properties.setProperty("nonce", nonceText.getText().trim());
	    		properties.store(  out, null);
	    		out.close();
	    		System.out.print("**** Tokens updated ****");
	    	}
    		catch(Exception ex) {
	        	System.out.print("Exception storing file "+ex.getMessage());
	        }
        }  
    }); 
    
    this.add(updateTokenButton);
    
    }
    
}
