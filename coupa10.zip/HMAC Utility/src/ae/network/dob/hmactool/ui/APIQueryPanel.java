package ae.network.dob.hmactool.ui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import ae.network.dob.hmactool.encrypt.AESGCMUtil;

public class APIQueryPanel extends JPanel{

JTextArea requestedHmacPayloadText;
	
	JTextArea encPayloadText;
	
	JTextField clientIDTextfield ;
    JTextField dateTimeTextfield ;
    JTextField merchantTerminalIdTextfield ;
    
    JTextArea hmacPayloadText ;

	private JCheckBox merchantTerminalCheckBox;

	private JCheckBox hmacValueCheckBox;

	private JCheckBox dateTimeCheckBox;
	
	public APIQueryPanel(){
		this.setBounds(10,57,1020,500); 
		this.setLayout(null);
		this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		this.setBackground(Color.lightGray); 
		
		createEncryptJpanel(); 
	    createHMACJpanel(); 
	}

	

	private void createEncryptJpanel( ) {
		JPanel encryptPanel = new JPanel(null);
		encryptPanel.setBounds(10,10,1000,250);
		encryptPanel.setBackground(Color.yellow);
		encryptPanel.setBorder(BorderFactory.createLineBorder(Color.black));
		encryptPanel.setVisible(true);
	    this.add(encryptPanel);
		
	    
	    JLabel clientIdLabel = new JLabel("Client Id"); clientIdLabel.setBounds(10, 10, 200, 20); encryptPanel.add(clientIdLabel);
	    JLabel dateTimeLabel = new JLabel("Date Time"); dateTimeLabel.setBounds(10, 70, 200, 20); encryptPanel.add(dateTimeLabel);
	    JLabel idLabel = new JLabel("Enter Merchant/Terminal Id"); idLabel.setBounds(10, 130, 200, 20); encryptPanel.add(idLabel);
	    
	     
	    Long currentDatetime = new Date().getTime();
	    
	    clientIDTextfield = new JTextField(KeyPanel.clientIdText.getText()); clientIDTextfield.setBounds(200, 10, 400, 20);  encryptPanel.add(clientIDTextfield);
	    dateTimeTextfield = new JTextField(String.valueOf(currentDatetime)); dateTimeTextfield.setBounds(200, 70, 400, 20);  encryptPanel.add(dateTimeTextfield);
	    merchantTerminalIdTextfield = new JTextField();    merchantTerminalIdTextfield.setBounds(200, 130, 400, 20);        encryptPanel.add(merchantTerminalIdTextfield);
	    		
	    dateTimeCheckBox = new JCheckBox("Copy DateTime");
	    dateTimeCheckBox.setBounds(600, 70, 400, 20);  encryptPanel.add(dateTimeCheckBox);
	    dateTimeCheckBox.setBackground(encryptPanel.getBackground());
	    dateTimeCheckBox.addItemListener(new ItemListener() {    
	        public void itemStateChanged(ItemEvent e) {  
	        	if(e.getStateChange() == 1 ) {
	        		dateTimeTextfield.selectAll();
	        		dateTimeTextfield.copy();
	        		
	        		merchantTerminalCheckBox.setSelected(false);
	        		hmacValueCheckBox.setSelected(false);
	        	} 
	        }    
	     }); 
	    
	    merchantTerminalCheckBox = new JCheckBox("Copy id");
	    merchantTerminalCheckBox.setBounds(600, 130, 400, 20);  encryptPanel.add(merchantTerminalCheckBox);
	    merchantTerminalCheckBox.setBackground(encryptPanel.getBackground());
	    merchantTerminalCheckBox.addItemListener(new ItemListener() {    
	        public void itemStateChanged(ItemEvent e) {  
	        	if(e.getStateChange() == 1 ) {
	        		merchantTerminalIdTextfield.selectAll();
	        		merchantTerminalIdTextfield.copy();
	        		
	        		dateTimeCheckBox.setSelected(false);
	        		hmacValueCheckBox.setSelected(false);
	        	} 
	        }    
	     }); 
	    
	    JButton resetButton=new JButton(" Reset ");  
	    resetButton.setBounds(870, 20, 80, 20);
	    encryptPanel.add(resetButton);
	    
	    resetButton.addActionListener(new ActionListener(){  
	    	public void actionPerformed(ActionEvent event){
	    		try {
	    			clientIDTextfield.setText(KeyPanel.clientIdText.getText());
	    			
	    			Long currentDatetime = new Date().getTime();
	    			dateTimeTextfield.setText(currentDatetime+"");
	    			
	    			merchantTerminalIdTextfield.setText("");
	    			hmacPayloadText.setText("");
	    			
	    		}catch(Exception exe) {System.out.println(exe.getMessage()); encPayloadText.setText("Decrypted Text not Valid");}
	        }  
	    }); 
	
	    JButton hmacPayloadButton=new JButton(" CLICK TO HMAC");  
	    hmacPayloadButton.setBounds(300,180,180,50);
	    encryptPanel.add(hmacPayloadButton);
	    
	    JLabel hmacDescriptionLabel = new JLabel("(Client Id + Date Time + Merchant/Terminal Id) to HMAC ");  
	    hmacDescriptionLabel.setBounds(230,210,480,50);
	    encryptPanel.add(hmacDescriptionLabel);
	    
	    hmacPayloadButton.addActionListener(new ActionListener(){  
	    	public void actionPerformed(ActionEvent event){
	    		try {
	    			System.out.println( KeyPanel.hmacSecretText.getText().trim() );
	    			System.out.println( KeyPanel.hmacAlgoText.getText().trim() );
	    			
	    			String clientIdStr = clientIDTextfield.getText().trim();
	    			String dateStr = dateTimeTextfield.getText().trim();
	    			String idStr = merchantTerminalIdTextfield.getText().trim();
	    			String requestedPayload = clientIdStr + dateStr + idStr;
	    			
	    			String hmacPayloadStr = AESGCMUtil.computeHMAC(requestedPayload, KeyPanel.hmacSecretText.getText().trim(), KeyPanel.hmacAlgoText.getText().trim()); 
	    					System.out.println("PLAIN Payload : " + hmacPayloadStr);
	    			hmacPayloadText.setText(" ");
	    			hmacPayloadText.setText( hmacPayloadStr	);  
	    			hmacPayloadText.select(0, 1);
	    		}catch(Exception exe) {System.out.println(exe.getMessage()); hmacPayloadText.setText("HMAC Text not Valid");}
	        }  
	    });
	
	}
	
	
	private void createHMACJpanel( ) {
		JPanel hmacPanel = new JPanel(null);
	    hmacPanel.setBounds(10,280,1000,190);
	    hmacPanel.setBackground(Color.ORANGE);
	    hmacPanel.setBorder(BorderFactory.createLineBorder(Color.black));
	    hmacPanel.setVisible(true);
	    this.add(hmacPanel);
	    
	    hmacPayloadText = new JTextArea(" ");
	    hmacPayloadText.setLineWrap(true);
//	    hmacPayloadText.setBounds(10, 10, 400, 150);
	    JScrollPane scrollableHmacPayloadText = new JScrollPane(hmacPayloadText, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);  
	    scrollableHmacPayloadText.setBounds(10, 10, 600, 150);
	    hmacPanel.add(scrollableHmacPayloadText);
	    
	    JLabel hmacPayloadLabel = new JLabel("HMAC PAYLOAD"); 
	    hmacPayloadLabel.setBounds(300, 160, 150, 20);
	    hmacPanel.add(hmacPayloadLabel);
	    
	    hmacValueCheckBox = new JCheckBox("Copy HMAC");
	    hmacValueCheckBox.setBounds(500, 160, 400, 20);  hmacPanel.add(hmacValueCheckBox);
	    hmacValueCheckBox.setBackground(hmacPanel.getBackground());
	    hmacValueCheckBox.addItemListener(new ItemListener() {    
	        public void itemStateChanged(ItemEvent e) {  
	        	if(e.getStateChange() == 1 ) {
	        		hmacPayloadText.selectAll();
	        		hmacPayloadText.copy();
	        		
	        		dateTimeCheckBox.setSelected(false);
	        		merchantTerminalCheckBox.setSelected(false);
	        	} 
	        }    
	     }); 
	}
}
