package ae.network.dob.adapter.ksa.common;

public class DateFormatUtils {

    private DateFormatUtils(){}

    public static final String FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
}
