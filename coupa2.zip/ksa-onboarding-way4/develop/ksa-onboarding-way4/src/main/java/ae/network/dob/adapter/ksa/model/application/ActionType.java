package ae.network.dob.adapter.ksa.model.application;

public enum ActionType {
    Add, Update, AddOrUpdate, CLOSURE
}