package ae.network.dob.adapter.ksa.model.application;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.List;

import static ae.network.dob.adapter.ksa.common.TextUtils.escapeXML;
import static ae.network.dob.adapter.ksa.common.TextUtils.truncate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {

    public static final int ADDRESS_LINE_LEN = 40;

    @NotNull
    private AddressType addressType;
    private String countryCode;
    private String state;
    @NotEmpty
    private String city;
    private String postalCode;
    @NotEmpty
    private String mobile;
    @NotEmpty
    private String email;
    private String fax;
    @NotEmpty
    private String workPhone;
    @NotEmpty
    private String addressLine1;
    @NotEmpty
    private String addressLine2;
    @NotEmpty
    private String addressLine3;

    /**
     * TODO quick workaround requested, 40 should be used instead and truncation is deleted
     */
    private List<@Size(max = 100) String> addressLines;


    public List<String> getAddressLines() {
        if (addressLines == null) {
            return Collections.emptyList();
        }
        return addressLines.stream().map(this::sanitize).toList();
    }

    private String sanitize(String str) {
        return escapeXML(truncate(str, ADDRESS_LINE_LEN));
    }
}
