package ae.network.dob.adapter.ksa.model.amendment;

// TODO Delete if the final version does not include chain, device or amendment
public enum AmendmentType {
    MERCHANT_NAME,
    LEGAL_NAME,
    LINKED_CHAIN,
    MCC,
    SCHEMES_OVERRIDING,
    ADDRESS,
    ACCEPTED_CARDS,
    FEES,
    SERVICES,
    CLOSURE,
    HOLD,
    RELEASE,
    ADDING_TERMINALS,
    IBAN,
    TERMINAL_CLOSURE,
    TERMINAL_REACTIVATING,
    MERCHANT_REACTIVATING,
    SETTLEMENT,
    FLEXI_CUT_OFF,
    LIABILITY,
    DISABLE_SCHEME,
    TERMINAL_ADDRESS,
    TERMINAL_DCC,
    TERMINAL_ACCEPTED_CARDS
}
