package ae.network.dob.adapter.ksa.model.application;

public enum AddressType {
    DEFAULT, PAYM_ADDR, CORRESPONDING, TRADING, STMT_ADDR, OWS_PS
}
