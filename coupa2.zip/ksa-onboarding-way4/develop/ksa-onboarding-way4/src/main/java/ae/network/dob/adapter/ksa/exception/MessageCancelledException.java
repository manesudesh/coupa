package ae.network.dob.adapter.ksa.exception;

public class MessageCancelledException extends MessageRejectionException {
    public MessageCancelledException(String applicationId) {
        super(applicationId, "No processing required");
    }
}
