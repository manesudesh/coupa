package ae.network.dob.adapter.ksa.config;

import ae.network.dob.adapter.ksa.service.ksaresponse.ResponseFileTransformer;
import ae.network.dob.adapter.ksa.service.ksaresponse.ResponseHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.channel.PublishSubscribeChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.core.GenericSelector;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.Pollers;
import org.springframework.integration.file.FileReadingMessageSource;
import org.springframework.integration.file.FileWritingMessageHandler;
import org.springframework.integration.file.support.FileExistsMode;
import org.springframework.integration.file.transformer.FileToStringTransformer;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.MessagingException;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.concurrent.TimeUnit;

import static java.nio.file.Files.*;

@Configuration
@EnableIntegration
@Slf4j
public class ResponseFilesIntegrationConfig {

    private final KsaFolderConfig folderConfig;

    private final ResponseFileTransformer responseFileTransformer;

    private final ResponseHandler responseHandler;

    private final PublishSubscribeChannel errorChannel;

    public ResponseFilesIntegrationConfig(KsaFolderConfig folderConfig,
                                          ResponseFileTransformer responseFileTransformer,
                                          ResponseHandler responseHandler,
                                          @Qualifier("errorChannel") PublishSubscribeChannel errorChannel) {
        this.folderConfig = folderConfig;
        this.responseFileTransformer = responseFileTransformer;
        this.responseHandler = responseHandler;
        this.errorChannel = errorChannel;
    }

    @Bean
    public IntegrationFlow acceptanceResponseFileFlow() {
        return IntegrationFlow.from(rxSourceDirectory(),
                        configurer -> configurer.poller(Pollers.fixedDelay(20, TimeUnit.MILLISECONDS)))
                .filter(onlyApprovalResponseFiles())
                .handle(archDirectory())
                .transform(new FileToStringTransformer())
                .transform(responseFileTransformer, "transformResponseFile")
                .handle(responseHandler, "handleAcceptanceResponseFile")
                .get();
    }

    @Bean
    public IntegrationFlow postingResponseFileFlow() {
        return IntegrationFlow.from(rbSourceDirectory(),
                        configurer -> configurer.poller(Pollers.fixedDelay(20, TimeUnit.SECONDS)))
                .filter(onlyPostingResponseFiles())
                .handle(archDirectory())
                .transform(new FileToStringTransformer())
                .transform(responseFileTransformer, "transformResponseFile")
                .handle(responseHandler, "handlePostingResponseFile")
                .get();
    }

    @Bean
    public IntegrationFlow errorHandlingFlow() {
        return IntegrationFlow.from(errorChannel)
                .wireTap(f -> f.handle(t ->
                        log.error("Error Occurred while processing a Response file {}",
                                ((MessagingException) t.getPayload()).getFailedMessage()
                                        .getPayload())))
                .handle(message -> moveFileToErrorLocation(
                                ((MessagingException) message.getPayload()).getFailedMessage()
                                        .getHeaders()
                                        .get("file_name")
                                        .toString()))
                .get();
    }

    public void moveFileToErrorLocation(String fileName) {

        log.info("moving File {} to the error location", folderConfig.getOut().concat(fileName));

        Path sourcePath = Paths.get(folderConfig.getOut().concat(fileName));
        Path destinationPath = Paths.get(folderConfig.getError().concat(fileName));

        try {

            if (!exists(Paths.get(folderConfig.getError()))) {
                log.info("Error directory does not exist, creating it.");
                createDirectory(Paths.get(folderConfig.getError()));
            }

            move(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);

        } catch (IOException e) {
            log.error("Can not move the file {} to the ERROR path",
                    folderConfig.getOut().concat(fileName),
                    e);
        }
    }

    public GenericSelector<File> onlyApprovalResponseFiles() {
        return new GenericSelector<File>() {
            @Override
            public boolean accept(File source) {
                return source.getName().startsWith("RX");
            }
        };
    }

    public GenericSelector<File> onlyPostingResponseFiles() {
        return new GenericSelector<File>() {
            @Override
            public boolean accept(File source) {
                return source.getName().startsWith("RB");
            }
        };
    }


    public MessageSource<File> rxSourceDirectory() {
        FileReadingMessageSource messageSource = new FileReadingMessageSource();
        messageSource.setDirectory(new File(folderConfig.getOut()));
        messageSource.setAutoCreateDirectory(true);
        messageSource.setWatchEvents(FileReadingMessageSource.WatchEventType.CREATE,
                FileReadingMessageSource.WatchEventType.MODIFY);
        return messageSource;
    }

    public MessageSource<File> rbSourceDirectory() {
        FileReadingMessageSource messageSource = new FileReadingMessageSource();
        messageSource.setDirectory(new File(folderConfig.getOut()));
        messageSource.setAutoCreateDirectory(true);
        messageSource.setWatchEvents(FileReadingMessageSource.WatchEventType.CREATE,
                FileReadingMessageSource.WatchEventType.MODIFY);
        return messageSource;
    }


    public MessageHandler archDirectory() {
        FileWritingMessageHandler handler = new FileWritingMessageHandler(new File(folderConfig.getArch()));
        handler.setFileExistsMode(FileExistsMode.REPLACE_IF_MODIFIED);
        handler.setAutoCreateDirectory(true);
        return handler;
    }
}