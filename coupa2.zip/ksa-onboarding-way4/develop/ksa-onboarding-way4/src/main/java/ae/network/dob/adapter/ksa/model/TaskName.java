package ae.network.dob.adapter.ksa.model;

public enum TaskName {
    VALIDATION,
    MERCHANT_ACCEPTED_BY_KSA,
    MERCHANT_POSTED_TO_KSA,
//    DEVICE_ACCEPTED_BY_KSA,
//    DEVICE_POSTED_TO_KSA,
//    AMENDMENT_ACCEPTED_BY_KSA,
//    AMENDMENT_POSTED_TO_KSA
}
