package ae.network.dob.adapter.ksa.config;

import ae.network.dob.adapter.ksa.model.errors.AdapterError;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
@Data
@ConfigurationProperties("error-messages")
public class ErrorMessageConfig {
    private List<AdapterError> messages = new ArrayList<>();
}
