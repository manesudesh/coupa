package ae.network.dob.adapter.ksa.exception;

public class AcquirerDoesNotExistException extends MessageRejectionException {
    public AcquirerDoesNotExistException(String acquirerName) {
        super(acquirerName,
              "Acquirer :".concat(acquirerName)
                      .concat(" Dose Not Exist in Ksa Adapter configurations"));
    }
}
