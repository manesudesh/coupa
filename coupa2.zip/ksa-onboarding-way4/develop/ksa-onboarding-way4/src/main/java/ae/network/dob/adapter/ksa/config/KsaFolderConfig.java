package ae.network.dob.adapter.ksa.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "ksa.folder.location")
public class KsaFolderConfig {
    private String in;
    private String out;
    private String arch;
    private String error;
    private String temp;
}
