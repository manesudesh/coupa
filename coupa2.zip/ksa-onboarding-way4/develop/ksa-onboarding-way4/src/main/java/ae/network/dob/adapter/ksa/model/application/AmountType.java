package ae.network.dob.adapter.ksa.model.application;

public enum AmountType {
    ABSOLUTE_VALUE, PERCENTAGE
}
