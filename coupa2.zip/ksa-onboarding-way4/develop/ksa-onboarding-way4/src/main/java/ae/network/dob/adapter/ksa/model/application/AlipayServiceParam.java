package ae.network.dob.adapter.ksa.model.application;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AlipayServiceParam extends MerchantService{
}
