package ae.network.dob.adapter.ksa.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@Builder
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "ksa_way4_fileNumberCount")
public class FileNumberCount extends AbstractAuditingEntity {
    @Id
    private String id;
    private long latestNumber;
}
