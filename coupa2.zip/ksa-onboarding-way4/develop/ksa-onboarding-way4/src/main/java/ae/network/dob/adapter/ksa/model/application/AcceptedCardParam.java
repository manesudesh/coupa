package ae.network.dob.adapter.ksa.model.application;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AcceptedCardParam {
    @NotNull
    @NotEmpty
    private String cardScheme;
    private String visaFeeBase;
    private String visaFeePcnt;
    private String masterCardFeeBase;
    private String masterCardFeePcnt;
    private String madaFeeMax;
    private String madaFeePcnt;
    @NotEmpty
    private List<AcceptedCardMode> acceptedCardModes;
}
