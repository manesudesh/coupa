package ae.network.dob.adapter.ksa;

import com.github.cloudyrock.spring.v5.EnableMongock;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.config.EnableMongoAuditing;

@EnableEncryptableProperties
@EnableMongoAuditing
@SpringBootApplication
@EnableMongock
public class OnboardingKsaApplication {

    public static void main(String[] args) {
        SpringApplication.run(OnboardingKsaApplication.class, args);
    }

}
