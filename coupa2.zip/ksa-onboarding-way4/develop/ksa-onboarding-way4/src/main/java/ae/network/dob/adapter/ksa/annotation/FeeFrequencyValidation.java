package ae.network.dob.adapter.ksa.annotation;

import ae.network.dob.adapter.ksa.validate.FeeValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

// TODO Leave in case FeeFrequencyValidation validation is needed
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = FeeValidator.class)
public @interface FeeFrequencyValidation {
    String message() default "reOccurrenceFrequency can not be null.";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
