package ae.network.dob.adapter.ksa.model.application;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AcceptedCardMode {
    @NotNull
    private CardModeName modeName;
    @NotNull
    private String tariffCodeExt;
    @NotNull
    private String feePercent;
    private String feeBaseAmount;
    private String feeMaxAmount;
}
