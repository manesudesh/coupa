package ae.network.dob.adapter.ksa.model.acquirer;

import ae.network.dob.adapter.ksa.model.AbstractAuditingEntity;
import ae.network.dob.adapter.ksa.model.request.Acquirer;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@Builder
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@Document("ksa_acquirerConfig")
public class AcquirerConfig extends AbstractAuditingEntity {
    @Id
    private String id;
    private Acquirer acquirer;
    private String orgId;
    private String name;
    private boolean complexTariffStructure;
    private String alipayPID;
}
