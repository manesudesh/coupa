package ae.network.dob.adapter.ksa.exception;

public class ApplicationDoesNotExistException extends MessageRejectionException {
    public ApplicationDoesNotExistException(String applicationId) {
        super(applicationId,
              "Application :".concat(applicationId)
                      .concat(" Dose Not Exist in Ksa Adapter configurations"));
    }
}