package ae.network.dob.adapter.ksa.model;

public enum FileType {
    MERCHANT,
    DEVICE,
    AMENDMENT
}
