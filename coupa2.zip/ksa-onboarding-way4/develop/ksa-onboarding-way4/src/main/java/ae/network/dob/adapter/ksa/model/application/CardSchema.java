package ae.network.dob.adapter.ksa.model.application;

public enum CardSchema {
    VISA,
    MC,
    PL, // Private Label
    JCB,
    MADA,
    CUP, // China Union Pay
    MER, // Mercury
    QPR, // MER Premium
    DCI, // Diners Club International
    AMEX,
    MIR,
    RUPAY,

    TBOD, // Departments
    TBOC,
    DODB,
    DOCR,
    DOHY,
    SBOC,
    SBOD,
    DOPR,
    ACQ_BKOC,
    ACQ_BKOD,
    ACQ_OTIC,
    ACQ_OTID,
    ACQ_DOCR,
    ACQ_DODB,
    TBHY,
    MISC // Income fees of acquirer


}
