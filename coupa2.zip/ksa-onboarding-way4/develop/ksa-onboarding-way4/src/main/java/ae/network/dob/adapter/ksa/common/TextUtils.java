package ae.network.dob.adapter.ksa.common;

import java.text.DecimalFormat;

import static org.apache.commons.text.StringEscapeUtils.escapeXml10;

public class TextUtils {

    private TextUtils(){}

    public static String truncate(String str, int maxLen) {
        if (str == null) {
            return null;
        }
        int maxLength = Math.min(str.length(), maxLen);
        return str.substring(0, maxLength);
    }

    public static String toAlphaNumeric(String str) {
        if (str == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (char c : str.toCharArray()) {
            if (Character.isDigit(c) || Character.isLetter(c) || Character.isSpaceChar(c)) {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static String formatMcc(Integer mcc) {
        if (mcc == null) return null;
        return new DecimalFormat("0000").format(mcc);
    }

    public static String escapeXML(String str) {
        return str == null ? null : escapeXml10(str);
    }
}
