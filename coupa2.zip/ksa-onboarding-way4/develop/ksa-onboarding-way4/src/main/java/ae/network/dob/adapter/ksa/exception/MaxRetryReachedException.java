package ae.network.dob.adapter.ksa.exception;

public class MaxRetryReachedException extends MessageRejectionException {
    public MaxRetryReachedException(String applicationId) {
        super(applicationId, "Maximum retries reached");
    }
}
