package ae.network.dob.adapter.ksa.model.application;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

/**
 * Client Can provide full high level name in the json and it will converted automatically to the
 * tech value used in the backend systems.
 *
 */
public enum CardModeName {
    ELEC, MANL, PREM, INT, DOM;


    private static final Map<String, CardModeName> namesMap = new HashMap<>(5);

    static {
        namesMap.put("ELECTRONIC", ELEC);
        namesMap.put("MANUAL", MANL);
        namesMap.put("DOMESTIC", DOM);
        namesMap.put("INTERNATIONAL", INT);
        namesMap.put("PREMIUM", PREM);
    }

    @JsonCreator
    public static CardModeName forValue(String value) {
        return namesMap.get(value);
    }

    @JsonValue
    public String toValue() {
        return namesMap.entrySet().stream().filter(entry -> entry.getValue() == this).findFirst().get().getKey();
    }
}
