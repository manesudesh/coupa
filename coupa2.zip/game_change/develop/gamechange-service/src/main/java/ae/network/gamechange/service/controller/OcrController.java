package ae.network.gamechange.service.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import ae.network.gamechange.service.controller.mapper.GamechangeRequestMapper;
import ae.network.gamechange.service.database.gamechange_request.BankLetter;
import ae.network.gamechange.service.database.gamechange_request.BankStatement;
import ae.network.gamechange.service.database.gamechange_request.GamechangeRequest;
import ae.network.gamechange.service.rest.api.OcrApi;
import ae.network.gamechange.service.rest.api.dto.FileData;
import ae.network.gamechange.service.rest.api.dto.GamechangeResponse;
import ae.network.gamechange.service.service.BankLetterService;
import ae.network.gamechange.service.service.BankStatementService;
import ae.network.gamechange.service.service.EidService;
import ae.network.gamechange.service.service.PassportService;
import ae.network.gamechange.service.service.TradeLicenseService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/ocr")
public class OcrController extends OcrApi {

    private final EidService eidService;
    private final TradeLicenseService tradeLicenseService;
    private final PassportService passportService;
    private final BankLetterService bankLetterService;
    private final BankStatementService bankStatementService;
    private final GamechangeRequestMapper gamechangeRequestMapper;

    @Override
    @PostMapping("/eid")
    public ResponseEntity<GamechangeResponse> extractEidWithHttpInfo(@RequestBody FileData fileData) {
        var extractPassportRequest = eidService.extractEid(fileData);

        return ResponseEntity.ok(gamechangeRequestMapper.map(extractPassportRequest));
    }

    @Override
    @PostMapping("/passport")
    public ResponseEntity<GamechangeResponse> extractPassportWithHttpInfo(@RequestBody FileData fileData) {
        var extractPassportRequest = passportService.extractPassport(fileData);

        return ResponseEntity.ok(gamechangeRequestMapper.map(extractPassportRequest));
    }

    @PostMapping("/eid/file")
    public ResponseEntity<GamechangeRequest> extractEid(@RequestParam("file") MultipartFile uploadedFile) {
        var file = convertMultipartFileToFile(uploadedFile);
        var eidRequest = eidService.extractEid(file);

        return ResponseEntity.ok(eidRequest);
    }

    @PostMapping("/trade-license/file")
    public ResponseEntity<String> extractTradeLicense(@RequestParam("file") MultipartFile uploadedFile) {
        if (uploadedFile.isEmpty()) {
            return new ResponseEntity<>("`file` parameter need to be uploaded", HttpStatus.BAD_REQUEST);
        }

        var file = convertMultipartFileToFile(uploadedFile);
        var tradeLicenseData = tradeLicenseService.extractTradeLicense(file);

        return ResponseEntity.ok(tradeLicenseData.toString());
    }
    
    @PostMapping("/bankletter")
    public ResponseEntity<GamechangeResponse> extractBankLetterWithHttpInfo(@RequestBody FileData fileData) {
        var extractBankLetterRequest = bankLetterService.extractBankLetter(fileData);

        return ResponseEntity.ok(gamechangeRequestMapper.map(extractBankLetterRequest));
    }
    
    @PostMapping("/bankletter/file")
    public ResponseEntity<GamechangeRequest> extractBankLetter(@RequestParam("file") MultipartFile uploadedFile) {
    	if (uploadedFile.isEmpty()) {
            return  ResponseEntity.badRequest().body(GamechangeRequest.builder().errorMessage("`file` parameter need to be uploaded").build());
        }

        var file = convertMultipartFileToFile(uploadedFile);
        var bankLetterData = bankLetterService.extractBankLetter(file);

        return ResponseEntity.ok(bankLetterData);
    }

    @PostMapping("/bankstatement")
    public ResponseEntity<GamechangeResponse> extractBankStatementWithHttpInfo(@RequestBody FileData fileData) {
        var extractBankStatementRequest = bankStatementService.extractBankStatement(fileData);

        return ResponseEntity.ok(gamechangeRequestMapper.map(extractBankStatementRequest));
    }
    
    @PostMapping("/bankstatement/file")
    public ResponseEntity<GamechangeRequest> extractBankStatement(@RequestParam("file") MultipartFile uploadedFile) {
        if (uploadedFile.isEmpty()) {
            return  ResponseEntity.badRequest().body(GamechangeRequest.builder().errorMessage("`file` parameter need to be uploaded").build());
        }

        var file = convertMultipartFileToFile(uploadedFile);
        var bankStatementData = bankStatementService.extractBankStatement(file);

        return ResponseEntity.ok(bankStatementData);
    }
    
    private File convertMultipartFileToFile(MultipartFile multipartFile) {
        File file = new File(multipartFile.getOriginalFilename());
        try {
            multipartFile.transferTo(file);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return file;
    }
}
