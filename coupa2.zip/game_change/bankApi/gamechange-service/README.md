# About: GameChange API Service

- [Technical Documentation](https://networkinternational.atlassian.net/wiki/spaces/NAACE/pages/3022061674/Gamechange+Service+Technical+Documentation)
- [Local DOB environment setup](https://networkinternational.atlassian.net/wiki/spaces/NAACE/pages/2666692975/Local+DOB+environment+run)

## Install

### TL;DR: do `mvn clean compile`

* FYI `./mvnw clean compile` will create the missing classes.
* FYI in some cases you'll need to mark the generated sources as `source folder` in your IDE. Those are:
  `/target/generated-sources/openapi/src/main/java` and `/target/generated-sources/annotations`
