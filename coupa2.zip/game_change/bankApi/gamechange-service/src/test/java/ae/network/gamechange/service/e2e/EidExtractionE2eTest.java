package ae.network.gamechange.service.e2e;

import ae.network.gamechange.service.test.helper.AssertHelper;
import ae.network.gamechange.service.test.mock.RestServiceMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ActiveProfiles("test")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class EidExtractionE2eTest {

    @Autowired
    @Qualifier("gamechangeAuthRestTemplate")
    private RestTemplate gamechangeAuthRestTemplate;

    @Autowired
    @Qualifier("gamechangeOcrRestTemplate")
    private RestTemplate gamechangeOcrRestTemplate;

    @Autowired
    private TestRestTemplate testRestTemplate;

    private RestServiceMock gamechangeAuthRestServiceMock;
    private RestServiceMock gamechangeOcrRestServiceMock;

    @BeforeEach
    public void init() {
        gamechangeAuthRestServiceMock = new RestServiceMock(gamechangeAuthRestTemplate);
        gamechangeOcrRestServiceMock = new RestServiceMock(gamechangeOcrRestTemplate);
    }

    @Test
    public void testEidExtraction() {
        // given
        gamechangeAuthRestServiceMock.mockGamechangeAuthorization();
        gamechangeOcrRestServiceMock.addMockResponse("ae/network/gamechange/service/e2e/eid_extraction/gamechange_extract_eid_response.json");

        // when
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        var entity = new HttpEntity<>("{\"fileLink\": \"passport-file-link-url.example.com\"}", headers);
        var actualResponse = testRestTemplate.exchange("/ocr/eid", HttpMethod.POST, entity, String.class);

        // then
        AssertHelper.assertAsJsons("ae/network/gamechange/service/e2e/eid_extraction/expected_eid_response.json", actualResponse.getBody());

        // assert ocr request
        var requests = gamechangeOcrRestServiceMock.getActualRestRequests();
        assertEquals(1, requests.size());
        var request = requests.get(0);
        assertEquals("https://gamechange.example.com/api/eida/extract", request.getURI().toString());
        var body = gamechangeOcrRestServiceMock.getActualRequestBody(0);
        assertTrue(body.contains("Dummy PDF download"));

        var contentType = request.getHeaders().getContentType();
        assertEquals("multipart", contentType.getType());
        assertEquals("form-data", contentType.getSubtype());

        assertEquals(HttpMethod.POST, request.getMethod());
    }
}
