package ae.network.gamechange.service.test.helper;

import org.json.JSONException;
import org.skyscreamer.jsonassert.Customization;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.comparator.CustomComparator;
import org.skyscreamer.jsonassert.comparator.JSONComparator;

import java.util.Arrays;

/**
 * Assertions for tests.
 */
public class AssertHelper {

    /**
     * Converts expected and actual to json and compares as JSON.
     *
     * @param expected       path to file, json or object with expected values
     * @param actual         path to file, json or object with actual values
     * @param fieldsToIgnore (optional) fields to ignore in assertion. E.g. 'jsonobject1.jsonobject2.fieldToIgnore'
     */
    public static void assertAsJsons(Object expected, Object actual, String... fieldsToIgnore) {
        if (expected == null || actual == null) {
            throw new AssertionError(String.format("ExpectedIsNull=%s, ActualIsNull=%s, FieldsToIgnore=%s",
                    expected == null, actual == null, Arrays.toString(fieldsToIgnore)));
        }

        try {
            assertJsons(JsonHelper.getJson(expected), JsonHelper.getJson(actual), fieldsToIgnore);
        } catch (Exception e) {
            throw new RuntimeException("Exception during assertAsJsons", e);
        }
    }

    public static void assertJsons(String expected, String actual, String... fieldsToIgnore) {
        try {
            JSONAssert.assertEquals(expected, actual,
                    buildIgnoringComparator(fieldsToIgnore));
        } catch (JSONException e) {
            System.out.println(e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private static JSONComparator buildIgnoringComparator(String... fieldsToIgnore) {

        return new CustomComparator(JSONCompareMode.LENIENT,
                Arrays.stream(fieldsToIgnore)
                        .map(field -> new Customization(field, (o1, o2) -> true)).toArray(Customization[]::new));
    }

}
