package ae.network.gamechange.service.test.helper;

import org.springframework.core.io.ClassPathResource;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

/**
 * Helps to work with test resources.
 */
public class FileHelper {

    /**
     * Reads test resource from classpath.
     * Only the files available in the classpath can be read.
     *
     * @param stringPath path to file e.g. "tools/any/workflow/input/expected_input.json"
     * @return content of the file
     * @throws RuntimeException if file not found or any other error occurred
     */
    public static String readTestResource(final String stringPath) {
        try {
            var testResource = getTestResource(stringPath);
            return String.join("\n", Files.readAllLines(testResource.toPath())); // lines separated by \n
        } catch (final IOException e) {
            throw new RuntimeException("Path is " + stringPath, e);
        }
    }

    /**
     * Reads test resource from classpath.
     * Only the files available in the classpath can be read.
     *
     * @param stringPath path to file e.g. "tools/any/workflow/input/expected_input.json"
     * @return content of the file
     * @throws RuntimeException if file not found or any other error occurred
     */
    public static File getTestResource(final String stringPath) {
        try {
            return new ClassPathResource(stringPath).getFile();
        } catch (final IOException e) {
            throw new RuntimeException("Path is " + stringPath, e);
        }
    }


}
