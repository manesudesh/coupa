package ae.network.gamechange.service.rest.gamechange;

import ae.network.gamechange.service.test.mock.RestServiceMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ActiveProfiles("test")
@SpringBootTest
public class AuthorizationIntegrationTest {

    @Autowired
    @Qualifier("gamechangeAuthRestTemplate")
    private RestTemplate gamechangeAuthRestTemplate;

    @Autowired
    @Qualifier("gamechangeOcrRestTemplate")
    private RestTemplate gamechangeOcrRestTemplate;

    @Autowired
    private AuthorizationRestService authorizationRestService;

    private RestServiceMock gamechangeAuthRestServiceMock;
    private RestServiceMock gamechangeOcrRestServiceMock;


    @BeforeEach
    public void init() {
        gamechangeAuthRestServiceMock = new RestServiceMock(gamechangeAuthRestTemplate);
        gamechangeOcrRestServiceMock = new RestServiceMock(gamechangeOcrRestTemplate);
    }

    @Test
    public void testRequestToken() {
        // given
        gamechangeAuthRestServiceMock.addMockResponse(
                "ae/network/gamechange/service/rest/gamechange/request_token/request_token_response.json");

        // when
        var actualToken = authorizationRestService.getAuthorizationToken();

        // then
        assertEquals("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c",
                actualToken);
        assertEquals(1, gamechangeAuthRestServiceMock.getActualRestRequests().size());
        gamechangeAuthRestServiceMock.assertActualRequest(0, "https://auth-gamechange.example.com/api/oauth2/token", "ae/network/gamechange/service/rest/gamechange/request_token/expected_request_token_request.json");
    }

    @Test
    public void testAuthorization() {
        // given
        gamechangeAuthRestServiceMock.mockGamechangeAuthorization();
        gamechangeOcrRestServiceMock.addMockResponse("{\"mock\": \"response\"}");

        // when
        gamechangeOcrRestTemplate.getForEntity("example.com", Object.class);

        // then
        var actualAuthorizationHeader = gamechangeOcrRestServiceMock.getActualRestRequests().get(0)
                .getHeaders().get(HttpHeaders.AUTHORIZATION);
        assertEquals("Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c", actualAuthorizationHeader.get(0).toString());
    }

}
