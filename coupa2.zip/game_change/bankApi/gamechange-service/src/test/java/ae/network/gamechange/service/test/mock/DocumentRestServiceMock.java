package ae.network.gamechange.service.test.mock;

import ae.network.gamechange.service.config.model.OrchestrationProperties;
import ae.network.gamechange.service.rest.api.dto.FileData;
import ae.network.gamechange.service.rest.orchestration.DocumentRestService;
import ae.network.gamechange.service.test.helper.FileHelper;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.io.File;

@Component
@Primary
public class DocumentRestServiceMock extends DocumentRestService {
    public DocumentRestServiceMock(OrchestrationProperties orchestrationProperties) {
        super(orchestrationProperties);
    }

    @Override
    public File downloadDocument(FileData fileLink) {
        return FileHelper.getTestResource("ae/network/gamechange/service/e2e/dummy-document.pdf");
    }
}
