package ae.network.gamechange.service.test.helper;

import ae.network.gamechange.service.database.gamechange_request.DateFormat;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalTimeSerializer;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;


@Component
public class JsonHelper {

    private static ObjectMapper objectMapper;

    public static ObjectMapper getObjectMapper() {
        if (objectMapper != null) {
            return objectMapper;
        }

        objectMapper = new ObjectMapper();

        JavaTimeModule javaTimeModule = new JavaTimeModule();
        javaTimeModule.addSerializer(LocalDate.class, new LocalDateSerializer(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        javaTimeModule.addSerializer(LocalDateTime.class, new LocalDateTimeSerializer(DateTimeFormatter.ofPattern(DateFormat.DATEFORMAT_NO_OFFSET)));
        javaTimeModule.addSerializer(LocalTime.class, new LocalTimeSerializer(DateTimeFormatter.ofPattern("HH:mm:ss")));
        objectMapper.registerModule(javaTimeModule);

        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_DEFAULT);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

        objectMapper.writerWithDefaultPrettyPrinter();

        // needed to disable the values from getter
        objectMapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.NONE);
        objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);

        return objectMapper;
    }

    public static String getJson(Object object) {
        String expectedJson;
        if (object instanceof String) {
            if (((String) object).endsWith(".json")) {
                expectedJson = FileHelper.readTestResource((String) object);
            } else {
                expectedJson = (String) object;
            }
        } else {
            expectedJson = writeAsJson(object);
        }

        return expectedJson;
    }

    public static <T> T readValue(String json, Class<T> clazz) {
        String jsonBody = getJson(json);

        try {
            return getObjectMapper().readValue(jsonBody, clazz);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to read JSON string into object", e);
        }
    }

    public static <T> T readValue(String json, TypeReference<T> type) {
        String jsonBody = getJson(json);

        try {
            return getObjectMapper().readValue(jsonBody, type);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to read JSON string into object", e);
        }
    }

    public static void writeJson(String filePath, Object object) {
        String json = getJson(object);

        try {
            Files.write(Paths.get(filePath), json.getBytes());
        } catch (IOException e) {
            throw new RuntimeException("Failed to write JSON to file", e);
        }
    }

    protected static String writeAsJson(Object object) {
        try {
            return getObjectMapper().writeValueAsString(object);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}
