package ae.network.gamechange.service.database.gamechange_request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.With;

import java.time.LocalDate;

@Data
@Builder
@With
@NoArgsConstructor
@AllArgsConstructor
public class Passport {

    private String passportNumber;
    private String firstName;
    private String lastName;
    private String nationality;
    private LocalDate dateOfBirth;
    private LocalDate issuedDate;
    private LocalDate expiryDate;
    private String address;
}
