package ae.network.gamechange.service.service;

import ae.network.gamechange.service.database.GamechangeRequestRepository;
import ae.network.gamechange.service.database.gamechange_request.GamechangeRequest;
import ae.network.gamechange.service.database.gamechange_request.Passport;
import ae.network.gamechange.service.database.gamechange_request.PassportOcrAttempt;
import ae.network.gamechange.service.database.gamechange_request.RequestType;
import ae.network.gamechange.service.rest.api.dto.FileData;
import ae.network.gamechange.service.rest.gamechange.PassportRestService;
import ae.network.gamechange.service.rest.gamechange.ocr.dto.PassportData;
import ae.network.gamechange.service.rest.gamechange.ocr.dto.ValueScore;
import ae.network.gamechange.service.utils.ExceptionUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
@RequiredArgsConstructor
public class PassportService {

    private final PassportRestService passportRestService;
    private final DocumentService documentService;
    private final GamechangeRequestRepository gamechangeRequestRepository;

    public GamechangeRequest extractPassport(FileData passportFileLink) {
        var passportDownloadResult = documentService.downloadDocument(passportFileLink);
        if (passportDownloadResult.error() != null) {
            var result = GamechangeRequest.builder()
                    .requestType(RequestType.PASSPORT_OCR)
                    .passportOcrAttempt(
                            PassportOcrAttempt.builder().fileData(passportFileLink).build())
                    .requestId(UUID.randomUUID().toString())
                    .success(false)
                    .errorMessage(passportDownloadResult.error()).build();
            gamechangeRequestRepository.save(result);
            return result;
        }

        var passportDocument = passportDownloadResult.file();

        var result = extractPassport(passportDocument);
        result.getPassportOcrAttempt().setFileData(passportFileLink);

        log.info("EID recognize attempt. PassportFileLink={}, success={}, attempt={}",
                passportFileLink, result.isSuccess(), result);
        gamechangeRequestRepository.save(result);

        return result;
    }

    public GamechangeRequest extractPassport(File passportPicture) {
        var resultBuilder = GamechangeRequest.builder()
                .requestType(RequestType.PASSPORT_OCR)
                .requestId(UUID.randomUUID().toString())
                .passportOcrAttempt(PassportOcrAttempt.builder().build());

        PassportData passportData;
        try {
            passportData = passportRestService.getPassport(passportPicture);
        } catch (Exception e) {
            var error = ExceptionUtils.buildErrorMessage("extract passport at gamechange", e);
            return resultBuilder.success(false).errorMessage(error).build();
        }

        if (passportData == null) {
            return resultBuilder.success(false).errorMessage("enpty passport data").build();
        }

        var passport = parsePassportData(passportData);
        var passportIdRecognized = passport.getPassportNumber() != null;
        resultBuilder.success(passportIdRecognized);
        resultBuilder
                .passportOcrAttempt(PassportOcrAttempt.builder().passportDataResponse(passportData).build())
                .passport(passport);

        return resultBuilder.build();
    }

    private Passport parsePassportData(PassportData passportData) {
        var resultBuilder = Passport.builder();
        if (passportData == null) {
            return resultBuilder.build();
        }

        Optional.ofNullable(passportData.getPassportNumber()).map(ValueScore::getValue).ifPresent(resultBuilder::passportNumber);
        Optional.ofNullable(passportData.getFirstName()).map(ValueScore::getValue).ifPresent(resultBuilder::firstName);
        Optional.ofNullable(passportData.getLastName()).map(ValueScore::getValue).ifPresent(resultBuilder::lastName);
        Optional.ofNullable(passportData.getNationality()).map(ValueScore::getValue).ifPresent(resultBuilder::nationality);
        Optional.ofNullable(passportData.getIssueDate()).map(ValueScore::getValue).map(LocalDate::parse).ifPresent(resultBuilder::issuedDate);
        Optional.ofNullable(passportData.getMrzData()).ifPresent(mrzData -> {
            Optional.ofNullable(mrzData.getDateOfBirth()).map(ValueScore::getValue).map(LocalDate::parse).ifPresent(resultBuilder::dateOfBirth);
            Optional.ofNullable(mrzData.getExpiryDate()).map(ValueScore::getValue).map(LocalDate::parse).ifPresent(resultBuilder::expiryDate);
            Optional.ofNullable(mrzData.getNationality()).map(ValueScore::getValue).ifPresent(resultBuilder::nationality);
            Optional.ofNullable(mrzData.getPassportNumber()).map(ValueScore::getValue).ifPresent(resultBuilder::passportNumber);
            Optional.ofNullable(mrzData.getFirstName()).map(ValueScore::getValue).ifPresent(resultBuilder::firstName);
        });

        return resultBuilder.build();
    }
}
