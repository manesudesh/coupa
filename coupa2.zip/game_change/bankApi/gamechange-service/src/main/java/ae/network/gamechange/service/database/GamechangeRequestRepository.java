package ae.network.gamechange.service.database;

import ae.network.gamechange.service.database.gamechange_request.GamechangeRequest;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GamechangeRequestRepository extends MongoRepository<GamechangeRequest, String> {
}
