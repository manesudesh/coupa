package ae.network.gamechange.service.service;

import ae.network.gamechange.service.rest.gamechange.TradeLicenseRestService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class TradeLicenseService {

    private final TradeLicenseRestService tradeLicenseRestService;

    public Optional<String> extractTradeLicense(File tradeLicensePicture) {
        String tradeLicense;
        try {
            var tradeLicenseData = tradeLicenseRestService.extractTradeLicense(tradeLicensePicture);
            tradeLicense = tradeLicenseData.getLicenseNumber() != null
                    ? tradeLicenseData.getLicenseNumber().getValue()
                    : null;
        } catch (Exception e) {
            log.error("Error extracting trade license", e);
            return Optional.empty();
        }

        return Optional.ofNullable(tradeLicense);
    }

}
