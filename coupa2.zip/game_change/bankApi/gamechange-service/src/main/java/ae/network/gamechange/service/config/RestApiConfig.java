package ae.network.gamechange.service.config;

import ae.network.gamechange.service.rest.api.service.ApiClient;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
@RequiredArgsConstructor
public class RestApiConfig {

    @Primary
    @Bean("ae.network.gamechange.service.rest.api.service.ApiClient")
    public ApiClient mockApiClient() {
        return new ApiClient();
    }
}
