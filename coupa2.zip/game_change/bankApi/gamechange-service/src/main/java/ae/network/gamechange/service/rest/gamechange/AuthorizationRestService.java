package ae.network.gamechange.service.rest.gamechange;

import ae.network.gamechange.service.config.model.GamechangeProperties;
import ae.network.gamechange.service.rest.gamechange.auth.AuthApi;
import ae.network.gamechange.service.rest.gamechange.auth.dto.OAuth2TokenRequest;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
@Slf4j
@RequiredArgsConstructor
public class AuthorizationRestService implements ClientHttpRequestInterceptor {

    public static AuthorizationRestService INSTANCE;

    private final GamechangeProperties gamechangeProperties;
    private final AuthApi authApi;

    @PostConstruct
    public void init() {
        INSTANCE = this;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
        var url = request.getURI().toString();
        boolean authenticationNotNeeded = url.contains("/api/health/ready");

        if (authenticationNotNeeded) {
            return execution.execute(request, body);
        }

        request.getHeaders().set(HttpHeaders.AUTHORIZATION, "Bearer " + getAuthorizationToken());
        return execution.execute(request, body);

    }

    public String getAuthorizationToken() {
        var authRequest = new OAuth2TokenRequest()
                .clientId(gamechangeProperties.getAuthClientId())
                .clientSecret(gamechangeProperties.getAuthToken())
                .grantType("client_credentials");

        return authApi.getOAuth2Token(authRequest).getAccessToken();
    }

}
