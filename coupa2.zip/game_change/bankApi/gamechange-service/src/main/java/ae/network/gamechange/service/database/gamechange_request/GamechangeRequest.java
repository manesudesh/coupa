package ae.network.gamechange.service.database.gamechange_request;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.With;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Builder
@With
@NoArgsConstructor
@AllArgsConstructor
@Document("gamechange_request")
public class GamechangeRequest {

    @Id
    private String id;

    private String requestId;

    private RequestType requestType;

    private boolean success;

    /**
     * Error message, if any.
     */
    private String errorMessage;

    private Passport passport;
    
    private BankLetter bankLetter;
    
    private BankStatement bankStatement;
    
    private BankLetterOcrAttempt bankLetterOcrAttempt;
    
    private BankStatementOcrAttempt bankStatementOcrAttempt;

    private Eid eid;

    private PassportOcrAttempt passportOcrAttempt;
    private EidOcrAttempt eidOcrAttempt;
}
