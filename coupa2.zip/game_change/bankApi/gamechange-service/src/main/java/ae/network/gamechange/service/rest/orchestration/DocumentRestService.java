package ae.network.gamechange.service.rest.orchestration;

import ae.network.gamechange.service.config.model.OrchestrationProperties;
import ae.network.gamechange.service.rest.api.dto.FileData;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.util.stream.Stream;

@Slf4j
@Component
@RequiredArgsConstructor
public class DocumentRestService {

    private final String TEMP_FILE_FOLDER = "temp-files-folder";
    // remove only those existing for more than 2 minutes to not accidentally remove the file that is used in another thread
    private final Long MINIMUM_FILE_LIFETIME_MS = 1000L * 120;

    @Autowired
    @Qualifier("orchestrationRestTemplate")
    private RestTemplate orchestrationRestTemplate;
    private final OrchestrationProperties orchestrationProperties;

    @PostConstruct
    public void cleanupTemporalFolder() {
        var tempFolder = new File(TEMP_FILE_FOLDER);
        if (!tempFolder.exists()) {
            tempFolder.mkdirs();
        }

        Stream.of(tempFolder.listFiles())
                .filter(this::canBeRemoved)
                .forEach(File::delete);
    }

    public File downloadDocument(FileData fileLink) {
        byte[] fileContent;
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(orchestrationProperties.getBaseUrl())
                .path("/files/shared/{containerName}/{fileName}")
                .queryParam("accessKey", fileLink.getAccessKey());

        URI uri = builder.buildAndExpand(fileLink.getContainerName(), fileLink.getFileName()).toUri();
        fileContent = orchestrationRestTemplate.getForEntity(uri, byte[].class)
                .getBody();

        return createFile(fileContent, fileLink.getFileName());
    }

    private boolean canBeRemoved(File file) {
        if (file == null) {
            return false;
        }

        if (!file.exists()) {
            return false;
        }

        var fileName = file.getName();
        try {
            var fileMilliseconds = Long.valueOf(file.getName().substring(0, fileName.indexOf("_")));
            return (System.currentTimeMillis() - fileMilliseconds) > MINIMUM_FILE_LIFETIME_MS;
        } catch (Exception e) {
            log.error("Cannot parse file name {}", fileName, e);
            return true;
        }
    }

    private File createFile(byte[] content, String filename) {
        if (content == null) {
            return null;
        }

        cleanupTemporalFolder();
        var tempFolder = new File(TEMP_FILE_FOLDER);
        String tempFileName = System.currentTimeMillis() + "_" + filename;
        var tempFile = tempFolder.toPath().resolve(tempFileName).toFile();
        try {
            Files.write(tempFile.toPath(), content);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return tempFile;
    }
}
