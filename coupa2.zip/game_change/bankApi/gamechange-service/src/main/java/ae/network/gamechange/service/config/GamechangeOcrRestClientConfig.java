package ae.network.gamechange.service.config;

import ae.network.gamechange.service.config.model.GamechangeProperties;
import ae.network.gamechange.service.rest.gamechange.AuthorizationRestService;
import ae.network.gamechange.service.rest.gamechange.ocr.service.ApiClient;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static ae.network.gamechange.service.database.gamechange_request.DateFormat.DATEFORMAT_NO_TIME;

@Configuration
@RequiredArgsConstructor
public class GamechangeOcrRestClientConfig {

    @Bean
    public RestTemplate gamechangeOcrRestTemplate(MappingJackson2HttpMessageConverter jsonConverter,
                                                  SimpleClientHttpRequestFactory requestFactory,
                                                  ClientHttpRequestInterceptor authorizationRequestInterceptor) {
        RestTemplate restTemplate = new RestTemplate(requestFactory);
        restTemplate.setMessageConverters(List.of(jsonConverter));
        restTemplate.getMessageConverters().add(new FormHttpMessageConverter());

        restTemplate.getInterceptors().add(authorizationRequestInterceptor);

        return restTemplate;
    }

    @Bean
    public MappingJackson2HttpMessageConverter gamechangeJackson2HttpMessageConverter(@Qualifier("gamechangeObjectMapper") ObjectMapper gamechangeObjectMapper) {
        MappingJackson2HttpMessageConverter jsonConverter = new MappingJackson2HttpMessageConverter();
        jsonConverter.setObjectMapper(gamechangeObjectMapper);
        return jsonConverter;
    }

    @Primary
    @Bean("ae.network.gamechange.service.rest.gamechange.ocr.service.ApiClient")
    public ApiClient gamechangeOcrApiClient(@Qualifier("gamechangeOcrRestTemplate") RestTemplate gamechangeOcrRestTemplate, GamechangeProperties gamechangeProperties) {
        var apiClient = new ApiClient(gamechangeOcrRestTemplate);
        apiClient = apiClient.setBasePath(gamechangeProperties.getBaseUrl());
        return apiClient;
    }

    @Bean
    public ObjectMapper gamechangeObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();

        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        JavaTimeModule javaTimeModule = new JavaTimeModule();
        javaTimeModule.addSerializer(LocalDate.class, new LocalDateSerializer(DateTimeFormatter.ofPattern(DATEFORMAT_NO_TIME)));
        objectMapper.registerModule(javaTimeModule);

        return objectMapper;
    }

    @Bean
    public SimpleClientHttpRequestFactory gamechangeRequestFactory(GamechangeProperties gamechangeProperties, @Autowired(required = false) Proxy proxy) {
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        if (proxy != null) {
            requestFactory.setProxy(proxy);
            requestFactory.setConnectTimeout(gamechangeProperties.getHttp().getConnectTimeout());
            requestFactory.setReadTimeout(gamechangeProperties.getHttp().getSocketTimeout());
        }
        return requestFactory;
    }

    @Bean
    @ConditionalOnProperty(prefix = "gamechange.http", name = "proxy-enabled", havingValue = "true")
    public Proxy buildProxy(GamechangeProperties gamechangeProperties) {
        InetSocketAddress inetSocketAddress = new InetSocketAddress(gamechangeProperties.getHttp().getProxyHost(), gamechangeProperties.getHttp().getProxyPort());
        return new Proxy(Proxy.Type.HTTP, inetSocketAddress);
    }

    @Bean
    public ClientHttpRequestInterceptor authorizationRequestInterceptor() {
        return (request, body, execution) -> AuthorizationRestService.INSTANCE.intercept(request, body, execution);
    }
}
