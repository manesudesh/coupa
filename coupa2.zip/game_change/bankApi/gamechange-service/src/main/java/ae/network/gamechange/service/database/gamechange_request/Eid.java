package ae.network.gamechange.service.database.gamechange_request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.With;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@With
public class Eid {

    private String eidNumber;
    private LocalDate expiryDate;
    private LocalDate dayOfBirth;
    private String nationality;

}
