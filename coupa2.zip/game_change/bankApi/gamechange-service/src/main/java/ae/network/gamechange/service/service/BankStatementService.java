package ae.network.gamechange.service.service;

import java.io.File;
import java.util.Optional;
import java.util.UUID;

import org.springframework.stereotype.Service;

import ae.network.gamechange.service.database.GamechangeRequestRepository;
import ae.network.gamechange.service.database.gamechange_request.BankStatement;
import ae.network.gamechange.service.database.gamechange_request.BankStatementOcrAttempt;
import ae.network.gamechange.service.database.gamechange_request.GamechangeRequest;
import ae.network.gamechange.service.database.gamechange_request.RequestType;
import ae.network.gamechange.service.rest.api.dto.FileData;
import ae.network.gamechange.service.rest.gamechange.BankStatementRestService;
import ae.network.gamechange.service.rest.gamechange.ocr.dto.BankStatementData;
import ae.network.gamechange.service.rest.gamechange.ocr.dto.ValueScore;
import ae.network.gamechange.service.utils.ExceptionUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class BankStatementService {

	private final BankStatementRestService bankStatementRestService;
    private final DocumentService documentService;
    private final GamechangeRequestRepository gamechangeRequestRepository;

    public GamechangeRequest extractBankStatement(FileData bankStatementFileLink) {
        var bankStatementDownloadResult = documentService.downloadDocument(bankStatementFileLink);
        if (bankStatementDownloadResult.error() != null) {
            var result = GamechangeRequest.builder()
                    .requestType(RequestType.BANKSTATEMENT_OCR)
                    .bankStatementOcrAttempt(
                            BankStatementOcrAttempt.builder().fileData(bankStatementFileLink).build())
                    .requestId(UUID.randomUUID().toString())
                    .success(false)
                    .errorMessage(bankStatementDownloadResult.error()).build();
            gamechangeRequestRepository.save(result);
            return result;
        }

        var bankStatementDocument = bankStatementDownloadResult.file();

        var result = extractBankStatement(bankStatementDocument);
        result.getBankStatementOcrAttempt().setFileData(bankStatementFileLink);

        log.info("BankStatement recognize attempt. BankStatementFileLink={}, success={}, attempt={}",
        		bankStatementFileLink, result.isSuccess(), result);
        gamechangeRequestRepository.save(result);

        return result;
    }

    public GamechangeRequest extractBankStatement(File bankStatementPicture) {
        var resultBuilder = GamechangeRequest.builder()
                .requestType(RequestType.BANKSTATEMENT_OCR)
                .requestId(UUID.randomUUID().toString())
                .bankStatementOcrAttempt(BankStatementOcrAttempt.builder().build());

        BankStatementData bankStatementData;
        try {
        	bankStatementData = bankStatementRestService.getBankStatement(bankStatementPicture);
        } catch (Exception e) {
            var error = ExceptionUtils.buildErrorMessage("extract bankStatement at gamechange", e);
            return resultBuilder.success(false).errorMessage(error).build();
        }

        if (bankStatementData == null) {
            return resultBuilder.success(false).errorMessage("enpty bankStatement data").build();
        }

        var bankStatement = parseBankStatementData(bankStatementData);
        var bankNameRecognized = bankStatement.getBankName() != null;
        resultBuilder.success(bankNameRecognized);
        resultBuilder
                .bankStatementOcrAttempt(BankStatementOcrAttempt.builder().bankStatementDataResponse(bankStatementData).build())
                .bankStatement(bankStatement);

        return resultBuilder.build();
    }

    private BankStatement parseBankStatementData(BankStatementData bankStatementData) {
        var resultBuilder = BankStatement.builder();
        if (bankStatementData == null) {
            return resultBuilder.build();
        }

        Optional.ofNullable(bankStatementData.getBankName()).map(ValueScore::getValue).ifPresent(resultBuilder::bankName);
        Optional.ofNullable(bankStatementData.getAccountHolderName()).map(ValueScore::getValue).ifPresent(resultBuilder::accountHolderName);
        Optional.ofNullable(bankStatementData.getAccountNumber()).map(ValueScore::getValue).ifPresent(resultBuilder::accountNumber);
        Optional.ofNullable(bankStatementData.getIban()).map(ValueScore::getValue).ifPresent(resultBuilder::iban);

        return resultBuilder.build();
    }
}
