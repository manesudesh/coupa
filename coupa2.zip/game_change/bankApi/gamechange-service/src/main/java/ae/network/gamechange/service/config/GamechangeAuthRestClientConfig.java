package ae.network.gamechange.service.config;

import ae.network.gamechange.service.config.model.GamechangeProperties;
import ae.network.gamechange.service.rest.gamechange.auth.service.ApiClient;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
@RequiredArgsConstructor
public class GamechangeAuthRestClientConfig {

    @Bean
    public RestTemplate gamechangeAuthRestTemplate(SimpleClientHttpRequestFactory requestFactory) {
        return new RestTemplate(requestFactory);
    }

    @Primary
    @Bean("ae.network.gamechange.service.rest.gamechange.auth.service.ApiClient")
    public ApiClient gamechangeAuthApiClient(@Qualifier("gamechangeAuthRestTemplate") RestTemplate gamechangeAuthRestTemplate, GamechangeProperties gamechangeProperties) {
        var apiClient = new ApiClient(gamechangeAuthRestTemplate);
        apiClient = apiClient.setBasePath(gamechangeProperties.getAuthBaseUrl());
        return apiClient;
    }
}
