package ae.network.gamechange.service.service;

import ae.network.gamechange.service.rest.api.dto.FileData;
import ae.network.gamechange.service.rest.orchestration.DocumentRestService;
import ae.network.gamechange.service.utils.ExceptionUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;

@Service
@Slf4j
@RequiredArgsConstructor
public class DocumentService {

    private final DocumentRestService documentRestService;

    public FileDownloadResult downloadDocument(FileData passportFileLink) {
        try {
            var file = documentRestService.downloadDocument(passportFileLink);
            return new FileDownloadResult(file, null);
        } catch (Exception e) {
            var error = ExceptionUtils.buildErrorMessage("downloading file " + passportFileLink, e);
            log.error("{}", error, e);
            return new FileDownloadResult(null, error);
        }
    }

    public record FileDownloadResult(File file, String error) {
    }
}
