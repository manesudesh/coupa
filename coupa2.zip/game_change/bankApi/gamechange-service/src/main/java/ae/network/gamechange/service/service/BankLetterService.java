package ae.network.gamechange.service.service;

import java.io.File;
import java.util.Optional;
import java.util.UUID;

import org.springframework.stereotype.Service;

import ae.network.gamechange.service.database.GamechangeRequestRepository;
import ae.network.gamechange.service.database.gamechange_request.BankLetter;
import ae.network.gamechange.service.database.gamechange_request.BankLetterOcrAttempt;
import ae.network.gamechange.service.database.gamechange_request.GamechangeRequest;
import ae.network.gamechange.service.database.gamechange_request.RequestType;
import ae.network.gamechange.service.rest.api.dto.FileData;
import ae.network.gamechange.service.rest.gamechange.BankLetterRestService;
import ae.network.gamechange.service.rest.gamechange.ocr.dto.BankLetterData;
import ae.network.gamechange.service.rest.gamechange.ocr.dto.ValueScore;
import ae.network.gamechange.service.utils.ExceptionUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class BankLetterService {

	private final BankLetterRestService bankLetterRestService;
    private final DocumentService documentService;
    private final GamechangeRequestRepository gamechangeRequestRepository;

    public GamechangeRequest extractBankLetter(FileData bankLetterFileLink) {
        var bankLetterDownloadResult = documentService.downloadDocument(bankLetterFileLink);
        if (bankLetterDownloadResult.error() != null) {
            var result = GamechangeRequest.builder()
                    .requestType(RequestType.BANKLETTER_OCR)
                    .bankLetterOcrAttempt(
                            BankLetterOcrAttempt.builder().fileData(bankLetterFileLink).build())
                    .requestId(UUID.randomUUID().toString())
                    .success(false)
                    .errorMessage(bankLetterDownloadResult.error()).build();
            gamechangeRequestRepository.save(result);
            return result;
        }

        var bankLetterDocument = bankLetterDownloadResult.file();

        var result = extractBankLetter(bankLetterDocument);
        result.getBankLetterOcrAttempt().setFileData(bankLetterFileLink);

        log.info("BankLetter recognize attempt. BankLetterFileLink={}, success={}, attempt={}",
        		bankLetterFileLink, result.isSuccess(), result);
        gamechangeRequestRepository.save(result);

        return result;
    }

    public GamechangeRequest extractBankLetter(File bankLetterPicture) {
        var resultBuilder = GamechangeRequest.builder()
                .requestType(RequestType.BANKLETTER_OCR)
                .requestId(UUID.randomUUID().toString())
                .bankLetterOcrAttempt(BankLetterOcrAttempt.builder().build());

        BankLetterData bankLetterData;
        try {
        	bankLetterData = bankLetterRestService.getBankLetter(bankLetterPicture);
        } catch (Exception e) {
            var error = ExceptionUtils.buildErrorMessage("extract bankLetter at gamechange", e);
            return resultBuilder.success(false).errorMessage(error).build();
        }

        if (bankLetterData == null) {
            return resultBuilder.success(false).errorMessage("enpty bankLetter data").build();
        }

        var bankLetter = parseBankLetterData(bankLetterData);
        var bankNameRecognized = bankLetter.getBankName() != null;
        resultBuilder.success(bankNameRecognized);
        resultBuilder
                .bankLetterOcrAttempt(BankLetterOcrAttempt.builder().bankLetterDataResponse(bankLetterData).build())
                .bankLetter(bankLetter);

        return resultBuilder.build();
    }

    private BankLetter parseBankLetterData(BankLetterData bankLetterData) {
        var resultBuilder = BankLetter.builder();
        if (bankLetterData == null) {
            return resultBuilder.build();
        }

        Optional.ofNullable(bankLetterData.getBankName()).map(ValueScore::getValue).ifPresent(resultBuilder::bankName);
        Optional.ofNullable(bankLetterData.getAccountHolderName()).map(ValueScore::getValue).ifPresent(resultBuilder::accountHolderName);
        Optional.ofNullable(bankLetterData.getAccountNumber()).map(ValueScore::getValue).ifPresent(resultBuilder::accountNumber);
        Optional.ofNullable(bankLetterData.getIban()).map(ValueScore::getValue).ifPresent(resultBuilder::iban);
        Optional.ofNullable(bankLetterData.getSwiftCode()).map(ValueScore::getValue).ifPresent(resultBuilder::swiftCode);

        return resultBuilder.build();
    }
}
