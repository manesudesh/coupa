package ae.network.gamechange.service.config;

import ae.network.gamechange.service.config.model.OrchestrationProperties;
import ae.network.gamechange.service.rest.api.orchestration.service.ApiClient;
import ae.network.gamechange.service.rest.orchestration.AuthorizationRestService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Configuration
@RequiredArgsConstructor
public class OrchestrationRestClientConfig {

    @Bean
    @Qualifier("orchestrationRestTemplate")
    public RestTemplate orchestrationRestTemplate(@Qualifier("gamechangeObjectMapper") ObjectMapper gamechangeObjectMapper) {
        MappingJackson2HttpMessageConverter jsonConverter = new MappingJackson2HttpMessageConverter();
        jsonConverter.setObjectMapper(gamechangeObjectMapper);

        StringHttpMessageConverter stringConverter = new StringHttpMessageConverter();
        ByteArrayHttpMessageConverter byteArrayConverter = new ByteArrayHttpMessageConverter();

        RestTemplate restTemplate = new RestTemplate();
        restTemplate.setMessageConverters(List.of(stringConverter, jsonConverter, byteArrayConverter));

        restTemplate.getInterceptors().add(buildAuthorizationRequestInterceptor());

        return restTemplate;
    }

    @Primary
    @Bean("ae.network.gamechange.service.rest.api.orchestration.service.ApiClient")
    public ApiClient mockApiClient(RestTemplate orchestrationRestTemplate, OrchestrationProperties orchestrationProperties) {
        var apiClient = new ApiClient(orchestrationRestTemplate);
        apiClient.setBasePath(orchestrationProperties.getBaseUrl());
        return apiClient;
    }

    private ClientHttpRequestInterceptor buildAuthorizationRequestInterceptor() {
        return (request, body, execution) -> AuthorizationRestService.INSTANCE.intercept(request, body, execution);
    }
}
