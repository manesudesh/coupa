package ae.network.gamechange.service.database.gamechange_request;

public enum RequestType {

    PASSPORT_OCR,
    EID_OCR,
    BANKLETTER_OCR,
    BANKSTATEMENT_OCR;
}
