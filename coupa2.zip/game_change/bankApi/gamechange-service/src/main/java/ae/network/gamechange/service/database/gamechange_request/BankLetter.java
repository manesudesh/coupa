package ae.network.gamechange.service.database.gamechange_request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.With;

import java.time.LocalDate;

@Data
@Builder
@With
@NoArgsConstructor
@AllArgsConstructor
public class BankLetter {

    private String bankName;
    private String accountNumber;
    private String accountHolderName;
    private String iban;
    private String swiftCode;
}
