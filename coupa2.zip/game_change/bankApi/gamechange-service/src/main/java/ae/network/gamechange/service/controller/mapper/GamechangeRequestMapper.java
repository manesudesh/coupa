package ae.network.gamechange.service.controller.mapper;

import ae.network.gamechange.service.database.gamechange_request.GamechangeRequest;
import ae.network.gamechange.service.rest.api.dto.Eid;
import ae.network.gamechange.service.rest.api.dto.GamechangeResponse;
import ae.network.gamechange.service.rest.api.dto.Passport;
import org.mapstruct.Mapper;

/**
 * This is configuration for using MapStruct.
 * See https://mapstruct.org/documentation/stable/reference/html/#installation
 */
@Mapper(componentModel = "spring")
public interface GamechangeRequestMapper {

    GamechangeResponse map(GamechangeRequest gamechangeRequest);

    Passport map(ae.network.gamechange.service.database.gamechange_request.Passport passport);

    Eid map(ae.network.gamechange.service.database.gamechange_request.Eid eid);

}
