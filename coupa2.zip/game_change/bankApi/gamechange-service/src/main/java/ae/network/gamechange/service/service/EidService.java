package ae.network.gamechange.service.service;

import ae.network.gamechange.service.database.GamechangeRequestRepository;
import ae.network.gamechange.service.database.gamechange_request.Eid;
import ae.network.gamechange.service.database.gamechange_request.EidOcrAttempt;
import ae.network.gamechange.service.database.gamechange_request.GamechangeRequest;
import ae.network.gamechange.service.database.gamechange_request.PassportOcrAttempt;
import ae.network.gamechange.service.database.gamechange_request.RequestType;
import ae.network.gamechange.service.rest.api.dto.FileData;
import ae.network.gamechange.service.rest.gamechange.EidRestService;
import ae.network.gamechange.service.rest.gamechange.ocr.dto.EidData;
import ae.network.gamechange.service.rest.gamechange.ocr.dto.ValueScore;
import ae.network.gamechange.service.utils.ExceptionUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
@RequiredArgsConstructor
public class EidService {

    private final EidRestService eidRestService;
    private final DocumentService documentService;
    private final GamechangeRequestRepository gamechangeRequestRepository;

    public GamechangeRequest extractEid(FileData eidFileLink) {
        var eidDownloadResult = documentService.downloadDocument(eidFileLink);
        if (eidDownloadResult.error() != null) {
            var result = GamechangeRequest
                    .builder()
                    .requestType(RequestType.EID_OCR)
                    .eidOcrAttempt(
                            EidOcrAttempt.builder().fileData(eidFileLink).build())
                    .requestId(UUID.randomUUID().toString())
                    .success(false)
                    .errorMessage(eidDownloadResult.error())
                    .build();
            gamechangeRequestRepository.save(result);
            return result;
        }

        var eidDocument = eidDownloadResult.file();

        var result = extractEid(eidDocument);
        result.getEidOcrAttempt().setFileData(eidFileLink);

        log.info("EID recognize attempt. EidFileLink={}, success={}, attempt={}",
                eidFileLink, result.isSuccess(), result);
        gamechangeRequestRepository.save(result);

        return result;
    }

    public GamechangeRequest extractEid(File eidPicture) {
        var resultBuilder = GamechangeRequest.builder()
                .requestType(RequestType.EID_OCR)
                .requestId(UUID.randomUUID().toString())
                .passportOcrAttempt(PassportOcrAttempt.builder().build());

        EidData eidData;
        try {
            eidData = eidRestService.getEid(eidPicture);
        } catch (Exception e) {
            var error = ExceptionUtils.buildErrorMessage("extract passport at gamechange", e);
            return resultBuilder.success(false).errorMessage(error).build();
        }

        if (eidData == null) {
            return resultBuilder.success(false).errorMessage("enpty passport data").build();
        }

        var eid = parseEidData(eidData);
        var eidRecognized = eid.getEidNumber() != null;
        resultBuilder.success(eidRecognized);
        resultBuilder
                .eidOcrAttempt(EidOcrAttempt.builder().eidDataResponse(eidData).build())
                .eid(eid);

        return resultBuilder.build();
    }

    private Eid parseEidData(EidData eidData) {
        var resultBuilder = Eid.builder();
        if (eidData == null) {
            return resultBuilder.build();
        }

        Optional.ofNullable(eidData.getEmiratesIdNumber()).map(ValueScore::getValue).ifPresent(resultBuilder::eidNumber);
        Optional.ofNullable(eidData.getDateOfBirth()).map(ValueScore::getValue).map(this::toDate).ifPresent(resultBuilder::dayOfBirth);
        Optional.ofNullable(eidData.getExpiryDate()).map(ValueScore::getValue).map(this::toDate).ifPresent(resultBuilder::expiryDate);
        Optional.ofNullable(eidData.getNationality()).map(ValueScore::getValue).ifPresent(resultBuilder::nationality);

        return resultBuilder.build();
    }

    private LocalDate toDate(String date) {
        try {
            return LocalDate.from(DateTimeFormatter.ofPattern("dd/MM/yyyy").parse(date));
        } catch (Exception e) {
            log.error("error parsing data {} to format {}", date, "dd/MM/yyyy", e);
            return null;
        }
    }
}
