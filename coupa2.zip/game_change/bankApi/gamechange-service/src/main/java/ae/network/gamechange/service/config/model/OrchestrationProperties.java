package ae.network.gamechange.service.config.model;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "orchestration")
public class OrchestrationProperties {

    private String baseUrl;
    private String username;
    private String password;
}
