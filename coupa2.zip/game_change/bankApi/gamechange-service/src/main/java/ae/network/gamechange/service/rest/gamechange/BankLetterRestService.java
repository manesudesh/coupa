package ae.network.gamechange.service.rest.gamechange;

import java.io.File;

import org.springframework.context.annotation.Configuration;

import ae.network.gamechange.service.rest.gamechange.ocr.OcrApi;
import ae.network.gamechange.service.rest.gamechange.ocr.dto.BankLetterData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Configuration
public class BankLetterRestService {

    private final OcrApi ocrApi;

    public BankLetterData getBankLetter(File bankLetter) {
        log.debug("Extracting bankletter data: {}", bankLetter);

        var response = ocrApi.extractBankLetterData(bankLetter);
        log.debug("Extracted bankLetter data: {}", response);

        return response;
    }
}