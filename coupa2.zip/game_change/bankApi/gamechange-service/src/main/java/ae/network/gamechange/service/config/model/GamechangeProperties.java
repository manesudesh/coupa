package ae.network.gamechange.service.config.model;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "gamechange")
public class GamechangeProperties {

    private String baseUrl;
    private String authBaseUrl;
    private String authClientId;
    private String authToken;
    private HttpProperties http;
    private boolean healthCheckEnabled;

}
