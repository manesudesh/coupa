package ae.network.gamechange.service.rest.gamechange;

import ae.network.gamechange.service.rest.gamechange.ocr.OcrApi;
import ae.network.gamechange.service.rest.gamechange.ocr.dto.PassportData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;

import java.io.File;

@Slf4j
@RequiredArgsConstructor
@Configuration
public class PassportRestService {

    private final OcrApi ocrApi;

    public PassportData getPassport(File passportPhoto) {
        log.debug("Extracting passport data: {}", passportPhoto);

        var response = ocrApi.extractPassportData(passportPhoto);

        log.debug("Extracted passport data: {}", response);

        return response;
    }
}