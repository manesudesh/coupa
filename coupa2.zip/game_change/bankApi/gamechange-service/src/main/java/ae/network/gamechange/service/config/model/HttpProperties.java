package ae.network.gamechange.service.config.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HttpProperties {

    boolean proxyEnabled;

    String proxyHost;

    Integer proxyPort;

    Integer socketTimeout;

    Integer connectTimeout;

    /**
     * Delay before retrying the REST request in case of connectivity issues.
     */
    Integer connectionRetryDelaySeconds;
}
