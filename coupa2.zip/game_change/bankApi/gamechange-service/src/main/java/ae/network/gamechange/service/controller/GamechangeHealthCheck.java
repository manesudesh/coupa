package ae.network.gamechange.service.controller;

import ae.network.gamechange.service.rest.gamechange.AuthorizationRestService;
import ae.network.gamechange.service.utils.ExceptionUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class GamechangeHealthCheck implements HealthIndicator {

    private final AuthorizationRestService authorizationRestService;

    @Override
    public Health health() {
        log.info("Checking connectivity to Gamechange");

        boolean healthy;

        try {
            healthy = null != authorizationRestService.getAuthorizationToken();
        } catch (Exception e) {
            var error = ExceptionUtils.buildErrorMessage("gamechange health check", e);
            log.info("Gamechange health check failed: {}", error);
            return Health.down().withDetail("error", error).build();
        }

        var health = healthy ? Health.up().build() : Health.down().build();
        log.info("Gamechange health check result: {}", health.getStatus());
        return health;
    }
}
