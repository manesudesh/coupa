package ae.network.gamechange.service.rest.gamechange;

import ae.network.gamechange.service.rest.gamechange.ocr.OcrApi;
import ae.network.gamechange.service.rest.gamechange.ocr.dto.TradeLicenseData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;

import java.io.File;

@Slf4j
@RequiredArgsConstructor
@Configuration
public class TradeLicenseRestService {

    private final OcrApi ocrApi;

    public TradeLicenseData extractTradeLicense(File tradeLicensePicture) {
        log.debug("Extracting trade license data: {}", tradeLicensePicture);

        var response = ocrApi.extractTradeLicenseData(tradeLicensePicture);
        log.debug("Extracted trade license data: {}", response);

        return response;
    }
}
