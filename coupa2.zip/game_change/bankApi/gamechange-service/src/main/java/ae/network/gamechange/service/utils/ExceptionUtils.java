package ae.network.gamechange.service.utils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExceptionUtils {

    public static String buildErrorMessage(String operationName, Exception e) {
        log.error("Error while {}", operationName, e);
        var exceptionMessage = org.apache.commons.lang3.exception.ExceptionUtils.getMessage(e);
        var error = String.format("Exception during %s. ExceptionName=%s. Message=%s",
                operationName, e.getClass().getSimpleName(), exceptionMessage);
        var rootCauseMessage = org.apache.commons.lang3.exception.ExceptionUtils.getRootCauseMessage(e);

        if (!exceptionMessage.equals(rootCauseMessage)) {
            error += ", RootCause=" + rootCauseMessage;
        }
        return error;
    }
}
