package ae.network.gamechange.service.rest.gamechange;

import java.io.File;

import org.springframework.context.annotation.Configuration;

import ae.network.gamechange.service.rest.gamechange.ocr.OcrApi;
import ae.network.gamechange.service.rest.gamechange.ocr.dto.BankStatementData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Configuration
public class BankStatementRestService {

    private final OcrApi ocrApi;

	public BankStatementData getBankStatement(File bankStatement) {
		log.debug("Extracting bankStatement data");

        var response = ocrApi.extractBankStatementData(bankStatement);
        log.debug("Extracted bankStatement data: {}", response);

        return response;
	}
}