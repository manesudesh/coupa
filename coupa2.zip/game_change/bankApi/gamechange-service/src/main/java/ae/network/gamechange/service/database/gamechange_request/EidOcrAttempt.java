package ae.network.gamechange.service.database.gamechange_request;

import ae.network.gamechange.service.rest.api.dto.FileData;
import ae.network.gamechange.service.rest.gamechange.ocr.dto.EidData;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.With;

@Data
@Builder
@With
@NoArgsConstructor
@AllArgsConstructor
public class EidOcrAttempt {

    FileData fileData;
    EidData eidDataResponse;
}
