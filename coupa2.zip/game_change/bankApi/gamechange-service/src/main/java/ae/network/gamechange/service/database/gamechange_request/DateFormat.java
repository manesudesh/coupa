package ae.network.gamechange.service.database.gamechange_request;

public interface DateFormat {

    String FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

    /**
     * See <a href="https://en.wikipedia.org/wiki/ISO_8601">...</a>
     */
    String DATEFORMAT_ISO = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

    /**
     * Simplified {@link #DATEFORMAT_ISO} without offset.
     */
    String DATEFORMAT_NO_OFFSET = "yyyy-MM-dd'T'HH:mm:ss";

    /**
     * Simplified {@link #DATEFORMAT_NO_OFFSET} without time.
     */
    String DATEFORMAT_NO_TIME = "yyyy-MM-dd";
}
