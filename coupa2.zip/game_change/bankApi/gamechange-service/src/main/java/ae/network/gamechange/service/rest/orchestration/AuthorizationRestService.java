package ae.network.gamechange.service.rest.orchestration;

import ae.network.gamechange.service.config.model.OrchestrationProperties;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Objects;

@Service("orchestrationAuthorizationService")
@Slf4j
@RequiredArgsConstructor
public class AuthorizationRestService implements ClientHttpRequestInterceptor {

    /**
     * @implNote temporary solution to avoid circular dependency: rest client -> auth interceptor -> this service
     */
    public static AuthorizationRestService INSTANCE;

    private final OrchestrationProperties orchestrationProperties;
    private final UsersApi usersApi;

    @PostConstruct
    public void init() {
        log.info("Checking Orchestration authorization properties are not empty");
        Objects.requireNonNull(orchestrationProperties.getBaseUrl());
        Objects.requireNonNull(orchestrationProperties.getUsername());
        Objects.requireNonNull(orchestrationProperties.getPassword());

        INSTANCE = this;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
        boolean authorizationNotNeeded = request.getURI().toString().contains("/users/signin");
        if (authorizationNotNeeded) {
            return execution.execute(request, body);
        }

        request.getHeaders().add(HttpHeaders.AUTHORIZATION, "Bearer " + getAuthorizationToken());
        return execution.execute(request, body);
    }

    /**
     * Do login and get orchestration Bearer token
     */
    public String getAuthorizationToken() {
        String username = orchestrationProperties.getUsername();
        String password = orchestrationProperties.getPassword();

        return usersApi.usersSigninPost(username, password);
    }
}
