package ae.network.gamechange.service.database.gamechange_request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.With;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BankStatement {

    private String accountHolderName;
    private String bankName;
    private String accountNumber;
    private String iban;
}
