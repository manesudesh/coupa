package ae.network.gamechange.service.e2e;

import ae.network.gamechange.service.service.TradeLicenseService;
import ae.network.gamechange.service.test.helper.FileHelper;
import ae.network.gamechange.service.test.mock.RestServiceMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ActiveProfiles("test")
@SpringBootTest
public class TradeLicenseExtractionE2eTest {

    @Autowired
    @Qualifier("gamechangeAuthRestTemplate")
    private RestTemplate gamechangeAuthRestTemplate;

    @Autowired
    @Qualifier("gamechangeOcrRestTemplate")
    private RestTemplate gamechangeOcrRestTemplate;

    @Autowired
    private TradeLicenseService tradeLicenseService;

    private RestServiceMock gamechangeAuthRestServiceMock;
    private RestServiceMock gamechangeOcrRestServiceMock;

    @BeforeEach
    public void init() {
        gamechangeAuthRestServiceMock = new RestServiceMock(gamechangeAuthRestTemplate);
        gamechangeOcrRestServiceMock = new RestServiceMock(gamechangeOcrRestTemplate);
    }

    @Test
    public void testTradeLicenseExtraction() {
        // given
        gamechangeAuthRestServiceMock.mockGamechangeAuthorization();
        gamechangeOcrRestServiceMock.addMockResponse("ae/network/gamechange/service/e2e/trade_license_extraction/gamechange_extract_trade_license_response.json");

        var tradeLicenseDocument = FileHelper.getTestResource("ae/network/gamechange/service/e2e/trade_license_extraction/trade_license.pdf");

        // when
        var actualTradeLicense = tradeLicenseService.extractTradeLicense(tradeLicenseDocument);

        // then
        assertTrue(actualTradeLicense.isPresent());
        assertEquals("1234567", actualTradeLicense.get());

        // assert ocr request
        var requests = gamechangeOcrRestServiceMock.getActualRestRequests();
        assertEquals(1, requests.size());
        var request = requests.get(0);
        assertEquals("https://gamechange.example.com/api/trade-license/extract", request.getURI().toString());
        var body = gamechangeOcrRestServiceMock.getActualRequestBody(0);
        assertTrue(body.contains("Dummy PDF download"));

        var contentType = request.getHeaders().getContentType();
        assertEquals("multipart", contentType.getType());
        assertEquals("form-data", contentType.getSubtype());

        assertEquals(HttpMethod.POST, request.getMethod());
    }
}
