package ae.network.gamechange.service.test.mock;

import ae.network.gamechange.service.test.helper.AssertHelper;
import ae.network.gamechange.service.test.helper.FileHelper;
import ae.network.gamechange.service.test.helper.JsonHelper;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.client.RequestMatcher;
import org.springframework.test.web.client.response.MockRestResponseCreators;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Simplifies REST service mocking.
 */
@Getter
public class RestServiceMock {

    private MockRestServiceServer mockServer;

    private List<ClientHttpRequest> actualRestRequests = new ArrayList<>();

    private RequestMatcher requestMatcher = request -> actualRestRequests.add(request);

    public RestServiceMock(RestTemplate restTemplate) {
        mockServer = MockRestServiceServer.createServer(restTemplate);
    }

    public void addMockResponse(String mockedResponse) {
        addMockResponse(mockedResponse, HttpStatus.OK);
    }

    public void addMockResponse(String mockedResponse, HttpStatus mockedResponseStatus) {
        MediaType contentType = mockedResponse.endsWith(".xml")
                ? MediaType.APPLICATION_XML
                : MediaType.APPLICATION_JSON;

        String body = MediaType.APPLICATION_XML == contentType
                ? FileHelper.readTestResource(mockedResponse)
                : JsonHelper.getJson(mockedResponse);

        mockServer.expect(requestMatcher)
                .andRespond(MockRestResponseCreators.withStatus(mockedResponseStatus)
                        .contentType(contentType)
                        .body(body));
    }

    public String getActualRequestBody(int requestNumber) {
        return getRequestBody(actualRestRequests.get(requestNumber));
    }

    public ClientHttpRequest getActualRequest(int requestNumber) {
        return actualRestRequests.get(requestNumber);
    }

    public Map<String, String> getActualRequestHeaders(int requestNumber) {
        return actualRestRequests.get(requestNumber).getHeaders().toSingleValueMap();
    }

    /**
     * Asserts actual HTTP request.
     *
     * @param requestNumber sequential number of the request starting from 0
     * @param expectedUrl   expected URL or {@code null} if assertion is not required
     * @param expectedBody  expected body or {@code null} if assertion is not required
     * @param ignoredFields (optional) list of body fields to ignore during comparison
     */
    public ClientHttpRequest assertActualRequest(int requestNumber,
                                                 String expectedUrl,
                                                 String expectedBody,
                                                 String... ignoredFields) {

        // 1 find the request
        ClientHttpRequest actualRequest = actualRestRequests.get(requestNumber);

        // 2 assert URL
        if (expectedUrl != null) {
            assertEquals(expectedUrl, getUrl(actualRequest));
        }

        // 3 assert body
        if (expectedBody == null) {
            return actualRequest;
        }
        String actualBody = getRequestBody(actualRequest);
        AssertHelper.assertAsJsons(
                expectedBody,
                actualBody,
                ignoredFields
        );

        return actualRequest;
    }

    private String getUrl(final ClientHttpRequest httpClientRequest) {
        return httpClientRequest.getURI().toString();
    }

    private String getRequestBody(final ClientHttpRequest request) {
        try {
            return (request.getBody()).toString();
        } catch (final IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void reset() {
        actualRestRequests.clear();
        mockServer.reset();
    }

    public void mockGamechangeAuthorization() {
        addMockResponse(
                "ae/network/gamechange/service/rest/gamechange/request_token/request_token_response.json",
                HttpStatus.OK);
    }
}
