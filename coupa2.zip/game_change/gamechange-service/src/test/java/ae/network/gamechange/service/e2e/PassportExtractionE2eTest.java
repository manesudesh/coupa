package ae.network.gamechange.service.e2e;

import ae.network.gamechange.service.service.PassportService;
import ae.network.gamechange.service.test.helper.FileHelper;
import ae.network.gamechange.service.test.mock.RestServiceMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ActiveProfiles("test")
@SpringBootTest
public class PassportExtractionE2eTest {

    @Autowired
    @Qualifier("gamechangeAuthRestTemplate")
    private RestTemplate gamechangeAuthRestTemplate;

    @Autowired
    @Qualifier("gamechangeOcrRestTemplate")
    private RestTemplate gamechangeOcrRestTemplate;

    @Autowired
    private PassportService passportService;

    private RestServiceMock gamechangeAuthRestServiceMock;
    private RestServiceMock gamechangeOcrRestServiceMock;

    @BeforeEach
    public void init() {
        gamechangeAuthRestServiceMock = new RestServiceMock(gamechangeAuthRestTemplate);
        gamechangeOcrRestServiceMock = new RestServiceMock(gamechangeOcrRestTemplate);
    }

    @Test
    public void testPassport() {
        // given
        gamechangeAuthRestServiceMock.mockGamechangeAuthorization();
        gamechangeOcrRestServiceMock.addMockResponse("ae/network/gamechange/service/e2e/passport_extraction/gamechange_extract_passport_response.json");

        var passportDocument = FileHelper.getTestResource("ae/network/gamechange/service/e2e/passport_extraction/passport.pdf");

        // when
        var actualPassport = passportService.extractPassport(passportDocument);

        // then
        assertTrue(actualPassport.isPresent());
        assertEquals("R102599", actualPassport.get());

        // assert ocr request
        var requests = gamechangeOcrRestServiceMock.getActualRestRequests();
        assertEquals(1, requests.size());
        var request = requests.get(0);
        assertEquals("https://gamechange.example.com/api/passport/extract", request.getURI().toString());
        var body = gamechangeOcrRestServiceMock.getActualRequestBody(0);
        assertTrue(body.contains("Dummy PDF download"));

        var contentType = request.getHeaders().getContentType();
        assertEquals("multipart", contentType.getType());
        assertEquals("form-data", contentType.getSubtype());

        assertEquals(HttpMethod.POST, request.getMethod());
    }
}
