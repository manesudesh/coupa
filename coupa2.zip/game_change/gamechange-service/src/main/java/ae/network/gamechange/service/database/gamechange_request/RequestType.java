package ae.network.gamechange.service.database.gamechange_request;

public class RequestType {

    public static final String EXTRACT_EID = "EXTRACT_EID";

    private RequestType() {
    }
}
