package ae.network.gamechange.service.model.bank.caller;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankStatementCallerResponse implements Serializable{
	
	private String customerId;
	private String accountHolderName;
    private Double totalAssets;    
    private Double totalLiablities;

}
