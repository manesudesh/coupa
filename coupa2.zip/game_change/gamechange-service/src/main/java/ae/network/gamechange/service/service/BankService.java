package ae.network.gamechange.service.service;

import java.io.File;
import java.util.Collections;
import java.util.List;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;

import ae.network.gamechange.service.model.bank.api.BankLetterAPIResponse;
import ae.network.gamechange.service.model.bank.api.BankStatementAPIResponse;
import ae.network.gamechange.service.model.bank.caller.BankLetterCallerResponse;
import ae.network.gamechange.service.model.bank.caller.BankStatementCallerResponse;
import ae.network.gamechange.service.rest.gamechange.ocr.service.ApiClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class BankService {

	private final ApiClient apiClient;
	
    public BankStatementCallerResponse postBankStatement(File bankFile, String apiEndpoint) throws Exception {
    	MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
    	HttpHeaders headerParams = new HttpHeaders();
    	MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();
        Object postBody = null;
        
    	formParams.add("file", new FileSystemResource(bankFile));
    	
    	ParameterizedTypeReference<BankStatementAPIResponse> returnType = new ParameterizedTypeReference<BankStatementAPIResponse>() {};
    	
    	ResponseEntity<BankStatementAPIResponse> responseEntity = extractDataWithHttpInfo(apiEndpoint, queryParams, cookieParams, formParams, postBody, headerParams, returnType);
    	return translateStatementResponse(responseEntity.getBody());
    }
    
    public BankLetterCallerResponse postBankLetter(File bankFile, String apiEndpoint) throws Exception {
    	MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
    	HttpHeaders headerParams = new HttpHeaders();
    	MultiValueMap<String, String> cookieParams = new LinkedMultiValueMap<String, String>();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();
        Object postBody = null;
        
    	formParams.add("file", new FileSystemResource(bankFile));
    	
    	ParameterizedTypeReference<BankLetterAPIResponse> returnType = new ParameterizedTypeReference<BankLetterAPIResponse>() {};
    	
    	ResponseEntity<BankLetterAPIResponse> responseEntity = extractDataWithHttpInfo(apiEndpoint, queryParams, cookieParams, formParams, postBody, headerParams, returnType);
    	return translateLetterResponse(responseEntity.getBody());
    }
    
    public <T> ResponseEntity<T> extractDataWithHttpInfo(
    		String apiEndpoint,
    		MultiValueMap<String, String> localVarQueryParams,
    		MultiValueMap<String, String> localVarCookieParams,
    		MultiValueMap<String, Object> localVarFormParams,
    		Object localVarPostBody,
    		HttpHeaders localVarHeaderParams,
    		ParameterizedTypeReference<T> localReturnType
    		) throws RestClientException {

        final String[] localVarAccepts = { 
            "application/json"
         };
        final List<MediaType> localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        final String[] localVarContentTypes = { 
            "multipart/form-data"
         };
        final MediaType localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

        localVarHeaderParams.setAccept(List.of(MediaType.APPLICATION_JSON));
        String[] localVarAuthNames = new String[] {  };
        
        return apiClient.invokeAPI(apiEndpoint, HttpMethod.POST, Collections.<String, Object>emptyMap(), localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarCookieParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localReturnType);
    }
    
    public BankLetterCallerResponse translateLetterResponse(BankLetterAPIResponse apiResponse)  {
    	BankLetterCallerResponse callerResponse = BankLetterCallerResponse.builder().build();
        if(apiResponse != null) {
        	if(apiResponse.getAccountHolderName()!= null) {callerResponse.setAccountHolderName(apiResponse.getAccountHolderName().getValue());}
        	if(apiResponse.getAccountNumber()!= null) {callerResponse.setAccountNumber(apiResponse.getAccountNumber().getValue());}
        	if(apiResponse.getBankName()!= null) {callerResponse.setBankName(apiResponse.getBankName().getValue());}
        	if(apiResponse.getIban()!= null) {callerResponse.setIban(apiResponse.getIban().getValue());}
        	if(apiResponse.getSwiftCode()!= null) {callerResponse.setSwiftCode(apiResponse.getSwiftCode().getValue());}
        }
    	return callerResponse;      
    }
    
    public BankStatementCallerResponse translateStatementResponse(BankStatementAPIResponse apiResponse)  {
    	BankStatementCallerResponse callerResponse = BankStatementCallerResponse.builder().build();
        if(apiResponse != null) {
        	if(apiResponse.getAccountHolderName()!= null) {callerResponse.setAccountHolderName(apiResponse.getAccountHolderName().getValue());}
        	if(apiResponse.getCustomerID()!= null) {callerResponse.setCustomerId(apiResponse.getCustomerID().getValue());}
        	if(apiResponse.getTotalAssets()!= null) {callerResponse.setTotalAssets(apiResponse.getTotalAssets().getValue());}
        	if(apiResponse.getTotalLiablities()!= null) {callerResponse.setTotalLiablities(apiResponse.getTotalLiablities().getValue());}
        }
    	return callerResponse;      
    }
}
