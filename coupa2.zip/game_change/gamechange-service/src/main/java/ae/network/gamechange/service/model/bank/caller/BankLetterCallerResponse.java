package ae.network.gamechange.service.model.bank.caller;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankLetterCallerResponse implements Serializable{
	
	private String bankName;
    private String accountNumber;
    private String accountHolderName;
    private String iban;
    private String swiftCode;

}
