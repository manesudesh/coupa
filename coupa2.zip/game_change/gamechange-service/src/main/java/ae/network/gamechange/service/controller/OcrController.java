package ae.network.gamechange.service.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import ae.network.gamechange.service.model.bank.caller.BankLetterCallerResponse;
import ae.network.gamechange.service.model.bank.caller.BankStatementCallerResponse;
import ae.network.gamechange.service.service.BankService;
import ae.network.gamechange.service.service.EidService;
import ae.network.gamechange.service.service.TradeLicenseService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/ocr")
public class OcrController {

    private final EidService eidService;
    private final TradeLicenseService tradeLicenseService;

    @PostMapping("/eid")
    public ResponseEntity<String> extractEid(@RequestParam("file") MultipartFile uploadedFile) {
        if (uploadedFile.isEmpty()) {
            return new ResponseEntity<>("`file` parameter need to be uploaded", HttpStatus.BAD_REQUEST);
        }

        var file = convertMultipartFileToFile(uploadedFile);
        var maybeEid = eidService.extractEid(file);

        return maybeEid
                .map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>("EID not found", HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<String> extractTradeLicense(@RequestParam("file") MultipartFile uploadedFile) {
        if (uploadedFile.isEmpty()) {
            return new ResponseEntity<>("`file` parameter need to be uploaded", HttpStatus.BAD_REQUEST);
        }

        var file = convertMultipartFileToFile(uploadedFile);
        var tradeLicenseData = tradeLicenseService.extractTradeLicense(file);

        return ResponseEntity.ok(tradeLicenseData.toString());
    }

    private File convertMultipartFileToFile(MultipartFile multipartFile) {
        File file = new File(multipartFile.getOriginalFilename());
        try {
            multipartFile.transferTo(file);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return file;
    }
    
    private File multipartToFile(MultipartFile multipartFile) {
        File file = new File(multipartFile.getOriginalFilename());
        try (FileOutputStream fos = new FileOutputStream(file)){
        	fos.write(multipartFile.getBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return file;
    }
    
    @Autowired
    BankService bankService;
    
    @Value("${gamechange.endpoint.bank-letter}") String bankLetterEndpoint;
    @Value("${gamechange.endpoint.bank-statement}") String bankStatementEndpoint;
    
    @PostMapping("/bankstatement")
    public BankStatementCallerResponse bankStatement(@RequestParam("file") MultipartFile uploadedFile) throws Exception {
    	return bankService.postBankStatement(multipartToFile(uploadedFile), bankStatementEndpoint);
    }
    
    @PostMapping("/bankletter")
    public BankLetterCallerResponse bankLetter(@RequestParam("file") MultipartFile uploadedFile) throws Exception {
    	return bankService.postBankLetter(multipartToFile(uploadedFile), bankLetterEndpoint);

    }

}
