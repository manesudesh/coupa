package ae.network.gamechange.service.model.bank.api;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankStatementAPIResponse implements Serializable{
	
	private BankAccount customerID;
    private BankAccount accountHolderName;
    private BankTotal totalAssets;
    private BankTotal totalLiablities;

}
