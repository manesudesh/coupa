package ae.network.gamechange.service.service;

import ae.network.gamechange.service.rest.gamechange.PassportRestService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class PassportService {

    private final PassportRestService passportRestService;

    public Optional<String> extractPassport(File passportPicture) {
        var recognizeAttempt = passportRestService.getPassport(passportPicture);

        var recognizedPassportId = recognizeAttempt.getPassportNumber();
        var passportNumber = recognizedPassportId != null ? recognizedPassportId.getValue() : null;

        log.info("Extract Passport attempt. PassportPicture={}, EID={}, Attempt={}", passportPicture, passportNumber, recognizeAttempt);

        return Optional.ofNullable(passportNumber);
    }
}
