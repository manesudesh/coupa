package ae.network.gamechange.service.service;

import ae.network.gamechange.service.rest.gamechange.EidRestService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class EidService {

    private final EidRestService eidRestService;

    public Optional<String> extractEid(File eidPicture) {
        var recognizeAttempt = eidRestService.getEid(eidPicture);

        var recognizedEid = recognizeAttempt.getEmiratesIdNumber();
        var eid = recognizedEid != null ? recognizedEid.getValue() : null;

        log.info("Extract EID attempt. EidPicture={}, EID={}, Attempt={}", eidPicture, eid, recognizeAttempt);

        return Optional.ofNullable(eid);
    }
}
