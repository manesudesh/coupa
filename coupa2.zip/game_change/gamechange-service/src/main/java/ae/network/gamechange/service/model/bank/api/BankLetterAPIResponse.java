package ae.network.gamechange.service.model.bank.api;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankLetterAPIResponse implements Serializable{
	
	private BankAccount bankName;
    private BankAccount accountNumber;
    private BankAccount accountHolderName;
    private BankAccount iban;
    private BankAccount swiftCode;

}
