package ae.network.gamechange.service.model.bank.api;

import lombok.Data;

@Data
public class BankAccount {

	private String value;
    private Double score;
    
}
