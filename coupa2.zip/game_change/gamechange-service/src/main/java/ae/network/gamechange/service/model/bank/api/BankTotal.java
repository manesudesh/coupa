package ae.network.gamechange.service.model.bank.api;

import lombok.Data;

@Data
public class BankTotal {
	private Double value;
    private Double score;
}
