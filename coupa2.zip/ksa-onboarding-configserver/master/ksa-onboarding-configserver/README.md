# README #

This README would normally document whatever steps are necessary to get your application up and running.

Eexecute below url to refresh all common properties to config client

	HttpMethod Post ::  http://localhost:8888/actuator/busrefresh