package ae.network.onboarding.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

@SpringBootApplication
@EnableConfigServer
@EnableEncryptableProperties
public class OctopusConfigServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(OctopusConfigServiceApplication.class, args);
    }

}
