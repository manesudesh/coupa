package ae.network.onboarding.bulk.upload.merchants.converter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ae.network.onboarding.bulk.upload.merchants.model.ApplicationRequest;
import ae.network.onboarding.bulk.upload.merchants.model.ExcelMerchant;
import ae.network.onboarding.bulk.upload.merchants.model.RequestStatus;
import ae.network.onboarding.bulk.upload.merchants.service.ValidationService;
import ae.network.onboarding.bulk.upload.merchants.test.util.JsonTestUtil;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ExcelMerchantToApplicationRequestConverterTest {

  @Mock
  private ValidationService validationService;
  @InjectMocks
  private ExcelMerchantToApplicationRequestConverter converter;

  @ParameterizedTest
  @DisplayName("Verify conversion of ExcelMerchant to ApplicationRequest with NEW status")
  @CsvSource({"application/excel_merchant.json"})
  public void shouldConvertApplicationRequestToExcelMerchant(String excelMerchantJsonFile) {
    ExcelMerchant merchant = JsonTestUtil.loadFromFile(excelMerchantJsonFile, ExcelMerchant.class);
    when(validationService.validateMerchant(merchant))
        .thenReturn(Optional.empty());

    ApplicationRequest applicationRequest = converter.convert(merchant);

    verify(validationService).validateMerchant(merchant);
    assertEquals(merchant, applicationRequest.getExcelMerchant());
    assertEquals(RequestStatus.NEW, applicationRequest.getRequestStatus());
  }

  @ParameterizedTest
  @DisplayName("Verify conversion of ExcelMerchant to ApplicationRequest with VALIDATION_FAILED status")
  @CsvSource({"application/excel_merchant.json"})
  public void shouldConvertApplicationRequestToExcelMerchantWithError(
      String excelMerchantJsonFile
  ) {
    ExcelMerchant merchant = JsonTestUtil.loadFromFile(excelMerchantJsonFile, ExcelMerchant.class);
    String validationErrorMessage = "Validation failed";
    when(validationService.validateMerchant(merchant))
        .thenReturn(Optional.of(validationErrorMessage));

    ApplicationRequest applicationRequest = converter.convert(merchant);

    verify(validationService).validateMerchant(merchant);
    assertEquals(merchant, applicationRequest.getExcelMerchant());
    assertEquals(RequestStatus.VALIDATION_FAILED, applicationRequest.getRequestStatus());
    assertEquals(validationErrorMessage, applicationRequest.getProcessingError());
  }
}
