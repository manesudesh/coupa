package ae.network.onboarding.bulk.upload.merchants.converter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import ae.network.onboarding.bulk.upload.merchants.config.OrchestrationProperties;
import ae.network.onboarding.bulk.upload.merchants.dto.OnboardingRequest;
import ae.network.onboarding.bulk.upload.merchants.model.ApplicationRequest;
import ae.network.onboarding.bulk.upload.merchants.test.util.JsonTestUtil;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ApplicationRequestToOnboardingRequestConverterTest {

  @Mock
  private OrchestrationProperties orchestrationProperties;
  @InjectMocks
  private ApplicationRequestToOnboardingRequestConverter converter;

  @ParameterizedTest
  @DisplayName("Verify conversion of ApplicationRequest to OnboardingRequest")
  @CsvSource({"application/application_request.json, application/onboarding_request.json"})
  public void shouldConvertApplicationRequestToOnboardingRequest(
      String applicationRequestJsonFile,
      String onboardingRequestJsonFile
  ) {
    String acquirer = "NI";
    String username = "MPGSOnly";
    ApplicationRequest applicationRequest = JsonTestUtil.loadFromFile(
        applicationRequestJsonFile,
        ApplicationRequest.class
    );
    OnboardingRequest onboardingRequest = JsonTestUtil.loadFromFile(
        onboardingRequestJsonFile,
        OnboardingRequest.class
    );
    when(orchestrationProperties.getOnboardingAcquirer())
        .thenReturn(acquirer);
    when(orchestrationProperties.getOnboardingUsername())
        .thenReturn(username);

    OnboardingRequest result = converter.convert(applicationRequest);

    assertTrue(result.getSkipCallback());
    assertEquals(onboardingRequest.getAcquirer(), result.getAcquirer());
    assertEquals(onboardingRequest.getUsername(), result.getUsername());
    assertEquals(onboardingRequest.getRequestType(), result.getRequestType());
    assertEquals(onboardingRequest.getPayload(), result.getPayload());
  }
}
