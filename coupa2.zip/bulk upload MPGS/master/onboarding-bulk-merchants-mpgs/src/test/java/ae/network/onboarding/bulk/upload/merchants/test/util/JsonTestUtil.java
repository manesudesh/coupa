package ae.network.onboarding.bulk.upload.merchants.test.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import lombok.experimental.UtilityClass;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@UtilityClass
public class JsonTestUtil {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    public static <T> T loadFromFile(String filePath, Class<T> toValueType) {
        return OBJECT_MAPPER.convertValue(JsonTestUtil.loadJson(filePath), toValueType);
    }

    public static JsonNode loadJson(String path) {
        Resource resource = new ClassPathResource(path);
        try {
            return OBJECT_MAPPER.readValue(resource.getURL(), JsonNode.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
