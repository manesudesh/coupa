package ae.network.onboarding.bulk.upload.merchants.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 
 * @version 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MerchantConfig {

    private String softPosAuthSystem;
    
    private String ecomAuthSystem;

}
