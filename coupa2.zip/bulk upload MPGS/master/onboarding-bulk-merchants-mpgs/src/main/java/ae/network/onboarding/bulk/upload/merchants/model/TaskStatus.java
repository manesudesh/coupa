package ae.network.onboarding.bulk.upload.merchants.model;

public enum TaskStatus {

  COMPLETED,
  FAILED,
  IN_PROGRESS,
  CANCELLED
}
