package ae.network.onboarding.bulk.upload.merchants.repository;

import ae.network.onboarding.bulk.upload.merchants.model.ApplicationRequest;
import ae.network.onboarding.bulk.upload.merchants.model.RequestStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ApplicationRequestRepository extends MongoRepository<ApplicationRequest, String> {

  Page<ApplicationRequest> findAllByRequestStatusOrderById(RequestStatus requestStatus, Pageable pageable);
}
