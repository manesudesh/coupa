package ae.network.onboarding.bulk.upload.merchants.model.common;

public interface DateFormat {
    String FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
}
