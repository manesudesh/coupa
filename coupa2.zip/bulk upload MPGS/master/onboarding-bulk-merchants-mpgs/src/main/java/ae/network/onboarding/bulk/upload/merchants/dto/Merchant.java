package ae.network.onboarding.bulk.upload.merchants.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Merchant {

  private String merchantId;
  private String merchantName;
  private String legalName;
  private MerchantType merchantType;
  private Integer mcc;
  private String merchantCurrency;
  private List<Terminal> terminals;
  private List<Address> addresses;
  private List<MerchantService> services;
}
