package ae.network.onboarding.bulk.upload.merchants.model;

import ae.network.onboarding.bulk.upload.merchants.model.common.DateFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

@Data
public class TaskHistory {

  private TaskStatus taskStatus;
  private String response;
  @JsonFormat(pattern = DateFormat.FORMAT)
  @DateTimeFormat(pattern = DateFormat.FORMAT)
  private Date createdDate;
  @JsonFormat(pattern = DateFormat.FORMAT)
  @DateTimeFormat(pattern = DateFormat.FORMAT)
  private Date lastModifiedDate;
}
