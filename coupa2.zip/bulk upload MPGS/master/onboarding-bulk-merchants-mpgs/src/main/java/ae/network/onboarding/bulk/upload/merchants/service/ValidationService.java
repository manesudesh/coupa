package ae.network.onboarding.bulk.upload.merchants.service;

import ae.network.onboarding.bulk.upload.merchants.model.ExcelMerchant;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class ValidationService {

  private final Validator validator;

  public Optional<String> validateMerchant(ExcelMerchant excelMerchant) {
    Set<ConstraintViolation<ExcelMerchant>> violations = new HashSet<>(
        validator.validate(excelMerchant));

    String validationMessage = violations.stream()
        .map(violation -> violation.getPropertyPath() + " : " + violation.getMessage())
        .sorted()
        .collect(Collectors.joining("\n"));
    boolean validationPassed = violations.isEmpty();

    log.info("ExcelMerchant Constraints validation: merchantIsValid={}, validationMessage={}",
        validationPassed, validationMessage);
    return validationPassed ? Optional.empty() : Optional.of(validationMessage);
  }
}
