package ae.network.onboarding.bulk.upload.merchants.scheduled;

import ae.network.onboarding.bulk.upload.merchants.service.OnboardingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class OnboardingJob {

  private final OnboardingService onboardingService;

  @Scheduled(cron = "${bulk-upload.onboarding-merchants-job-cron}")
  public void runOnboardMerchants() {
    log.info("Starting Scheduled job for Orchestration processing");
    onboardingService.onboard();
    log.info("Finished Scheduled job for Orchestration processing");
  }
}
