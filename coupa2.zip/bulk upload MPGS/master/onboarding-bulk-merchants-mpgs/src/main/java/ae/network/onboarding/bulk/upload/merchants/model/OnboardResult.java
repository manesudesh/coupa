package ae.network.onboarding.bulk.upload.merchants.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OnboardResult {

  private String applicationId;
  private String requestId;
  private String request;
  private String response;
}
