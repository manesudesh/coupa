package ae.network.onboarding.bulk.upload.merchants.model.common;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

@Data
public abstract class AuditingEntity implements Serializable {

  @CreatedDate
  @JsonFormat(pattern = DateFormat.FORMAT)
  @DateTimeFormat(pattern = DateFormat.FORMAT)
  private Date createdDate = new Date();

  @LastModifiedDate
  @JsonFormat(pattern = DateFormat.FORMAT)
  @DateTimeFormat(pattern = DateFormat.FORMAT)
  private Date lastModifiedDate = new Date();
}