package ae.network.onboarding.bulk.upload.merchants.model;

import ae.network.onboarding.bulk.upload.merchants.model.common.AuditingEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Document(collection = "mpgs_bulk_upload")
public class ApplicationRequest extends AuditingEntity {

  @Id
  private String id;
  private String processingError;
  private Integer retriesCount;
  private RequestStatus requestStatus;
  private ExcelMerchant excelMerchant;
  private OnboardResult onboardResult;
}
