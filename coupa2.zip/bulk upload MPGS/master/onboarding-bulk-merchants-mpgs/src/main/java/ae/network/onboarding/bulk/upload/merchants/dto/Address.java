package ae.network.onboarding.bulk.upload.merchants.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Address {

  private AddressType addressType;
  private String countryCode;
  private String city;
  private String state;
  private String postalCode;
  private String phone;
  private String pobox;
  private String email;
}
