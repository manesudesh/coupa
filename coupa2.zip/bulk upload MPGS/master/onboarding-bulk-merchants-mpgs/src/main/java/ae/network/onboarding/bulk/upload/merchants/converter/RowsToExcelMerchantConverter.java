package ae.network.onboarding.bulk.upload.merchants.converter;

import ae.network.onboarding.bulk.upload.merchants.model.ExcelMerchant;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.IterableUtils;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.util.Pair;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class RowsToExcelMerchantConverter implements Converter<Pair<Row, Row>, ExcelMerchant> {

  @Override
  public ExcelMerchant convert(Pair<Row, Row> rowPair) {
    ExcelMerchant excelMerchant = new ExcelMerchant();
    Row merchantRow = rowPair.getFirst();
    Row headerRow = rowPair.getSecond();

    try {
      for (int j = 0; j < merchantRow.getPhysicalNumberOfCells(); j++) {
        Cell headerCell = headerRow.getCell(j);
        Cell merchantCell = merchantRow.getCell(j);
        Field[] merchantFields = ExcelMerchant.class.getDeclaredFields();
        Field merchantField = IterableUtils.find(
            Arrays.stream(merchantFields).collect(Collectors.toList()),
            field -> field.getName().equals(headerCell.getStringCellValue())
        );

        if (merchantField != null) {
          merchantField.setAccessible(true);
          switch (merchantCell.getCellType()) {
            case STRING:
              merchantField.set(excelMerchant, merchantCell.getStringCellValue());
              break;
            case NUMERIC:
              merchantField.set(
                  excelMerchant,
                  Integer.toString((int) merchantCell.getNumericCellValue())
              );
              break;
          }
        } else {
          log.warn(
              "Mapping wasn't completed for column \"{}\", please verify Merchant object structure",
              headerCell.getStringCellValue()
          );
        }
      }
    } catch (IllegalAccessException e) {
      log.error("Mapping Row to ExcelMerchant is failed: {}", e.getMessage());
      throw new RuntimeException(e);
    }

    return excelMerchant;
  }
}
