package ae.network.onboarding.bulk.upload.merchants.model;

import ae.network.onboarding.bulk.upload.merchants.dto.OnboardingRequest;
import ae.network.onboarding.bulk.upload.merchants.model.common.AuditingEntity;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Builder
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Document(collection = "mpgs_request")
public class MpgsApplicationRequest extends AuditingEntity {

  @Id
  private String id;
  private String acquirer;
  private String applicationId;
  private String requestId;
  private OnboardingRequest payload;
  @Builder.Default
  private List<Task> tasks = new ArrayList<>();
}
