package ae.network.onboarding.bulk.upload.merchants.controller;

import ae.network.onboarding.bulk.upload.merchants.dto.BulkUploadResponse;
import ae.network.onboarding.bulk.upload.merchants.model.RequestStatus;
import ae.network.onboarding.bulk.upload.merchants.service.BulkUploadService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class BulkUploadController {

  private static final String DEFAULT_PAGE = "0";
  private static final String DEFAULT_PAGE_SIZE = "50";

  private final BulkUploadService bulkUploadService;

  @GetMapping("/bulk-upload-requests")
  public ResponseEntity<BulkUploadResponse> getBulkUploadRequests(
      @RequestParam RequestStatus status,
      @RequestParam(required = false, defaultValue = DEFAULT_PAGE) Integer page,
      @RequestParam(required = false, defaultValue = DEFAULT_PAGE_SIZE) Integer size
  ) {
    return ResponseEntity.ok(bulkUploadService.getBulkUploadRequests(
        status,
        Pageable.ofSize(size).withPage(page))
    );
  }
}
