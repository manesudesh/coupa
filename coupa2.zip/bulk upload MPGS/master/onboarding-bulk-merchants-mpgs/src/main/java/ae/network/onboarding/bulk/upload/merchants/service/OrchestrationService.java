package ae.network.onboarding.bulk.upload.merchants.service;

import ae.network.onboarding.bulk.upload.merchants.client.OrchestrationHttpClient;
import ae.network.onboarding.bulk.upload.merchants.converter.ApplicationRequestToOnboardingRequestConverter;
import ae.network.onboarding.bulk.upload.merchants.dto.OnboardingRequest;
import ae.network.onboarding.bulk.upload.merchants.dto.OnboardingResponse;
import ae.network.onboarding.bulk.upload.merchants.model.ApplicationRequest;
import ae.network.onboarding.bulk.upload.merchants.model.OnboardResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrchestrationService {

  private final OrchestrationHttpClient orchestrationHttpClient;
  private final ApplicationRequestToOnboardingRequestConverter converter;
  private final ObjectMapper objectMapper;

  public OnboardResult createApplication(ApplicationRequest applicationRequest) {
    OnboardingRequest onboardingRequest = converter.convert(applicationRequest);
    String onboardRequestBody = buildRequestBody(onboardingRequest);
    String onboardResponseBody = orchestrationHttpClient.doOnboardRequest(onboardRequestBody);
    OnboardingResponse onboardingResponse = parseOnboardCreateResponse(onboardResponseBody);
    Objects.requireNonNull(
        onboardingResponse.getApplicationId(),
        "ApplicationId is null. Response=[" + onboardResponseBody + "]"
    );

    return OnboardResult.builder()
        .requestId(onboardingRequest.getRequestId())
        .applicationId(onboardingResponse.getApplicationId())
        .request(onboardRequestBody)
        .response(onboardResponseBody)
        .build();
  }

  private OnboardingResponse parseOnboardCreateResponse(String onboardResponseBody) {
    try {
      return objectMapper.readValue(onboardResponseBody.getBytes(), OnboardingResponse.class);
    } catch (IOException e) {
      log.error("Error Parsing Onboarding Create Response :", e);
      return new OnboardingResponse();
    }
  }

  private String buildRequestBody(OnboardingRequest onboardingRequest) {
    try {
      ByteArrayOutputStream jsonBytes = new ByteArrayOutputStream();
      objectMapper.writeValue(jsonBytes, onboardingRequest);
      return jsonBytes.toString();
    } catch (IOException e) {
      log.error("Error transforming ApplicationRequest to JSON", e);
      throw new RuntimeException(e);
    }
  }
}
