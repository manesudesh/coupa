package ae.network.onboarding.bulk.upload.merchants.scheduled;

import ae.network.onboarding.bulk.upload.merchants.service.BulkUploadService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class BulkUploadJob {

  private final BulkUploadService bulkUploadService;

  @Scheduled(cron = "${bulk-upload.bulk-upload-merchants-job-cron}")
  public void processBulkUploadMerchants() {
    log.info("Starting Scheduled job for bulk uploading merchants from excel sheet to database");
    bulkUploadService.backupAndProcess();
    log.info("Finished Scheduled job for bulk uploading merchants from excel sheet to database");
  }
}
