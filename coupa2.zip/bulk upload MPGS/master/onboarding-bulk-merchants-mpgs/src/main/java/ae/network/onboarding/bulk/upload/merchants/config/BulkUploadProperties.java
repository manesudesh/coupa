package ae.network.onboarding.bulk.upload.merchants.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "bulk-upload")
@Data
public class BulkUploadProperties {

  private String merchantsInputFolderPath;
  private String merchantsBackupFolderPath;
  private Integer retries;
  private Integer batchSize;
}
