package ae.network.onboarding.bulk.upload.merchants.converter;

import ae.network.onboarding.bulk.upload.merchants.model.ApplicationRequest;
import ae.network.onboarding.bulk.upload.merchants.model.ExcelMerchant;
import ae.network.onboarding.bulk.upload.merchants.model.RequestStatus;
import ae.network.onboarding.bulk.upload.merchants.service.ValidationService;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@RequiredArgsConstructor
public class ExcelMerchantToApplicationRequestConverter implements
    Converter<ExcelMerchant, ApplicationRequest> {

  private final ValidationService validationService;

  @Override
  public ApplicationRequest convert(ExcelMerchant excelMerchant) {
    log.info("Mapping ExcelMerchant to ApplicationRequest: {}", excelMerchant);

    Optional<String> validationError = validationService.validateMerchant(excelMerchant);
    boolean validationSuccess = !validationError.isPresent();

    ApplicationRequest applicationRequest = ApplicationRequest.builder()
        .requestStatus(validationSuccess ? RequestStatus.NEW : RequestStatus.VALIDATION_FAILED)
        .excelMerchant(excelMerchant)
        .processingError(validationSuccess ? null : validationError.get())
        .build();

    log.info("ExcelMerchant mapped to ApplicationRequest: {}", applicationRequest);

    return applicationRequest;
  }
}
