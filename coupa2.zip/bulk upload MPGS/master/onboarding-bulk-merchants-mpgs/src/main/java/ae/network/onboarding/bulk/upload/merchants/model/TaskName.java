package ae.network.onboarding.bulk.upload.merchants.model;

public enum TaskName {

  ONBOARDING_MERCHANT;
}
