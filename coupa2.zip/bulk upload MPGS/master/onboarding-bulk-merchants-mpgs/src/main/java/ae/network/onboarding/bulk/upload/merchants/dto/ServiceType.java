package ae.network.onboarding.bulk.upload.merchants.dto;

public enum ServiceType {

  MPGS;
}
