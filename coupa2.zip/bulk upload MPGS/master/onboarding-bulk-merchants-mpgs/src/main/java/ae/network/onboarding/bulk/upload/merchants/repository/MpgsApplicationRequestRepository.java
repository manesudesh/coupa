package ae.network.onboarding.bulk.upload.merchants.repository;

import ae.network.onboarding.bulk.upload.merchants.model.ApplicationRequest;
import ae.network.onboarding.bulk.upload.merchants.model.MpgsApplicationRequest;
import ae.network.onboarding.bulk.upload.merchants.model.RequestStatus;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface MpgsApplicationRequestRepository extends
    MongoRepository<ApplicationRequest, String> {

  @Query("{ 'applicationId' : { $in: ?0 } }")
  List<MpgsApplicationRequest> findAllByApplicationId(List<String> applicationIds);
}
