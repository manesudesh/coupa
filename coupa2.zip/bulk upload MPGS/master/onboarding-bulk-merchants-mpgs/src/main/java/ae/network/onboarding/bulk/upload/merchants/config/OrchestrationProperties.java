package ae.network.onboarding.bulk.upload.merchants.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "orchestration")
@Data
public class OrchestrationProperties {

  private String onboardingLoginUrl;
  private String onboardingCreateUrl;
  private String onboardingUsername;
  private String onboardingPassword;
  private String onboardingAcquirer;
}
