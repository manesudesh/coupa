package ae.network.onboarding.bulk.upload.merchants.model;

import java.util.ArrayList;
import java.util.Collection;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Task {

  private String name;
  private String entityId;
  private TaskStatus taskStatus;
  @Builder.Default
  private Collection<TaskHistory> taskHistory = new ArrayList<>();
}
