package ae.network.onboarding.bulk.upload.merchants.scheduled;

import ae.network.onboarding.bulk.upload.merchants.service.OnboardingResultService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class OnboardingResultJob {

  private final OnboardingResultService onboardingResultService;

  @Scheduled(cron = "${bulk-upload.onboarding-result-job-cron}")
  public void runOnboardResultCheck() {
    log.info("Starting Scheduled job for MPGS Onboarding Status Check");
    onboardingResultService.onboardResultCheck();
    log.info("Finished Scheduled job for MPGS Onboarding Status Check");
  }
}
