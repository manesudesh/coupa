package ae.network.onboarding.bulk.upload.merchants.service;

import ae.network.onboarding.bulk.upload.merchants.converter.ExcelMerchantToApplicationRequestConverter;
import ae.network.onboarding.bulk.upload.merchants.dto.BulkUploadResponse;
import ae.network.onboarding.bulk.upload.merchants.model.ApplicationRequest;
import ae.network.onboarding.bulk.upload.merchants.model.ExcelMerchant;
import ae.network.onboarding.bulk.upload.merchants.model.RequestStatus;
import ae.network.onboarding.bulk.upload.merchants.repository.ApplicationRequestRepository;
import ae.network.onboarding.bulk.upload.merchants.repository.MpgsApplicationRequestRepository;
import java.io.File;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class BulkUploadService {

  private final FileService fileService;
  private final ExcelMerchantToApplicationRequestConverter converter;
  private final ApplicationRequestRepository applicationRequestRepository;

  public void backupAndProcess() {
    log.info("Bulk uploading of merchants has started");

    List<ExcelMerchant> excelMerchants = fileService.backupNewFiles()
        .stream()
        .map(File::getPath)
        .map(fileService::readMerchants)
        .flatMap(List::stream)
        .collect(Collectors.toList());

    if (!excelMerchants.isEmpty()) {
      List<ApplicationRequest> newApplicationRequests = excelMerchants.stream()
          .peek(
              merchant ->
                  log.info("Excel Merchant that ready to be saved to the database: {}", merchant)
          )
          .map(converter::convert)
          .collect(Collectors.toList());

      applicationRequestRepository.saveAll(newApplicationRequests);

      log.info("Bulk uploading of merchants has finished");
    } else {
      log.info("No new merchants for bulk uploading");
    }
  }

  public BulkUploadResponse getBulkUploadRequests(RequestStatus status, Pageable pageable) {
    Page<ApplicationRequest> applicationRequestsPage
        = applicationRequestRepository.findAllByRequestStatusOrderById(status, pageable);

    return BulkUploadResponse.builder()
        .data(applicationRequestsPage.toList())
        .page(pageable.getPageNumber())
        .count(applicationRequestsPage.getTotalElements())
        .build();
  }
}
