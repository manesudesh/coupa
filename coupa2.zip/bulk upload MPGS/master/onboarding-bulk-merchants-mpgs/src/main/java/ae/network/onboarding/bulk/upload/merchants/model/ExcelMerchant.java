package ae.network.onboarding.bulk.upload.merchants.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@Data
public class ExcelMerchant {

  @NotBlank
  @Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Merchant Id should only consist of alphanumeric string.")
  private String merchantId;
  @NotBlank
  private String merchantName;
  @NotBlank
  private String state;
  @NotBlank
  private String tradingName;
  @NotBlank
  @Pattern(regexp = "[0-9]+", message = "categoryCode must contain only digits")
  private String categoryCode;
  @NotBlank
  private String goodsDescription;
  @NotBlank
  private String street;
  @NotBlank
  private String city;
  @NotBlank
  private String stateProvince;
  @NotBlank
  @Pattern(regexp = "[0-9]+", message = "postalCode must contain only digits")
  private String postalCode;
  @NotBlank
  private String countryCode;
  @NotBlank
  private String contactName;
  @NotBlank
  @Pattern(regexp = "^\\+?[0-9]+$", message = "phone must contain only digits and, optionally, a leading '+'")
  private String phone;
  @NotBlank
  @Email
  private String email;
  @NotBlank
  private String currency;
  @NotBlank
  private String cardType;
  @NotBlank
  private String terminalId;
}

