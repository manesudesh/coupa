package ae.network.onboarding.bulk.upload.merchants.model;

public enum RequestStatus {

  NEW,
  SENT_TO_ORCHESTRATION,
  ORCHESTRATION_FAILED,
  VALIDATION_FAILED,
  MPGS_COMPLETED;
}
