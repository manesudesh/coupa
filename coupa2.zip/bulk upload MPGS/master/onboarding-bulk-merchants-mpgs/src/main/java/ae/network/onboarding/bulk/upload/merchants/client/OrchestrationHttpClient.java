package ae.network.onboarding.bulk.upload.merchants.client;

import ae.network.onboarding.bulk.upload.merchants.config.OrchestrationProperties;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@RequiredArgsConstructor
@Slf4j
public class OrchestrationHttpClient {

  private static final String USER_AGENT = "Mozilla/5.0";
  private static final String USERNAME = "username";
  private static final String PASSWORD = "password";

  private final RestTemplate restTemplate;
  private final OrchestrationProperties orchestrationProperties;
  private final AtomicReference<String> currentToken = new AtomicReference<>();

  public String doOnboardRequest(String onboardRequestBody) {
    ResponseEntity<String> response = executeOnboardRequest(onboardRequestBody);
    log.info(
        "Onboarding ResponseCode: {}, Response: {}",
        response.getStatusCode().value(),
        response.getBody()
    );
    return response.getStatusCode().value() == HttpStatus.OK.value() ? response.getBody() : null;
  }

  private ResponseEntity<String> executeOnboardRequest(String requestBody) {
    String authorizationToken = generateToken();

    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setBearerAuth(authorizationToken);
    headers.add(HttpHeaders.USER_AGENT, USER_AGENT);

    UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(
        orchestrationProperties.getOnboardingCreateUrl()
    );

    try {
      return executeRequest(builder.toUriString(), requestBody, headers);
    } catch (HttpClientErrorException ex) {
      if (ex.getStatusCode().value() == HttpStatus.UNAUTHORIZED.value()) {
        log.info("Token was expired");
        currentToken.set("");
        headers.setBearerAuth(generateToken());
        return executeRequest(builder.toUriString(), requestBody, headers);
      } else {
        log.error("HTTP Client Error: {}", ex.getMessage());
        throw new RuntimeException(ex);
      }
    }
  }

  private String generateToken() {
    String savedToken = currentToken.get();

    if (!Objects.isNull(savedToken) && !savedToken.isEmpty()) {
      log.info("Return existing token");
      return savedToken;
    } else {
      log.info("Generating new token");

      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
      headers.add(HttpHeaders.USER_AGENT, USER_AGENT);

      UriComponentsBuilder builder = UriComponentsBuilder
          .fromHttpUrl(orchestrationProperties.getOnboardingLoginUrl())
          .queryParam(USERNAME, orchestrationProperties.getOnboardingUsername())
          .queryParam(PASSWORD, orchestrationProperties.getOnboardingPassword());

      String generatedToken = restTemplate.exchange(
          builder.toUriString(),
          HttpMethod.POST,
          new HttpEntity<>(headers),
          String.class
      ).getBody();

      currentToken.set(generatedToken);
      return generatedToken;
    }
  }

  private ResponseEntity<String> executeRequest(String url, String requestBody, HttpHeaders headers) {
    return restTemplate.exchange(
        url,
        HttpMethod.POST,
        new HttpEntity<>(requestBody, headers),
        String.class);
  }
}
