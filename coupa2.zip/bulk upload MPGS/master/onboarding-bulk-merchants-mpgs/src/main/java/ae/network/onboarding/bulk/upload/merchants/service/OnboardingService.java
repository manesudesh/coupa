package ae.network.onboarding.bulk.upload.merchants.service;

import ae.network.onboarding.bulk.upload.merchants.config.BulkUploadProperties;
import ae.network.onboarding.bulk.upload.merchants.model.ApplicationRequest;
import ae.network.onboarding.bulk.upload.merchants.model.OnboardResult;
import ae.network.onboarding.bulk.upload.merchants.model.RequestStatus;
import ae.network.onboarding.bulk.upload.merchants.repository.ApplicationRequestRepository;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class OnboardingService {

  private final ApplicationRequestRepository applicationRequestRepository;
  private final OrchestrationService orchestrationService;
  private final BulkUploadProperties bulkUploadProperties;

  public void onboard() {
    List<ApplicationRequest> applicationRequests = applicationRequestRepository.findAllByRequestStatusOrderById(
        RequestStatus.NEW,
        Pageable.ofSize(bulkUploadProperties.getBatchSize())
    ).toList();

    log.info("Applications to process: {}", applicationRequests);

    applicationRequests.forEach(this::createOnboardingApplicationRequest);

    applicationRequestRepository.saveAll(applicationRequests);
  }

  private void createOnboardingApplicationRequest(ApplicationRequest applicationRequest) {
    try {
      OnboardResult onboardResult = orchestrationService.createApplication(applicationRequest);
      applicationRequest.setOnboardResult(onboardResult);
      applicationRequest.setRequestStatus(RequestStatus.SENT_TO_ORCHESTRATION);
      log.info(
          "Sent to Orchestration: applicationId={}, orchestrationResponse={}",
          applicationRequest.getId(),
          onboardResult.getResponse()
      );
    } catch (Exception e) {
      doFailOrRetryRequest(applicationRequest, e);
    }
  }

  private void doFailOrRetryRequest(ApplicationRequest applicationRequest, Exception e) {
    if (applicationRequest.getRetriesCount() == null) {
      applicationRequest.setRetriesCount(0);
    } else {
      applicationRequest.setRetriesCount(applicationRequest.getRetriesCount() + 1);
    }

    if (applicationRequest.getRetriesCount() < bulkUploadProperties.getRetries()) {
      log.info(
          "Error during sending to Orchestration: applicationId={}, retries={}, error={}",
          applicationRequest.getId(),
          applicationRequest.getRetriesCount(),
          e.getMessage()
      );
    } else {
      log.error(
          "Exceeded number of retries during sending to Orchestration: applicationId={}, error={}",
          applicationRequest.getId(),
          e.getMessage()
      );
      applicationRequest.setProcessingError(
          "Error during sending to Orchestration: " + e.getMessage()
      );
      applicationRequest.setRequestStatus(RequestStatus.ORCHESTRATION_FAILED);
    }
  }
}
