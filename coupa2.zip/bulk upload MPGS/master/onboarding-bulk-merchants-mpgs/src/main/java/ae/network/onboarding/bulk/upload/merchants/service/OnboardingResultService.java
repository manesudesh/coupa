package ae.network.onboarding.bulk.upload.merchants.service;

import static ae.network.onboarding.bulk.upload.merchants.model.RequestStatus.MPGS_COMPLETED;

import ae.network.onboarding.bulk.upload.merchants.config.BulkUploadProperties;
import ae.network.onboarding.bulk.upload.merchants.model.ApplicationRequest;
import ae.network.onboarding.bulk.upload.merchants.model.MpgsApplicationRequest;
import ae.network.onboarding.bulk.upload.merchants.model.RequestStatus;
import ae.network.onboarding.bulk.upload.merchants.model.Task;
import ae.network.onboarding.bulk.upload.merchants.model.TaskName;
import ae.network.onboarding.bulk.upload.merchants.model.TaskStatus;
import ae.network.onboarding.bulk.upload.merchants.repository.ApplicationRequestRepository;
import ae.network.onboarding.bulk.upload.merchants.repository.MpgsApplicationRequestRepository;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.IterableUtils;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class OnboardingResultService {

  private final ApplicationRequestRepository repository;
  private final MpgsApplicationRequestRepository mpgsRepository;
  private final BulkUploadProperties bulkUploadProperties;

  public void onboardResultCheck() {
    List<ApplicationRequest> applicationRequests = repository.findAllByRequestStatusOrderById(
        RequestStatus.SENT_TO_ORCHESTRATION,
        Pageable.ofSize(bulkUploadProperties.getBatchSize())
    ).toList();
    List<MpgsApplicationRequest> mpgsApplicationRequests = mpgsRepository.findAllByApplicationId(
        applicationRequests.stream()
            .map(applicationRequest -> applicationRequest.getOnboardResult().getApplicationId())
            .collect(Collectors.toList())
    );

    if (!mpgsApplicationRequests.isEmpty()) {
      List<ApplicationRequest> applicationsForSaving = applicationRequests.stream()
          .filter(applicationRequest -> isMpgsApplicationRequestCompleted(
              mpgsApplicationRequests,
              applicationRequest.getOnboardResult().getApplicationId()
          ))
          .collect(Collectors.toList());

      applicationsForSaving.forEach(applicationRequest -> {
        applicationRequest.setRequestStatus(MPGS_COMPLETED);
      });

      log.info("Completed application requests: {}", applicationsForSaving);

      repository.saveAll(applicationRequests);
    } else {
      log.info("MPGS Application Requests not found for processing");
    }
  }

  private boolean isMpgsApplicationRequestCompleted(
      List<MpgsApplicationRequest> mpgsApplicationRequests,
      String applicationId
  ) {
    boolean isCompleted = false;
    MpgsApplicationRequest foundMpgsApplicationRequest = IterableUtils.find(
        mpgsApplicationRequests,
        mpgsApplicationRequest -> mpgsApplicationRequest.getApplicationId().equals(applicationId)
    );

    if (Objects.nonNull(foundMpgsApplicationRequest)) {
      log.info(
          "MPGS application found {} for processing with applicationId={}",
          foundMpgsApplicationRequest,
          applicationId
      );

      Task foundCompletedTask = IterableUtils.find(
          foundMpgsApplicationRequest.getTasks(),
          task -> task.getName().equals(TaskName.ONBOARDING_MERCHANT.name())
              && task.getTaskStatus().equals(TaskStatus.COMPLETED)
      );

      isCompleted = Objects.nonNull(foundCompletedTask);
    } else {
      log.info("No MPGS application found for request with applicationId={}", applicationId);
    }

    return isCompleted;
  }
}
