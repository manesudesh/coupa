package ae.network.onboarding.bulk.upload.merchants.converter;

import ae.network.onboarding.bulk.upload.merchants.config.OrchestrationProperties;
import ae.network.onboarding.bulk.upload.merchants.dto.Address;
import ae.network.onboarding.bulk.upload.merchants.dto.AddressType;
import ae.network.onboarding.bulk.upload.merchants.dto.Application;
import ae.network.onboarding.bulk.upload.merchants.dto.Merchant;
import ae.network.onboarding.bulk.upload.merchants.dto.MerchantService;
import ae.network.onboarding.bulk.upload.merchants.dto.MerchantType;
import ae.network.onboarding.bulk.upload.merchants.dto.OnboardingRequest;
import ae.network.onboarding.bulk.upload.merchants.dto.Payload;
import ae.network.onboarding.bulk.upload.merchants.dto.RequestType;
import ae.network.onboarding.bulk.upload.merchants.dto.ServiceType;
import ae.network.onboarding.bulk.upload.merchants.dto.Terminal;
import ae.network.onboarding.bulk.upload.merchants.model.ApplicationRequest;
import ae.network.onboarding.bulk.upload.merchants.model.ExcelMerchant;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@RequiredArgsConstructor
public class ApplicationRequestToOnboardingRequestConverter implements
    Converter<ApplicationRequest, OnboardingRequest> {

  private static final String UNITED_ARAB_EMIRATES_STATE = "United Arab Emirates";

  private final OrchestrationProperties orchestrationProperties;

  @Override
  public OnboardingRequest convert(ApplicationRequest applicationRequest) {
    String requestId = UUID.randomUUID().toString();

    Merchant merchant = buildMerchant(applicationRequest);

    Application application = Application.builder()
        .merchants(Collections.singletonList(merchant))
        .build();

    List<Application> applications = Collections.singletonList(application);

    Payload payload = Payload.builder()
        .applications(applications)
        .build();

    return OnboardingRequest
        .builder()
        .acquirer(orchestrationProperties.getOnboardingAcquirer())
        .username(orchestrationProperties.getOnboardingUsername())
        .requestId(requestId)
        .skipCallback(Boolean.TRUE)
        .requestType(RequestType.ONBOARDING)
        .payload(payload)
        .build();
  }

  private Merchant buildMerchant(ApplicationRequest applicationRequest) {
    ExcelMerchant excelMerchant = applicationRequest.getExcelMerchant();

    Terminal terminal = Terminal.builder()
        .terminalId(excelMerchant.getTerminalId())
        .build();

    Address address = Address.builder()
        .addressType(AddressType.DEFAULT)
        .countryCode(excelMerchant.getCountryCode())
        .city(excelMerchant.getCity())
        .state(UNITED_ARAB_EMIRATES_STATE)
        .postalCode(excelMerchant.getPostalCode())
        .phone(excelMerchant.getPhone())
        .pobox(excelMerchant.getPostalCode())
        .email(excelMerchant.getEmail())
        .build();

    MerchantService merchantService = MerchantService.builder()
        .serviceType(ServiceType.MPGS)
        .build();

    return Merchant.builder()
        .merchantId(excelMerchant.getMerchantId())
        .merchantName(excelMerchant.getMerchantName())
        .legalName(excelMerchant.getTradingName())
        .mcc(Integer.parseInt(excelMerchant.getCategoryCode()))
        .merchantCurrency(excelMerchant.getCurrency())
        .merchantType(MerchantType.POS)
        .terminals(Collections.singletonList(terminal))
        .addresses(Collections.singletonList(address))
        .services(Collections.singletonList(merchantService))
        .build();
  }
}
