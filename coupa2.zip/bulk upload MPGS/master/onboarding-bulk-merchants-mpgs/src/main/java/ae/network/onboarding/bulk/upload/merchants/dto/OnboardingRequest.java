package ae.network.onboarding.bulk.upload.merchants.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OnboardingRequest {

  private String acquirer;
  private String username;
  private String requestId;
  private Boolean skipCallback;
  private RequestType requestType;
  private Payload payload;
}
