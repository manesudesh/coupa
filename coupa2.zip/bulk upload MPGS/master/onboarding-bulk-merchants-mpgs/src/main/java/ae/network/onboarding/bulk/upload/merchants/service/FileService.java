package ae.network.onboarding.bulk.upload.merchants.service;

import ae.network.onboarding.bulk.upload.merchants.config.BulkUploadProperties;
import ae.network.onboarding.bulk.upload.merchants.converter.RowsToExcelMerchantConverter;
import ae.network.onboarding.bulk.upload.merchants.model.ExcelMerchant;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class FileService {

  private final RowsToExcelMerchantConverter converter;
  private final BulkUploadProperties bulkUploadProperties;

  @PostConstruct
  public void init() {
    File inputFolder = new File(bulkUploadProperties.getMerchantsInputFolderPath());
    log.info("Input folder path: {}, exists={}", inputFolder.toPath().toAbsolutePath(),
        inputFolder.exists());
    if (!inputFolder.exists()) {
      inputFolder.mkdirs();
      log.info("Folder {} created", inputFolder.toPath().toAbsolutePath());
    }

    File backupFolder = new File(bulkUploadProperties.getMerchantsBackupFolderPath());
    log.info("Backup folder path: {}, exists={}", backupFolder.toPath().toAbsolutePath(),
        backupFolder.exists());
    if (!backupFolder.exists()) {
      backupFolder.mkdirs();
      log.info("Folder {} created", backupFolder.toPath().toAbsolutePath());
    }
  }

  public List<File> backupNewFiles() {
    boolean folderExclusivelyLocked = tryLockFolder(
        Paths.get(bulkUploadProperties.getMerchantsBackupFolderPath()));

    if (!folderExclusivelyLocked) {
      log.info("Skip backup files as folder is already locked");
      return Collections.emptyList();
    }

    try {
      return backupAndGetNewFiles();
    } finally {
      unlockFolder(Paths.get(bulkUploadProperties.getMerchantsBackupFolderPath()));
    }
  }

  public List<ExcelMerchant> readMerchants(String path) {
    try (InputStream inputStream = new FileInputStream(path);
        Workbook workbook = new XSSFWorkbook(inputStream)) {

      List<ExcelMerchant> excelMerchants = new ArrayList<>();
      Sheet sheet = workbook.getSheetAt(0);
      Row headerRow = sheet.getRow(0);

      for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
        Row merchantRow = sheet.getRow(i);
        excelMerchants.add(converter.convert(Pair.of(merchantRow, headerRow)));
      }

      return excelMerchants;
    } catch (IOException e) {
      log.error("Error when reading merchants from excel sheet: {}", e.getMessage());
      throw new RuntimeException(e);
    }
  }

  private List<File> backupAndGetNewFiles() {
    List<File> inputFiles = getFiles(bulkUploadProperties.getMerchantsInputFolderPath());
    List<File> backupFiles = getFiles(bulkUploadProperties.getMerchantsBackupFolderPath());

    Set<String> backupFileNames = backupFiles.stream()
        .map(File::getName)
        .collect(Collectors.toSet());

    List<File> newInputFiles = inputFiles.stream()
        .filter(inputFile -> !backupFileNames.contains(inputFile.getName()))
        .collect(Collectors.toList());

    newInputFiles.forEach(newFile ->
        copyFile(newFile.toPath(),
            new File(bulkUploadProperties.getMerchantsBackupFolderPath()).toPath()));

    return newInputFiles;
  }

  private void copyFile(Path source, Path targetDirectory) {
    Path target = targetDirectory.resolve(source.getFileName());
    try {
      Files.copy(source, target);
    } catch (IOException e) {
      log.error("File copying is failed: {}", e.getMessage());
      throw new RuntimeException(e);
    }
  }

  private List<File> getFiles(String path) {
    return Stream.of(Objects.requireNonNull(new File(path).listFiles()))
        .collect(Collectors.toList());
  }

  private boolean tryLockFolder(Path path) {
    Optional<File> maybeLockFile = getFolderLockFile(path);
    boolean lockExists = maybeLockFile.isPresent();
    boolean canLock = !lockExists || isLockExpired(maybeLockFile.get());

    if (!canLock) {
      log.info("Cant lock folder. lockExists={}, canLock={}", lockExists, canLock);
      return false;
    } else {
      return lockFolder(path);
    }
  }

  private boolean lockFolder(Path path) {
    try {
      unlockFolder(path);

      Files.write(path.resolve("folder.lock"), (String.valueOf(new Date().getTime())).getBytes());
      return true;
    } catch (IOException e) {
      log.error("Error while writing lock file", e);
      return false;
    }
  }

  private void unlockFolder(Path path) {
    getFolderLockFile(path).ifPresent(File::delete);
  }

  private boolean isLockExpired(File lockFile) {
    // let the locking be huge (minutes, not seconds) to eliminate race conditions
    int lockTimeout = 5;

    try {
      String lockTimestamp = Files.readAllLines(lockFile.toPath()).get(0);
      LocalDateTime lockTime = Instant
          .ofEpochMilli(Long.parseLong(lockTimestamp))
          .atZone(ZoneId.systemDefault())
          .toLocalDateTime();

      LocalDateTime expiryTime = lockTime.plusMinutes(lockTimeout);

      return LocalDateTime.now().isAfter(expiryTime);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  private Optional<File> getFolderLockFile(Path lockFolder) {
    return Arrays.stream(lockFolder.toFile().listFiles())
        .filter(file -> file.getName().endsWith("folder.lock"))
        .findFirst();
  }
}
