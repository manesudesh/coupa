package ae.network.onboarding.bulk.upload.merchants.dto;

import ae.network.onboarding.bulk.upload.merchants.model.ApplicationRequest;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BulkUploadResponse {

  private final Long count;
  private final Integer page;
  private final List<ApplicationRequest> data;
}
