package ae.network.onboarding.bulk.upload.merchants.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.Date;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class OnboardingResponse {

  private String requestId;
  private String applicationId;
  private String requestStatus;
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
  private Date lastUpdate;

}