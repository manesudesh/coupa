package ae.network.onboarding.octopus.rabbitmq.consumer;

import ae.network.onboarding.octopus.model.failure.FailedMessage;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DataMongoTest
class DeadLetterConsumerTest {
    @Autowired
    MongoTemplate mongoTemplate;

    @Test
    void onMessage() {
        DeadLetterConsumer deadLetterConsumer = new DeadLetterConsumer(mongoTemplate);
        Message message = new Message("{message: 'Hello'}".getBytes(), new MessageProperties());
        deadLetterConsumer.onMessage(message);
        List<FailedMessage> failedMessages = mongoTemplate.find(new Query(), FailedMessage.class);
        assertEquals(failedMessages.size(), 1);
    }
}