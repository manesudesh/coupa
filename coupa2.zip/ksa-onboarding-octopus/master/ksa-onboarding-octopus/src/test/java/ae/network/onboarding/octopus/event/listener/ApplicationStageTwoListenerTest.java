package ae.network.onboarding.octopus.event.listener;

import ae.network.onboarding.octopus.database.service.ApplicationRequestService;
import ae.network.onboarding.octopus.event.ApplicationCompletedEvent;
import ae.network.onboarding.octopus.event.StageOneCompletedEvent;
import ae.network.onboarding.octopus.event.StageOneSkippedEvent;
import ae.network.onboarding.octopus.model.reply.ProcessingResult;
import ae.network.onboarding.octopus.model.request.*;
import ae.network.onboarding.octopus.rabbitmq.RabbitService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import java.util.Collections;
import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
class ApplicationStageTwoListenerTest {

    public static final String TYME = "TYME";
    private ApplicationStageTwoListener listener;

    @Mock
    private ApplicationEventPublisher applicationEventPublisher;

    @Mock
    private ApplicationRequestService service;

    @Mock
    private RabbitService rabbitService;

    @BeforeEach
    void init() {
        listener = new ApplicationStageTwoListener(rabbitService, applicationEventPublisher, service);
    }

    @Test
    void testOnboardingStageTwo() {
        final ApplicationRequest applicationRequest = new ApplicationRequest();
        applicationRequest.setAuthorizedSystems(BackendSystem.getStageTwoSystems());
        applicationRequest.setApplicationId("app-id");
        applicationRequest.setAcquirer(TYME);
        applicationRequest.setRequestStatus(RequestStatus.STAGE_ONE_COMPLETED);
        listener.onApplicationEvent(new StageOneCompletedEvent(applicationRequest));
        Mockito.verify(rabbitService, times(BackendSystem.getStageTwoSystems().size())).sendMessage(any(), any());
        assertEquals(RequestStatus.ONBOARDING_STAGE_TWO, applicationRequest.getRequestStatus());
    }

    @Test
    void testStageTwoSkipped() {
        final ApplicationRequest applicationRequest = new ApplicationRequest();
        applicationRequest.setAuthorizedSystems(BackendSystem.getStageTwoSystems());
        applicationRequest.setApplicationId("app-id");
        applicationRequest.setAcquirer(TYME);
        final HashMap<BackendSystem, ProcessingResult> resultsMap = buildResultsMap(TaskStatus.COMPLETED);
        applicationRequest.setResultsMap(resultsMap);
        applicationRequest.setRequestStatus(RequestStatus.STAGE_ONE_COMPLETED);
        listener.onApplicationEvent(new StageOneSkippedEvent(applicationRequest));
        Mockito.verify(rabbitService, times(0)).sendMessage(any(), any());
        Mockito.verify(applicationEventPublisher, times(1)).publishEvent(any(ApplicationCompletedEvent.class));
    }

    @Test
    void testStageTwoFailedBefore() {
        final ApplicationRequest applicationRequest = new ApplicationRequest();
        applicationRequest.setAuthorizedSystems(BackendSystem.getStageTwoSystems());
        applicationRequest.setApplicationId("app-id");
        applicationRequest.setAcquirer(TYME);
        final HashMap<BackendSystem, ProcessingResult> resultsMap = buildResultsMap(TaskStatus.FAILED);
        applicationRequest.setResultsMap(resultsMap);
        listener.onApplicationEvent(new StageOneSkippedEvent(applicationRequest));
        Mockito.verify(rabbitService, times(BackendSystem.getStageTwoSystems().size())).sendMessage(any(), any());
        assertEquals(RequestStatus.ONBOARDING_STAGE_TWO, applicationRequest.getRequestStatus());
    }

    private HashMap<BackendSystem, ProcessingResult> buildResultsMap(TaskStatus taskStatus) {
        final HashMap<BackendSystem, ProcessingResult> resultsMap = new HashMap<>();
        for (BackendSystem backendSystem : BackendSystem.getStageTwoSystems()) {
            final Task task = new Task();
            task.setTaskStatus(taskStatus);
            resultsMap.put(backendSystem,
                    ProcessingResult.builder().tasks(Collections.singletonList(task)).finalStatus(taskStatus).build());
        }
        return resultsMap;
    }
}