package ae.network.onboarding.octopus.rabbitmq.processors;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class CorrelationDataProcessorTest {

    private final CorrelationDataProcessor dataProcessor = new CorrelationDataProcessor(Mockito.mock(RabbitTemplate.class), "test-app");

    @Test
    void testCorrelationIdAdded() {
        Message message = new Message("Hi".getBytes(), new MessageProperties());
        message = dataProcessor.postProcessMessage(message);
        assertNotNull(message.getMessageProperties().getCorrelationId());
    }

    @Test
    void testCorrelationIdNotOverriden() {
        MessageProperties messageProperties = new MessageProperties();
        String correlationId = "id";
        messageProperties.setCorrelationId(correlationId);
        Message message = new Message("Hi".getBytes(), messageProperties);
        message = dataProcessor.postProcessMessage(message);
        assertEquals(correlationId, message.getMessageProperties().getCorrelationId());
    }
}