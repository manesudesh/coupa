package ae.network.onboarding.octopus;

import ae.network.onboarding.octopus.config.DummyRabbit;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;

@SpringBootTest
@Import(DummyRabbit.class)
class OnboardingOctopusApplicationTests {

    @Test
    void contextLoads() {
    }

}
