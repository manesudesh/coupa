package ae.network.onboarding.octopus.rabbitmq.consumer;

import ae.network.onboarding.octopus.config.DummyRabbit;
import ae.network.onboarding.octopus.config.DummyUserDetails;
import ae.network.onboarding.octopus.database.repository.ApplicationRequestRepository;
import ae.network.onboarding.octopus.database.service.ApplicationRequestService;
import ae.network.onboarding.octopus.event.ApplicationCompletedEvent;
import ae.network.onboarding.octopus.event.ApplicationFailedEvent;
import ae.network.onboarding.octopus.exception.ApplicationNotFoundException;
import ae.network.onboarding.octopus.exception.MessageRejectionException;
import ae.network.onboarding.octopus.model.reply.ApplicationUpdate;
import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.model.request.BackendSystem;
import ae.network.onboarding.octopus.model.request.RequestStatus;
import ae.network.onboarding.octopus.model.request.TaskStatus;
import ae.network.onboarding.octopus.rabbitmq.service.RabbitServiceImpl;
import ae.network.onboarding.octopus.security.UserDetails;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Import;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

import static ae.network.onboarding.octopus.model.request.BackendSystem.KSA_NGO;
import static ae.network.onboarding.octopus.model.request.BackendSystem.KSA_WAY4;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@DataMongoTest
@Import({DummyRabbit.class, DummyUserDetails.class})
class ApplicationUpdateConsumerTest {

    private static final String JSON_PATH = "src/test/resources/json/";
    private static long incrementalId = 1L;
    @Autowired
    ApplicationRequestRepository repository;
    @Autowired
    UserDetails userDetails;
    private String testApplicationId;
    @MockBean
    private RabbitServiceImpl rabbitService;
    @Mock
    private ApplicationEventPublisher applicationEventPublisher;
    private ApplicationRequestService requestService;
    private ApplicationUpdateConsumer updateConsumer;

    @BeforeEach
    void init() {
        requestService = new ApplicationRequestService(repository, applicationEventPublisher, userDetails);
        updateConsumer = new ApplicationUpdateConsumer(requestService, rabbitService, applicationEventPublisher);

        // save existing application
        ApplicationRequest request = new ApplicationRequest();
        request.setRequestId(String.valueOf(incrementalId++));
        testApplicationId = requestService.createApplication(request).getApplicationId();
        System.out.println("id: " + testApplicationId);
    }

    @Test
    void testInvalidApplicationThrowsMessageRejection() throws JsonProcessingException {

        Message message = getUpdateMessage("ID_NOT_THERE", KSA_WAY4, TaskStatus.COMPLETED);

        assertThrows(MessageRejectionException.class, () -> updateConsumer.onMessage(message));
    }

    @Test
    void testInvalidJsonThrowsMessageRejection() {
        Message message = new Message("Invalid JSON".getBytes(), new MessageProperties());

        assertThrows(MessageRejectionException.class, () -> updateConsumer.onMessage(message));
    }

    @Test
    void testCompletedApplicationThrowsMessageRejection() throws JsonProcessingException {
        ApplicationRequest request = requestService.findByApplicationId(testApplicationId).orElse(new ApplicationRequest());
        request.setRequestStatus(RequestStatus.COMPLETED);
        requestService.saveOrUpdateApplication(request);
        Message message = getUpdateMessage(KSA_NGO, TaskStatus.COMPLETED);

        assertThrows(MessageRejectionException.class, () -> updateConsumer.onMessage(message));
    }

    @Test
    void testApplicationUpdated() throws JsonProcessingException {
        Message message = getUpdateMessage(KSA_NGO, TaskStatus.COMPLETED);
        updateConsumer.onMessage(message);
        final ApplicationRequest application = requestService.findByApplicationId(testApplicationId)
                .orElseThrow(ApplicationNotFoundException::new);
        assertFalse(application.getResultsMap().get(KSA_NGO).getTasks().isEmpty());
    }

    private Message getUpdateMessage(BackendSystem system, TaskStatus taskStatus) throws JsonProcessingException {
        return getUpdateMessage(testApplicationId, system, taskStatus);
    }

    private Message getUpdateMessage(String applicationId, BackendSystem system, TaskStatus taskStatus) throws JsonProcessingException {
        ApplicationUpdate applicationUpdate = createApplicationUpdate(applicationId, system, taskStatus);

        ObjectMapper objectMapper = new ObjectMapper();
        String content = objectMapper.writeValueAsString(applicationUpdate);
        return new Message(content.getBytes(), new MessageProperties());
    }

    @Test
    void testFailedEventPublished() throws JsonProcessingException {

        Message message = getUpdateMessage(KSA_NGO, TaskStatus.FAILED);

        updateConsumer.onMessage(message);
        verify(applicationEventPublisher, times(1)).publishEvent(any(ApplicationFailedEvent.class));
    }

    @Test
    void testApplicationCompletedOneStage() throws JsonProcessingException {
        List<BackendSystem> stageOneSystems = Arrays.asList(KSA_NGO, KSA_WAY4);
        for (BackendSystem system : stageOneSystems) {
            Message message = getUpdateMessage(system, TaskStatus.COMPLETED);
            updateConsumer.onMessage(message);
        }
        verify(applicationEventPublisher, times(1)).publishEvent(any(ApplicationCompletedEvent.class));
    }

    @Test
    void testApplicationCompletedEventPublished() throws JsonProcessingException {
        final ApplicationRequest application = requestService.findByApplicationId(testApplicationId)
                .orElseThrow(ApplicationNotFoundException::new);
        for (BackendSystem system : application.getAuthorizedSystems()) {
            Message message = getUpdateMessage(system, TaskStatus.COMPLETED);
            updateConsumer.onMessage(message);
        }
        verify(applicationEventPublisher, atLeastOnce()).publishEvent(any(ApplicationCompletedEvent.class));
    }

    @Test
    void testMessageRetryForRecoverableError() throws JsonProcessingException {
        ApplicationUpdateConsumer brokenConsumer = new ApplicationUpdateConsumer(null, rabbitService, applicationEventPublisher);
        Message message = getUpdateMessage(KSA_WAY4, TaskStatus.COMPLETED);
        brokenConsumer.onMessage(message);
        verify(rabbitService, times(1)).retryMessage(any());
    }

    private ApplicationUpdate createApplicationUpdate(String applicationId, BackendSystem source, TaskStatus taskStatus) {
        try {
            String messageContent = new String(Files.readAllBytes(Paths.get(JSON_PATH + "applicationUpdate.json")));
            ApplicationUpdate reply = new ObjectMapper().readValue(messageContent, ApplicationUpdate.class);
            reply.setApplicationId(applicationId);
            reply.setBackendSystem(source);
            reply.getProcessingResult().setFinalStatus(taskStatus);
            return reply;
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}