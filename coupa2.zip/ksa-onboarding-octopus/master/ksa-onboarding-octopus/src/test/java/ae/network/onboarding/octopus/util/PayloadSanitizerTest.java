package ae.network.onboarding.octopus.util;

import ae.network.onboarding.octopus.config.DummyRabbit;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@Import({DummyRabbit.class})
@DisplayName("Testing PayloadSanitizer")
class PayloadSanitizerTest {

    private static final String ROOT_DIR = "src/test/resources/json/sanitizer/";
    private static final ObjectMapper mapper = new ObjectMapper();

    private static final String invalidChars = "[^\\w\\s]";
    private static final Pattern pattern = Pattern.compile(invalidChars, Pattern.CASE_INSENSITIVE);
    private static final int defaultMaxLength = 40;
    private static final Function<String, Boolean> customValidator = (s) -> !StringUtils.hasLength(s) || (s.length() <= defaultMaxLength && !pattern.matcher(s).find());
    private static final Function<String, String> customSanitizer = (s) -> {
        String result = s.replaceAll(invalidChars, "").trim().replaceAll(" +", " ");
        if (result.length() <= defaultMaxLength) {
            return result;
        } else {
            return result.substring(0, defaultMaxLength);
        }
    };


    @Test
    @DisplayName("when source json is VALID for default configurations")
    void when_source_json_is_valid_for_default_configurations() throws IOException {
        String sourceJson = toJsonString("sanitizer-valid-default-config.json");

        PayloadSanitizer payloadSanitizer = new PayloadSanitizer();

        // act
        String sanitizedJson = payloadSanitizer.sanitize(sourceJson);

        // assert
        assertTrue(sourceJson.trim().equalsIgnoreCase(sanitizedJson.trim()), () -> "Both source json and sanitized json should be the same");
    }

    @Test
    @DisplayName("when source json is INVALID for default configurations")
    void when_source_json_is_invalid_for_default_configurations() throws IOException {
        // prepare
        String sourceJson = toJsonString("sanitizer-invalid-default-config.json");

        PayloadSanitizer payloadSanitizer = new PayloadSanitizer();

        // act
        String sanitizedJson = payloadSanitizer.sanitize(sourceJson);

        JsonNode sanitizedJsonNode = mapper.readTree(sanitizedJson);
        String actualChainName = sanitizedJsonNode.at("/payload/applications/0/chain/chainName").toString();
        String expectedChainName = "\"this is an 009 invalid chain name\"";
        String actualMerchantName = sanitizedJsonNode.at("/payload/applications/0/merchants/0/merchantName").toString();
        String expectedMerchantName = "\"this merchant name123 i\"";
        String actualLegalName = sanitizedJsonNode.at("/payload/applications/0/merchants/0/legalName").toString();
        String expectedLegalName = "\"an 009 invalid legal name\"";

        ArrayNode actualAddressLineArray1 = (ArrayNode) sanitizedJsonNode.at("/payload/applications/0/merchants/0/addresses/0/addressLines");
        List<String> actualAddressLineArrayList1 = mapper.readerFor(new TypeReference<List<String>>() {
        }).readValue(actualAddressLineArray1);
        ArrayNode actualAddressLineArray2 = (ArrayNode) sanitizedJsonNode.at("/payload/applications/0/merchants/0/addresses/1/addressLines");
        List<String> actualAddressLineArrayList2 = mapper.readerFor(new TypeReference<List<String>>() {
        }).readValue(actualAddressLineArray2);
        String expectedAddressLine1 = "amp this is amp obviously 456789 an inva";
        String expectedAddressLine2 = "this too amp is amp an 456789 invalid ad";

        // assert
        assertAll(
                () -> assertFalse(sourceJson.trim().equalsIgnoreCase(sanitizedJson.trim()), () -> "Source json and sanitized json should NOT be the same"),
                () -> assertEquals(expectedChainName, actualChainName, () -> "chain name should be: " + expectedChainName),
                () -> assertEquals(expectedMerchantName, actualMerchantName, () -> "merchant name should be: " + expectedMerchantName),
                () -> assertEquals(expectedLegalName, actualLegalName, () -> "legal name should be: " + expectedLegalName),
                () -> assertTrue(actualAddressLineArrayList1.contains(expectedAddressLine1), () -> "address [0] addressLines should contain: " + expectedAddressLine1),
                () -> assertTrue(actualAddressLineArrayList2.contains(expectedAddressLine2), () -> "address [1] addressLines should contain: " + expectedAddressLine2)
        );
    }

    @Test
    @DisplayName("when source json is VALID for custom configurations")
    void when_source_json_is_valid_for_custom_configurations() throws IOException {
        // prepare
        String sourceJson = toJsonString("sanitizer-valid-custom-config.json");

        final Set<PayloadSanitizer.Sanitizer> sanitizers = new HashSet<>();
        sanitizers.add(PayloadSanitizer.Sanitizer.builder()
                .enabled(false)
                .parent((s) -> "/")
                .name("aField")
                .path("/aField")
                .validate(customValidator)
                .sanitize(customSanitizer)
                .build());
        sanitizers.add(PayloadSanitizer.Sanitizer.builder()
                .enabled(true)
                .parent((s) -> s.replaceAll("/\\bnestField", ""))
                .name("nestField")
                .path("/anObject/nestedObject/nestField")
                .validate(customValidator)
                .sanitize(customSanitizer)
                .build());
        sanitizers.add(PayloadSanitizer.Sanitizer.builder()
                .enabled(true)
                .parent((s) -> s.replaceAll("/\\bnestedArray/\\d", "/nestedArray"))
                .name("nestedArray")
                .index((s) -> Integer.valueOf(s.substring(s.lastIndexOf("/") + 1)))
                .validate(customValidator)
                .sanitize(customSanitizer)
                .path("/anObject/nestedArray")
                .build());

        PayloadSanitizer payloadSanitizer = new PayloadSanitizer(sanitizers);

        // act
        String sanitizedJson = payloadSanitizer.sanitize(sourceJson);

        // assert
        assertTrue(sourceJson.trim().equalsIgnoreCase(sanitizedJson.trim()), () -> "Both source json and sanitized json should be the same");
    }

    @Test
    @DisplayName("when source json is INVALID for custom configurations")
    void when_source_json_is_invalid_for_custom_configurations() throws IOException {
        // prepare
        String sourceJson = toJsonString("sanitizer-invalid-custom-config.json");

        final Set<PayloadSanitizer.Sanitizer> sanitizers = new HashSet<>();
        sanitizers.add(PayloadSanitizer.Sanitizer.builder()
                .enabled(true)
                .parent((s) -> "/")
                .name("aField")
                .path("/aField")
                .validate(customValidator)
                .sanitize(customSanitizer)
                .build());
        sanitizers.add(PayloadSanitizer.Sanitizer.builder()
                .enabled(true)
                .parent((s) -> s.replaceAll("/\\bnestField", ""))
                .name("nestField")
                .path("/anObject/nestedObject/nestField")
                .validate(customValidator)
                .sanitize(customSanitizer)
                .build());
        sanitizers.add(PayloadSanitizer.Sanitizer.builder()
                .enabled(true)
                .parent((s) -> s.replaceAll("/\\bnestedArray/\\d", "/nestedArray"))
                .name("nestedArray")
                .path("/anObject/nestedArray")
                .index((s) -> Integer.valueOf(s.substring(s.lastIndexOf("/") + 1)))
                .validate(customValidator)
                .sanitize(customSanitizer)
                .build());

        PayloadSanitizer payloadSanitizer = new PayloadSanitizer(sanitizers);

        // act
        String sanitizedJson = payloadSanitizer.sanitize(sourceJson);

        JsonNode sanitizedJsonNode = mapper.readTree(sanitizedJson);
        String actualAfield = sanitizedJsonNode.get("aField").toString();
        String expectedAField = "\"a value that is 100 invalid 098765\"";
        String actualNestField = sanitizedJsonNode.at("/anObject/nestedObject/nestField").toString();
        String expectedNestField = "\"a 0987654 nested value 09876 huh\"";
        ArrayNode actualNestedArray = (ArrayNode) sanitizedJsonNode.at("/anObject/nestedArray");

        List<String> actualNestedArrayList = mapper.readerFor(new TypeReference<List<String>>() {
        }).readValue(actualNestedArray);
        String expectedNestedArray1 = "validtwo 45678 index 1 0987";
        String expectedNestedArray2 = "validfour 100 45678 index 3 show";

        // assert
        assertAll(
                () -> assertFalse(sourceJson.trim().equalsIgnoreCase(sanitizedJson.trim()), () -> "Source json and sanitized json should NOT be the same"),
                () -> assertEquals(expectedAField, actualAfield, () -> "aField should be: " + expectedAField),
                () -> assertEquals(expectedNestField, actualNestField, () -> "nestField should be: " + expectedNestField),
                () -> assertTrue(actualNestedArrayList.contains(expectedNestedArray1), () -> "nestedArray should contain: " + expectedNestedArray1),
                () -> assertTrue(actualNestedArrayList.contains(expectedNestedArray2), () -> "nestedArray should contain: " + expectedNestedArray2)
        );
    }

    @Test
    @DisplayName("when source json is NULL")
    void when_source_json_is_NULL() throws IOException {
        // prepare
        String sourceJson = null;

        PayloadSanitizer payloadSanitizer = new PayloadSanitizer();

        // act
        String sanitizedJson = payloadSanitizer.sanitize(sourceJson);

        // assert
        assertNull(sanitizedJson, () -> "Sanitized json should be NULL");
    }

    private String toJsonString(String s) throws IOException {
        // prepare
        String payload = new String(Files.readAllBytes(Paths.get(ROOT_DIR + s)));
        JsonNode rootNode = mapper.readTree(payload);
        return rootNode.toString();
    }
}