package ae.network.onboarding.octopus.rabbitmq.processors;

import ae.network.onboarding.octopus.exception.MessageRejectionException;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import static ae.network.onboarding.octopus.rabbitmq.message.QueueMessage.DELAY_HEADER;
import static ae.network.onboarding.octopus.rabbitmq.message.QueueMessage.MAX_RETRY_HEADER;
import static ae.network.onboarding.octopus.rabbitmq.processors.MaxRetryProcessor.DELAY_MULTIPLIER;
import static org.junit.jupiter.api.Assertions.*;

class MaxRetryProcessorTest {

    private final MaxRetryProcessor maxRetryProcessor = new MaxRetryProcessor(Mockito.mock(RabbitTemplate.class), 3, 5);

    @Test
    void testHeaderAddedForNewMessage() {
        Message message = new Message("Hi".getBytes(), new MessageProperties());
        message = maxRetryProcessor.postProcessMessage(message);
        assertNotNull(message.getMessageProperties().getHeader(MAX_RETRY_HEADER));
    }

    @Test
    void testRetryAttemptsDecrement() {
        MessageProperties messageProperties = new MessageProperties();
        messageProperties.setHeader(MAX_RETRY_HEADER, 10);
        Message message = new Message("Hi".getBytes(), messageProperties);
        message = maxRetryProcessor.postProcessMessage(message);
        assertEquals(Integer.valueOf(9), message.getMessageProperties().getHeader(MAX_RETRY_HEADER));
    }

    @Test
    void testDelayExponentialIncrease() {
        MessageProperties messageProperties = new MessageProperties();
        messageProperties.setHeader(DELAY_HEADER, 10);
        Message message = new Message("Hi".getBytes(), messageProperties);
        message = maxRetryProcessor.postProcessMessage(message);
        assertEquals(Integer.valueOf(10 * DELAY_MULTIPLIER), message.getMessageProperties().getHeader(DELAY_HEADER));
    }

    @Test
    void testNoRetryAfterReachingMax() {
        MessageProperties messageProperties = new MessageProperties();
        messageProperties.setHeader(MAX_RETRY_HEADER, 0);
        Message message = new Message("Hi".getBytes(), messageProperties);
        assertThrows(MessageRejectionException.class, () -> maxRetryProcessor.postProcessMessage(message));
    }
}