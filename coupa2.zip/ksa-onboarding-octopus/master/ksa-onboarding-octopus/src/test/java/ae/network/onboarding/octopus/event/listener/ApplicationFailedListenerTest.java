package ae.network.onboarding.octopus.event.listener;

import ae.network.onboarding.octopus.event.ApplicationFailedEvent;
import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.octopus.rabbitmq.service.RabbitServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ApplicationFailedListenerTest {

    @Test
    void testSendingNotification(@Mock RabbitServiceImpl rabbitService) {
        ApplicationFailedListener listener = new ApplicationFailedListener(rabbitService);
        ApplicationRequest application = new ApplicationRequest();
        listener.onApplicationEvent(new ApplicationFailedEvent(application));
        verify(rabbitService, atLeastOnce()).sendMessage(RabbitQueue.KSA_NOTIFICATIONS, application);
    }
}