package ae.network.onboarding.octopus.event.listener;

import ae.network.onboarding.octopus.database.service.ApplicationRequestService;
import ae.network.onboarding.octopus.event.ApplicationReceivedEvent;
import ae.network.onboarding.octopus.event.StageOneSkippedEvent;
import ae.network.onboarding.octopus.model.reply.ProcessingResult;
import ae.network.onboarding.octopus.model.request.*;
import ae.network.onboarding.octopus.rabbitmq.RabbitService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import java.util.Collections;
import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
class ApplicationReceivedListenerTest {

    public static final String TYME = "TYME";
    private ApplicationReceivedListener listener;

    @Mock
    private ApplicationEventPublisher applicationEventPublisher;

    @Mock
    private ApplicationRequestService service;

    @Mock
    private RabbitService rabbitService;

    @BeforeEach
    void init() {
        listener = new ApplicationReceivedListener(rabbitService, applicationEventPublisher, service);
    }

    @Test
    void testOnboardingStageOne() {
        final ApplicationRequest applicationRequest = new ApplicationRequest();
        applicationRequest.setAuthorizedSystems(BackendSystem.getStageOneSystems());
        applicationRequest.setApplicationId("app-id");
        applicationRequest.setAcquirer(TYME);
        listener.onApplicationEvent(new ApplicationReceivedEvent(applicationRequest));
        Mockito.verify(rabbitService, times(BackendSystem.getStageOneSystems().size())).sendMessage(any(), any());
        assertEquals(RequestStatus.ONBOARDING_STAGE_ONE, applicationRequest.getRequestStatus());
    }

    @Test
    void testStageOneSkipped() {
        final ApplicationRequest applicationRequest = new ApplicationRequest();
        applicationRequest.setAuthorizedSystems(BackendSystem.getStageOneSystems());
        applicationRequest.setApplicationId("app-id");
        applicationRequest.setAcquirer(TYME);
        final HashMap<BackendSystem, ProcessingResult> resultsMap = getResultsMap(TaskStatus.COMPLETED);
        applicationRequest.setResultsMap(resultsMap);
        listener.onApplicationEvent(new ApplicationReceivedEvent(applicationRequest));
        Mockito.verify(rabbitService, times(0)).sendMessage(any(), any());
        Mockito.verify(applicationEventPublisher, times(1)).publishEvent(any(StageOneSkippedEvent.class));
    }

    @Test
    void testStageOneFailedBefore() {
        final ApplicationRequest applicationRequest = new ApplicationRequest();
        applicationRequest.setAuthorizedSystems(BackendSystem.getStageOneSystems());
        applicationRequest.setApplicationId("app-id");
        applicationRequest.setAcquirer(TYME);
        final HashMap<BackendSystem, ProcessingResult> resultsMap = getResultsMap(TaskStatus.FAILED);
        applicationRequest.setResultsMap(resultsMap);
        listener.onApplicationEvent(new ApplicationReceivedEvent(applicationRequest));
        Mockito.verify(rabbitService, times(BackendSystem.getStageOneSystems().size())).sendMessage(any(), any());
        assertEquals(RequestStatus.ONBOARDING_STAGE_ONE, applicationRequest.getRequestStatus());
    }

    private HashMap<BackendSystem, ProcessingResult> getResultsMap(TaskStatus taskStatus) {
        final HashMap<BackendSystem, ProcessingResult> resultsMap = new HashMap<>();
        for (BackendSystem backendSystem : BackendSystem.getStageOneSystems()) {
            final Task task = new Task();
            task.setTaskStatus(taskStatus);
            resultsMap.put(backendSystem,
                    ProcessingResult.builder().tasks(Collections.singletonList(task)).finalStatus(taskStatus).build());
        }
        return resultsMap;
    }

}