package ae.network.onboarding.octopus.database;

import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.stereotype.Component;

/**
 * @author walid.sewaify
 * @since 2020-01-23
 */
@EnableMongoAuditing
@Component
public class DatabaseConfig {
}
