package ae.network.onboarding.octopus.security;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.ForwardedHeaderFilter;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author walid.sewaify
 * @since 2020-02-10
 */
@Configuration
public class WebInterceptorsConfig implements WebMvcConfigurer {
    private final UserDetailsHandlerInterceptor userDetailsHandlerInterceptor;

    public WebInterceptorsConfig(UserDetailsHandlerInterceptor userDetailsConfigurer) {
        this.userDetailsHandlerInterceptor = userDetailsConfigurer;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(userDetailsHandlerInterceptor);
    }

    /**
     * Bean for overriding remote host (if request comes through a proxy)
     */
    @Bean
    FilterRegistrationBean<ForwardedHeaderFilter> forwardedHeaderFilter() {
        FilterRegistrationBean<ForwardedHeaderFilter> bean = new FilterRegistrationBean<>();
        bean.setFilter(new ForwardedHeaderFilter());
        return bean;
    }
}
