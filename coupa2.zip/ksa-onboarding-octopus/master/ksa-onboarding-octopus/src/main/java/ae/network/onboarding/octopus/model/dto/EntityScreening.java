package ae.network.onboarding.octopus.model.dto;

import ae.network.onboarding.octopus.model.reply.ScreeningResult;
import ae.network.onboarding.octopus.model.request.BackendSystem;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;
import java.util.Map;

/**
 * Groups merchants by entity Id, and add screening results.
 *
 * @author walid.sewaify
 * @since 2020-06-07
 */
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
class EntityScreening {
    @EqualsAndHashCode.Include
    private String entityId;
    private Map<BackendSystem, ScreeningResult> screeningResult = new HashMap<>();
}
