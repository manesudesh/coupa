package ae.network.onboarding.octopus.event;

import ae.network.onboarding.octopus.model.request.ApplicationRequest;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
public class ApplicationCompletedEvent extends OnboardingApplicationEvent {

    public ApplicationCompletedEvent(ApplicationRequest applicationRequest) {
        super(applicationRequest);
    }
}
