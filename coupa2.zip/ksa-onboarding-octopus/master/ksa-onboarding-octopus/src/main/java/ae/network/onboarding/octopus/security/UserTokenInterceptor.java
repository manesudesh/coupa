package ae.network.onboarding.octopus.security;

import ae.network.onboarding.octopus.model.request.BackendSystem;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import jakarta.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 * adds access token claims to request context
 *
 * @author walid.sewaify
 * @since 2020-02-10
 */
@Component
@Slf4j
@Profile("security")
public class UserTokenInterceptor extends UserDetailsHandlerInterceptor {
    private static final String IP_HEADER = "X-Forwarded-For";
    private static final String X_OCTOPUS_USERNAME = "X-OCTOPUS-USERNAME";
    private static final String X_OCTOPUS_ACQUIRER = "X-OCTOPUS-ACQUIRER";
    private static final String X_OCTOPUS_BACKEND_SYSTEMS = "X-OCTOPUS-BACKEND-SYSTEMS";

    private final UserDetails userDetails;

    public UserTokenInterceptor(UserDetails userDetails) {
        this.userDetails = userDetails;
    }

    @Override
    public void setUserDetails(HttpServletRequest request) throws IllegalAccessException {
        // update request scoped user details
        String username = request.getHeader(X_OCTOPUS_USERNAME);
        String acquirer = request.getHeader(X_OCTOPUS_ACQUIRER);
        Enumeration<String> backendSystems = request.getHeaders(X_OCTOPUS_BACKEND_SYSTEMS);

        if (username == null || acquirer == null || backendSystems == null) {
            throw new IllegalAccessException("Invalid security context");
        }

        userDetails.setUsername(username);
        userDetails.setAcquirer(acquirer);
        List<BackendSystem> authorizedSystems = new ArrayList<>();
        while (backendSystems.hasMoreElements()) {
            String backendSystem = backendSystems.nextElement();
            if (backendSystem != null && !backendSystem.trim().isEmpty()) {
                authorizedSystems.add(BackendSystem.valueOf(backendSystem));
            }
        }
        userDetails.setAuthorizedSystems(authorizedSystems);
        userDetails.setIp(request.getHeader(IP_HEADER));
    }
}
