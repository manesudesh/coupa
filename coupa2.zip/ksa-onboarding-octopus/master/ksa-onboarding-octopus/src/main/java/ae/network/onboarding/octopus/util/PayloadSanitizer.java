package ae.network.onboarding.octopus.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.manager.JspHelper;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
public class PayloadSanitizer {

    private static final ObjectMapper mapper = new ObjectMapper();
    private static final Set<Sanitizer> defaultSanitizers = new HashSet<>();
    private static final Function<String, String> alphanumericSanitizer = TextUtils::toAlphaNumeric;
    private static final Function<String, String> whitespacesSanitizer = TextUtils::trimAllWhitespaces;
    private static final Function<String, String> xmlSanitizer = JspHelper::escapeXml;

    private final Set<Sanitizer> sanitizers = new HashSet<>();

    public PayloadSanitizer() {
        sanitizers.addAll(defaultSanitizers);
    }

    public PayloadSanitizer(Set<Sanitizer> sanitizers) {
        this.sanitizers.addAll(sanitizers);
    }

    static {
        defaultSanitizers.add(Sanitizer.builder()
                .enabled(true)
                .parent((s) -> s.replaceAll("/\\bmerchantName", ""))
                .name("merchantName")
                .path("/payload/applications/merchants/merchantName")
                .validate(defaultValidator(23))
                .sanitize(defaultSanitizer(23))
                .build());
        defaultSanitizers.add(Sanitizer.builder()
                .enabled(true)
                .parent((s) -> s.replaceAll("/\\blegalName", ""))
                .name("legalName")
                .path("/payload/applications/merchants/legalName")
                .validate(defaultValidator(40))
                .sanitize(defaultSanitizer(40))
                .build());
        defaultSanitizers.add(Sanitizer.builder()
                .enabled(true)
                .parent((s) -> s.replaceAll("/\\bchainName", ""))
                .name("chainName")
                .path("/payload/applications/chain/chainName")
                .validate(defaultValidator(40))
                .sanitize(defaultSanitizer(40))
                .build());
        defaultSanitizers.add(Sanitizer.builder()
                .enabled(true)
                .parent((s) -> s.replaceAll("/\\baddressLines/\\d", "/addressLines"))
                .name("addressLines")
                .path("/payload/applications/merchants/addresses/addressLines")
                .index((s) -> Integer.valueOf(s.substring(s.lastIndexOf("/") + 1)))
                .validate(defaultValidator(40))
                .sanitize(xmlSanitizer.andThen(defaultSanitizer(40)))
                .build());
    }

    private static Function<String, Boolean> defaultValidator(int len) {
        return (s) -> TextUtils.isAlphaNumeric(s) && TextUtils.isValidLength(s, len);
    }

    private static Function<String, String> defaultSanitizer(int len) {
        return alphanumericSanitizer.andThen(whitespacesSanitizer.andThen(truncateSanitizer(len)));
    }

    private static Function<String, String> truncateSanitizer(int defaultMaxLength) {
        return s -> TextUtils.truncate(s, defaultMaxLength);
    }

    public boolean add(Sanitizer sanitizer) {
        return sanitizers.add(sanitizer);
    }

    public boolean addAll(Set<Sanitizer> sanitizers) {
        return this.sanitizers.addAll(sanitizers);
    }

    public boolean removeAll() {
        return sanitizers.removeAll(new ArrayList<>(sanitizers));
    }

    public void useDefaults() {
        removeAll();
        addAll(defaultSanitizers);
    }

    public void useCustom(Set<Sanitizer> sanitizers) {
        removeAll();
        addAll(sanitizers);
    }

    private void enableAll(boolean enable) {
        sanitizers.forEach(sanitizer -> sanitizer.setEnabled(enable));
    }

    private boolean enableByPath(String path, boolean enable) {
        if (!StringUtils.hasLength(path)) return false;

        Sanitizer sanitizer = sanitizers.stream().filter(s -> s.getPath().equalsIgnoreCase(path)).findFirst().orElse(null);
        if (Objects.nonNull(sanitizer)) {
            sanitizer.setEnabled(enable);
            return true;
        } else {
            return false;
        }
    }

    public String sanitize(String payload) {
        if (!StringUtils.hasLength(payload)) {
            return payload;
        }

        try {
            final Set<SanitationEntry> entries = new HashSet<>();

            JsonNode rootNode = mapper.readTree(payload);
            sanitizeNode(rootNode, "", rootNode, entries);

            for (SanitationEntry entry : entries) {
                if (entry.getParent().equals("/")) {
                    ((ObjectNode) rootNode).put(entry.getName(), entry.getSanitizedValue());
                } else {
                    JsonNode parent = rootNode.at(entry.getParent());
                    if (parent.isArray()) {
                        List<String> all = mapper.readerFor(new TypeReference<List<String>>() {
                        }).readValue(parent);
                        List<String> updated = all.stream().filter(a -> !a.trim().equalsIgnoreCase(entry.getDirtyValue().trim())).collect(Collectors.toList());
                        updated.add(entry.getSanitizedValue());

                        ((ArrayNode) parent).removeAll();
                        updated.forEach(((ArrayNode) parent)::add);
                    } else {
                        ((ObjectNode) parent).put(entry.getName(), entry.getSanitizedValue());
                    }
                }
            }
            return rootNode.toString();
        } catch (Exception e) {
            log.error("sanitization error", e);
            return payload;
        }
    }

    private void sanitizeNode(JsonNode rootNode, String prefix, JsonNode currentNode, Set<SanitationEntry> entries) {
        if (currentNode.isArray()) {
            ArrayNode arrayNode = (ArrayNode) currentNode;
            Iterator<JsonNode> node = arrayNode.elements();
            int index = 0;
            while (node.hasNext()) {
                sanitizeNode(rootNode, !prefix.isEmpty() ? prefix + "/" + index : String.valueOf(index), node.next(), entries);
                index++;
            }
        } else if (currentNode.isObject()) {
            currentNode.fields().forEachRemaining(entry -> sanitizeNode(rootNode, !prefix.isEmpty() ? prefix + "/" + entry.getKey() : entry.getKey(), entry.getValue(), entries));
        } else {
            Optional<SanitationEntry> optionalEntry = sanitizeLeafNode(Arguments.builder()
                    .root(rootNode).path("/" + prefix)
                    .dirtyValue(currentNode.textValue())
                    .build());
            optionalEntry.ifPresent(entries::add);
        }
    }

    private Optional<SanitationEntry> sanitizeLeafNode(Arguments arguments) {
        String simplified = arguments.getPath().replaceAll("/\\d+", "");
        Optional<Sanitizer> sanitizer = sanitizers.stream().filter(s -> s.isEnabled() && s.getPath().equalsIgnoreCase(simplified)).findFirst();
        if (sanitizer.isPresent()) {
            Sanitizer found = sanitizer.get();
            if (!found.validate.apply(arguments.getDirtyValue())) {
                String sanitized = found.sanitize.apply(arguments.getDirtyValue());
                SanitationEntry sanitationEntry = SanitationEntry.builder()
                        .name(found.getName())
                        .path(arguments.getPath())
                        .parent(found.parent.apply(arguments.getPath()))
                        .index(Objects.nonNull(found.index) ? found.index.apply(arguments.getPath()) : 0)
                        .dirtyValue(arguments.getDirtyValue())
                        .sanitizedValue(sanitized)
                        .build();
                return Optional.of(sanitationEntry);
            }
        }
        return Optional.empty();
    }

    public boolean removeByPath(String path) {
        if (!StringUtils.hasLength(path)) return false;
        return sanitizers.removeIf(s -> s.getPath().equalsIgnoreCase(path));
    }

    public boolean enableByPath(String path) {
        return enableByPath(path, true);
    }

    public boolean disableByPath(String path) {
        return enableByPath(path, false);
    }

    public void enableAll() {
        enableAll(true);
    }

    public void disableAll() {
        enableAll(false);
    }

    @Getter
    @Builder
    private static class SanitationEntry {
        private String name;
        private String path;
        private String parent;
        private int index;
        private String dirtyValue;
        private String sanitizedValue;
    }

    @Getter
    @Setter
    @Builder
    public static class Sanitizer {
        private boolean enabled;
        private String name;
        private String path;
        private Function<String, String> parent;
        private Function<String, Integer> index;
        private Function<String, Boolean> validate;
        private Function<String, String> sanitize;
    }

    @Getter
    @Builder
    private static class Arguments {
        private JsonNode root;
        private String path;
        private String dirtyValue;
    }

}
