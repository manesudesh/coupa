package ae.network.onboarding.octopus.database.repository;

import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.model.request.RequestStatus;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
public interface ApplicationRequestRepository extends MongoRepository<ApplicationRequest, String> {
    Optional<ApplicationRequest> findByApplicationId(String applicationId);

    Optional<ApplicationRequest> findByRequestIdAndAcquirer(String requestId, String acquirer);

    List<ApplicationRequest> findByAcquirerAndRequestStatusNotInAndCreatedDateGreaterThan
            (String acquirer, List<RequestStatus> statues, Date dateBefore);
}
