package ae.network.onboarding.octopus.model.request;

import java.util.Arrays;
import java.util.List;

public enum RequestStatus {
    RECEIVED, ONBOARDING_STAGE_ONE, STAGE_ONE_COMPLETED, ONBOARDING_STAGE_TWO, COMPLETED, FAILED;

    private static final List<RequestStatus> IN_PROGRESS =
            Arrays.asList(ONBOARDING_STAGE_ONE, ONBOARDING_STAGE_TWO, STAGE_ONE_COMPLETED);

    public String getFriendlyName() {
        boolean inProgress = IN_PROGRESS.contains(this);
        if (inProgress) {
            return "IN_PROGRESS";
        } else {
            return this.name();
        }
    }
}
