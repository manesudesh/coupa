package ae.network.onboarding.octopus.model.request;

import ae.network.onboarding.octopus.common.DateFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TaskHistory {
    private TaskStatus taskStatus;
    private String statusCode;
    private String response;
    @JsonFormat(pattern = DateFormat.FORMAT)
    @DateTimeFormat(pattern = DateFormat.FORMAT)
    private Date createdDate;
    @JsonFormat(pattern = DateFormat.FORMAT)
    @DateTimeFormat(pattern = DateFormat.FORMAT)
    private Date lastModifiedDate;
}
