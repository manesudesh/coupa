package ae.network.onboarding.octopus.controller.validation;

import com.fasterxml.jackson.databind.JsonNode;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * @author walid.sewaify
 * @since 2020-03-15
 */
public class ScreeningPayloadValidator implements
        ConstraintValidator<ValidScreeningPayload, JsonNode> {

    private static final String MERCHANT = "merchant";
    private static final String IDENTIFIER = "identifier";
    private static final String NAME = "name";

    @Override
    public void initialize(ValidScreeningPayload payload) {
    }

    @Override
    public boolean isValid(JsonNode payload,
                           ConstraintValidatorContext cxt) {
        String message;
        if (payload == null) {
            message = "Mandatory field";
        } else if (!payload.isObject()) {
            message = "JSON object is expected";
        } else {
            if (!payload.has(MERCHANT)) {
                message = "No merchants available for screening";
            } else if (payload.get(MERCHANT).get(IDENTIFIER) == null) {
                message = "Merchant identifier is mandatory";
            } else if (payload.get(MERCHANT).get(NAME) == null) {
                message = "Merchant name is mandatory";
            } else {
                return true;
            }
        }
        cxt.disableDefaultConstraintViolation();
        cxt.buildConstraintViolationWithTemplate(message).addConstraintViolation();
        return false;
    }
}
