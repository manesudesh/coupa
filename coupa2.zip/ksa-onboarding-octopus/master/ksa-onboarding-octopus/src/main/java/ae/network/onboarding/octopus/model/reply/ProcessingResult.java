package ae.network.onboarding.octopus.model.reply;

import ae.network.onboarding.octopus.model.request.Task;
import ae.network.onboarding.octopus.model.request.TaskStatus;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @author walid.sewaify
 * @since 2020-03-05
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProcessingResult {
    private TaskStatus finalStatus;
    private Collection<Task> tasks = new ArrayList<>();
    private Boolean mergeToExisting;
}