package ae.network.onboarding.octopus.model.reply;

import ae.network.onboarding.octopus.model.request.BackendSystem;
import ae.network.onboarding.octopus.rabbitmq.message.QueueMessage;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collection;

/**
 * Update message to queue (sent from consumers)
 *
 * @author walid.sewaify
 * @since 2020-01-23
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationUpdate implements QueueMessage {
    private String applicationId;
    private BackendSystem backendSystem;
    private ProcessingResult processingResult;
    private Attachment attachment;
    private Collection<ScreeningResult> screeningResults;
    private AdditionalData additionalData;
}