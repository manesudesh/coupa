package ae.network.onboarding.octopus.model.dto;

import ae.network.onboarding.octopus.model.request.BackendSystem;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-05-19
 */
public interface AcquirerRequest {
    String getRequestId();

    String getCallbackUrl();

    String getCallbackEmail();

    JsonNode getPayload();

    List<BackendSystem> getBackendSystems();

    boolean isDryRun();

    boolean isRetry();
}
