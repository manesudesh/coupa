package ae.network.onboarding.octopus.rabbitmq.config;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
public enum RabbitExchange {
    KSA_ONBOARDING("ksa-onboarding-exchange"),
    KSA_ONBOARDING_RETRY("ksa-onboarding-delayed-exchange"),
    KSA_ONBOARDING_FAIL("ksa-onboarding-fail-exchange");

    private final String exchangeName;

    RabbitExchange(String exchangeName) {
        this.exchangeName = exchangeName;
    }

    public String getExchangeName() {
        return exchangeName;
    }
}
