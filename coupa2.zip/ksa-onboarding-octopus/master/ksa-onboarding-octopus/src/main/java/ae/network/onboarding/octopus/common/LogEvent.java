package ae.network.onboarding.octopus.common;

import ae.network.onboarding.octopus.model.failure.FailedMessage;
import ae.network.onboarding.octopus.model.reply.ApplicationUpdate;
import ae.network.onboarding.octopus.model.request.RequestStatus;
import net.logstash.logback.argument.StructuredArgument;

import static net.logstash.logback.argument.StructuredArguments.v;

/**
 * @author walid.sewaify
 * @since 2020-04-10
 */
public abstract class LogEvent {
    public static StructuredArgument appUpdate(RequestStatus requestStatus) {
        return v("app_event", requestStatus);
    }

    public static StructuredArgument deadMessage(FailedMessage message) {
        return v("dead_message_event", message);
    }


    public static StructuredArgument backendUpdate(ApplicationUpdate applicationUpdate) {
        return v("backend_event", applicationUpdate);
    }

    public static StructuredArgument elapsed(long elapsedTime) {
        return v("elapsed_event", elapsedTime);
    }
}
