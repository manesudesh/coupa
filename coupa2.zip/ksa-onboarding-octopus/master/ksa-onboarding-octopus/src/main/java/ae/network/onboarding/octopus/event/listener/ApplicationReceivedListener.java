package ae.network.onboarding.octopus.event.listener;

import ae.network.onboarding.octopus.database.service.ApplicationRequestService;
import ae.network.onboarding.octopus.event.ApplicationReceivedEvent;
import ae.network.onboarding.octopus.event.StageOneSkippedEvent;
import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.model.request.BackendSystem;
import ae.network.onboarding.octopus.model.request.RequestStatus;
import ae.network.onboarding.octopus.rabbitmq.RabbitService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
@Component
@Slf4j
public class ApplicationReceivedListener implements ApplicationListener<ApplicationReceivedEvent> {
    private final RabbitService rabbitService;
    private final ApplicationEventPublisher applicationEventPublisher;
    private final ApplicationRequestService applicationRequestService;

    public ApplicationReceivedListener(RabbitService rabbitService, ApplicationEventPublisher applicationEventPublisher,
                                       ApplicationRequestService applicationRequestService) {
        this.rabbitService = rabbitService;
        this.applicationEventPublisher = applicationEventPublisher;
        this.applicationRequestService = applicationRequestService;
    }

    @Override
    public void onApplicationEvent(ApplicationReceivedEvent event) {
        ApplicationRequest application = event.getSource();
        log.info("application {} is received", application.getApplicationId());

        boolean skipStageOne = true;
        for (BackendSystem system : BackendSystem.getStageOneSystems()) {
            if (application.isOnboardingRequired(system)) {
                skipStageOne = false;
                rabbitService.sendMessage(system.getRabbitQueue(), application);
            }
        }
        if (skipStageOne) {
            log.info("Skipped stage one onboarding for application {}", application.getApplicationId());
            applicationEventPublisher.publishEvent(new StageOneSkippedEvent(application));
        } else {
            log.info("application {} sent to stage one onboarding systems", application.getApplicationId());
            application.setRequestStatus(RequestStatus.ONBOARDING_STAGE_ONE);
            applicationRequestService.saveOrUpdateApplication(application);
        }
    }

}