package ae.network.onboarding.octopus.security;

import org.springframework.web.servlet.HandlerInterceptor;
//import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Responsible for populating user details object (http request scope)
 *
 * @author walid.sewaify
 * @since 2020-02-10
 */
public abstract class UserDetailsHandlerInterceptor implements HandlerInterceptor { //extends  HandlerInterceptorAdapter {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws
            Exception {
        setUserDetails(request);
//        return super.preHandle(request, response, handler);
        return true;
    }

    public abstract void setUserDetails(HttpServletRequest request) throws Exception;
}
