package ae.network.onboarding.octopus.util;

/**
 * @author walid.sewaify
 * @since 2021-01-19
 */
public class TextUtils {

    public static String truncate(String str, int maxLen) {
        if (str == null) {
            return null;
        }
        int maxLength = Math.min(str.length(), maxLen);
        return str.substring(0, maxLength);
    }

    public static String toAlphaNumeric(String str) {
        if (str == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (char c : str.toCharArray()) {
            if (Character.isDigit(c) || Character.isLetter(c) || Character.isSpaceChar(c)) {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static boolean isValidLength(String s, int len) {
        return s == null || s.length() <= len;
    }

    public static String trimAllWhitespaces(String str) {
        if (str == null) {
            return null;
        }
        return str.trim().replaceAll(" +", " ");
    }

    public static boolean isAlphaNumeric(String str) {
        if (str == null) {
            return true;
        }
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c) && !Character.isLetter(c) && !Character.isSpaceChar(c)) {
                return false;
            }
        }
        return true;
    }
}