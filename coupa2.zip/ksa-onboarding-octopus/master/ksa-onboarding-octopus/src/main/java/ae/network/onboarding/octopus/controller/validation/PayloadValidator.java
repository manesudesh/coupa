package ae.network.onboarding.octopus.controller.validation;

import com.fasterxml.jackson.databind.JsonNode;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * @author walid.sewaify
 * @since 2020-03-15
 */
public class PayloadValidator implements
        ConstraintValidator<ValidPayload, JsonNode> {

    private static final String APPLICATIONS = "applications";

    @Override
    public void initialize(ValidPayload payload) {
    }

    @Override
    public boolean isValid(JsonNode payload,
                           ConstraintValidatorContext cxt) {
        String message;
        if (payload == null) {
            message = "Mandatory field";
        } else if (!payload.isObject()) {
            message = "JSON object is expected";
        } else if (!payload.has(APPLICATIONS) || payload.get(APPLICATIONS).isEmpty()) {
            message = "No applications provided in the payload";
        } else {
            return true;
        }
        cxt.disableDefaultConstraintViolation();
        cxt.buildConstraintViolationWithTemplate(message).addConstraintViolation();
        return false;
    }
}
