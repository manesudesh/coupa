package ae.network.onboarding.octopus.model.request;

import java.util.Arrays;
import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
public enum TaskStatus {
    COMPLETED, PARTIALLY_COMPLETED, FAILED, CANCELLED, IN_PROGRESS;

    private static final List<TaskStatus> CLOSURE_STATUS = Arrays.asList(COMPLETED, CANCELLED);
    private static final List<TaskStatus> FAILURE_STATUS = Arrays.asList(FAILED, PARTIALLY_COMPLETED);

    public boolean isClosureStatus() {
        return CLOSURE_STATUS.contains(this);
    }

    public boolean isFailureStatus() {
        return FAILURE_STATUS.contains(this);
    }

}
