package ae.network.onboarding.octopus.model.dto;

import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.model.request.BackendSystem;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static ae.network.onboarding.octopus.common.DateFormat.SIMPLE_FORMAT;

/**
 * @author walid.sewaify
 * @since 2020-08-16
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OpenApplication {
    private String requestId;
    private String applicationId;
    private String creationDate;
    private String lastUpdate;
    private List<BackendSystem> completedSystems;
    private List<BackendSystem> remainingSystems;

    public OpenApplication(ApplicationRequest applicationRequest) {
        this.requestId = applicationRequest.getRequestId();
        this.applicationId = applicationRequest.getApplicationId();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(SIMPLE_FORMAT);
        this.creationDate = simpleDateFormat.format(applicationRequest.getCreatedDate());
        this.lastUpdate = simpleDateFormat.format(applicationRequest.getLastModifiedDate());

        this.completedSystems = applicationRequest.getResultsMap().entrySet().stream()
                .filter(entry -> entry.getValue().getFinalStatus().isClosureStatus())
                .map(Map.Entry::getKey).collect(Collectors.toList());

        this.remainingSystems = applicationRequest.getAuthorizedSystems().stream()
                .filter(system -> !completedSystems.contains(system)).collect(Collectors.toList());
    }
}
