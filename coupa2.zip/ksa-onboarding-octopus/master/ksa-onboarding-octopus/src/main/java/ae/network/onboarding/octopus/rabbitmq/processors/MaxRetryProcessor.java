package ae.network.onboarding.octopus.rabbitmq.processors;

import ae.network.onboarding.octopus.exception.MaxRetryReachedException;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;

import static ae.network.onboarding.octopus.rabbitmq.message.QueueMessage.DELAY_HEADER;
import static ae.network.onboarding.octopus.rabbitmq.message.QueueMessage.MAX_RETRY_HEADER;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@Component
public class MaxRetryProcessor implements MessagePostProcessor {
    public static final int DELAY_MULTIPLIER = 5;

    private final RabbitTemplate rabbitTemplate;
    private final int maxRetryAttempts;
    private final int retryInSeconds;


    public MaxRetryProcessor(RabbitTemplate rabbitTemplate,
                             @Value("${octopus.processor.max-retry}") int maxRetryAttempts,
                             @Value("${octopus.consumer.error-retry-in-seconds}") int retryInSeconds) {
        this.rabbitTemplate = rabbitTemplate;
        this.maxRetryAttempts = maxRetryAttempts;
        this.retryInSeconds = retryInSeconds;
    }

    @Override
    public Message postProcessMessage(Message message) throws AmqpException {
        MessageProperties messageProperties = message.getMessageProperties();
        Object maxRetryHeader = messageProperties.getHeader(MAX_RETRY_HEADER);
        Object currentDelayHeader = messageProperties.getHeader(DELAY_HEADER);
        if (maxRetryHeader == null) {
            messageProperties.setHeader(MAX_RETRY_HEADER, maxRetryAttempts);
        } else {
            int maxRetry = asNumber(maxRetryHeader);
            if (maxRetry <= 0) {
                throw new MaxRetryReachedException();
            } else {
                messageProperties.setHeader(MAX_RETRY_HEADER, maxRetry - 1);
            }
        }

        if (currentDelayHeader == null) {
            messageProperties.setHeader(DELAY_HEADER, retryInSeconds);
        } else {
            int currentDelay = asNumber(currentDelayHeader);
            messageProperties.setHeader(DELAY_HEADER, currentDelay * DELAY_MULTIPLIER);
        }

        return message;
    }

    private int asNumber(Object maxRetryHeader) {
        try {
            return Integer.parseInt(maxRetryHeader.toString());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    @PostConstruct
    public void init() {
        rabbitTemplate.addBeforePublishPostProcessors(this);
    }
}
