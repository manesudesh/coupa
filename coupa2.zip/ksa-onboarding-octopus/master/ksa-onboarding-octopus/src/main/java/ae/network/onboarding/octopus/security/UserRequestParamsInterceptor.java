package ae.network.onboarding.octopus.security;

import ae.network.onboarding.octopus.model.request.BackendSystem;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Fill user details using http request parameters
 *
 * @author walid.sewaify
 * @since 2020-02-10
 */
@Component
@Profile("!security")
public class UserRequestParamsInterceptor extends UserDetailsHandlerInterceptor {
    private static final String USERNAME = "username";
    private static final String ACQUIRER = "acquirer";
    private static final String AUTHORIZED_SYSTEMS = "authorizedSystems";

    private final UserDetails userDetails;

    public UserRequestParamsInterceptor(UserDetails userDetails) {
        this.userDetails = userDetails;
    }

    @Override
    public void setUserDetails(HttpServletRequest request) {
        Optional<String> username = Optional.ofNullable(request.getParameter(USERNAME));
        Optional<String> acquirer = Optional.ofNullable(request.getParameter(ACQUIRER));
        Optional<String> authorizedSystems = Optional.ofNullable(request.getParameter(AUTHORIZED_SYSTEMS));

        userDetails.setUsername(username.orElse("testUser"));
        userDetails.setAcquirer(acquirer.orElse("NI"));
        authorizedSystems.ifPresent(systems -> userDetails.setAuthorizedSystems(Arrays.stream(systems.split(","))
                .filter(system -> !system.trim().isEmpty())
                .map(BackendSystem::valueOf).collect(Collectors.toList())));

    }
}
