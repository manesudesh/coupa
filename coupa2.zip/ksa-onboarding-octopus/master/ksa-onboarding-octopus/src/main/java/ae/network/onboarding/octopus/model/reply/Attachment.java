package ae.network.onboarding.octopus.model.reply;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * @author walid.sewaify
 * @since 2020-05-14
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Attachment {
    private String fileName;

    private String contentType;

    private byte[] content;
}
