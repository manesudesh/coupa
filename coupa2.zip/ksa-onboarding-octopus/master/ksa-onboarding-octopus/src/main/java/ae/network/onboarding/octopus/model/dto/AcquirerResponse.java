package ae.network.onboarding.octopus.model.dto;

import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.model.request.RequestStatus;
import ae.network.onboarding.octopus.model.request.RequestType;
import ae.network.onboarding.octopus.model.request.TaskHistory;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static ae.network.onboarding.octopus.common.DateFormat.SIMPLE_FORMAT;

/**
 * @author walid.sewaify
 * @since 2020-03-01
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AcquirerResponse {
    private static final String VALIDATION = "VALIDATION";

    private String requestId;
    private String applicationId;
    private String requestStatus;
    private String lastUpdate;
    private String screeningResult;
    private List<String> validationErrors;


    public AcquirerResponse(ApplicationRequest applicationRequest) {
        this.requestId = applicationRequest.getRequestId();
        this.applicationId = applicationRequest.getApplicationId();
        this.requestStatus = applicationRequest.getRequestStatus().getFriendlyName();
        this.lastUpdate = new SimpleDateFormat(SIMPLE_FORMAT).format(applicationRequest.getLastModifiedDate());
        if (applicationRequest.getRequestType() == RequestType.SCREENING &&
                applicationRequest.getRequestStatus() == RequestStatus.COMPLETED) {
            this.screeningResult = applicationRequest.getScreeningResult();
        }
        if (applicationRequest.getRequestStatus() == RequestStatus.FAILED) {
            validationErrors = applicationRequest.getResultsMap().values().stream()
                    .flatMap(result -> result.getTasks().stream()).filter(task -> VALIDATION.equalsIgnoreCase(task.getName()))
                    .flatMap((task -> task.getTaskHistory() == null ? Stream.empty() : task.getTaskHistory().stream()))
                    .map(TaskHistory::getResponse).collect(Collectors.toList());
        }
    }
}
