package ae.network.onboarding.octopus.event;

import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import lombok.extern.slf4j.Slf4j;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
@Slf4j
public class ApplicationReceivedEvent extends OnboardingApplicationEvent {
    public ApplicationReceivedEvent(ApplicationRequest applicationRequest) {
        super(applicationRequest);
    }
}
