package ae.network.onboarding.octopus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@SpringBootApplication
@EnableEncryptableProperties
public class OnboardingOctopusApplication {

    public static void main(String[] args) {
        SpringApplication.run(OnboardingOctopusApplication.class, args);
    }

}
