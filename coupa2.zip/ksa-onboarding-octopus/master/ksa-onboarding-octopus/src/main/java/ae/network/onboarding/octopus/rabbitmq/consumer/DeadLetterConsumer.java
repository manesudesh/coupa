package ae.network.onboarding.octopus.rabbitmq.consumer;

import ae.network.onboarding.octopus.common.LogEvent;
import ae.network.onboarding.octopus.common.MdcUtils;
import ae.network.onboarding.octopus.exception.MessageRejectionException;
import ae.network.onboarding.octopus.model.failure.FailedMessage;
import ae.network.onboarding.octopus.rabbitmq.config.RabbitQueue;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.ErrorHandler;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@Component
@Slf4j
public class DeadLetterConsumer implements MessageListener, ErrorHandler {

    private final MongoTemplate mongoTemplate;

    public DeadLetterConsumer(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    @Bean
    SimpleMessageListenerContainer deadLetterListener(ConnectionFactory connectionFactory) {
        SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
        container.setConnectionFactory(connectionFactory);
        container.setQueueNames(RabbitQueue.KSA_FAILS.getQueueName());
        container.setMessageListener(this);
        container.setErrorHandler(this);
        return container;
    }

    @Override
    public void onMessage(Message message) {
        MdcUtils.setCorrId(message.getMessageProperties().getCorrelationId());

        FailedMessage failedMessage = new FailedMessage(message);
        log.error("Dead message found in error state, investigation required : {}", LogEvent.deadMessage(failedMessage));
        mongoTemplate.save(failedMessage);
    }

    @Override
    public void handleError(Throwable e) {
        log.error("Error while handling message in DLQ", e);
        throw new MessageRejectionException(e);
    }
}
