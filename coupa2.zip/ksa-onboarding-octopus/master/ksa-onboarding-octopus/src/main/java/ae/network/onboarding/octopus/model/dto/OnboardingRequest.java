package ae.network.onboarding.octopus.model.dto;

import ae.network.onboarding.octopus.controller.validation.ValidPayload;
import ae.network.onboarding.octopus.model.request.BackendSystem;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-03-01
 */
@Data
public class OnboardingRequest implements AcquirerRequest {
    @NotNull
    @Size(min = 6, max = 64)
    @Pattern(regexp = "[a-zA-Z0-9\\-_]*")
    private String requestId;
    @Pattern(regexp = "^$|https?://[^\\s/$.?#].[^\\s]{0,30}")
    private String callbackUrl;
    @Email
    private String callbackEmail;
    @ValidPayload
    private JsonNode payload;
    // filter authorized systems
    private List<BackendSystem> backendSystems;
    private boolean dryRun;
    private boolean retry;
}
