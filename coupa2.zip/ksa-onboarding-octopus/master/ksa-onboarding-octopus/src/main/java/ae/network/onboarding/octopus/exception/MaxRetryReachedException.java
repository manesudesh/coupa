package ae.network.onboarding.octopus.exception;

/**
 * @author walid.sewaify
 * @since 2020-01-26
 */
public class MaxRetryReachedException extends MessageRejectionException {
    public MaxRetryReachedException() {
        super("Maximum retries reached");
    }
}
