package ae.network.onboarding.octopus.model.reply;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

/**
 * @author walid.sewaify
 * @since 2020-06-18
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
public class ScreeningResult {
    @NonNull
    private String entityId;
    @NonNull
    private String result;
    private String matchedMerchants;
    private String downloadReport;
}
