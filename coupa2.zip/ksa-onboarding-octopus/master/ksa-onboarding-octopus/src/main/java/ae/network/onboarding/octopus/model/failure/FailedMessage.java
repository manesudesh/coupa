package ae.network.onboarding.octopus.model.failure;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.amqp.core.Message;
import org.springframework.data.mongodb.core.mapping.Document;

import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * @author walid.sewaify
 * @since 2020-01-26
 */
@Data
@NoArgsConstructor
@Document("failures")
public class FailedMessage {
    private Map<String, Object> headers;
    private DBObject body;
    private String bodyString;

    public FailedMessage(Message message) {
        this.headers = message.getMessageProperties().getHeaders();
        this.bodyString = new String(message.getBody(), StandardCharsets.UTF_8);
        this.body = BasicDBObject.parse(bodyString);
    }
}