package ae.network.onboarding.octopus.event.listener;

import ae.network.onboarding.octopus.database.service.ApplicationRequestService;
import ae.network.onboarding.octopus.event.ApplicationCompletedEvent;
import ae.network.onboarding.octopus.event.StageOneEvent;
import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.model.request.BackendSystem;
import ae.network.onboarding.octopus.model.request.RequestStatus;
import ae.network.onboarding.octopus.rabbitmq.RabbitService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

/**
 * When onboarding to stage one is completed or skipped
 *
 * @author walid.sewaify
 * @since 2020-01-27
 */
@Component
@Slf4j
public class ApplicationStageTwoListener implements ApplicationListener<StageOneEvent> {

    private final RabbitService rabbitService;
    private final ApplicationEventPublisher applicationEventPublisher;
    private final ApplicationRequestService applicationRequestService;


    public ApplicationStageTwoListener(RabbitService rabbitService, ApplicationEventPublisher applicationEventPublisher, ApplicationRequestService applicationRequestService) {
        this.rabbitService = rabbitService;
        this.applicationEventPublisher = applicationEventPublisher;
        this.applicationRequestService = applicationRequestService;
    }

    @Override
    public void onApplicationEvent(StageOneEvent event) {
        ApplicationRequest application = event.getSource();
        log.info("Sending application {} to stage two backend systems", application.getApplicationId());

        boolean skipStageTwo = true;
        for (BackendSystem system : BackendSystem.getStageTwoSystems()) {
            if (application.isOnboardingRequired(system)) {
                skipStageTwo = false;
                rabbitService.sendMessage(system.getRabbitQueue(), application);
            }
        }
        if (skipStageTwo) {
            log.info("Skipped stage two onboarding for application {}", application.getApplicationId());
            application.setRequestStatus(RequestStatus.COMPLETED);
            applicationRequestService.saveOrUpdateApplication(application);
            applicationEventPublisher.publishEvent(new ApplicationCompletedEvent(application));
        } else {
            log.info("application {} sent to stage two onboarding systems", application.getApplicationId());
            application.setRequestStatus(RequestStatus.ONBOARDING_STAGE_TWO);
            applicationRequestService.saveOrUpdateApplication(application);
        }
    }
}