package ae.network.onboarding.octopus.model.request;

public enum Source {
    API
}
