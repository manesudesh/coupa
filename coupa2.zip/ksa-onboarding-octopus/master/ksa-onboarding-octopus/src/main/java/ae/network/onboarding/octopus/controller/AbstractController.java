package ae.network.onboarding.octopus.controller;

import ae.network.onboarding.octopus.database.service.ApplicationRequestService;
import ae.network.onboarding.octopus.exception.ApplicationNotFoundException;
import ae.network.onboarding.octopus.model.dto.AcquirerRequest;
import ae.network.onboarding.octopus.model.dto.AcquirerResponse;
import ae.network.onboarding.octopus.model.dto.AcquirerResponseWithDetails;
import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.model.request.RequestType;
import com.mongodb.BasicDBObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@Slf4j
public abstract class AbstractController {

    private final ApplicationRequestService applicationRequestService;

    protected AbstractController(ApplicationRequestService applicationRequestService) {
        this.applicationRequestService = applicationRequestService;
    }

    ApplicationRequest submitApplication(ApplicationRequest request) {
        return applicationRequestService.createApplication(request);
    }

    ApplicationRequest buildApplicationRequest(AcquirerRequest acquirerRequest, RequestType requestType) {
        String requestId = acquirerRequest.getRequestId();
        ApplicationRequest request;
        Optional<ApplicationRequest> optionalAppRequest = applicationRequestService.findByRequestId(requestId);
        if (optionalAppRequest.isPresent()) {
            if (!acquirerRequest.isRetry()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Request already exists");
            }

            request = optionalAppRequest.get();
            if (request.getRequestType() != requestType) {
                String errorMessage = "request Id already exists for a different request type..";
                log.error(errorMessage);
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, errorMessage);
            }

            log.warn("request id already exists, re-running the onboarding flow only for incomplete systems..");

            // keep track of application Ids
            request.getOtherIds().add(request.getApplicationId());
        } else {
            request = new ApplicationRequest();
            request.setRequestId(requestId);
        }
        request.setPayload(BasicDBObject.parse(acquirerRequest.getPayload().toString()));
        request.setCallbackUrl(acquirerRequest.getCallbackUrl());
        request.setCallbackEmail(acquirerRequest.getCallbackEmail());
        request.setRequestType(requestType);
        request.setDryRun(acquirerRequest.isDryRun());
        request.setRetry(acquirerRequest.isRetry());
        request.setAuthorizedSystems(acquirerRequest.getBackendSystems());
        return request;
    }

    Optional<ApplicationRequest> findApplication(String requestId) {
        return applicationRequestService.findByRequestId(requestId);
    }

    AcquirerResponse getApplicationResponse(String requestId, Boolean detailed) {
        Optional<ApplicationRequest> optionalAppRequest = this.findApplication(requestId);
        return optionalAppRequest
                .map(req -> Boolean.TRUE.equals(detailed) ? new AcquirerResponseWithDetails(req) : new AcquirerResponse(req))
                .orElseThrow(ApplicationNotFoundException::new);

    }
}
