package ae.network.onboarding.octopus.model.request;

public enum RequestType {
    ONBOARDING, AMENDMENT, MERCHANT_CLOSURE, TERMINAL_CLOSURE, SCREENING
}
