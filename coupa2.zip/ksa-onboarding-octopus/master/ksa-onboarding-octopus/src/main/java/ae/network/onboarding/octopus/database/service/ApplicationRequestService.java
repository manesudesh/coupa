package ae.network.onboarding.octopus.database.service;

import ae.network.onboarding.octopus.common.LogEvent;
import ae.network.onboarding.octopus.common.MdcUtils;
import ae.network.onboarding.octopus.database.repository.ApplicationRequestRepository;
import ae.network.onboarding.octopus.event.ApplicationReceivedEvent;
import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import ae.network.onboarding.octopus.model.request.BackendSystem;
import ae.network.onboarding.octopus.model.request.RequestStatus;
import ae.network.onboarding.octopus.model.request.Source;
import ae.network.onboarding.octopus.security.UserDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

import static ae.network.onboarding.octopus.model.request.RequestStatus.COMPLETED;
import static ae.network.onboarding.octopus.model.request.RequestStatus.FAILED;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
@Service
@Slf4j
public class ApplicationRequestService {
    private final ApplicationRequestRepository repository;
    private final ApplicationEventPublisher applicationEventPublisher;
    private final UserDetails userDetails;


    public ApplicationRequestService(ApplicationRequestRepository repository
            , ApplicationEventPublisher applicationEventPublisher, UserDetails userDetails) {
        this.repository = repository;
        this.applicationEventPublisher = applicationEventPublisher;
        this.userDetails = userDetails;
    }

    public ApplicationRequest createApplication(ApplicationRequest request) {
        request.setAcquirer(userDetails.getAcquirer());
        request.setUsername(userDetails.getUsername());
        request.setIp(userDetails.getIp());
        request.setRequestStatus(RequestStatus.RECEIVED);
        request.setApplicationId(UUID.randomUUID().toString());
        request.setSource(Source.API);
        request.setRequestStatus(RequestStatus.RECEIVED);

        // filter authorized systems based on user request
        final List<BackendSystem> userAuthorizedSystems = userDetails.getAuthorizedSystems();
        final List<BackendSystem> requestedSystems = request.getAuthorizedSystems();
        if (requestedSystems == null) {
            request.setAuthorizedSystems(userAuthorizedSystems);
        } else {
            request.setAuthorizedSystems(userAuthorizedSystems.stream().filter(requestedSystems::contains)
                    .collect(Collectors.toList()));
        }

        // set corr is for logging
        MdcUtils.setCorrId(request.getApplicationId());

        request = saveOrUpdateApplication(request);

        applicationEventPublisher.publishEvent(new ApplicationReceivedEvent(request));
        return request;
    }

    public ApplicationRequest saveOrUpdateApplication(ApplicationRequest request) {
        Optional<ApplicationRequest> currentApplication = findByApplicationId(request.getApplicationId());
        if (!currentApplication.isPresent() ||
                !currentApplication.get().getRequestStatus().equals(request.getRequestStatus())) {
            log.info("Application status update {}", LogEvent.appUpdate(request.getRequestStatus()));
        }
        // Definsive check to make sure no duplications there
        Optional<ApplicationRequest> existingRequest =
                repository.findByRequestIdAndAcquirer(request.getRequestId(), request.getAcquirer());
        if (existingRequest.isPresent() && !existingRequest.get().getId().equals(request.getId())) {
            log.error("Duplicate record for same application {}", request.getApplicationId());
            throw new IllegalStateException("Duplicate application");
        }
        return repository.save(request);
    }

    public Optional<ApplicationRequest> findByApplicationId(String applicationId) {
        return repository.findByApplicationId(applicationId);
    }

    public Optional<ApplicationRequest> findByRequestId(String requestId) {
        return repository.findByRequestIdAndAcquirer(requestId, userDetails.getAcquirer());
    }

    public List<ApplicationRequest> findOpenApplications(Integer hoursBefore) {
        if (hoursBefore == null) {
            hoursBefore = 6;
        }

        Instant startTime = LocalDateTime.now().atZone(ZoneId.systemDefault()).minusHours(hoursBefore).toInstant();
        log.info("finding open applications since {}", startTime);

        List<RequestStatus> completedTasks = Arrays.asList(COMPLETED, FAILED);
        return repository.findByAcquirerAndRequestStatusNotInAndCreatedDateGreaterThan
                (userDetails.getAcquirer(), completedTasks, Date.from(startTime));
    }
}
