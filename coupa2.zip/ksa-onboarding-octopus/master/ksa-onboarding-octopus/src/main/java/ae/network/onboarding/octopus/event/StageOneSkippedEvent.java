package ae.network.onboarding.octopus.event;

import ae.network.onboarding.octopus.model.request.ApplicationRequest;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
public class StageOneSkippedEvent extends StageOneEvent {

    public StageOneSkippedEvent(ApplicationRequest applicationRequest) {
        super(applicationRequest);
    }
}
