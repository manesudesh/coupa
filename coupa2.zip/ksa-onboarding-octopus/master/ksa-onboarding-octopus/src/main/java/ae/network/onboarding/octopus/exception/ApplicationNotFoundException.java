package ae.network.onboarding.octopus.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * @author walid.sewaify
 * @since 2020-01-26
 */
@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class ApplicationNotFoundException extends MessageRejectionException {
    public ApplicationNotFoundException() {
        super("Application not found");
    }
}
