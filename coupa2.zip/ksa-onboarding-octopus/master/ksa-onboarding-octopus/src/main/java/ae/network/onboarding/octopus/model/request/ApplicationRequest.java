package ae.network.onboarding.octopus.model.request;

import ae.network.onboarding.octopus.database.AbstractAuditingEntity;
import ae.network.onboarding.octopus.model.reply.AdditionalData;
import ae.network.onboarding.octopus.model.reply.Attachment;
import ae.network.onboarding.octopus.model.reply.ProcessingResult;
import ae.network.onboarding.octopus.model.reply.ScreeningResult;
import ae.network.onboarding.octopus.rabbitmq.message.QueueMessage;
import com.mongodb.DBObject;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.*;

import static ae.network.onboarding.octopus.model.request.RequestStatus.ONBOARDING_STAGE_ONE;
import static ae.network.onboarding.octopus.model.request.RequestStatus.STAGE_ONE_COMPLETED;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Document("applications")
public class ApplicationRequest extends AbstractAuditingEntity implements QueueMessage {
    @Id
    @EqualsAndHashCode.Include
    private String id;

    @Version
    private Integer version;
    /**
     * Partner acquirer
     */
    private String acquirer;
    /**
     * Skip callback
     */
    private boolean skipCallback;
    /**
     * Request type (Create-update-close)
     */
    private RequestType requestType;
    /**
     * Default is API
     */
    private Source source;
    /**
     * Application status
     */
    private RequestStatus requestStatus;
    /**
     * unique global id
     */
    private String applicationId;
    /**
     * acquirer request id (unique across each acquirer)
     */
    private String requestId;
    /**
     * application content
     */
    private DBObject payload;
    /**
     * List of tasks
     */
    private Map<BackendSystem, ProcessingResult> resultsMap = new HashMap<>();
    /**
     * List of attachments
     */
    private Map<BackendSystem, Attachment> attachmentsMap = new HashMap<>();
    /**
     * List of attachments
     */
    private Map<BackendSystem, Collection<ScreeningResult>> screeningMap = new HashMap<>();
    /**
     * List of Additional Data received from backend systems
     */
    private Map<BackendSystem, AdditionalData> additionalDataMap = new HashMap<>();
    /**
     * User who created the application
     */
    private String username;
    /**
     * Ip of the application sender
     */
    private String ip;
    /**
     * Callback url
     */
    private String callbackUrl;
    /**
     * Callback email
     */
    private String callbackEmail;
    /**
     * List of authorized Onboarding systems.
     */
    private List<BackendSystem> authorizedSystems;

    /**
     * history of application id (in case the application reposted for error corrections)
     */
    private List<String> otherIds = new ArrayList<>();

    /**
     * URL for displaying screening result
     */
    private String screeningResult;

    /**
     * Dry run request (not backend changes are done)
     */
    private boolean dryRun;

    /**
     * enable retry for an existing request
     */
    private boolean retry;

    /**
     * payload version
     */
    private String payloadVersion;

    public void updateTasks(BackendSystem targetSystem, ProcessingResult newResult) {
        if (Boolean.TRUE.equals(newResult.getMergeToExisting())) {
            // add new tasks to existing tasks
            resultsMap.computeIfPresent(targetSystem, (backendSystem, currentResult) -> {
                currentResult.setFinalStatus(newResult.getFinalStatus());
                currentResult.getTasks().addAll(newResult.getTasks());
                return currentResult;
            });
            resultsMap.putIfAbsent(targetSystem, newResult);
        } else {
            resultsMap.put(targetSystem, newResult);
        }
        if (isOnboardingFailed(targetSystem)) {
            requestStatus = RequestStatus.FAILED;
        } else if (isApplicationCompleted()) {
            requestStatus = RequestStatus.COMPLETED;
        } else if (requestStatus == ONBOARDING_STAGE_ONE && isStageOneCompleted()) {
            requestStatus = STAGE_ONE_COMPLETED;
        }
    }

    private boolean isStageOneCompleted() {
        return BackendSystem.getStageOneSystems().stream().filter(authorizedSystems::contains).allMatch(this::isOnboardingCompleted);
    }

    private boolean isOnboardingCompleted(BackendSystem targetSystem) {
        return resultsMap.containsKey(targetSystem) && resultsMap.get(targetSystem).getFinalStatus().isClosureStatus();
    }

    private boolean isOnboardingFailed(BackendSystem targetSystem) {
        return resultsMap.containsKey(targetSystem) && resultsMap.get(targetSystem).getFinalStatus().isFailureStatus();
    }

    private boolean isApplicationCompleted() {
        return authorizedSystems.stream().allMatch(this::isOnboardingCompleted);
    }

    public boolean isOnboardingRequired(BackendSystem backendSystem) {
        return authorizedSystems.contains(backendSystem) && !isOnboardingCompleted(backendSystem);
    }

    /**
     * @return Time since the application is created in milli-seconds
     */
    public long getElapsedTime() {
        if (getCreatedDate() == null) {
            return 0;
        }
        return new Date().getTime() - getCreatedDate().getTime();
    }

    public void addAttachment(BackendSystem backendSystem, Attachment attachment) {
        attachmentsMap.put(backendSystem, attachment);
    }

    public void addScreeningResult(BackendSystem backendSystem, Collection<ScreeningResult> screeningResults) {
        screeningMap.put(backendSystem, screeningResults);
    }

    public void addAdditionalData(BackendSystem backendSystem, AdditionalData additionalData) {
        additionalDataMap.put(backendSystem, additionalData);
    }

}
