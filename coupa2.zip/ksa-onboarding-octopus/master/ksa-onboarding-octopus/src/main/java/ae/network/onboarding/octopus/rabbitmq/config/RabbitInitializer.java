package ae.network.onboarding.octopus.rabbitmq.config;

import org.springframework.amqp.core.*;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static ae.network.onboarding.octopus.rabbitmq.config.RabbitExchange.*;
import static ae.network.onboarding.octopus.rabbitmq.config.RabbitQueue.KSA_FAILS;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
@Component
public class RabbitInitializer {
    private static final String DEAD_LETTER_EXCHANGE = "x-dead-letter-exchange";
    private final AmqpAdmin rabbitAdmin;

    public RabbitInitializer(AmqpAdmin rabbitAdmin) {
        this.rabbitAdmin = rabbitAdmin;
    }

    @PostConstruct
    public void initRabbit() {
        initExchanges();
        initQueues();
    }


    private void initExchanges() {
        rabbitAdmin.declareExchange(mainExchange());
        rabbitAdmin.declareExchange(delayedExchange());
        rabbitAdmin.declareExchange(failureExchange());
    }

    private void initQueues() {
        initFailQueue();
        initWorkingQueues();
    }

    private void initFailQueue() {
        String failuresQueueName = KSA_FAILS.getQueueName();
        Queue queue = new Queue(failuresQueueName, true, false, false, null);
        rabbitAdmin.declareQueue(queue);
        Binding binding = new Binding(failuresQueueName, Binding.DestinationType.QUEUE, KSA_ONBOARDING_FAIL.getExchangeName()
                , "*", null);
        rabbitAdmin.declareBinding(binding);
    }

    private void initWorkingQueues() {
        List<RabbitExchange> workingExchanges = Arrays.asList(KSA_ONBOARDING, KSA_ONBOARDING_RETRY);

        for (RabbitQueue rabbitQueue : RabbitQueue.getWorkingQueues()) {
            String queueName = rabbitQueue.getQueueName();
            // assign dead letter queue
            Map<String, Object> args = new HashMap<>();
            args.put(DEAD_LETTER_EXCHANGE, KSA_ONBOARDING_FAIL.getExchangeName());
            Queue queue = new Queue(queueName, true, false, false, args);
            rabbitAdmin.declareQueue(queue);

            for (String routingKey : rabbitQueue.getRoutingKeys()) {
                for (RabbitExchange exch : workingExchanges) {
                    Binding binding = new Binding(queueName, Binding.DestinationType.QUEUE, exch.getExchangeName()
                            , routingKey, null);
                    rabbitAdmin.declareBinding(binding);
                }
            }
        }
    }

    private Exchange mainExchange() {
        return ExchangeBuilder.topicExchange(KSA_ONBOARDING.getExchangeName())
                .durable(true).build();
    }

    private Exchange delayedExchange() {
        return ExchangeBuilder.directExchange(KSA_ONBOARDING_RETRY.getExchangeName())
                .durable(true).delayed().build();
    }

    private Exchange failureExchange() {
        return ExchangeBuilder.fanoutExchange(KSA_ONBOARDING_FAIL.getExchangeName())
                .durable(true).build();
    }
}
