package ae.network.onboarding.octopus.model.dto;

import java.util.Collection;
 
import java.util.HashSet;
 
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;

import ae.network.onboarding.octopus.model.reply.ScreeningResult;
import ae.network.onboarding.octopus.model.request.BackendSystem;
import lombok.Getter;

/**
 * @author walid.sewaify
 * @since 2020-03-01
 */
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ScreeningResponse {

	private Set<EntityScreening> entities = new HashSet<>();

	public ScreeningResponse(Map<BackendSystem, Collection<ScreeningResult>> resultsMap,
			Map<BackendSystem, String> reportDownloadMap) {

		resultsMap.forEach((backendSystem, screeningResults) -> {
			if (BackendSystem.KSA_MATCH.equals(backendSystem)) {
				entities.add(getMatchResponse(backendSystem, resultsMap.get(BackendSystem.KSA_MATCH)));
			} else {
				for (ScreeningResult screeningResult : screeningResults) {

					String entityId = screeningResult.getEntityId();
					EntityScreening entityScreening = entities.stream()
							.filter(entity -> entityId != null && entityId.equals(entity.getEntityId())).findAny()
							.orElse(new EntityScreening());
					entityScreening.setEntityId(entityId);
//					if (BackendSystem.MATCH.equals(backendSystem)) {
//						entityScreening.getScreeningResult().put(backendSystem,
//								screeningResults.stream().filter(result -> "ON_HOLD".equals(result.getResult()))
//										.findFirst().orElse(screeningResult));
//					} else {
						entityScreening.getScreeningResult().put(backendSystem, screeningResult);
					//}
					if (reportDownloadMap.containsKey(backendSystem)) {
						screeningResult.setDownloadReport(reportDownloadMap.get(backendSystem));
					}
					entities.add(entityScreening);
				}
			}
		});
	}

	/**
	 * @param backEndSystem
	 * @param screeningResults
	 * @return MatchResponse Details
	 */
	private EntityScreening getMatchResponse(BackendSystem backEndSystem,
			Collection<ScreeningResult> screeningResults) {
		ScreeningResult resultEntity = screeningResults.stream().findFirst().orElse(null);
		String entityId = resultEntity.getEntityId();
		EntityScreening entityScreening = entities.stream()
				.filter(entity -> entityId != null && entityId.equals(entity.getEntityId())).findAny()
				.orElse(new EntityScreening());
		entityScreening.setEntityId(entityId);
		entityScreening.getScreeningResult().put(backEndSystem, screeningResults.stream()
				.filter(result -> "ON_HOLD".equals(result.getResult())).findFirst().orElse(resultEntity));

		 

		return entityScreening;

	}
}
