package ae.network.onboarding.octopus.event;

import ae.network.onboarding.octopus.model.request.ApplicationRequest;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
public class StageOneCompletedEvent extends StageOneEvent {

    public StageOneCompletedEvent(ApplicationRequest applicationRequest) {
        super(applicationRequest);
    }
}
