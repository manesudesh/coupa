package ae.network.onboarding.octopus.model.request;

import ae.network.onboarding.octopus.rabbitmq.config.RabbitQueue;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * List of all onboarding backend systems
 */
public enum BackendSystem {
  /*  // stage one (has no dependencies)
    WAY4(RabbitQueue.WAY4), BASE24(RabbitQueue.BASE24), MATCH(RabbitQueue.MATCH), FISERV(RabbitQueue.FISERV), TRUSTWAVE(RabbitQueue.TRUSTWAVE),
    // stage two (dependent on stage one system)
    NGO(RabbitQueue.NGO), NGT(RabbitQueue.NGT), MCSEC(RabbitQueue.MCSEC), PP(RabbitQueue.PP), MCP(RabbitQueue.MCP),
    FXCO(RabbitQueue.FXCO), POSINV(RabbitQueue.POSINV), SS(RabbitQueue.SS), TEST(RabbitQueue.TEST),
    ALIPAY(RabbitQueue.ALIPAY), QRPAY(RabbitQueue.QRPAY), WECHAT(RabbitQueue.WECHAT), G2(RabbitQueue.G2),
    LOYALTY(RabbitQueue.LOYALTY), VERIFONE(RabbitQueue.VERIFONE), SOFTPOS(RabbitQueue.SOFTPOS), _3ds2(RabbitQueue._3ds2),
	MPGS(RabbitQueue.MPGS),SOFTPOS_MOSAMBEE(RabbitQueue.SOFTPOS_MOSAMBEE);
	
    private static final List<BackendSystem> stageOneSystems = Arrays.asList(WAY4, BASE24, MATCH, FISERV, TRUSTWAVE,MPGS);
*/
	
	KSA_MATCH(RabbitQueue.KSA_MATCH),
    KSA_WAY4(RabbitQueue.KSA_WAY4),
	KSA_NGO(RabbitQueue.KSA_NGO),
	KSA_3DS2(RabbitQueue.KSA_3DS2);
	
	private static final List<BackendSystem> stageOneSystems = Arrays.asList(KSA_MATCH, KSA_WAY4, KSA_NGO, KSA_3DS2);
    
    private final RabbitQueue rabbitQueue;

    BackendSystem(RabbitQueue rabbitQueue) {
        this.rabbitQueue = rabbitQueue;
    }

    public static List<BackendSystem> getStageOneSystems() {
        return stageOneSystems;
    }

    public static List<BackendSystem> getStageTwoSystems() {
        return Arrays.stream(values()).filter(system -> !stageOneSystems.contains(system)).collect(Collectors.toList());
    }

    public static boolean contains(String backendSystem) {
        return Arrays.stream(values()).anyMatch(system -> system.name().equalsIgnoreCase(backendSystem));
    }

    public RabbitQueue getRabbitQueue() {
        return rabbitQueue;
    }
}
