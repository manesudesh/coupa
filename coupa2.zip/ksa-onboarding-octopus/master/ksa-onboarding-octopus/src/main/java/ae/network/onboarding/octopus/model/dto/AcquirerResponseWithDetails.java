package ae.network.onboarding.octopus.model.dto;

import ae.network.onboarding.octopus.model.request.ApplicationRequest;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author walid.sewaify
 * @since 2020-03-01
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AcquirerResponseWithDetails extends AcquirerResponse {
    private final ApplicationRequest applicationRequest;

    public AcquirerResponseWithDetails(ApplicationRequest applicationRequest) {
        super(applicationRequest);
        this.applicationRequest = applicationRequest;
    }


    public ApplicationRequest getDetailedReport() {
        return applicationRequest;
    }
}
