package ae.network.onboarding.auth.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.Base64;
import java.util.Date;

class TokenUtil {

    static final String TESTING_SECRET = "testingSecret";
    static final int EXPIRY_AFTER = 3600000;
    private static final String AUTHORITIES_KEY = JwtTokenProvider.AUTHORITIES_KEY;

    static String createUnsupportedToken() {
        return Jwts.builder()
                .setPayload("payload")
                .signWith(SignatureAlgorithm.HS512, "anyKey")
                .compact();
    }

    static String createExpiredToken() {
        String authorities = "ROLE_USER";
        Date now = new Date();
        Date validity = new Date(now.getTime() - 100000);
        return Jwts.builder()
                .setSubject("username")
                .claim(AUTHORITIES_KEY, authorities)
                .signWith(SignatureAlgorithm.HS256, Base64.getEncoder().encodeToString(TESTING_SECRET.getBytes()))
                .setIssuedAt(now)
                .setExpiration(validity)
                .compact();
    }

    static String createTokenWithDifferentSignature() {
        String authorities = "ROLE_USER";
        Date now = new Date();
        Date validity = new Date(now.getTime() + 100000);
        return Jwts.builder()
                .setSubject("username")
                .claim(AUTHORITIES_KEY, authorities)
                .signWith(SignatureAlgorithm.HS512, "otherKey")
                .setIssuedAt(now)
                .setExpiration(validity)
                .compact();
    }
}
