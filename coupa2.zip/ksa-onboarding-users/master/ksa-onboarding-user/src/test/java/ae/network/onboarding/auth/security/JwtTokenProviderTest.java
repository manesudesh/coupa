package ae.network.onboarding.auth.security;

import ae.network.onboarding.auth.model.BackendSystem;
import ae.network.onboarding.auth.model.Role;
import ae.network.onboarding.auth.model.User;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

import static ae.network.onboarding.auth.security.TokenUtil.EXPIRY_AFTER;
import static ae.network.onboarding.auth.security.TokenUtil.TESTING_SECRET;
import static ae.network.onboarding.auth.security.TokenUtil.createExpiredToken;
import static ae.network.onboarding.auth.security.TokenUtil.createTokenWithDifferentSignature;
import static ae.network.onboarding.auth.security.TokenUtil.createUnsupportedToken;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

class JwtTokenProviderTest {
    private JwtTokenProvider tokenProvider;

    @BeforeEach
    void setup() {
        tokenProvider = new JwtTokenProvider();
        ReflectionTestUtils.setField(tokenProvider, "secretKey", TESTING_SECRET);
        ReflectionTestUtils.setField(tokenProvider, "validityInMilliseconds", EXPIRY_AFTER);
        tokenProvider.init();
    }

    @Test
    void testCreateToken() {
        String username = "username";
        User user = createUser(username);
        String token = tokenProvider.createToken(user);

        Claims claims = Jwts.parser().setSigningKey(Base64.getEncoder().encodeToString(TESTING_SECRET.getBytes()))
                .parseClaimsJws(token).getBody();
        List<SimpleGrantedAuthority> authorities = Arrays.stream(claims.get(JwtTokenProvider.AUTHORITIES_KEY).toString().split(","))
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());
        List<BackendSystem> systems = Arrays.stream(claims.get(JwtTokenProvider.SYSTEMS_KEY).toString().split(","))
                .map(BackendSystem::valueOf)
                .collect(Collectors.toList());

        assertEquals(Role.values().length, authorities.size());
        assertEquals(BackendSystem.values().length, systems.size());
        assertEquals("NI", claims.get(JwtTokenProvider.ACQUIRER_KEY));
    }

    @Test
    void testResolveToken() {
        final String token = tokenProvider.createToken(createUser("username"));
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader(HttpHeaders.AUTHORIZATION, "Bearer " + token);
        assertEquals(token, tokenProvider.resolveToken(request));
    }

    @Test
    void testGetUsername() {
        final String username = "username";
        final String token = tokenProvider.createToken(createUser(username));
        assertEquals(username, tokenProvider.getUsername(token));
    }

    @Test
    void testReturnFalseWhenJWThasInvalidSignature() {
        boolean isTokenValid = tokenProvider.validateToken(createTokenWithDifferentSignature());
        assertFalse(isTokenValid);
    }

    @Test
    void testReturnFalseWhenJWTisMalformed() {
        final String token = tokenProvider.createToken(createUser("anyuser"));
        String invalidToken = token.substring(1);
        boolean isTokenValid = tokenProvider.validateToken(invalidToken);
        assertFalse(isTokenValid);
    }

    @Test
    void testReturnFalseWhenJWTisExpired() {
        final String token = createExpiredToken();
        boolean isTokenValid = tokenProvider.validateToken(token);
        assertFalse(isTokenValid);
    }

    @Test
    void testReturnFalseWhenJWTisUnsupported() {
        String unsupportedToken = createUnsupportedToken();
        boolean isTokenValid = tokenProvider.validateToken(unsupportedToken);
        assertFalse(isTokenValid);
    }

    @Test
    void testReturnFalseWhenJWTisInvalid() {
        boolean isTokenValid = tokenProvider.validateToken("");
        assertFalse(isTokenValid);
    }


    private User createUser(String username) {
        User user = new User();
        user.setRoles(Arrays.asList(Role.values()));
        user.setBackendSystems(Arrays.asList(BackendSystem.values()));
        user.setUsername(username);
        user.setAcquirer("NI");
        return user;
    }

}