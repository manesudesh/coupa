package ae.network.onboarding.auth.service;

import ae.network.onboarding.auth.exception.CustomException;
import ae.network.onboarding.auth.model.Role;
import ae.network.onboarding.auth.model.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class UserServiceTest {


    @Autowired
    UserService userService;

    @Value("${login.default-password}")
    private String defaultPassword;

    @Test
    void testSuccessfulLogin() {
        assertNotNull(userService.signin("admin", "Test@1234"));
    }

    @Test
    void testFailedLogin() {
        assertThrows(CustomException.class, () -> userService.signin("admin", null));
    }

    @Test
    void testSignUp() {
        User user = new User();
        String username = "username";
        user.setUsername(username);
        user.setRoles(Collections.singletonList(Role.ADMIN));
        user.setBackendSystems(Collections.emptyList());
        user.setAcquirer("NI");
        userService.signup(user);
        userService.signin(username, defaultPassword);
    }

    @Test
    void testInvalidSignUp() {
        User user = new User();
        user.setUsername("admin");
        user.setRoles(Collections.singletonList(Role.ADMIN));
        user.setBackendSystems(Collections.emptyList());
        assertThrows(CustomException.class, () -> userService.signup(user));
    }

    @Test
    void testInvalidAcquirer() {
        User user = new User();
        user.setUsername("admin");
        user.setRoles(Collections.singletonList(Role.ADMIN));
        user.setBackendSystems(Collections.emptyList());
        user.setAcquirer("INVALID");
        assertThrows(CustomException.class, () -> userService.signup(user));
    }

    @Test
    void testRefreshToken() {
        userService.refresh("admin");
    }

    @Test
    void testSearchUser() {
        assertTrue(userService.search("admin").getRoles().size() > 0);
    }

    @Test
    void testDeleteUser() {
        userService.delete("admin");
        assertThrows(CustomException.class, () -> userService.signin("admin", null));

    }
}