package ae.network.onboarding.auth.controller;

import ae.network.onboarding.auth.model.Role;
import ae.network.onboarding.auth.model.User;
import ae.network.onboarding.auth.security.JwtTokenProvider;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.Collections;

import static com.mongodb.internal.connection.tlschannel.util.Util.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Integration test for users service
 */
@AutoConfigureMockMvc
@SpringBootTest
class UserControllerTest {
    private static String token;
    @Autowired
    JwtTokenProvider jwtTokenProvider;
    @Autowired
    private MockMvc mvc;

    @BeforeEach
    void testValidLogin() throws Exception {
        final MvcResult mvcResult = mvc.perform(
                post("/users/signin")
                        .param("username", "admin")
                        .param("password", "Test@1234"))
                .andExpect(status().isOk()).andReturn();
        token = mvcResult.getResponse().getContentAsString();
    }

    @Test
    void testInvalidLogin() throws Exception {
        mvc.perform(
                post("/users/signin")
                        .param("username", "admin")
                        .param("password", "wrong"))
                .andExpect(status().is4xxClientError());
    }

    @Test
    void testUserSignUp() throws Exception {
        mvc.perform(
                post("/users/signup")
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(userAsJson("newClient")))
                .andExpect(status().isOk());
    }

    @Test
    void testInvalidUserSignUp() throws Exception {
        mvc.perform(
                post("/users/signup")
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(userAsJson(null)))
                .andExpect(status().is4xxClientError());
    }

    @Test
    void testUserDkete() throws Exception {
        mvc.perform(
                delete("/users/ni")
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + token))
                .andExpect(status().isOk());
    }

    @Test
    void testUserSearch() throws Exception {
        mvc.perform(
                get("/users/tyme")
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + token))
                .andExpect(status().isOk()).andExpect(content().json("{'username':'tyme'}"));
    }

    @Test
    void testWhoAmI() throws Exception {
        mvc.perform(
                get("/users/whoami")
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + token))
                .andExpect(status().isOk()).andExpect(content().json("{'username':'admin'}"));
    }

    @Test
    void testTokenRefresh() throws Exception {
        final MvcResult mvcResult = mvc.perform(
                get("/users/refresh")
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + token))
                .andExpect(status().isOk()).andReturn();
        assertTrue(jwtTokenProvider.validateToken(mvcResult.getResponse().getContentAsString()));
    }

    private String userAsJson(String newClient) throws JsonProcessingException {
        User user = new User();
        user.setUsername(newClient);
        user.setAcquirer("NI");
        user.setRoles(Collections.singletonList(Role.CLIENT));
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(user);
    }
}