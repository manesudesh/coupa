package ae.network.onboarding.auth.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;

/**
 * @author https:jwt.io/
 */
@Configuration
//@EnableSwagger2
@SecurityScheme( name = "Authorization", type = SecuritySchemeType.APIKEY,  in = SecuritySchemeIn.HEADER ) 
public class SwaggerConfig {
	
	
	@Bean
	  public OpenAPI userOpenAPI() {
	      return new OpenAPI()
	              .info(new Info().title("Users & Authentication API")
	              .description("Users management service that allows users to authenticate and obtain a JWT access token. You can find out more about JWT at [https:jwt.io/](https:jwt.io/). Once you have successfully logged in and obtained the token, you should click on the right top button `Authorize` and introduce it with the prefix \"Bearer \".")
	              .version("v1")
	              .license(new License().name("Network International").url("https://NI.github.org/docs")))
	              .externalDocs(new ExternalDocumentation());
	  } 
	  
    /*
	@Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.any())
                .paths(Predicates.not(PathSelectors.regex("/error")))
                .build()
                .apiInfo(metadata())
                .useDefaultResponseMessages(false)
                .securitySchemes(new ArrayList<>(Collections.singletonList(new ApiKey("Bearer %token", "Authorization", "Header"))))
                .tags(new Tag("users", "Operations about users"))
                .genericModelSubstitutes(Optional.class);

    }

    private ApiInfo metadata() {
        return new ApiInfoBuilder()
                .title("Users & Authentication API")
                .description(
                        "Users management service that allows users to authenticate and obtain a JWT access token. You can find out more about JWT at [https:jwt.io/](https:jwt.io/). Once you have successfully logged in and obtained the token, you should click on the right top button `Authorize` and introduce it with the prefix \"Bearer \".")
                .version("1.0.0")
                .build();
    }
*/

}
