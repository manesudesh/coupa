package ae.network.onboarding.auth.mongodata;

import org.springframework.context.annotation.Profile;

/**
 * @author walid.sewaify
 * @since 12-02-2020
 */
//@Configuration
@Profile("!prod")
public class MongobeeConfig {
	/*
	@Bean
    public MongoClient mongoClient()
    {
		return new MongoClient();
    }
    		
    @Bean
    public Mongobee mongobee(MongoClient mongoClient, MongoTemplate mongoTemplate, MongoProperties mongoProperties) {
        Mongobee mongobee = new Mongobee(mongoClient);
        mongobee.setDbName(mongoProperties.getMongoClientDatabase());
        mongobee.setMongoTemplate(mongoTemplate);
        // package to scan for migrations
        mongobee.setChangeLogsScanPackage(MongobeeConfig.class.getPackage().getName());
        mongobee.setEnabled(true);
        return mongobee;
    }
    */
}
