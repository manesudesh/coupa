package ae.network.onboarding.auth.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.Size;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@Document("users")
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Data
public class User {

    @Id
    @EqualsAndHashCode.Include
    private String id;

    @Size(min = 4, max = 255, message = "Minimum username length: 4 characters")
    private String username;

    private String email;

    private String password;

    private List<Role> roles;

    private String acquirer;

    private List<BackendSystem> backendSystems = Collections.emptyList();

    private Date latestAccess;

}
