package ae.network.onboarding.auth.dto;

import java.util.List;

import ae.network.onboarding.auth.model.BackendSystem;
import ae.network.onboarding.auth.model.Role;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class UserDataDTO {

//    @ApiModelProperty(position = 0)
    @NotNull
    @Size(min = 2, max = 32)
    private String username;
//    @ApiModelProperty(position = 1)
    @Size(min = 5, max = 32)
    private String email;
//    @ApiModelProperty(position = 2)
    @NotNull
    private List<Role> roles;
//    @ApiModelProperty(position = 3)
    private List<BackendSystem> backendSystems;
    @NotNull
//    @ApiModelProperty(position = 4)
    private String acquirer;
}
