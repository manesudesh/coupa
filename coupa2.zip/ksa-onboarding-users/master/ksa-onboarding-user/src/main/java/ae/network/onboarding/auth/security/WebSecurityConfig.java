package ae.network.onboarding.auth.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true, jsr250Enabled = true)
public class WebSecurityConfig // extends WebSecurityConfigurerAdapter
{
	public AuthenticationManager authenticationManager;
	
	@Autowired  JwtTokenFilter jwtTokenFilter;
	
	  @Bean
	    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
	        http.csrf().disable()
	                .authorizeRequests()
	                .requestMatchers("/users/signin").permitAll()//
	                .requestMatchers("/users/signup").permitAll()//
	                .requestMatchers("/users/whoami").permitAll()//
	                .requestMatchers("/actuator/**").permitAll()
	                .requestMatchers("/v3/api-docs/**").permitAll()
	                .anyRequest()
	                .authenticated()
	                .and()
	                .exceptionHandling().accessDeniedPage("/login");
	        
	        DefaultSecurityFilterChain securityfilterChain =  http.build();
	        
	        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

	        http.addFilterBefore(jwtTokenFilter, UsernamePasswordAuthenticationFilter.class);
	       
	        authenticationManager = http.getSharedObject(AuthenticationManagerBuilder.class).getOrBuild();
	        
	        return securityfilterChain;
	    }
	  
	  @Bean
	    public WebSecurityCustomizer webSecurityCustomizer() {
	        return (web) -> web.ignoring().requestMatchers("/v3/api-docs",
	        		"/swagger-resources/**",
	        		"/swagger-ui.html",
	        		"/swagger-ui/**",
	        		"/actuator/**",
	        		"/configuration/**",
	        		"/webjars/**",
	        		"/public");
	    }
	  
}
