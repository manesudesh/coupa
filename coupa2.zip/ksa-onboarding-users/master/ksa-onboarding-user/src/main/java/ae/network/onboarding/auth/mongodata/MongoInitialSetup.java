package ae.network.onboarding.auth.mongodata;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.github.cloudyrock.mongock.ChangeLog;

import lombok.extern.slf4j.Slf4j;

/**
 * Creating mongodb initial data
 *
 * @author walid.sewaify
 * @since 12-02-2020
 */
@ChangeLog(order = "001") 
@Slf4j
public class MongoInitialSetup {
    private static final String TEST_PASS = new BCryptPasswordEncoder(12).encode("Test@1234");
/*
    @ChangeSet(order = "01", author = "octopus", id = "01-createDefaultAdminUser")
    public void createDefaultAdminUser(MongoTemplate mongoTemplate) {
        User admin = new User();
        admin.setUsername("admin");
        admin.setPassword(TEST_PASS);
        admin.setEmail("onboarding@network.global");
        admin.setRoles(new ArrayList<>(Collections.singletonList(Role.ADMIN)));
        admin.setBackendSystems(Collections.emptyList());
        mongoTemplate.save(admin);
    }

    @ChangeSet(order = "02", author = "octopus", id = "02-createDefaultNIClient")
    public void createDefaultNIClient(MongoTemplate mongoTemplate) {
        User user = new User();
        user.setUsername("ni");
        user.setPassword(TEST_PASS);
        user.setAcquirer("NI");
        user.setEmail("onboarding@network.global");
        user.setRoles(new ArrayList<>(Collections.singletonList(Role.CLIENT)));
        user.setBackendSystems(Arrays.asList(BackendSystem.values()));
        mongoTemplate.save(user);
    }

    @ChangeSet(order = "03", author = "octopus", id = "03-createDefaultTymeClient")
    public void createDefaultTymeClient(MongoTemplate mongoTemplate) {
        User user = new User();
        user.setUsername("tyme");
        user.setPassword(TEST_PASS);
        user.setAcquirer("TYME");
        user.setEmail("onboarding@network.global");
        user.setRoles(new ArrayList<>(Collections.singletonList(Role.CLIENT)));
        user.setBackendSystems(Arrays.asList(BackendSystem.values()));
        mongoTemplate.save(user);
    }

    @ChangeSet(order = "04", author = "octopus", id = "03-createTymeTestUser")
    public void createTymeTestUser(MongoTemplate mongoTemplate) {
        User user = new User();
        user.setUsername("tyme_test");
        user.setPassword(TEST_PASS);
        user.setAcquirer("TYME");
        user.setEmail("onboarding@network.global");
        user.setRoles(new ArrayList<>(Collections.singletonList(Role.CLIENT)));
        user.setBackendSystems(Collections.singletonList(BackendSystem.TEST));
        mongoTemplate.save(user);
    }

    @ChangeSet(order = "05", author = "octopus", id = "03-createNITestUser")
    public void createNITestUser(MongoTemplate mongoTemplate) {
        User user = new User();
        user.setUsername("ni_test");
        user.setPassword(TEST_PASS);
        user.setAcquirer("NI");
        user.setEmail("onboarding@network.global");
        user.setRoles(new ArrayList<>(Collections.singletonList(Role.CLIENT)));
        user.setBackendSystems(Collections.singletonList(BackendSystem.TEST));
        mongoTemplate.save(user);
    }
    
    @ChangeSet(order = "06", author = "octopus", id = "01-createNIKSAUser")
    public void createNIKSAtUser(MongoTemplate mongoTemplate) {
        User user = new User();
        user.setUsername("ksa_ni");
        user.setPassword(TEST_PASS);
        user.setAcquirer("KSA_NI");
        user.setEmail("onboarding@network.global");
        user.setRoles(new ArrayList<>(Collections.singletonList(Role.ADMIN)));
        user.setBackendSystems(Arrays.asList(BackendSystem.KSA_NGO, BackendSystem.KSA_WAY4, BackendSystem.KSA_3ds2));
        mongoTemplate.save(user);
    }
 */   
}
