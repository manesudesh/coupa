package ae.network.onboarding.auth;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.EventListener;

import com.github.cloudyrock.spring.v5.EnableMongock;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import com.ulisesbocchio.jasyptspringboot.caching.RefreshScopeRefreshedEventListener;

@SpringBootApplication
@RefreshScope
@EnableEncryptableProperties
@EnableMongock
public class OctopusUsersServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(OctopusUsersServiceApplication.class, args);
    }

    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }
    
    
    @EventListener({
    	ApplicationReadyEvent.class ,
    	RefreshScopeRefreshedEventListener.class
    })
    public void onEvent(ApplicationEvent re) {
//    	System.out.println(" On OCTOPUS USER Refresh EVENNENT");
    }
}
