package ae.network.onboarding.auth.dto;

import ae.network.onboarding.auth.model.Role;
import lombok.Data;

import java.util.List;

@Data
public class UserResponseDTO {

//    @ApiModelProperty(position = 0)
    private String id;
//    @ApiModelProperty(position = 1)
    private String username;
//    @ApiModelProperty(position = 2)
    private String email;
//    @ApiModelProperty(position = 3)
    private List<Role> roles;
}
