package ae.network.onboarding.gateway.security;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.ReactiveAuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

/**
 * @author Otto Success Joseph
 * @since 25 January 2020
 */
@Component
@Slf4j
public class AuthenticationManager implements ReactiveAuthenticationManager {

    private final JwtTokenProvider tokenProvider;

    public AuthenticationManager(JwtTokenProvider tokenProvider) {
        this.tokenProvider = tokenProvider;
    }

    @Override
    public Mono<Authentication> authenticate(Authentication authentication) {
        String authToken = authentication.getCredentials().toString();
        log.debug("processing token: {}", authToken);
        if (tokenProvider.validateToken(authToken)) {
            String username = tokenProvider.getTokenClaims(authToken).getUserName();
            log.info("valid token, user {} is logged-in", username);
            UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(
                    username, null, tokenProvider.getAuthority(authToken));
            return Mono.just(auth);

        }
        return Mono.empty();
    }

    public Mono<Authentication> authenticate(ServerWebExchange swe) {
        String authToken = tokenProvider.resolveToken(swe);
        if (authToken == null) {
            log.debug("No valid token found for authentication");
            return Mono.empty();
        }

        Mono<Authentication> result = authenticate(new UsernamePasswordAuthenticationToken(authToken, authToken));

        // attach headers for claims
        result.subscribe(authentication -> {
            TokenClaims tokenClaims = tokenProvider.getTokenClaims(authToken);
            swe.getRequest().mutate()
                    .header("X-OCTOPUS-USERNAME", tokenClaims.getUserName())
                    .header("X-OCTOPUS-ACQUIRER", tokenClaims.getAcquirer())
                    .header("X-OCTOPUS-BACKEND-SYSTEMS", tokenClaims.getBackendSystems().toArray(new String[0]));
        });
        
        return result;
    }
}
