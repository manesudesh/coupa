package ae.network.onboarding.gateway.security;

import lombok.Data;

import java.util.List;

/**
 * @author walid.sewaify
 * @since 2021-01-03
 */
@Data
public class TokenClaims {
    private String userName;
    private String acquirer;
    private List<String> authorities;
    private List<String> backendSystems;
}
