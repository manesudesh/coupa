package ae.network.onboarding.gateway.security;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

/**
 * @author walid.sewaify
 * @since 2020-04-02
 */
@Slf4j
public class LoggingFilter implements WebFilter {

    private static final String FORWARDED_HEADER = "X-Forwarded-For";

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        logRemoteAddr(request);
        return chain.filter(exchange);
    }

    private void logRemoteAddr(final ServerHttpRequest request) {
        final String ipFromHeader = request.getHeaders().getFirst(FORWARDED_HEADER);
        if (ipFromHeader != null && ipFromHeader.length() > 0) {
            MDC.put("remote_ip", ipFromHeader);
        }
        log.debug("Headers: " + request.getHeaders().toString());
    }
}
