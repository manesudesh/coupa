package ae.network.onboarding.gateway.security;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import static ae.network.onboarding.gateway.security.TokenUtil.TESTING_SECRET;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SecurityContextRepositoryTest {

    private SecurityContextRepository securityContextRepository;

    @BeforeEach
    void setup() {
        JwtTokenProvider tokenProvider = new JwtTokenProvider();
        ReflectionTestUtils.setField(tokenProvider, "secretKey", TESTING_SECRET);
        tokenProvider.init();
        securityContextRepository = new SecurityContextRepository(new AuthenticationManager(tokenProvider));
    }


    @Test
    void testFailedAuthentication(@Mock ServerWebExchange serverWebExchange, @Mock ServerHttpRequest httpRequest) {
        HttpHeaders headers = new HttpHeaders();
        when(httpRequest.getHeaders()).thenReturn(headers);
        when(serverWebExchange.getRequest()).thenReturn(httpRequest);
        assertNotEquals(Mono.empty(), securityContextRepository.load(serverWebExchange));
    }
}