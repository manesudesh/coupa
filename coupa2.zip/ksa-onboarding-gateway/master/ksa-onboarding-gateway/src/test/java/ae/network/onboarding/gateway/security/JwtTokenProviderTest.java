package ae.network.onboarding.gateway.security;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.server.ServerWebExchange;

import java.util.Collections;

import static ae.network.onboarding.gateway.security.TokenUtil.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class JwtTokenProviderTest {
    private static final String ROLE_ADMIN = Role.ADMIN.id();
    private static final String ROLE_CLIENT = Role.CLIENT.id();

    private JwtTokenProvider tokenProvider;

    @BeforeEach
    void setup() {
        tokenProvider = new JwtTokenProvider();
        ReflectionTestUtils.setField(tokenProvider, "secretKey", TESTING_SECRET);
        tokenProvider.init();
    }

    @Test
    void testResolveToken(@Mock ServerWebExchange serverWebExchange, @Mock ServerHttpRequest httpRequest) {
        final String token = createToken("username", ROLE_ADMIN, ROLE_CLIENT);
        HttpHeaders headers = new HttpHeaders();
        headers.put(HttpHeaders.AUTHORIZATION, Collections.singletonList("Bearer " + token));
        when(httpRequest.getHeaders()).thenReturn(headers);
        when(serverWebExchange.getRequest()).thenReturn(httpRequest);
        assertEquals(token, tokenProvider.resolveToken(serverWebExchange));
        assertEquals(2, tokenProvider.getAuthority(token).size());
    }

    @Test
    void testGetUsername() {
        final String username = "username";
        final String token = createToken(username, ROLE_ADMIN);
        assertEquals(username, tokenProvider.getTokenClaims(token).getUserName());
    }

    @Test
    void testReturnFalseWhenJWThasInvalidSignature() {
        boolean isTokenValid = tokenProvider.validateToken(createTokenWithDifferentSignature());
        assertFalse(isTokenValid);
    }

    @Test
    void testReturnFalseWhenJWTisMalformed() {
        final String token = createToken("anyuser", ROLE_ADMIN);
        String invalidToken = token.substring(1);
        boolean isTokenValid = tokenProvider.validateToken(invalidToken);
        assertFalse(isTokenValid);
    }

    @Test
    void testReturnFalseWhenJWTisExpired() {
        final String token = createExpiredToken();
        boolean isTokenValid = tokenProvider.validateToken(token);
        assertFalse(isTokenValid);
    }

    @Test
    void testReturnFalseWhenJWTisUnsupported() {
        String unsupportedToken = createUnsupportedToken();
        boolean isTokenValid = tokenProvider.validateToken(unsupportedToken);
        assertFalse(isTokenValid);
    }

    @Test
    void testReturnFalseWhenJWTisInvalid() {
        boolean isTokenValid = tokenProvider.validateToken("");
        assertFalse(isTokenValid);
    }
}