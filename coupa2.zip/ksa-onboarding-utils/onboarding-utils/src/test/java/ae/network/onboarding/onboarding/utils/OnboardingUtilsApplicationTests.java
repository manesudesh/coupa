package ae.network.onboarding.onboarding.utils;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;

@SpringBootTest
@Import(DummyRabbit.class)
class OnboardingUtilsApplicationTests {

    @Test
    void contextLoads() {
    }

}
