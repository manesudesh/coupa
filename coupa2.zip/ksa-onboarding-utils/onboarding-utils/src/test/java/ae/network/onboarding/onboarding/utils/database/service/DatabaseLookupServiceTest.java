package ae.network.onboarding.onboarding.utils.database.service;

import ae.network.onboarding.onboarding.utils.database.repository.CountryRepository;
import ae.network.onboarding.onboarding.utils.database.repository.CurrencyRepository;
import ae.network.onboarding.onboarding.utils.database.service.lookup.DatabaseLookupService;
import ae.network.onboarding.onboarding.utils.database.service.lookup.LookupService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.context.annotation.ComponentScan;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@DataMongoTest
@ComponentScan("ae.network.onboarding.onboarding.utils.mongodata")
class DatabaseLookupServiceTest {
    @Autowired
    private CountryRepository countryRepository;

    @Autowired
    private CurrencyRepository currencyRepository;

    private LookupService lookupService;

    @BeforeEach
    void init() {
        lookupService = new DatabaseLookupService(countryRepository, currencyRepository);
    }

    @Test
    void testAlpha2CountryCodes() {
        String uae = lookupService.countryCodeToAlpha2("ARE");
        String egy = lookupService.countryCodeToAlpha2("EGY");
        assertEquals("AE", uae);
        assertEquals("EG", egy);
    }

    @Test
    void testInvalidAlpha2CountryCodes() {
        String nil = lookupService.countryCodeToAlpha2(null);
        String empty = lookupService.countryCodeToAlpha2("");
        String invalid = lookupService.countryCodeToAlpha2("ZZZ");
        assertNull(nil);
        assertNull(empty);
        assertNull(invalid);
    }

    @Test
    void testAlpha3CountryCodes() {
        String uae = lookupService.countryCodeToAlpha3("AE");
        String egy = lookupService.countryCodeToAlpha3("EG");
        assertEquals("ARE", uae);
        assertEquals("EGY", egy);
    }

    @Test
    void testInvalidAlpha3CountryCodes() {
        String nil = lookupService.countryCodeToAlpha3(null);
        String empty = lookupService.countryCodeToAlpha3("");
        String invalid = lookupService.countryCodeToAlpha3("ZZZ");
        assertNull(nil);
        assertNull(empty);
        assertNull(invalid);
    }

    @Test
    void testCurrencyNumber() {
        Integer uae = lookupService.currencyCodeToCurrencyNumber("AED");
        Integer egy = lookupService.currencyCodeToCurrencyNumber("EGP");
        assertEquals(784, uae);
        assertEquals(818, egy);
    }

    @Test
    void testInvalidCurrencyCode() {
        Integer nil = lookupService.currencyCodeToCurrencyNumber(null);
        Integer empty = lookupService.currencyCodeToCurrencyNumber("");
        Integer invalid = lookupService.currencyCodeToCurrencyNumber("XXX");
        assertNull(nil);
        assertNull(empty);
        assertNull(invalid);
    }

    @Test
    void testNumericAlpha3CountryCodes() {
        Integer uae = lookupService.countryCodeAlpha3ToNumeric("ARE");
        Integer egy = lookupService.countryCodeAlpha3ToNumeric("EGY");
        assertEquals(784, uae);
        assertEquals(818, egy);
    }
}