package ae.network.onboarding.onboarding.utils.database.service.mail;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import java.util.Collection;
import java.util.Collections;

/**
 * @author walid.sewaify
 * @since 2020-09-13
 */
@Service
@Slf4j
public class MailServiceImpl implements MailService {

    private final JavaMailSender javaMailSender;

    public MailServiceImpl(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    @Override
    @SneakyThrows({MessagingException.class, JsonProcessingException.class})
    public void sendHtmlEmail(String emailAsJson) {

        Email email = new ObjectMapper().readValue(emailAsJson, Email.class);

        if (email == null || email.getTo() == null || email.getFrom() == null || email.getEmailContent() == null) {
            throw new RuntimeException("Invalid email data");
        }
        log.info("Processing html email request: " + email.toString());

        MimeMessage mimeMessage = this.javaMailSender.createMimeMessage();
        // Prepare message using a Spring helper
        MimeMessageHelper message =
                new MimeMessageHelper(mimeMessage, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, "UTF-8");
        message.setText(email.getEmailContent(), true);

        message.setSubject(email.getSubject());
        message.setFrom(email.getFrom());
        for (String to : safe(email.getTo())) {
            message.addTo(to);
        }
        for (String cc : safe(email.getCc())) {
            message.addTo(cc);
        }
        for (String bcc : safe(email.getBcc())) {
            message.addTo(bcc);
        }
        for (Attachment attachment : safe(email.getAttachments())) {
            if (attachment != null) {
                log.info("adding attachment {}", attachment.getFileName());
                message.addAttachment(attachment.getFileName(), new ByteArrayResource(attachment.getContent()));
            }
        }

        log.info("mail content: " + email.getEmailContent());
        this.javaMailSender.send(mimeMessage);
    }

    private static <T> Collection<T> safe(Collection<T> coll) {
        return coll == null ? Collections.emptyList() : coll;
    }

}
