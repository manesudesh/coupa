package ae.network.onboarding.onboarding.utils.database.service;

import ae.network.onboarding.onboarding.utils.database.service.lookup.LookupService;
import ae.network.onboarding.onboarding.utils.database.service.mail.MailService;

/**
 * @author walid.sewaify
 * @since 2020-09-20
 */
public interface OnboardingUtils extends LookupService, MailService {
}
