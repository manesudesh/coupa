package ae.network.onboarding.onboarding.utils.database.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "utils_countries")
public class Country {
    @Id
    private String name;
    private String alpha2;
    private String alpha3;
    private Integer numeric;
}
