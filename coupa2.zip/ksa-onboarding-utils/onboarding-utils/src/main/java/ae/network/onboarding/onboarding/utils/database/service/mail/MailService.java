package ae.network.onboarding.onboarding.utils.database.service.mail;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;

public interface MailService {
    @Async
    void sendHtmlEmail(String emailAsJson);
}
