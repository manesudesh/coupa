package ae.network.onboarding.onboarding.utils.database.service.mail;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.io.Serializable;

/**
 * @author walid.sewaify
 * @since 2020-05-14
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Attachment implements Serializable {
    private String fileName;

    private String contentType;

    private byte[] content;
}
