package ae.network.onboarding.onboarding.utils.database.repository;


import ae.network.onboarding.onboarding.utils.database.model.Currency;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
public interface CurrencyRepository extends MongoRepository<Currency, String> {
    Optional<Currency> findByCurrencyCode(String currencyCode);
}
