package ae.network.onboarding.onboarding.utils.database.service.lookup;

import ae.network.onboarding.onboarding.utils.database.model.Country;
import ae.network.onboarding.onboarding.utils.database.model.Currency;
import ae.network.onboarding.onboarding.utils.database.repository.CountryRepository;
import ae.network.onboarding.onboarding.utils.database.repository.CurrencyRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author walid.sewaify
 * @since 2020-08-06
 */
@Service
@Slf4j
public class DatabaseLookupService implements LookupService {

    private final CountryRepository countryRepository;
    private final CurrencyRepository currencyRepository;

    public DatabaseLookupService(CountryRepository countryRepository, CurrencyRepository currencyRepository) {
        this.countryRepository = countryRepository;
        this.currencyRepository = currencyRepository;
    }
    
    @Override
    @Cacheable(cacheNames = "allCountryCode")
    public List<Country>  allCountryCode() {
        List<Country> countryList = countryRepository.findAll();
//        log.info(" ALLCOUNTRYYYYYYYYYCODDDDE to ");
        return countryList;
    }

    @Override
    @Cacheable(cacheNames = "countryCodeToAlpha2")
    public String countryCodeToAlpha2(String alpha3CountryCode) {
        if (alpha3CountryCode == null) {
            return null;
        }
        Optional<Country> countryOpt = countryRepository.findByAlpha3(alpha3CountryCode.toUpperCase());
        String result = countryOpt.map(Country::getAlpha2).orElse(null);
        log.info("{} mapped to {}", alpha3CountryCode, result);
        return result;
    }

    @Override
    @Cacheable(cacheNames = "countryCodeToAlpha3")
    public String countryCodeToAlpha3(String alpha2CountryCode) {
        if (alpha2CountryCode == null) {
            return null;
        }
        Optional<Country> countryOpt = countryRepository.findByAlpha2(alpha2CountryCode.toUpperCase());
        String result = countryOpt.map(Country::getAlpha3).orElse(null);
        log.info("{} mapped to {}", alpha2CountryCode, result);
        return result;
    }

    @Override
    @Cacheable(cacheNames = "currencyCodeToCurrencyNumber")
    public Integer currencyCodeToCurrencyNumber(String currencyCode) {
        if (currencyCode == null) {
            return null;
        }
        Optional<Currency> currencyOpt = currencyRepository.findByCurrencyCode(currencyCode.toUpperCase());
        Integer result = currencyOpt.map(Currency::getCurrencyNumber).orElse(null);
        log.info("{} mapped to {}", currencyCode, result);
        return result;
    }

    @Override
    @Cacheable(cacheNames = "countryCodeAlpha3ToNumeric")
    public Integer countryCodeAlpha3ToNumeric(String alpha3CountryCode) {
        if (alpha3CountryCode == null) {
            return null;
        }
        Optional<Country> countryOpt = countryRepository.findByAlpha3(alpha3CountryCode.toUpperCase());
        Integer result = countryOpt.map(Country::getNumeric).orElse(null);
        log.info("{} mapped to {}", alpha3CountryCode, result);
        return result;
    }
}
