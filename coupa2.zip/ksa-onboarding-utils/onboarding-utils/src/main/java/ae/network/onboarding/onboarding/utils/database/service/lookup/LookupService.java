package ae.network.onboarding.onboarding.utils.database.service.lookup;

import java.util.List;

import ae.network.onboarding.onboarding.utils.database.model.Country;

/**
 * @author walid.sewaify
 * @since 2020-08-06
 */
public interface LookupService {
    /**
     * @param countryCode alpha3 country code that should be mapped to alpha2 code
     * @return mapped value if exists, or else null
     */
    String countryCodeToAlpha2(String countryCode);

    /**
     * @param countryCode alpha2 country code that should be mapped to alpha3 code
     * @return mapped value if exists, or else null
     */
    String countryCodeToAlpha3(String countryCode);

    /**
     * @param currencyCode 3 letter currency code
     * @return currency number if exists, or else null
     */
    Integer currencyCodeToCurrencyNumber(String currencyCode);

    /**
     * @param countryCode alpha3 code
     * @return numeric code
     */
    Integer countryCodeAlpha3ToNumeric(String countryCode);
    
    public List<Country>  allCountryCode();
}
