package ae.network.onboarding.onboarding.utils.rabbitmq.config;

import ae.network.onboarding.onboarding.utils.database.service.OnboardingUtils;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
//import org.springframework.amqp.remoting.service.AmqpInvokerServiceExporter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@Configuration
@EnableRabbit
public class RabbitConfig {

    private static final String UTILS_QUEUE = "utils";

    @Bean
    public AmqpAdmin rabbitAdmin(ConnectionFactory factory) {
        return new RabbitAdmin(factory);
    }

   /* @Bean
    public AmqpInvokerServiceExporter utilServicesExporter(
            OnboardingUtils implementation, AmqpTemplate template) {

        AmqpInvokerServiceExporter exporter = new AmqpInvokerServiceExporter();
        exporter.setServiceInterface(OnboardingUtils.class);
        exporter.setService(implementation);
        exporter.setAmqpTemplate(template);
        return exporter;
    }
*/
    
    @Bean
    public SimpleMessageListenerContainer utilServicesListener(ConnectionFactory factory, 
    		MessageConsumer consumer
            ) {
        SimpleMessageListenerContainer container = new SimpleMessageListenerContainer(factory);
//        container.setMessageListener(utilServicesExporter);
        container.setMessageListener(consumer);
        container.setQueueNames(UTILS_QUEUE);
        container.setBeanName("OnboardingUtils");
        return container;
    }
}
