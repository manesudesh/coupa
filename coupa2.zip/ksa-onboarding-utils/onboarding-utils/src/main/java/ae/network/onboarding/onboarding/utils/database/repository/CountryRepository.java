package ae.network.onboarding.onboarding.utils.database.repository;


import ae.network.onboarding.onboarding.utils.database.model.Country;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
public interface CountryRepository extends MongoRepository<Country, String> {

    Optional<Country> findByAlpha3(String alpha3);

    Optional<Country> findByAlpha2(String alpha2);
}
