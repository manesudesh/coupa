package ae.network.onboarding.onboarding.utils.database.service;

import ae.network.onboarding.onboarding.utils.database.model.Country;
import ae.network.onboarding.onboarding.utils.database.service.lookup.LookupService;
import ae.network.onboarding.onboarding.utils.database.service.mail.MailService;
import lombok.AllArgsConstructor;

import java.util.List;

import org.springframework.stereotype.Service;

/**
 * @author walid.sewaify
 * @since 2020-09-20
 */
@Service
@AllArgsConstructor
public class OnboardingUtilsImpl implements OnboardingUtils {
    public final LookupService lookupService;
    public final MailService mailService;

    @Override
    public String countryCodeToAlpha2(String countryCode) {
        return lookupService.countryCodeToAlpha2(countryCode);
    }

    @Override
    public String countryCodeToAlpha3(String countryCode) {
        return lookupService.countryCodeToAlpha3(countryCode);
    }

    @Override
    public Integer currencyCodeToCurrencyNumber(String currencyCode) {
        return lookupService.currencyCodeToCurrencyNumber(currencyCode);
    }

    @Override
    public Integer countryCodeAlpha3ToNumeric(String countryCode) {
        return lookupService.countryCodeAlpha3ToNumeric(countryCode);
    }

    @Override
    public void sendHtmlEmail(String emailAsJson) {
        mailService.sendHtmlEmail(emailAsJson);
    }

	@Override
	public List<Country> allCountryCode() {
		return lookupService.allCountryCode();
	}
}
