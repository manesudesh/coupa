package ae.network.onboarding.onboarding.utils.database.service.mail;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;
import java.util.Collection;

/**
 * @author Success.Otto
 * @since 25/03/2020
 */
@Data
@Slf4j
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class Email implements Serializable {
    /**
     * Content of the email
     */
    private String emailContent;
    /**
     * Heading of the mail
     */
    private String subject;
    /**
     * Where the mail is coming from and con not be null
     */
    private String from;
    /**
     * Mails can be sent to multiple recipients. Specifies recipients of the mail
     */
    private Collection<String> to;
    /**
     * References are sometimes in a mail. Email address to keep in the loop of the mail
     */
    private Collection<String> cc;
    /**
     * Similar to cc but this mail won't be displayed in the recipients mail
     */
    private Collection<String> bcc;
    /**
     * Attachments to the mail
     */
    private Collection<Attachment> attachments;
}
