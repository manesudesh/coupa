package ae.network.onboarding.onboarding.utils.database.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "utils_currencies")
public class Currency {
    @Id
    private String currencyCode;
    private String countryName;
    private String currencyName;
    private String countryCodeAlpha2;
    private Integer currencyNumber;
    private int minorUnit;
}
