package ae.network.onboarding.onboarding.utils.rabbitmq.config;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ae.network.onboarding.onboarding.utils.database.model.Country;
import ae.network.onboarding.onboarding.utils.database.service.OnboardingUtils;
import ae.network.onboarding.onboarding.utils.database.service.OnboardingUtilsImpl;
import ae.network.onboarding.onboarding.utils.database.service.lookup.DatabaseLookupService;
import ae.network.onboarding.onboarding.utils.database.service.lookup.LookupService;
import ae.network.onboarding.onboarding.utils.database.service.mail.MailService;

@RestController
@RequestMapping({"/onboarding"})
public class MessageController {

	@Autowired
	DatabaseLookupService lookupService;
	
	@GetMapping("/lookup")
    public List<Country> lookup() {
		List<Country> countryList = lookupService.allCountryCode();
		return countryList;
    }
	/*
	@GetMapping("/email")
    public MailService email() {
        return mailService;
    }
    */
}
