package ae.network.onboarding.onboarding.utils;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@SpringBootApplication
@EnableCaching
@EnableAsync
public class OnboardingUtilsApplication {

    public static void main(String[] args) {
        SpringApplication.run(OnboardingUtilsApplication.class, args);
    }
}
