package ae.network.onboarding.onboarding.utils.rabbitmq.config;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ErrorHandler;

import ae.network.onboarding.onboarding.utils.database.service.OnboardingUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MessageConsumer implements MessageListener, ErrorHandler{

	@Autowired
	OnboardingUtils oo;
	
	@Override
	public void handleError(Throwable t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMessage(Message message) {
		log.info("Received message : {}", message.getMessageProperties());
oo.countryCodeAlpha3ToNumeric("DZA");
        // parse message
        String messageContent = new String(message.getBody());
        log.info("messageContent : {}", messageContent);	
        
	}
	
	@RabbitListener(queues = "utils")
    public String listen(String in) {
        return "<abcd>ByeBye<>";
    }

}
