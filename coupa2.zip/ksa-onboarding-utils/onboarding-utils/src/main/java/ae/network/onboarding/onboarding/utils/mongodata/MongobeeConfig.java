package ae.network.onboarding.onboarding.utils.mongodata;

import org.springframework.context.annotation.Configuration;

/**
 * @author walid.sewaify
 * @since 12-02-2020
 */
@Configuration
public class MongobeeConfig {
   /* @Bean
    public Mongobee mongobee(MongoClient mongoClient, MongoTemplate mongoTemplate, MongoProperties mongoProperties) {
        Mongobee mongobee = new Mongobee(mongoClient);
        mongobee.setDbName(mongoProperties.getMongoClientDatabase());
        mongobee.setMongoTemplate(mongoTemplate);
        // package to scan for migrations
        mongobee.setChangeLogsScanPackage(MongobeeConfig.class.getPackage().getName());
        mongobee.setEnabled(true);
        return mongobee;
    }
    */
}