package ae.network.onboarding.onboarding.utils.mongodata;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.springframework.core.io.ClassPathResource;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.onboarding.onboarding.utils.database.model.Country;
import ae.network.onboarding.onboarding.utils.database.model.Currency;
import io.changock.migration.api.annotations.ChangeLog;
import io.changock.migration.api.annotations.ChangeSet;
import lombok.extern.slf4j.Slf4j;

/**
 * Creating mongodb initial data
 *
 * @author walid.sewaify
 * @author Success.Otto
 * @since 12-02-2020
 */
@ChangeLog(order = "001")
@Slf4j
public class MongoInitialSetup {

    @ChangeSet(order = "01", author = "utils", id = "01-createCountries", runAlways = false)
    public void createCountries(MongoTemplate mongoTemplate) {
        loadAndSaveCountries(mongoTemplate);
    }

    @ChangeSet(order = "02", author = "utils", id = "01-createCurrencies", runAlways = false)
    public void createCurrencies(MongoTemplate mongoTemplate) {
        loadAndSaveCurrencies(mongoTemplate);
    }

    private void loadAndSaveCountries(MongoTemplate mongoTemplate) {
        TypeReference<List<Country>> typeReference = new TypeReference<List<Country>>() {
        };

        try (InputStream inputStream = new ClassPathResource("data/countries.json").getInputStream()) {
            List<Country> countries = new ObjectMapper().readValue(inputStream, typeReference);
            countries.forEach(mongoTemplate::save);
            log.info("Countries saved to database!");
        } catch (IOException e) {
            log.error("Error processing countries data File", e);
        }
    }

    private void loadAndSaveCurrencies(MongoTemplate mongoTemplate) {
        TypeReference<List<Currency>> typeReference = new TypeReference<List<Currency>>() {
        };

        try (InputStream inputStream = new ClassPathResource("data/currencies.json").getInputStream()) {
            List<Currency> currencies = new ObjectMapper().readValue(inputStream, typeReference);
            currencies.forEach(mongoTemplate::save);
            log.info("Currencies saved to database!");
        } catch (IOException e) {
            log.error("Error processing currencies data File", e);
        }

    }

}