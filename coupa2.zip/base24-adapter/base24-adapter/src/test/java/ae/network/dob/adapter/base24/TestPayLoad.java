package ae.network.dob.adapter.base24;

public class TestPayLoad {
	
	public static String REQ_PAYLOAD ="{\r\n" + 
			"    \"acquirer\" : \"NI\",\r\n" + 
			"    \"requestType\" : \"ONBOARDING\",\r\n" + 
			"    \"applicationId\" : \"123456789\",\r\n" + 
			"    \"requestId\" : \"0123456789\",\r\n" + 
			"    \"payload\" : {\r\n" + 
			"        \"applications\": [\r\n" + 
			"            {\r\n" + 
			"                \"chain\" : {\r\n" + 
			"                    \"chainId\": \"987654321\",\r\n" + 
			"                    \"chainName\": \"Company1\",\r\n" + 
			"                    \"groupCode\" : \"OTH\",\r\n" + 
			"                    \"chainLevelReportRequired\" : false,\r\n" + 
			"                    \"groupLevelReportingRequired\" : false\r\n" + 
			"                },\r\n" + 
			"                \"merchants\": [\r\n" + 
			"                    {\r\n" + 
			"                        \"merchantId\": \"200600060180\",\r\n" + 
			"                        \"merchantName\": \"abcdef\",\r\n" + 
			"                        \"legalName\": \"AABC\",\r\n" + 
			"                        \"merchantType\": \"POS\",\r\n" + 
			"                        \"mcc\": \"5814\",\r\n" + 
			"                        \"depitAccountNumOrIban\" : \"A12321584\",\r\n" + 
			"                        \"creitAccountNumOrIban\" : \"A12321584\",\r\n" + 
			"                        \"merchantCurrency\": \"USD\",\r\n" + 
			"                        \"statementFrequency\": \"DAILY\",\r\n" + 
			"                        \"statementDeliveryType\": \"Email\",\r\n" + 
			"                        \"paymentMode\" : \"IFT\",\r\n" + 
			"                        \"addresses\": [\r\n" + 
			"                            {\r\n" + 
			"                                \"addressType\": \"DEFAULT\",\r\n" + 
			"                                \"countryCode\": \"ARE\",\r\n" + 
			"                                \"state\": \"DXB\",\r\n" + 
			"                                \"city\": \"Dubai\",\r\n" + 
			"                                \"postalCode\": \"0000000784\",\r\n" + 
			"                                \"pobox\": \"644973\",\r\n" + 
			"                                \"longitude\": \"55.3418550\",\r\n" + 
			"                                \"latitude\": \"25.2044464\",\r\n" + 
			"                                \"fax\": \"\",\r\n" + 
			"                                \"email\": \"farah@4maat.com\",\r\n" + 
			"                                \"addressLines\" : [\"addressLine1\", \"addressLine2\"],\r\n" + 
			"                                \"additionalEmail\": \"\"\r\n" + 
			"                            }\r\n" + 
			"                        ],\r\n" + 
			"                        \"configurations\" : {\r\n" + 
			"\r\n" + 
			"                            \"overrideDefaultSchemesMcc\" : false,\r\n" + 
			"                            \"commissionSettlement\" : \"NEXT_STTLM\",\r\n" + 
			"                            \"refundControlValue\" : \"C\",\r\n" + 
			"                            \"acceptedCardSchemes\": [\r\n" + 
			"                                {\r\n" + 
			"                                    \"cardSchema\": \"VISA\",\r\n" + 
			"                                    \"tariffRate\" : 1.5,\r\n" + 
			"                                    \"acceptedCardModes\": [\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"ELECTRONIC\",\r\n" + 
			"                                            \"rate\" : 1.75\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"MANUAL\",\r\n" + 
			"                                            \"rate\" : 1.70\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"PREMIUM\",\r\n" + 
			"                                            \"rate\" : 1.73\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"INTERNATIONAL\",\r\n" + 
			"                                            \"rate\" : 1.75\r\n" + 
			"                                        }\r\n" + 
			"\r\n" + 
			"                                    ]\r\n" + 
			"                                },\r\n" + 
			"                                {\r\n" + 
			"                                    \"cardSchema\": \"MC\",\r\n" + 
			"                                    \"tariffRate\" : 1.5,\r\n" + 
			"                                    \"acceptedCardModes\": [\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"ELECTRONIC\",\r\n" + 
			"                                            \"rate\" : 1.75\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"MANUAL\",\r\n" + 
			"                                            \"rate\" : 1.70\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"PREMIUM\",\r\n" + 
			"                                            \"rate\" : 1.73\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"INTERNATIONAL\",\r\n" + 
			"                                            \"rate\" : 1.75\r\n" + 
			"                                        }\r\n" + 
			"                                    ]\r\n" + 
			"                                },\r\n" + 
			"                                {\r\n" + 
			"                                    \"cardSchema\": \"PL\",\r\n" + 
			"                                    \"tariffRate\" : 1.5,\r\n" + 
			"                                    \"acceptedCardModes\": [\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"ELECTRONIC\",\r\n" + 
			"                                            \"rate\" : 1.75\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"MANUAL\",\r\n" + 
			"                                            \"rate\" : 1.70\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"PREMIUM\",\r\n" + 
			"                                            \"rate\" : 1.73\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"INTERNATIONAL\",\r\n" + 
			"                                            \"rate\" : 1.75\r\n" + 
			"                                        }\r\n" + 
			"                                    ]\r\n" + 
			"                                },\r\n" + 
			"                                {\r\n" + 
			"                                    \"cardSchema\": \"JCB\",\r\n" + 
			"                                    \"tariffRate\" : 1.5,\r\n" + 
			"                                    \"acceptedCardModes\": [\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"ELECTRONIC\",\r\n" + 
			"                                            \"rate\" : 1.75\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"MANUAL\",\r\n" + 
			"                                            \"rate\" : 1.70\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"PREMIUM\",\r\n" + 
			"                                            \"rate\" : 1.73\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"INTERNATIONAL\",\r\n" + 
			"                                            \"rate\" : 1.75\r\n" + 
			"                                        }\r\n" + 
			"                                    ]\r\n" + 
			"                                },\r\n" + 
			"                                {\r\n" + 
			"                                    \"cardSchema\": \"CUP\",\r\n" + 
			"                                    \"tariffRate\" : 1.5,\r\n" + 
			"                                    \"acceptedCardModes\": [\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"ELECTRONIC\",\r\n" + 
			"                                            \"rate\" : 1.75\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"MANUAL\",\r\n" + 
			"                                            \"rate\" : 1.70\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"PREMIUM\",\r\n" + 
			"                                            \"rate\" : 1.73\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"INTERNATIONAL\",\r\n" + 
			"                                            \"rate\" : 1.75\r\n" + 
			"                                        }\r\n" + 
			"                                    ]\r\n" + 
			"                                },\r\n" + 
			"                                {\r\n" + 
			"                                    \"cardSchema\": \"MER\",\r\n" + 
			"                                    \"tariffRate\" : 1.5,\r\n" + 
			"                                    \"acceptedCardModes\": [\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"ELECTRONIC\",\r\n" + 
			"                                            \"rate\" : 1.75\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"MANUAL\",\r\n" + 
			"                                            \"rate\" : 1.70\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"PREMIUM\",\r\n" + 
			"                                            \"rate\" : 1.73\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"INTERNATIONAL\",\r\n" + 
			"                                            \"rate\" : 1.75\r\n" + 
			"                                        }\r\n" + 
			"                                    ]\r\n" + 
			"                                },\r\n" + 
			"                                {\r\n" + 
			"                                    \"cardSchema\": \"DCI\",\r\n" + 
			"                                    \"tariffRate\" : 1.5,\r\n" + 
			"                                    \"acceptedCardModes\": [\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"ELECTRONIC\",\r\n" + 
			"                                            \"rate\" : 1.75\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"MANUAL\",\r\n" + 
			"                                            \"rate\" : 1.70\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"PREMIUM\",\r\n" + 
			"                                            \"rate\" : 1.73\r\n" + 
			"                                        },\r\n" + 
			"                                        {\r\n" + 
			"                                            \"modeName\": \"INTERNATIONAL\",\r\n" + 
			"                                            \"rate\" : 1.75\r\n" + 
			"                                        }\r\n" + 
			"                                    ]\r\n" + 
			"                                }\r\n" + 
			"                            ],\r\n" + 
			"                            \"fees\": [\r\n" + 
			"                                {\r\n" + 
			"                                    \"feeTypeName\": \"MIS\",\r\n" + 
			"                                    \"reOccurrenceFrequency\": \"WEEKLY\",\r\n" + 
			"                                    \"feeValue\": 0\r\n" + 
			"                                },\r\n" + 
			"                                {\r\n" + 
			"                                    \"feeTypeName\": \"ACQ_MMBR_FEE\",\r\n" + 
			"                                    \"reOccurrenceFrequency\": \"DAILY\",\r\n" + 
			"                                    \"feeValue\": 0\r\n" + 
			"                                },\r\n" + 
			"                                {\r\n" + 
			"                                    \"feeTypeName\": \"MFEE_STRT\",\r\n" + 
			"                                    \"reOccurrenceFrequency\": \"MONTHLY\",\r\n" + 
			"                                    \"feeValue\": 0\r\n" + 
			"                                },\r\n" + 
			"                                {\r\n" + 
			"                                    \"feeTypeName\": \"MFEE_FRD_HND\",\r\n" + 
			"                                    \"reOccurrenceFrequency\": \"DAILY\",\r\n" + 
			"                                    \"feeValue\": 0\r\n" + 
			"                                },\r\n" + 
			"                                {\r\n" + 
			"                                    \"feeTypeName\": \"TRANS_FEE\",\r\n" + 
			"                                    \"reOccurrenceFrequency\": \"DAILY\",\r\n" + 
			"                                    \"feeValue\": 0\r\n" + 
			"                                },\r\n" + 
			"                                {\r\n" + 
			"                                    \"feeTypeName\": \"REFUND_FEE\",\r\n" + 
			"                                    \"reOccurrenceFrequency\": \"DAILY\",\r\n" + 
			"                                    \"feeValue\": 0\r\n" + 
			"                                }\r\n" + 
			"\r\n" + 
			"                            ]\r\n" + 
			"                            \r\n" + 
			"                        },\r\n" + 
			"                        \"services\": [\r\n" + 
			"                            {\r\n" + 
			"                                \"serviceType\": \"DCC\",\r\n" + 
			"                                \"dccProvider\": \"PP\",\r\n" + 
			"                                \"dccSettlementFrequency\": \"MONTHLY\",\r\n" + 
			"                                \"daysOfMonth\": 31,\r\n" + 
			"                                \"dccAcquirerRate\": 99999,\r\n" + 
			"                                \"dccMerchantMarkupRate\": 0.25,\r\n" + 
			"                                \"dccMarkupRate\": 5.99\r\n" + 
			"                            },\r\n" + 
			"                            {\r\n" + 
			"                                \"serviceType\": \"RENTAL\",\r\n" + 
			"                                \"rentalModeCode\": \"CASH\",\r\n" + 
			"                                \"rentalModeName\": \"Cash deposit\"\r\n" + 
			"                            }\r\n" + 
			"                        ],\r\n" + 
			"                        \"terminals\": [\r\n" + 
			"                            {\r\n" + 
			"                                \"terminalId\": \"13004710\",\r\n" + 
			"                                \"terminalType\" : \"PC\",\r\n" + 
			"                                \"maker\" : \"NGINX\",\r\n" + 
			"                                \"terminalModel\": \"VX680\",\r\n" + 
			"                                \"communicationMethod\": \"SG\",\r\n" + 
			"                                \"dccEnabled\": false,\r\n" + 
			"                                \"fees\": [\r\n" + 
			"                                    {\r\n" + 
			"                                        \"feeType\" : \"SIM_FEE\",\r\n" + 
			"                                        \"feeValue\" : 1.5\r\n" + 
			"                                    }\r\n" + 
			"                                    \r\n" + 
			"                                ],\r\n" + 
			"                                \"allowedOperations\": {\r\n" + 
			"                                    \"tips\": false,\r\n" + 
			"                                    \"standardFunction\": true,\r\n" + 
			"                                    \"refund\": false,\r\n" + 
			"                                    \"preAuthorization\": false,\r\n" + 
			"                                    \"keyEntry\": false,\r\n" + 
			"                                    \"cashAdvance\": false\r\n" + 
			"                                }\r\n" + 
			"                            }\r\n" + 
			"                        ]\r\n" + 
			"                    }\r\n" + 
			"                ]\r\n" + 
			"            }\r\n" + 
			"        ]\r\n" + 
			"    }\r\n" + 
			"}";
	
}
