package ae.network.dob.adapter.base24;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;

//@SpringBootTest
//@Import(DummyRabbit.class)
class OnboardingBase24AdapterTests {

//    @Test
    void contextLoads() {
    }

}
