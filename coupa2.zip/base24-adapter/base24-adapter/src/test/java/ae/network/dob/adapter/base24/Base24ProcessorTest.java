package ae.network.dob.adapter.base24;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.rabbitmq.config.RabbitQueue;
import ae.network.dob.adapter.base24.rabbitmq.service.RabbitServiceImpl;
import ae.network.dob.adapter.base24.service.Base24RequestProcessor;

@SpringBootTest
@Import(DummyRabbit.class)
class Base24RequestProcessorTest {

	@Autowired
	Base24RequestProcessor service;

	@MockBean
	RabbitServiceImpl rabbitService;

    @Test
	void testCreateNewApplication() {
    	ApplicationRequest request = null;
    	try {
			request = new ObjectMapper().readValue(TestPayLoad.REQ_PAYLOAD, ApplicationRequest.class);
			
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		service.processApplication(request);
		assertEquals(service.findByApplicationId(request.getId()).orElse(null), request);
		Mockito.verify(rabbitService, times(RabbitQueue.getInitialWorkingQueues().size())).sendMessage(any(), any());
	}

    @Test
	void testUpdate() {
		ApplicationRequest request = new ApplicationRequest();
		String id = "id_2";
		request.setApplicationId(id);
		request.setAcquirer(Acquirer.TYME);
		service.processApplication(request);
		//request.setRequestStatus(RequestStatus.COMPLETED);
		service.saveOrUpdateApplication(request);
		Optional<ApplicationRequest> found = service.findByApplicationId(id);
		assertTrue(found.isPresent());
		//assertEquals(found.get().getRequestStatus(), RequestStatus.COMPLETED);
	}
}