package ae.network.dob.adapter.base24.database.model.request;

public enum RequestType {
    ONBOARDING, AMENDMENT, MERCHANT_CLOSURE, TERMINAL_CLOSURE
}
