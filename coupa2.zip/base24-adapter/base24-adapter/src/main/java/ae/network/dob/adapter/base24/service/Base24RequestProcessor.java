package ae.network.dob.adapter.base24.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import ae.network.dob.adapter.base24.database.model.reply.ApplicationUpdate;
import ae.network.dob.adapter.base24.database.model.reply.ProcessingResult;
import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.database.model.request.BackendSystem;
import ae.network.dob.adapter.base24.database.model.request.TargetSystem;
import ae.network.dob.adapter.base24.database.model.request.Task;
import ae.network.dob.adapter.base24.database.model.request.TaskHistory;
import ae.network.dob.adapter.base24.database.model.request.TaskName;
import ae.network.dob.adapter.base24.database.model.request.TaskStatus;
import ae.network.dob.adapter.base24.database.repository.ApplicationRequestRepository;
import ae.network.dob.adapter.base24.rabbitmq.RabbitService;
import ae.network.dob.adapter.base24.rabbitmq.config.RabbitQueue;
import ae.network.dob.adapter.base24.utils.Base24FileGenerationService;
import ae.network.dob.adapter.base24.utils.Base24FileManager;
import ae.network.dob.adapter.base24.validation.CommonValidator;
import ae.network.dob.adapter.base24.validation.NIValidator;
import ae.network.dob.adapter.base24.validation.TYMEValidator;
import ae.network.dob.adapter.base24.validation.ValidationResult;
import ae.network.dob.adapter.base24.validation.ValidationService;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Waseem.Ismail
 * @since 2020-01-29
 */

@Service
@Slf4j
public class Base24RequestProcessor {

	private final ApplicationRequestRepository applicationRequestRepository;
	private final RabbitService rabbitService;
	private Base24FileGenerationService base24FileGenerationService;

	private CommonValidator commonValidator;
	private NIValidator niValidator;
	private TYMEValidator tymeValidator;

	public Base24RequestProcessor(ApplicationRequestRepository applicationRequestRepository, RabbitService rabbitService,
			Base24FileManager base24FileManager, Base24FileGenerationService base24FileGenerationService,
			CommonValidator commonValidator, NIValidator niValidator, TYMEValidator tymeValidator) {

		this.applicationRequestRepository = applicationRequestRepository;
		this.rabbitService = rabbitService;
		this.base24FileGenerationService = base24FileGenerationService;
		this.commonValidator = commonValidator;
		this.niValidator = niValidator;
		this.tymeValidator = tymeValidator;
	}

	public void processApplication(ApplicationRequest request) {
		
		log.info("Application Request received {})",request.getApplicationId());

		request = applicationRequestRepository.insert(request);

		List<ValidationResult> validationResult = validateRequest(request);

		boolean validationPassed = !(validationResult.stream().anyMatch(result -> !result.isPassed()));

		Task validationTask = Task.builder().taskStatus(validationPassed ? TaskStatus.COMPLETED : TaskStatus.FAILED)
				.name(TaskName.VALIDATION.name())
				.taskHistory(
						Arrays.asList(createTaskHistory(validationPassed ? TaskStatus.COMPLETED : TaskStatus.FAILED,
								validationPassed ? "OK" : "ERROR", Arrays.toString(validationResult.toArray()))))
				.build();

		if (request.getTasks() == null)
			request.setTasks(new ArrayList<Task>());

		request.getTasks().add(validationTask);

		request = applicationRequestRepository.save(request);

		if (validationPassed) {

			base24FileGenerationService.generateBase24RequestFile(request);

			Task fileGenerationTask = Task.builder().taskStatus(TaskStatus.COMPLETED).chainId(request.getRequestId())
					.name(TaskName.FILE_GENERATION.name()).build();

			request.getTasks().add(fileGenerationTask);

			applicationRequestRepository.save(request);

		} else {
			// validation failed, send feedback message with the stored status
			rabbitService.sendMessage(RabbitQueue.UPDATES, createApplicationResponse(request));
		}

	}

	public void saveOrUpdateApplication(ApplicationRequest request) {
		applicationRequestRepository.save(request);
	}

	public Optional<ApplicationRequest> findByApplicationId(String applicationId) {
		return applicationRequestRepository.findById(applicationId);
	}

	private List<ValidationResult> validateRequest(ApplicationRequest request) {

		List<ValidationResult> validationResult = new ArrayList<ValidationResult>();
		if (request.getAcquirer().equals(Acquirer.NI)) {
			validationResult = ValidationService.getValidator().validate(commonValidator, request)
					.validate(niValidator, request).getValidationResult();

		} else if (request.getAcquirer().equals(Acquirer.TYME)) {
			validationResult = ValidationService.getValidator().validate(commonValidator, request)
					.validate(tymeValidator, request).getValidationResult();
		}

		return validationResult;
	}

	private TaskHistory createTaskHistory(TaskStatus status, String statusCode, String response) {
		return TaskHistory.builder().createdDate(new Date()).lastModifiedDate(new Date()).statusCode(statusCode)
				.taskStatus(status).response(response).build();
	}

	private Object createApplicationResponse(ApplicationRequest request) {
		return ApplicationUpdate.builder().applicationId(request.getApplicationId()).
				backendSystem(BackendSystem.BASE24).
				processingResult(ProcessingResult.builder().
				finalStatus(calculateFinalStatus(request)).tasks(request.getTasks()).build())
                .build();
	}
	
	private TaskStatus calculateFinalStatus(ApplicationRequest request) {
        if(request.getTasks().stream().allMatch(task -> task.getTaskStatus().equals(TaskStatus.FAILED))){
            return TaskStatus.FAILED;
        }else if(request.getTasks().stream().allMatch(task -> task.getTaskStatus().equals(TaskStatus.COMPLETED))){
            return TaskStatus.COMPLETED;
        }else {
            return TaskStatus.PARTIALLY_COMPLETED;
        }
    }
}
