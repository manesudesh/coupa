package ae.network.dob.adapter.base24.database.model.request;

public enum Acquirer {
    NI, TYME
}
