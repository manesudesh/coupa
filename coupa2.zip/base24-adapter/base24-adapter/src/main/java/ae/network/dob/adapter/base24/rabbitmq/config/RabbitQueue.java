package ae.network.dob.adapter.base24.rabbitmq.config;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.mongodb.client.model.Updates;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
public enum RabbitQueue {
    // Working Queues
    BASE24("base24", "routing.backend.base24"),
    UPDATES("updates", "routing.updates");

    private final String queueName;
    private final String[] routingKeys;

    RabbitQueue(String queueName, String... routingKeys) {
        this.queueName = queueName;
        this.routingKeys = routingKeys;
    }

    public String getQueueName() {
        return queueName;
    }

    public List<String> getRoutingKeys() {
        return Arrays.asList(routingKeys);
    }

    /**
     * @return all queues that bind to working exchanges (not failure)
     */
    public static List<RabbitQueue> getWorkingQueues() {
        return Arrays.stream(values()).collect(Collectors.toList());
    }

    /**
     * @return list of backend systems that should be called first
     */
    public static List<RabbitQueue> getInitialWorkingQueues() {
        return Arrays.asList(BASE24, UPDATES);
    }
}
