package ae.network.dob.adapter.base24.database.model.request;

import java.util.Collection;
import java.util.Collections;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Task {
    private Long id;
    private String name;
    private String chainId;
    private String merchantId;
    private String terminalId;
    private TaskStatus taskStatus;
    private Collection<TaskHistory> taskHistory;
}
