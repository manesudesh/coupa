package ae.network.dob.adapter.base24.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Data
@Configuration
@ConfigurationProperties(prefix = "base24")
public class Base24FolderConfigs {

	private String error;
	private String arch;
	private String in;
	private String out;
	private String temp;

}
