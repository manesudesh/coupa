package ae.network.dob.adapter.base24.rabbitmq.processors;

import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import ae.network.dob.adapter.base24.exception.MaxRetryReachedException;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@Component
public class MaxRetryProcessor implements MessagePostProcessor {
    public static final String MAX_RETRY_HEADER = "max_retry";

    private final int maxRetryAttempts;

    public MaxRetryProcessor(@Value("${octopus.processor.max-retry}") int maxRetryAttempts) {
        this.maxRetryAttempts = maxRetryAttempts;
    }

    @Override
    public Message postProcessMessage(Message message) throws AmqpException {
        MessageProperties messageProperties = message.getMessageProperties();
        Integer maxRetry = messageProperties.getHeader(MAX_RETRY_HEADER);
        if (maxRetry == null) {
            messageProperties.setHeader(MAX_RETRY_HEADER, maxRetryAttempts);
        } else if (maxRetry == 0) {
            throw new MaxRetryReachedException();
        } else {
            messageProperties.setHeader(MAX_RETRY_HEADER, maxRetry - 1);
        }
        return message;
    }
}
