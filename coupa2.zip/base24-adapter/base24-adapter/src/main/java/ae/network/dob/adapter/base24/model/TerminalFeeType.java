package ae.network.dob.adapter.base24.model;

/**
 * @author Yousry
 * @version 1.0
 */

public enum TerminalFeeType {
    SIM_FEE, GPRS_FEE, TERMINAL_RENTAL_FEE, INS_FEE;
}
