package ae.network.dob.adapter.base24.rabbitmq.consumer;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

import ae.network.dob.adapter.base24.database.model.failure.FailedMessage;
import lombok.extern.slf4j.Slf4j;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@Component
@Slf4j
public class DeadLetterConsumer implements MessageListener {

    private final MongoTemplate mongoTemplate;

    public DeadLetterConsumer(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    @Bean
    SimpleMessageListenerContainer deadLetterListener(ConnectionFactory connectionFactory) {
        SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
        container.setConnectionFactory(connectionFactory);
       // container.setQueueNames(RabbitQueue.FAILS.getQueueName());
        container.setMessageListener(this);
        return container;
    }

    @Override
    public void onMessage(Message message) {
        log.error("Dead message found in error state, investigation required : {}", message.toString());

        mongoTemplate.save(new FailedMessage(message));
    }
}
