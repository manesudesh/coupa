package ae.network.dob.adapter.base24.exception;

import org.springframework.amqp.AmqpRejectAndDontRequeueException;

/**
 * Reject message altogether, and send it to failure queue for investigation.
 * Use when there is no way to recover the error.
 *
 * @author walid.sewaify
 * @since 2020-01-27
 */
public class MessageRejectionException extends AmqpRejectAndDontRequeueException {
    public MessageRejectionException(String message) {
        super(message);
    }

    public MessageRejectionException(Throwable cause) {
        super(cause);
    }

    public MessageRejectionException(String message, Throwable cause) {
        super(message, cause);
    }

    public MessageRejectionException(String message, boolean rejectManual, Throwable cause) {
        super(message, rejectManual, cause);
    }
}
