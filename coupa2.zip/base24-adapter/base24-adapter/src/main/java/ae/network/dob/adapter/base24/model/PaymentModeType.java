package ae.network.dob.adapter.base24.model;

public enum PaymentModeType {

    EFT,
    EQ,
    FN,
    IFT,
    MC,
    NN,
    OB,
    TT;

}
