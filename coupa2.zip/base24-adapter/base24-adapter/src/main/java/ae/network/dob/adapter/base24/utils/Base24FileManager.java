package ae.network.dob.adapter.base24.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.Date;
import java.util.Calendar;
import java.util.TimeZone;

import org.springframework.stereotype.Component;

import ae.network.dob.adapter.base24.config.Base24FolderConfigs;

/**
 * @todo still need to write the logic to either create new file or append the
 *       new content to the existing file. fileNames also need to be managed,
 *       logic to increment the file number/day need to be implemented as well.
 *       most probably a file registry need to be implemented either at Mongo DB
 *       or flat file.
 **/

@Component
public class Base24FileManager {

	private Base24FolderConfigs base24FolderConfigs;

	public Base24FileManager(Base24FolderConfigs base24FolderConfigs) {

		this.base24FolderConfigs = base24FolderConfigs;
	}

	public File exportFiletoBase24Dir(String fileContent) {

		String fileName = getCurrentFileName();
		
		File base24File = new File(fileName);
		
		try {

			
			if(base24File.exists()) {
				FileOutputStream fileOutputStream = new FileOutputStream(base24File,true);
				OutputStreamWriter filewriter = new OutputStreamWriter(fileOutputStream);
				filewriter.append("\n"+fileContent);
				filewriter.close();
			}else {
				FileOutputStream fileOutputStream = new FileOutputStream(base24File);
				OutputStreamWriter filewriter = new OutputStreamWriter(fileOutputStream);
				filewriter.write(fileContent);
				filewriter.close();
			}
			
			

		} catch (IOException e) {
			e.printStackTrace();
		}

		return base24File;
	}

	public String getCurrentFileName() {

		Date date = new Date(System.currentTimeMillis());
		Calendar cal = Calendar.getInstance(TimeZone.getDefault());
		cal.setTime(date);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DAY_OF_MONTH);

		return base24FolderConfigs.getOut() + "RF" + (month < 10 ? "0" + month : month) + (day < 10 ? "0" + day : day)
				+ getFileNumber();
	}

	private String getFileNumber() {
		// TODO Auto-generated method stub/ need to implement a registry to record the daily file counts
		return "01";
	}
}
