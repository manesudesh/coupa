package ae.network.dob.adapter.base24.validation;

import org.springframework.stereotype.Service;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CommonValidator implements Validator<ApplicationRequest> {

	@Override
	public ValidationResult validate(ApplicationRequest entity) {

		log.info("Common validator started.");

		return ValidationResult.builder().passed(true).build();
	}

	@Override
	public ValidatorType getType() {
		return ValidatorType.COMMON;
	}
}
