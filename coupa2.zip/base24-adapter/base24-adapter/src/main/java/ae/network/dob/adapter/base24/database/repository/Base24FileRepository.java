package ae.network.dob.adapter.base24.database.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import ae.network.dob.adapter.base24.database.model.request.Base24File;

public interface Base24FileRepository extends MongoRepository<Base24File, String> {
    Optional<Base24File> findByApplicationId(String applicationId);
    Optional<Base24File> findByTemplateId(String templateId);
    Optional<Base24File> findByFileName(String filename);
}
