package ae.network.dob.adapter.base24.database.model.request;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import ae.network.dob.adapter.base24.rabbitmq.config.RabbitQueue;

/**
 * List of all onboarding backend systems
 */
public enum BackendSystem {
    // stage one
		BASE24(RabbitQueue.BASE24);



    private static final List<BackendSystem> stageOneSystems = Arrays.asList(BASE24);

    private final RabbitQueue rabbitQueue;

    BackendSystem(RabbitQueue rabbitQueue) {
        this.rabbitQueue = rabbitQueue;
    }

    public static List<BackendSystem> getStageOneSystems() {
        return stageOneSystems;
    }

    public static List<BackendSystem> getStageTwoSystems() {
        return Arrays.stream(values()).filter(system -> !stageOneSystems.contains(system)).collect(Collectors.toList());
    }

    public RabbitQueue getRabbitQueue() {
        return rabbitQueue;
    }
}
