package ae.network.dob.adapter.base24.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SchemeOverrideValue {
    private Integer mcc;
    private String dBAName;
}
