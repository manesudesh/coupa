package ae.network.dob.adapter.base24.event.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import ae.network.dob.adapter.base24.event.Base24CompletedEvent;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
@Component
@Slf4j
public class Base24CompletedListener implements ApplicationListener<Base24CompletedEvent> {

	@Override
	public void onApplicationEvent(Base24CompletedEvent event) {
		// todo
		log.info("Base24 completed for application {}, starting onboarding to other systems",
				event.getSource().getApplicationId());
	}

}