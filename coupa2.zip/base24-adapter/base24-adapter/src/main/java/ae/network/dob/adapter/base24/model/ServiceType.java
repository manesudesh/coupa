package ae.network.dob.adapter.base24.model;

/**
 * @author Yousry
 * @version 1.0
 */

public enum ServiceType {
    DCC("DCC"),
    RENTAL("RENTAL"),
    MC_3D_SECURE("MC_3D_SECURE");

    private final String value;

    ServiceType(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }
}
