package ae.network.dob.adapter.base24.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {

    private AddressType addressType;
    private String countryCode;
    private String state;
    private String city;
    private String postalCode;
    private String phone;
    private String pobox;
    private String email;
    private String fax;
    private String longitude;
    private String latitude;
    private String additionalEmail;
    private List<String> addressLines;
}
