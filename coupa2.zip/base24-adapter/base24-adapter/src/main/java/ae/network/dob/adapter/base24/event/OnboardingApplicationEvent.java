package ae.network.dob.adapter.base24.event;

import org.springframework.context.ApplicationEvent;

import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
public abstract class OnboardingApplicationEvent extends ApplicationEvent {
    OnboardingApplicationEvent(ApplicationRequest applicationRequest) {
        super(applicationRequest);
    }

    @Override
    public ApplicationRequest getSource() {
        return (ApplicationRequest) super.getSource();
    }
}
