package ae.network.dob.adapter.base24.validation;


public interface Validator<T> {

    ValidatorType getType();
    ValidationResult validate(T entity);
}
