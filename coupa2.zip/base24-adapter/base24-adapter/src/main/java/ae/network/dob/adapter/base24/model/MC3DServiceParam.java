package ae.network.dob.adapter.base24.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@Builder
public class MC3DServiceParam extends MerchantService{
    // TODO: implementation
}
