package ae.network.dob.adapter.base24.utils;

import java.util.HashMap;
import java.util.Map;

/** @todo move all the hardcoded values to the DB **/

public class Base24TemplateIDUtil {

	public static final Map<String, String[]> Base24TemplateID;
	static {
		Base24TemplateID = new HashMap<String, String[]>();
		Base24TemplateID.put("AUD", new String[]{"025036000000","43036000",""});
		Base24TemplateID.put("USD", new String[]{"002840000000","43840000",""});
		Base24TemplateID.put("EUR", new String[]{"007978000000","43978000",""});
		Base24TemplateID.put("BHD", new String[]{"013048000000","43048000",""});
		Base24TemplateID.put("XAF", new String[]{"103950000000","43950000",""});
		Base24TemplateID.put("XOF", new String[]{"069952000000","43952000",""});
		Base24TemplateID.put("INR", new String[]{"015356000000","43356000",""});
		Base24TemplateID.put("CAD", new String[]{"005124000000","43124000",""});
		Base24TemplateID.put("EGP", new String[]{"009818000000","43818000",""});
		Base24TemplateID.put("GBP", new String[]{"006826000000","43826000",""});
		Base24TemplateID.put("IRR", new String[]{"","4326400000",""});
		Base24TemplateID.put("JOD", new String[]{"010400000000","43400000",""});
		Base24TemplateID.put("KWD", new String[]{"021414000000","43414000",""});
		Base24TemplateID.put("LBP", new String[]{"026422000000","43422000",""});
		Base24TemplateID.put("CHF", new String[]{"008756000000","43756000",""});
		Base24TemplateID.put("NAD", new String[]{"221516000000","43516000",""});
		Base24TemplateID.put("OMR", new String[]{"014512000000","43512000",""});
		Base24TemplateID.put("QAR", new String[]{"024634000000","43634000",""});
		Base24TemplateID.put("SAR", new String[]{"012682000000","43682000",""});
		Base24TemplateID.put("SGD", new String[]{"043702000000","43702000",""});
	}
}
