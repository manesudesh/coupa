package ae.network.dob.adapter.base24.model;
/**
 * @author Yousry
 * @version 1.0
 */
public enum MerchantType {
    POS, ECOM;
}
