package ae.network.dob.adapter.base24.validation;

public enum ValidatorType {
    COMMON,NI,TYME
}
