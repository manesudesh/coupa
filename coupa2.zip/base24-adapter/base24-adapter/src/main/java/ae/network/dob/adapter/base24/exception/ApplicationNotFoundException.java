package ae.network.dob.adapter.base24.exception;

/**
 * @author walid.sewaify
 * @since 2020-01-26
 */
public class ApplicationNotFoundException extends MessageRejectionException {
    public ApplicationNotFoundException() {
        super("Application not found");
    }
}
