package ae.network.dob.adapter.base24.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MerchantConfig {

    /**
     * by default it is false, if the Acquirer set it into true, the new values should be provided for Visa, MC at least
     * in the accepted card part under the merchant configuration.
     */
    private boolean overrideDefaultSchemesMcc;

    @NotNull
    @NotEmpty
    private List<AcceptedCardParam> acceptedCardSchemes;

    @NotNull
    @NotEmpty
    private List<FeesParam> fees;

    @NotNull
    private String commissionSettlement; // NEXT_STTLM Or M1 (monthly)

    private RefundControlValue refundControlValue;
}
