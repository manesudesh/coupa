package ae.network.dob.adapter.base24.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

public enum RefundControlValue {

    WITHOUT_COMMISSION_AND_FEE,
    WITH_COMMISSION_AND_FEE,
    ONLY_FEE_WITHOUT_COMMISSION,
    ONLY_COMMISSION_WITHOUT_FEE;


    private static Map<String, RefundControlValue> namesMap = new HashMap<String, RefundControlValue>(5);

    static {
        namesMap.put("G", WITHOUT_COMMISSION_AND_FEE);
        namesMap.put("R",WITH_COMMISSION_AND_FEE);
        namesMap.put("C", ONLY_FEE_WITHOUT_COMMISSION);
        namesMap.put("N", ONLY_COMMISSION_WITHOUT_FEE);
    }

    @JsonCreator
    public static RefundControlValue forValue(String value) {
        return namesMap.get(value);
    }

    @JsonValue
    public String toValue() {
        return namesMap.entrySet().stream().filter(entry-> entry.getValue() == this).findFirst().get().getKey();
    }
}
