package ae.network.dob.adapter.base24.model;

public enum ReportTypeName {
    ADVICE, TRANSACTIONS_ACTIVITY, MERCURY_OLD, MERCURY_NEW
}
