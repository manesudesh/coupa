package ae.network.dob.adapter.base24.database.model.reply;

import lombok.Builder;
import lombok.Data;
import org.springframework.context.annotation.Bean;

@Data
@Builder
public class ValidationError {
    private String fieldName;
    private String errorMessage;
    private String errorCode;
}
