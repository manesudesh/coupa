package ae.network.dob.adapter.base24.rabbitmq;

import org.springframework.amqp.core.Message;

import ae.network.dob.adapter.base24.rabbitmq.config.RabbitQueue;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
public interface RabbitService {
    /**
     * Send a message to exchange queue that is stored in JSON format
     *
     * @param queue   receiving queue
     * @param message content
     */
    void sendMessage(RabbitQueue queue, Object message);

    /**
     * retry sending message to same queue after a period of time
     *
     * @param message original message
     * @param seconds time in seconds
     */
    void retryMessage(Message message, int seconds);
}
