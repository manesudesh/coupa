package ae.network.dob.adapter.base24.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

/**
 * client Can provide full high level name in the json and it will converted automatically to the
 * tech value used in the backend systems.
 *
 * @author Yousry
 * @version 1.0
 */
public enum CardModeName {
    ELEC, MANL, PREM, INT, DOM;


    private static Map<String, CardModeName> namesMap = new HashMap<String, CardModeName>(5);

    static {
        namesMap.put("ELECTRONIC", ELEC);
        namesMap.put("MANUAL",MANL);
        namesMap.put("DOMESTIC", DOM);
        namesMap.put("INTERNATIONAL", INT);
        namesMap.put("PREMIUM", PREM);
    }

    @JsonCreator
    public static CardModeName forValue(String value) {
        return namesMap.get(value);
    }

    @JsonValue
    public String toValue() {
        return namesMap.entrySet().stream().filter(entry-> entry.getValue() == this).findFirst().get().getKey();
    }
}
