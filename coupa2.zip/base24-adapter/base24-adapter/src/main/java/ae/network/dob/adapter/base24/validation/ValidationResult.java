package ae.network.dob.adapter.base24.validation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@AllArgsConstructor
@Builder
@ToString(includeFieldNames=true)
public class ValidationResult {

    private boolean passed;
    private String code;
    private String message;
}
