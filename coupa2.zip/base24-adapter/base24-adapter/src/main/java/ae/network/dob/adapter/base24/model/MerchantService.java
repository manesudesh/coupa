package ae.network.dob.adapter.base24.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.*;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.Data;

/**
 * @author Yousry
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "serviceType",visible = true)
@JsonSubTypes({
        @Type(value = DCCServiceParam.class, name = "DCC"),
        @Type(value = RentalParam.class, name = "RENTAL"),
        @Type(value = MC3DServiceParam.class, name = "MC_3D_SECURE")})
@Data
public class MerchantService {

    @JsonProperty("serviceType")
    protected ServiceType serviceType;
}
