package ae.network.dob.adapter.base24.model.dto;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author walid.sewaify
 * @since 2020-03-01
 */
@Data
public class AcquirerRequest {
    @NotNull
    private String requestId;
    @NotNull
    private JsonNode payload;
}
