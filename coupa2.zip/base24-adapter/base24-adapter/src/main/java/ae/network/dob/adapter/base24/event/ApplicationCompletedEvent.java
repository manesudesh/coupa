package ae.network.dob.adapter.base24.event;

import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
public class ApplicationCompletedEvent extends OnboardingApplicationEvent {

    public ApplicationCompletedEvent(ApplicationRequest applicationRequest) {
        super(applicationRequest);
    }
}
