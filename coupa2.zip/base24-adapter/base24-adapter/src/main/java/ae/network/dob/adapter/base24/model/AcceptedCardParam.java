package ae.network.dob.adapter.base24.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AcceptedCardParam {

    private CardSchema cardSchema;
    private BigDecimal tariffRate; // for Tyme only , for NI should be from accepted modes as it has many moods, electronics, manual ..etc
    private List<AcceptedCardMode> acceptedCardModes;
    private SchemeOverrideValue schemeOverrideValue;

}
