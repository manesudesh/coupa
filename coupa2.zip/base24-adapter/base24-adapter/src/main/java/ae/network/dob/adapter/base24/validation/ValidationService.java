package ae.network.dob.adapter.base24.validation;

import java.util.ArrayList;
import java.util.List;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ValidationService {

	public static Intiator getValidator() {
		return new ValidationService().new Intiator();
	}

	public class Intiator {
		private List<ValidationResult> validationResults = new ArrayList<>();

		private Intiator() {

		}

		@SuppressWarnings("unchecked")
		public <T> Intiator validate(Validator<T> validator, T objectToValidate) {
			ValidationResult result = validator.validate(objectToValidate);

			validationResults.add(result);

			return this;
		}

		public List<ValidationResult> getValidationResult() {
			if (validationResults.isEmpty()) {
				throw new RuntimeException("Please use validate method before getting validations");
			} else {
				return validationResults;
			}
		}
	}

}
