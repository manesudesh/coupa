package ae.network.dob.adapter.base24.exception;

/**
 * @author walid.sewaify
 * @since 2020-01-26
 */
public class MaxRetryReachedException extends MessageRejectionException {
    public MaxRetryReachedException() {
        super("Maximum retries reached");
    }
}
