package ae.network.dob.adapter.base24.rabbitmq.consumer;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.exception.MessageRejectionException;
import ae.network.dob.adapter.base24.rabbitmq.RabbitService;
import ae.network.dob.adapter.base24.rabbitmq.config.RabbitQueue;
import ae.network.dob.adapter.base24.service.Base24RequestProcessor;
import lombok.extern.slf4j.Slf4j;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@Component
@Slf4j
public class Base24ApplicationConsumer implements MessageListener {
	private static final int RETRY_DELAY_SECONDS = 30;

	private final Base24RequestProcessor base24RequestProcessor;
	private final RabbitService rabbitService;

	public Base24ApplicationConsumer(Base24RequestProcessor base24RequestProcessor, RabbitService rabbitService,
			ApplicationEventPublisher applicationEventPublisher) {
		this.base24RequestProcessor = base24RequestProcessor;
		this.rabbitService = rabbitService;
	}

	@Bean
	SimpleMessageListenerContainer replyListener(ConnectionFactory connectionFactory) {
		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		container.setConnectionFactory(connectionFactory);
		container.setQueueNames(RabbitQueue.BASE24.getQueueName());
		container.setMessageListener(this);
		return container;
	}

	@Override
	public void onMessage(Message message) {
		String messageContent = new String(message.getBody());
		
		log.info("Incoming Message : {}", messageContent);
		try {

			ApplicationRequest request = new ObjectMapper().readValue(messageContent, ApplicationRequest.class);
			base24RequestProcessor.processApplication(request);

		} catch (MessageRejectionException | JsonProcessingException e) {
			log.error("JSON Message can not be processed, {}", e.getMessage());
			throw new MessageRejectionException("JSON Message can not be processed, " + e.getMessage());
		} catch (Exception e) {
			rabbitService.retryMessage(message, RETRY_DELAY_SECONDS);
		}
	}

}
