package ae.network.dob.adapter.base24.database.model.reply;


import ae.network.dob.adapter.base24.database.model.request.BackendSystem;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ApplicationUpdate {
    private String applicationId;
    private BackendSystem backendSystem;
    private ProcessingResult processingResult;
}
