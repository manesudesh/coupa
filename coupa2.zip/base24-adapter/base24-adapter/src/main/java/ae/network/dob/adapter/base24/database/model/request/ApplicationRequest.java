package ae.network.dob.adapter.base24.database.model.request;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import ae.network.dob.adapter.base24.database.model.AbstractAuditingEntity;
import ae.network.dob.adapter.base24.model.OnboardingRequest;
import ae.network.dob.adapter.base24.database.model.request.Acquirer;

/**
 * @author yousry
 * @version 1.0
 */


@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "request")
public class ApplicationRequest extends AbstractAuditingEntity {

    @Id
    private String id;

    @NotNull(message = "acquirer can not be null.")
    private Acquirer acquirer;

    @JsonProperty(required=true)
    private RequestType requestType;

    @NotNull(message = "applicationId can not be null.")
    private String applicationId;

    @NotNull(message = "requestId can not be null.")
    private String requestId;

    private OnboardingRequest payload;

    private Collection<Task> tasks = new ArrayList<Task>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Acquirer getAcquirer() {
        return acquirer;
    }

    public void setAcquirer(Acquirer acquirer) {
        this.acquirer = acquirer;
    }

    public RequestType getRequestType() {
        return requestType;
    }

    public void setRequestType(RequestType requestType) {
        this.requestType = requestType;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public OnboardingRequest getPayload() {
        return payload;
    }

    public void setPayload(OnboardingRequest payload) {
        this.payload = payload;
    }

    public Collection<Task> getTasks() {
        return tasks;
    }

    public void setTasks(Collection<Task> tasks) {
        this.tasks = tasks;
    }
}
