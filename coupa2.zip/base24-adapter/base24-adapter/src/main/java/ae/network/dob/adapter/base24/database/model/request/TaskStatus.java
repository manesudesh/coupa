package ae.network.dob.adapter.base24.database.model.request;

import java.util.Arrays;
import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
public enum TaskStatus {
    SCHEDULED, SENT_TO_TARGET, COMPLETED, COMPLETED_WITH_ERROR, FAILED, CANCELLED,PARTIALLY_COMPLETED;

    private static final List<TaskStatus> CLOSURE_STATUS = Arrays.asList(COMPLETED, CANCELLED, COMPLETED_WITH_ERROR);

    public static boolean isClosureStatus(TaskStatus taskStatus) {
        return CLOSURE_STATUS.contains(taskStatus);
    }

}