package ae.network.dob.adapter.base24.database.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;

import java.util.Optional;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
public interface ApplicationRequestRepository extends MongoRepository<ApplicationRequest, String> {

	Optional<ApplicationRequest> findById(String applicationId);
    
    @Query("{'applications.merchants.merchantId': ?0 ,'applications.merchants.actionType': ?1}")
    Optional<ApplicationRequest> findByMerchantIdAndActionType(String merchantId,String actionType);
    
    @Query("{'applications.merchants.terminals.terminalId': ?0, 'applications.merchants.terminals.actionType': ?1}")
    Optional<ApplicationRequest> findByTerminalIdAndActionType(String terminalId,String actiontype);
    
    @Query("{'applications.merchants.merchantId': ?0 ,'applications.merchants.actionType': ?1, 'applications.merchants.merchantType': 'POS'}")
    Optional<ApplicationRequest> findByMerchantIdAndActionTypeAndMerchantType(String merchantId,String actionType, String merchantType);
}
