package ae.network.dob.adapter.base24.utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.StringJoiner;

import org.springframework.stereotype.Service;

import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.database.model.request.Base24File;
import ae.network.dob.adapter.base24.database.model.request.RequestType;
import ae.network.dob.adapter.base24.database.model.request.Task;
import ae.network.dob.adapter.base24.database.model.request.TaskHistory;
import ae.network.dob.adapter.base24.database.model.request.TaskName;
import ae.network.dob.adapter.base24.database.model.request.TaskStatus;
import ae.network.dob.adapter.base24.database.repository.ApplicationRequestRepository;
import ae.network.dob.adapter.base24.database.repository.Base24FileRepository;
import ae.network.dob.adapter.base24.model.Address;
import ae.network.dob.adapter.base24.model.AddressType;
import ae.network.dob.adapter.base24.model.Application;
import ae.network.dob.adapter.base24.model.CardSchema;
import ae.network.dob.adapter.base24.model.Merchant;
import ae.network.dob.adapter.base24.model.MerchantType;
import ae.network.dob.adapter.base24.model.OnboardingRequest;
import ae.network.dob.adapter.base24.model.Terminal;

/**
 * @author Waseem
 */

@Service
public class Base24FileGenerationService {

	private Base24FileManager base24FileManager;
	private Base24FileRepository applicationBase24FileRepository;
	private ApplicationRequestRepository applicationRequestRepository;
	
	
	public Base24FileGenerationService(Base24FileManager base24FileManager,
			Base24FileRepository applicationBase24FileRepository,
			ApplicationRequestRepository applicationRequestRepository) {
		this.base24FileManager = base24FileManager;
		this.applicationBase24FileRepository = applicationBase24FileRepository;
		this.applicationRequestRepository = applicationRequestRepository;
	}


	public void generateBase24RequestFile(ApplicationRequest applicationRequest) {
		
		OnboardingRequest requestPayLoad = applicationRequest.getPayload();
		Acquirer runningBank = Acquirer.NI;
		
		if (applicationRequest.getAcquirer().equals(Acquirer.TYME)) {
			runningBank = Acquirer.TYME;
		}

		for (Application merchantApplication : requestPayLoad.getApplications()) {
			
			for (Merchant merchant : merchantApplication.getMerchants()) {
				
															
				String prdfFileContent = generatePRDFFile(applicationRequest ,merchant, runningBank, applicationRequest.getApplicationId());
				base24FileManager.exportFiletoBase24Dir(prdfFileContent);
				
				Task merchantTask = addRecordGenerationTask(applicationRequest,merchant.getMerchantId(),TaskName.SEND_MERCHANT_REQUEST);
				
				String prdfFIID = getFIID(merchant, runningBank);				
				String prdfTemplateID = getPRDFTemplateID(prdfFIID,merchant,runningBank);
				
				Base24File prdfFile = createBase24FileEntity(applicationRequest.getApplicationId(),
						"PRDF",merchant.getMerchantId() ,prdfTemplateID,prdfFileContent);
				
				applicationBase24FileRepository.save(prdfFile);
								
				for (Terminal terminal : merchant.getTerminals()) {
					
															
					String ptdFileContent = generatePTDFile(applicationRequest, terminal, merchant, runningBank);					
					base24FileManager.exportFiletoBase24Dir(ptdFileContent);
					
					Task terminalTask = addRecordGenerationTask(applicationRequest,terminal.getTerminalId(),TaskName.SEND_TERMINAL_REQUEST);
					
					String ptdTemplateId = getPTDTemplateId(merchant, terminal,runningBank);
					
					Base24File ptdFile = createBase24FileEntity(applicationRequest.getApplicationId(),"PTD",
							terminal.getTerminalId(), ptdTemplateId,
							ptdFileContent);
					
					applicationBase24FileRepository.save(ptdFile);
					
					if (merchant.getMerchantType().equals(MerchantType.POS)) {

						
						String csecdFileContent = generateCSECDFile(applicationRequest, terminal, merchant, runningBank);						
						base24FileManager.exportFiletoBase24Dir(csecdFileContent);
						
						Task csecdTask = addRecordGenerationTask(applicationRequest,terminal.getTerminalId(),TaskName.SEND_POS_TERMINAL_REQUEST);
						
						String csecdTemplateId = getCSECDTemplateId(merchant,terminal,runningBank);
						
						Base24File csecFile = createBase24FileEntity(applicationRequest.getApplicationId(),"CSECD",
								terminal.getTerminalId(), csecdTemplateId,
								csecdFileContent);
						
						applicationBase24FileRepository.save(csecFile);
						
					}
				}				
			}
		}
	}


	private String generatePRDFFile(ApplicationRequest applicationRequest, Merchant merchant, Acquirer runningBank, String applicationId) {

		StringJoiner recordBuilder = new StringJoiner("|");

		recordBuilder.add("PR");//Record\File type
		String opType = getBase24OPType(applicationRequest.getRequestType());
		recordBuilder.add(opType);

		// FIID
		String FIID = getFIID(merchant, runningBank);
		

		String merchantId = merchant.getMerchantId();

		String merchantTemplateId = getPRDFTemplateID(FIID,merchant, runningBank);

		recordBuilder.add(merchantTemplateId);

		recordBuilder.add(merchantId);

		recordBuilder.add(FIID);

		recordBuilder.add(merchant.getMerchantName());// IS IT MERCHANT NAME.Mapped with “Merchant name”

		// @todo add validation to check if the address is available
		
		Address merchantDefaultAddress = getMerchantDefaultAddress(merchant);
		recordBuilder.add(merchantDefaultAddress.getPobox());// Mapped with “P.O. Box” in "Address" table for address
																// type

		recordBuilder.add(merchantDefaultAddress.getCity());// Mapped with “City” in Address table or address type
															// "Statement address" for

		recordBuilder.add(merchantDefaultAddress.getState());// Mapped with “State / Country” in Address table for
																// address type "Statement

		recordBuilder.add(merchantDefaultAddress.getPhone());// ITS PART OF THE ADDRESS ARRAY SIMILAR TO THE CITY

		recordBuilder.add(merchantDefaultAddress.getPhone());// THIS ELEMENT IS NOT PRESENT ANY WHERE IN THE APPLICATION
														// PAYLOAD

		recordBuilder.add(merchant.getMcc().toString());// SIC CODE

		recordBuilder.add("");// Mapped with "PRE COMPL: VAL" of "BASE24 Attributes" table. Y/N or Keep empty
		recordBuilder.add("");// Mapped with "RETL VAL" of "BASE24 Attributes" table. Y/N or Keep empty

		recordBuilder.add(merchant.getConfigurations().getAcceptedCardSchemes().get(0).getAcceptedCardModes().get(0).getRate().toString());// Mapped with "AMT" of "BASE24 Attributes" table.

		recordBuilder.add("");// The Automated Clearing House (ACH) company identification code.Keep EMPty
		recordBuilder.add(merchant.getMcc().toString());// MAIL PHONE SIC CODE

		recordBuilder.add("");// SERVICE ESTABLISHMENT
		recordBuilder.add("");// CHECK MERSH ID
		recordBuilder.add("");// CHECK RTG GROUP
		recordBuilder.add("");// EPP Flag.Y/N or keep empty
		recordBuilder.add("");// RETAILER CUTOVER/BALANCE START,Hour and minute fields (hh:mm) based on
								// 24-hour time that
		recordBuilder.add("");// RETAILER CUTOVER/BALANCE END,Hour and minute fields (hh:mm) based on 24-hour
		recordBuilder.add("");// ACQUIRER TXN PROFILE
		recordBuilder.add("");// RETAILER TXN PROFILE
		recordBuilder.add("");// EMV CAPABLE
		recordBuilder.add("");// AMEX SE NUMBER CHECK
		recordBuilder.add("");// COUNTY
		recordBuilder.add("Y");// FLAG CARD TYPE UPDATE

		String cardTypes = getMerchantCardTypesStr(merchant);
		recordBuilder.add(cardTypes);
		
		recordBuilder.add("N");// Note: Currently BIN tables are not supported during amendment flow, so set N
		// for amendment until it will be supported by flow. •Closure: always N
		//recordBuilder.add("");// BIN SHARE OFFER ID, not applicable
		recordBuilder.add("||||||||||||||||||||||||||||||||");
		// End OF PRDF File

		return recordBuilder.toString();
		
	}

	private String generatePTDFile(ApplicationRequest applicationRequest, Terminal terminal, Merchant merchant, Acquirer runningBank) {

		StringJoiner recordBuilder = new StringJoiner("|");
		recordBuilder.add("PT");
		recordBuilder.add(getBase24OPType(applicationRequest.getRequestType()));

		// FIID
		String FIID = getFIID(merchant, runningBank);
		
		String templateID = getPTDTemplateId(merchant, terminal,runningBank);
		recordBuilder.add(templateID);// TemplateID

		recordBuilder.add(terminal.getTerminalId());

		recordBuilder.add(FIID);// FIID

		recordBuilder.add("");// SITE ID, A value used to group terminals at a specific site, Keep Empty

		recordBuilder.add(merchant.getMerchantName());// LOCATION, Mapped with "Outlet (Merchant)"."Merchant Name"

		// getting the default merchant Address
		Address merchantDefaultAddress = getMerchantDefaultAddress(merchant);

		recordBuilder.add(merchantDefaultAddress.getCity());// Mapped with “City” in "Address"

		recordBuilder.add(merchantDefaultAddress.getState());// STATE

		recordBuilder.add(merchantDefaultAddress.getCountryCode());// make sure country code is 2 letters

		recordBuilder.add("");// Postal code, keep empty

		recordBuilder.add(merchant.getMerchantName());// Terminal owner

		recordBuilder.add(merchant.getMerchantId());// Retail id, mapped with merchant ID

		recordBuilder.add(terminal.isDccEnabled()?"A":"D");// TERM STATUS

		recordBuilder.add("");// BELLING INFO, KEEP EMPTY
		recordBuilder.add("");// CLERK ID, KEEP EMPTY
		recordBuilder.add("");// LANGUAGE ID, KEEP EMPTY
		recordBuilder.add("");// PG ID
		recordBuilder.add("");// TMS FLAG, KEEP EMPTY
		recordBuilder.add("");// SEND B24 RCDE, KEEP EMPTY
		recordBuilder.add("");// ROUTING GROUP, KEEP EMPTY
		recordBuilder.add("");// DUAL SITE INDICATOR, KEEP EMPTY
		recordBuilder.add("");// LOAD FILE NAME, KEEP EMPTY
		recordBuilder.add("");// TERMINAL CUT OVER, will be passed as 0 for now, check with Srimathi/Waleed if
								// this can be provided
		recordBuilder.add("");// TERMINAL SIC CODE,KEEP EMPTY
		recordBuilder.add("");// CONTACT INPUT CAPABILITIES, can be empty need to check with Srimathi/Waleed
								// if this can be provided
		recordBuilder.add("");// CONTACTLESS INPUT CAPABILTIES,can be empty need to check with Srimathi/Waleed
								// if this can be provided
		recordBuilder.add("Y");// FLAG CARD TYPE UPDATE, Y or No, need to check if this can be provided in the
								// JSON
		recordBuilder.add(getMerchantCardTypesStr(merchant));// Accepted card Types, currently
																// we fetch this from the Merchant configs not the
																// terminal
		recordBuilder.add("|");
				
		return recordBuilder.toString();
	}

	private String generateCSECDFile(ApplicationRequest applicationRequest, Terminal terminal, Merchant merchant, Acquirer runningBank) {

		StringJoiner recordBuilder = new StringJoiner("|");
		recordBuilder.add("CS");
		recordBuilder.add(getBase24OPType(applicationRequest.getRequestType()));
		/*
		 * Set "A" in case of new terminal creation Set "C" in case of terminal update
		 * Set "D" in case of terminal delete
		 */
		String templateID = getCSECDTemplateId(merchant, terminal, runningBank);
		recordBuilder.add(templateID);// still the template ID need to be provided(Srimathi).
		recordBuilder.add(terminal.getTerminalId());

		return recordBuilder.toString();
	}
	
	private String getFIID(Merchant merchant, Acquirer runningBank) {
		String FIID="";
		if (runningBank == Acquirer.NI && merchant.getMerchantType() == MerchantType.POS) {
			FIID = "NPOS";
		} else if (runningBank == Acquirer.NI && merchant.getMerchantType() == MerchantType.ECOM) {
			FIID = "NGEN";
		}
		if (runningBank == Acquirer.TYME) {
			FIID = "TMBK";
		}
		return FIID;
	}

	private Address getMerchantDefaultAddress(Merchant merchant) {
		for (Address address : merchant.getAddresses()) {
			if (address.getAddressType().equals(AddressType.DEFAULT))
				return address;
		}

		return merchant.getAddresses().get(0);
	}

	private String getMerchantCardTypesStr(Merchant merchant) {
		StringJoiner cardTypes = new StringJoiner("|");
		for (int i = 0; i < 30; i++) {						
			if (i >= merchant.getConfigurations().getAcceptedCardSchemes().size() - 1) {
				cardTypes.add("");
			} else {
				CardSchema schema = merchant.getConfigurations().getAcceptedCardSchemes().get(i).getCardSchema();
				switch(schema) {
					case AMEX: cardTypes.add("AX");
						break;
					case VISA: cardTypes.add("V");
						break;
					case CUP:  cardTypes.add("CU");
						break;
					case DCI:  cardTypes.add("DC");
						break;
					case JCB:  cardTypes.add("JC");
						break;
					case MC:   cardTypes.add("NP");
						break;
					case MER:  cardTypes.add("NP");
						break;
					default:   cardTypes.add("");
						break;
				}				
			}
		}
		return cardTypes.toString();
	}

	private Base24File createBase24FileEntity(String applicationId,String recordType, String recordId, String templateId,
			String fileContent) {

		return Base24File.builder().fileContent(recordType).applicationId(applicationId).fileContent(fileContent).
				templateId(templateId).recordId(recordId).
				fileName(base24FileManager.getCurrentFileName()).
				build();
	}

	

	private String getPRDFTemplateID(String FIID, Merchant merchant, Acquirer runningBank) {

		if (runningBank.equals(Acquirer.TYME)) {
			return "451000000000";
		} else if (merchant.getMerchantType().equals("POS")) {
			return "001000000373";
		} else {
			return Base24TemplateIDUtil.Base24TemplateID.get(merchant.getMerchantCurrency())[0];
		}
	}

	private String getPTDTemplateId(Merchant merchant, Terminal terminal, Acquirer runningBank) {

		if (runningBank.equals(Acquirer.TYME)) {
			return "90400000";
		} else if (merchant.getMerchantType().equals("POS")) {
			return "10000373";
		} else {
			return Base24TemplateIDUtil.Base24TemplateID.get(merchant.getMerchantCurrency())[1];
		}
	}

	private String getCSECDTemplateId(Merchant merchant, Terminal terminal, Acquirer runningBank) {

		if (runningBank.equals(Acquirer.TYME)) {
			return "90400000";
		} else if (merchant.getMerchantType().equals("POS")) {
			return "10000373";
		} else {
			return Base24TemplateIDUtil.Base24TemplateID.get(merchant.getMerchantCurrency())[2];
		}
	}

	private String getBase24OPType(RequestType actionType) {

		switch (actionType) {
		case AMENDMENT:
			return "C";
		case MERCHANT_CLOSURE:
			return "D";
		case ONBOARDING: return "A";			
		case TERMINAL_CLOSURE:
			return "D";
		default:
			return "";
		
		}

	}

	private Task addRecordGenerationTask(ApplicationRequest applicationRequest, String entityId, TaskName taskName) {		
		
		Task entityTask = Task.builder().merchantId(entityId)
				.chainId(applicationRequest.getApplicationId()).name(taskName.name()).taskHistory(new ArrayList<TaskHistory>())
				.taskStatus(TaskStatus.SCHEDULED).build();
		
		entityTask.getTaskHistory().add(createTaskHistory(applicationRequest, TaskStatus.SCHEDULED,"OK",null));
		
		return entityTask;
		
	}

	private TaskHistory createTaskHistory(ApplicationRequest applicationRequest,TaskStatus taskStatus,String statusCode,String response) {

		TaskHistory taskHistory = TaskHistory.builder().
				createdDate(new Date()).
				lastModifiedDate(new Date()).
				statusCode(statusCode).
				taskStatus(taskStatus).
				response(response).
				build();
		
		return taskHistory;		
	}
}
