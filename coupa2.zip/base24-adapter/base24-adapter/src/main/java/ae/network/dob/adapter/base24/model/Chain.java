package ae.network.dob.adapter.base24.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Chain {

    @NotNull
    private String chainId;
    @NotNull
    private String chainName;
    @NotNull
    private GroupCode groupCode;
    @NotNull
    private boolean chainLevelReportRequired;
    @NotNull
    private boolean groupLevelReportingRequired;

    // local usage
    private ActionType actionType;
}
