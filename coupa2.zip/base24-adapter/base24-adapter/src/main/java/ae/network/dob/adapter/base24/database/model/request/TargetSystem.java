package ae.network.dob.adapter.base24.database.model.request;

public enum TargetSystem {
    // todo add more
    Base24
}
