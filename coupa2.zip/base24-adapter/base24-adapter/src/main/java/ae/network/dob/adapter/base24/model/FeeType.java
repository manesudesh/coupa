package ae.network.dob.adapter.base24.model;

public enum FeeType {
    MIS,
    ACQ_MMBR_FEE, // MEMBERSHIP FEE
    MFEE_STRT, // STARTUP FEE
    MFEE_FRD_HND, // Fraud
    FRAUD_HAND_FEE, // Fraud Tyme
    TRANS_FEE, // for NI
    REFUND_FEE; // for NI
}
