package ae.network.dob.adapter.base24.config;

import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.stereotype.Component;

@EnableMongoAuditing
@Component
public class DatabaseConfig {
}
