package ae.network.dob.adapter.base24.validation;

public enum ResultCode {
    OK,VALIDATION_ERROR
}
