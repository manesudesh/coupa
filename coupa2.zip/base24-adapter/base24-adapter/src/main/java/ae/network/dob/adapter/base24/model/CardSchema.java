package ae.network.dob.adapter.base24.model;

public enum CardSchema {
    VISA,
    MC,
    PL, // Private Label
    JCB,
    CUP, // China Union Pay
    MER, // Mercury
    DCI, // Diners Club International
    AMEX,

    TBOD, // Departments
    DODB,
    DOCR,
    DOHY,
    SBOC,
    SBOD,
    DOPR,


}
