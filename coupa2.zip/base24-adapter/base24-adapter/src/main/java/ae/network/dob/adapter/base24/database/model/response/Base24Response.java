package ae.network.dob.adapter.base24.database.model.response;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

//PT|A|13005308 |ERROR : 0000 [ENOERR] The operation completed successfully.

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString(includeFieldNames = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "base24_base24Response")
@Builder(access = AccessLevel.PUBLIC)
public class Base24Response {
	
	@Id
	private String recordId;
	private String recordType;
	private String actionType;
	private Boolean status;
	private String errorCode;
	private String errorDescription;
}
