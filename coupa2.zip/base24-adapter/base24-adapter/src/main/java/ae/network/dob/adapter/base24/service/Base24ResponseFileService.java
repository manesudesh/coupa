package ae.network.dob.adapter.base24.service;

import org.springframework.stereotype.Service;

import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.database.model.request.Task;
import ae.network.dob.adapter.base24.database.model.request.TaskName;
import ae.network.dob.adapter.base24.database.model.request.TaskStatus;
import ae.network.dob.adapter.base24.database.model.response.Base24Response;
import ae.network.dob.adapter.base24.database.repository.ApplicationRequestRepository;
import ae.network.dob.adapter.base24.database.repository.Base24ResponseFileRepository;

@Service
public class Base24ResponseFileService {

	private Base24ResponseFileRepository base24ResponseFileRepository;
	private ApplicationRequestRepository applicationRequestRepository;

	public Base24ResponseFileService(Base24ResponseFileRepository base24ResponseFileRepository,
			ApplicationRequestRepository applicationRequestRepository) {
		this.base24ResponseFileRepository = base24ResponseFileRepository;
		this.applicationRequestRepository = applicationRequestRepository;
	}

	public void processResponse(Base24Response base24Response) {

		base24ResponseFileRepository.save(base24Response);
		ApplicationRequest applicationRequest = null;

		// find the application object
		switch (base24Response.getRecordType()) {
		case "PR":
			applicationRequest = applicationRequestRepository
					.findByMerchantIdAndActionType(base24Response.getRecordId(), base24Response.getActionType()).get();
			break;
			
		case "PT":
			applicationRequest = applicationRequestRepository
					.findByTerminalIdAndActionType(base24Response.getRecordId(), base24Response.getActionType()).get();
			break;
			
		case "CS":
			applicationRequest = applicationRequestRepository
				.findByMerchantIdAndActionTypeAndMerchantType(base24Response.getRecordId(), base24Response.getActionType(),"POS").get();
			break;
		}

		buildReceivedFileTaskHistory(applicationRequest,base24Response);
		
		Task fileReceivedTask = Task.builder().
				taskStatus(base24Response.getStatus()?TaskStatus.COMPLETED:TaskStatus.FAILED).
				name(TaskName.RECEIVE_APP_RESPONSE.name()).
				build();
		
				
		
		
		//create a new task and assign it to the request object
		//save the newly updated request object.
		// send notification to the Updates Queue

	}

	private void buildReceivedFileTaskHistory(ApplicationRequest applicationRequest, Base24Response base24Response) {
		// TODO Auto-generated method stub
		
	}
}
