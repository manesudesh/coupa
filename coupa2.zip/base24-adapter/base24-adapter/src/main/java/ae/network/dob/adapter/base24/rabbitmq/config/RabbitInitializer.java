package ae.network.dob.adapter.base24.rabbitmq.config;

import static ae.network.dob.adapter.base24.rabbitmq.config.RabbitExchange.ONBOARDING;
import static ae.network.dob.adapter.base24.rabbitmq.config.RabbitExchange.ONBOARDING_FAIL;
import static ae.network.dob.adapter.base24.rabbitmq.config.RabbitExchange.ONBOARDING_RETRY;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.Exchange;
import org.springframework.amqp.core.ExchangeBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.stereotype.Component;

/**
 * @author walid.sewaify
 * @since 2020-01-27
 */
@Component
public class RabbitInitializer {
    private final AmqpAdmin rabbitAdmin;

    private static final String DEAD_LETTER_EXCHANGE = "x-dead-letter-exchange";

    public RabbitInitializer(AmqpAdmin rabbitAdmin) {
        this.rabbitAdmin = rabbitAdmin;
    }

    @PostConstruct
    public void initRabbit() {
        initExchanges();
        initQueues();
    }


    private void initExchanges() {
        rabbitAdmin.declareExchange(mainExchange());
        rabbitAdmin.declareExchange(delayedExchange());
        rabbitAdmin.declareExchange(failureExchange());
    }

    private void initQueues() {
        initWorkingQueues();
    }

   

    private void initWorkingQueues() {
        List<RabbitExchange> workingExchanges = Arrays.asList(ONBOARDING, ONBOARDING_RETRY);

        for (RabbitQueue rabbitQueue : RabbitQueue.getWorkingQueues()) {
            String queueName = rabbitQueue.getQueueName();
            // assign dead letter queue
            Map<String, Object> args = new HashMap<>();
            args.put(DEAD_LETTER_EXCHANGE, ONBOARDING_FAIL.getExchangeName());
            Queue queue = new Queue(queueName, true, false, false, args);
            rabbitAdmin.declareQueue(queue);

            for (String routingKey : rabbitQueue.getRoutingKeys()) {
                for (RabbitExchange exch : workingExchanges) {
                    Binding binding = new Binding(queueName, Binding.DestinationType.QUEUE, exch.getExchangeName()
                            , routingKey, null);
                    rabbitAdmin.declareBinding(binding);
                }
            }
        }
    }

    private Exchange mainExchange() {
        return ExchangeBuilder.topicExchange(ONBOARDING.getExchangeName())
                .durable(true).build();
    }

    private Exchange delayedExchange() {
        return ExchangeBuilder.directExchange(ONBOARDING_RETRY.getExchangeName())
                .durable(true).delayed().build();
    }

    private Exchange failureExchange() {
        return ExchangeBuilder.fanoutExchange(ONBOARDING_FAIL.getExchangeName())
                .durable(true).build();
    }
}
