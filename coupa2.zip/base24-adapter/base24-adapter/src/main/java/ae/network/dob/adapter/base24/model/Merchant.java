package ae.network.dob.adapter.base24.model;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Merchant {

    @NotNull
    private String merchantId;
    @NotNull
    private String merchantName;
    @NotNull
    private String legalName;
    @NotNull
    private MerchantType merchantType;
    @NotNull
    private Integer mcc;
    @NotNull
    private String depitAccountNumOrIban;
    @NotNull
    private String creitAccountNumOrIban;
    @NotNull
    private String merchantCurrency;
    @NotNull
    private ReOccurrenceFrequency statementFrequency;
    @NotNull
    private ReportDeliveryType statementDeliveryType;
    @NotNull
    private PaymentModeType paymentMode;
    @NotNull
    private boolean kyc;
    private long statementDay;

    @NotNull
    private List<Address> addresses;
    @NotNull
    private MerchantConfig configurations;
    @NotNull
    private List<MerchantService> services;
    private List<Terminal> terminals;



    @JsonIgnore
    private String chainId;
    @JsonIgnore
    private ActionType actionType;


    /**
     * generate the pricing in the simple format for simple pricing structure
     *
     * @return
     */
    public String getSimplePricingString() {
        List<String> prices = configurations.getAcceptedCardSchemes().stream().map(acceptedCardParam -> getSimplePricing(acceptedCardParam)).collect(Collectors.toList());
        return prices.stream().collect(Collectors.joining(";"));
    }

    /**
     * check if specific schema is enabled or not
     *
     * @param schemaName
     * @return
     */
    public String getCardSchemaAvailability(String schemaName) {
        if (configurations.getAcceptedCardSchemes().stream().anyMatch(acceptedCardParam -> acceptedCardParam.getCardSchema().name().equalsIgnoreCase(schemaName)))
            return "Y";

        return "N";
    }

    /**
     * check if specific Fee is enabled or not
     *
     * @param feeName
     * @return
     */
    public String getFeeAvailability(String feeName) {
        if (configurations.getFees().stream().anyMatch(feesParam -> feesParam.getFeeTypeName().name().equalsIgnoreCase(feeName)))
            return "Y";

        return "N";
    }

    /**
     * get the value for specific Fee type
     *
     * @param feeName
     * @return
     */
    public BigDecimal getFeeValue(String feeName) {
        if (configurations.getFees().stream().anyMatch(feesParam -> feesParam.getFeeTypeName().name().equalsIgnoreCase(feeName)))
            return configurations.getFees().stream().filter(feesParam -> feesParam.getFeeTypeName().name().equalsIgnoreCase(feeName)).findFirst().get().getFeeValue();

        return BigDecimal.ZERO;
    }

    /**
     * checks if the merchant has DCC option or not
     *
     * @return true/false
     */
    public boolean isDcc() {
        if (services != null && ! services.isEmpty())
            return services.stream().anyMatch(merchantService -> merchantService.getServiceType().equals(ServiceType.DCC));
        else
            return false;
    }

    /**
     * get the DCC provider in case the merchant is dcc enabled
     *
     * @return dcc provider
     */
    public String getDccProvider() {
        return ((DCCServiceParam) services.stream().filter(merchantService -> merchantService.getServiceType().equals(ServiceType.DCC)).findFirst().get()).getDccProvider().name();
    }

    /**
     * get DCC settlement occurrence
     *
     * @return
     */
    public ReOccurrenceFrequency getDccSettlementsOccurrence() {
        return ((DCCServiceParam) services.stream().filter(merchantService -> merchantService.getServiceType().equals(ServiceType.DCC)).findFirst().get()).getDccSettlementFrequency();
    }


    /**
     * get the override merchant name per scheme
     * @param scheme
     * @return
     */
    public String getOverrideSchemeMerchantName(String scheme){
        return configurations.getAcceptedCardSchemes().stream()
                .filter(acceptedCardParam -> acceptedCardParam.getCardSchema().equals(CardSchema.valueOf(scheme))).findFirst().get().getSchemeOverrideValue().getDBAName();
    }


    /**
     * get the override merchant mcc per scheme
     * @param scheme
     * @return
     */
    public Integer getOverrideSchemeMerchantMcc(String scheme) {
        return configurations.getAcceptedCardSchemes().stream()
                .filter(acceptedCardParam -> acceptedCardParam.getCardSchema().equals(CardSchema.valueOf(scheme))).findFirst().get().getSchemeOverrideValue().getMcc();
    }

    /**
     * generate the simple pricing string depends on the type of the schema.
     *
     * @param acceptedCardParam
     * @return
     */
    private String getSimplePricing(AcceptedCardParam acceptedCardParam) {
        final List<String> deptCodes = Arrays.asList("TBOD", "DODB", "DOCR", "DOHY", "SBOC", "SBOD", "DOPR");
        if (deptCodes.stream().anyMatch(deptcode -> acceptedCardParam.getCardSchema().name().equals(deptcode))) {
            return acceptedCardParam.getCardSchema().name() + "=" + acceptedCardParam.getCardSchema().name() + "_" + acceptedCardParam.getTariffRate();
        } else {
            return acceptedCardParam.getCardSchema().name() + "=" + acceptedCardParam.getTariffRate();
        }
    }

}
