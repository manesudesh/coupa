package ae.network.dob.adapter.base24.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TerminalFee {

    private TerminalFeeType feeType;
    //private String currencyCode;
    //private AmountType amountType;
    private BigDecimal feeValue;

}