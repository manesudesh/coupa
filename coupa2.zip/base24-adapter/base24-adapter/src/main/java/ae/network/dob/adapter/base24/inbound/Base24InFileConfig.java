package ae.network.dob.adapter.base24.inbound;

import java.io.File;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.file.FileReadingMessageSource;
import org.springframework.integration.file.filters.SimplePatternFileListFilter;
import org.springframework.integration.file.transformer.FileToStringTransformer;
import org.springframework.messaging.MessageChannel;

import ae.network.dob.adapter.base24.config.Base24FolderConfigs;

@Configuration
@EnableIntegration
public class Base24InFileConfig{
	
    public String FILE_PATTERN = "*";
    private Base24FolderConfigs base24FolderConfigs;

    public Base24InFileConfig(Base24FolderConfigs base24FolderConfigs) {
        this.base24FolderConfigs = base24FolderConfigs;
    }

    @Bean
    public MessageChannel fileChannel() {
        return new DirectChannel();
    }
     
    @Bean
    @InboundChannelAdapter(value = "fileChannel", poller =@Poller(fixedDelay = "1000") )
    public MessageSource<File> fileReadingMessageSource() {
        FileReadingMessageSource sourceReader= new FileReadingMessageSource();
        sourceReader.setDirectory(new File(base24FolderConfigs.getIn()));
        sourceReader.setFilter(new SimplePatternFileListFilter(FILE_PATTERN));
        return sourceReader;
    }
    
    @Bean
    public FileToStringTransformer fileToStringTransformer() {
        return new FileToStringTransformer();
    }
    
    @Bean
    public IntegrationFlow processFileFlow() {
        return IntegrationFlows.from("fileChannel")
            .transform(fileToStringTransformer())
            .handle("base24ResponseFileProcessor", "process").get();
        }
    
 }