package ae.network.dob.adapter.base24.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FeesParam {

    private FeeType feeTypeName;
    private ReOccurrenceFrequency reOccurrenceFrequency;
    //private AmountType feeType;
    private BigDecimal feeValue;
}
