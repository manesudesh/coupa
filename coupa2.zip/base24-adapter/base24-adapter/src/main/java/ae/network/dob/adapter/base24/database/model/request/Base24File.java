package ae.network.dob.adapter.base24.database.model.request;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import ae.network.dob.adapter.base24.database.model.AbstractAuditingEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@AllArgsConstructor
@Builder
@ToString(includeFieldNames = true)
@JsonIgnoreProperties(ignoreUnknown   = true)
@Document(collection = "base24_base24File")
public class Base24File extends AbstractAuditingEntity {

	@Id
    private String id;
    private String applicationId; 
    private String templateId;
    private String recordId;
    private String fileName;
    private String fileType;
    private String fileContent;
	private String status;
    
}