package ae.network.dob.adapter.base24.database.model.request;

public enum TaskName {
    VALIDATION,
    SEND_APP_REQUEST,
    RECEIVE_APP_RESPONSE,
    FILE_GENERATION,
    SEND_MERCHANT_REQUEST,
    RECEIVE_MERCHANT_RESPONSE,
    SEND_TERMINAL_REQUEST,
    SEND_POS_TERMINAL_REQUEST,    
    RECEIVE_TERMINAL_RESPONSE
}
