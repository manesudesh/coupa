package ae.network.dob.adapter.base24.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Terminal {

    private String terminalId;
    private String terminalType; // PC or ?
    private String maker;
    private String terminalModel;
    private TerminalCommunicationMethod communicationMethod;
    private boolean dccEnabled;
    private List<TerminalFee> fees;
    private TerminalOperations allowedOperations;

    @JsonIgnore
    private String merchantId;
    @JsonIgnore
    private String merchantCurrency;
    @JsonIgnore
    private ActionType actionType;;



    /**
     * get the value for specific Fee type
     *
     * @param feeName
     * @return
     */
    public BigDecimal getFeeValue(String feeName) {
        if (fees.stream().anyMatch(fee -> fee.getFeeType().name().equalsIgnoreCase(feeName)))
            return fees.stream().filter(fee -> fee.getFeeType().name().equalsIgnoreCase(feeName)).findFirst().get().getFeeValue();

        return BigDecimal.ZERO;
    }

}
