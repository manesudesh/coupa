package ae.network.dob.adapter.base24.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Yousry
 * @version 1.0
 */

public enum ReOccurrenceFrequency {
    D, W, M;


    private static Map<String, ReOccurrenceFrequency> namesMap = new HashMap<String, ReOccurrenceFrequency>(5);

    static {
        namesMap.put("DAILY", D);
        namesMap.put("WEEKLY",W);
        namesMap.put("MONTHLY", M);
    }

    @JsonCreator
    public static ReOccurrenceFrequency forValue(String value) {
        return namesMap.get(value);
    }

    @JsonValue
    public String toValue() {
        return namesMap.entrySet().stream().filter(entry-> entry.getValue() == this).findFirst().get().getKey();
    }
}