package ae.network.dob.adapter.base24.database.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import ae.network.dob.adapter.base24.database.model.response.Base24Response;

public interface Base24ResponseFileRepository extends MongoRepository<Base24Response, String> {
    Optional<Base24Response> findByRecordId(String recordId);
    Optional<Base24Response> findByRecordIdAndRecordType(String recordId,String recordType);
}
