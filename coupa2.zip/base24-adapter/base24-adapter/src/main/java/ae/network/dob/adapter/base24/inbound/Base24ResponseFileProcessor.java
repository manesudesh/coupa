package ae.network.dob.adapter.base24.inbound;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;

import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import ae.network.dob.adapter.base24.database.model.response.Base24Response;
import ae.network.dob.adapter.base24.service.Base24ResponseFileService;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class Base24ResponseFileProcessor {

	private static final String HEADER_FILE_NAME = "file_name";
	private Base24ResponseFileService base24ResponseFileService;
	
	

	public Base24ResponseFileProcessor(Base24ResponseFileService base24ResponseFileService) {
		this.base24ResponseFileService = base24ResponseFileService;
	}

	public void process(Message<String> msg) {

		log.info("Base24 Response File {} under processing", msg.getHeaders().get(HEADER_FILE_NAME));

		File file = new File(msg.getHeaders().get("file_originalFile").toString());

		String content = msg.getPayload();
		Collection<Base24Response> responses = createArrayOfResponseObjects(content);
		
		responses.stream().forEach(base24ResponseFileService::processResponse);
		
		log.info("Finished processing the File {} .", msg.getHeaders().get(HEADER_FILE_NAME));
		file.delete();
	}

	private Collection<Base24Response> createArrayOfResponseObjects(String content) {

		String[] lines = content.split("\\r?\\n");

		log.info("Number of Records :{}", lines.length);
		ArrayList<Base24Response> base24ResponseReport = new ArrayList<Base24Response>();

		for (String line : lines) {

			Base24Response base24Response = Base24Response.builder().recordType(line.substring(0, 2))
					.actionType(line.substring(3, 4)).recordId(line.substring(5, 24).trim())
					.errorCode(line.substring(33, 38)).errorDescription(line.substring(38))
					.status("0000".equals(line.substring(33, 38).trim())).build();

			log.info(base24Response.toString());

			base24ResponseReport.add(base24Response);
		}

		return base24ResponseReport;
	}
}
