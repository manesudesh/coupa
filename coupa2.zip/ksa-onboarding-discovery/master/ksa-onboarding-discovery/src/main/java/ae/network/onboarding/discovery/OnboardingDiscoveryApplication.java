package ae.network.onboarding.discovery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class OnboardingDiscoveryApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnboardingDiscoveryApplication.class, args);
	}

}
