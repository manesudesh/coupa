package ae.network.onboarding.auth.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ae.network.onboarding.auth.dto.UserDataDTO;
import ae.network.onboarding.auth.dto.UserResponseDTO;
import ae.network.onboarding.auth.model.User;
import ae.network.onboarding.auth.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/users")
@Tag(name = "users")
public class UserController {
	
    private static final String ROLE_ADMIN = "'ROLE_ADMIN'";
    private static final String ROLE_CLIENT = "'ROLE_CLIENT'";

    private final UserService userService;
    private final ModelMapper modelMapper;

    @Autowired
    public UserController(UserService userService, ModelMapper modelMapper) {
        this.userService = userService;
        this.modelMapper = modelMapper;
    }

    @PostMapping("/signin")
    @Operation(summary = "${UserController.signin}")
    @ApiResponses(value = {
          @ApiResponse(responseCode = "400", description = "Something went wrong"),
          @ApiResponse(responseCode = "422", description = "Invalid username/password supplied")})
    public String login(
    		@RequestParam String username,
            @RequestParam String password) {
        return userService.signin(username, password);
    }

    @PostMapping("/changepwd")
    @PreAuthorize("hasRole(" + ROLE_ADMIN + ")")
    @Operation(summary = "${UserController.changePassword}")
    @ApiResponses(value = {
          @ApiResponse(responseCode = "400", description = "Something went wrong"),
          @ApiResponse(responseCode = "422", description = "Invalid username/password supplied")})
    public boolean changePassword(
    		@Parameter(name = "Username") @RequestParam String username,
            @Parameter(name = "Password") @RequestParam String password) {
        userService.changePassword(username, password);
        return true;
    }

    @PostMapping("/signup")
    @PreAuthorize("hasRole(" + ROLE_ADMIN + ")")
    @Operation(summary = "${UserController.signup}")
    @ApiResponses(value = {
          @ApiResponse(responseCode = "400", description = "Something went wrong"),
          @ApiResponse(responseCode = "403", description = "Access denied"),
          @ApiResponse(responseCode = "422", description = "Username is already in use"),
          @ApiResponse(responseCode = "500", description = "Expired or invalid JWT token")})
    public String signup(@Parameter(name = "Signup User") @Valid @RequestBody UserDataDTO user) {
        return userService.signup(modelMapper.map(user, User.class));
    }

    @DeleteMapping(value = "/{username}")
    @PreAuthorize("hasRole(" + ROLE_ADMIN + ")")
    @Operation(summary = "${UserController.delete}")
    @ApiResponses(value = {
          @ApiResponse(responseCode = "400", description = "Something went wrong"),
          @ApiResponse(responseCode = "403", description = "Access denied"),
          @ApiResponse(responseCode = "404", description = "The user doesn't exist"),
          @ApiResponse(responseCode = "500", description = "Expired or invalid JWT token")})
    public boolean delete(@Parameter(name = "Username", required = true) @PathVariable String username) {
        userService.delete(username);
        return true;
    }

    @GetMapping(value = "/{username}")
    @PreAuthorize("hasRole(" + ROLE_ADMIN + ")")
    @Operation(summary = "${UserController.search}", responses = { @ApiResponse(content = @Content(schema = @Schema(implementation = UserResponseDTO.class)))} )
    @ApiResponses(value = {
          @ApiResponse(responseCode = "400", description = "Something went wrong"),
          @ApiResponse(responseCode = "403", description = "Access denied"),
          @ApiResponse(responseCode = "404", description = "The user doesn't exist"),
          @ApiResponse(responseCode = "500", description = "Expired or invalid JWT token")})
    public UserResponseDTO search(@Parameter(name = "Username") @PathVariable String username) {
        return modelMapper.map(userService.search(username), UserResponseDTO.class);
    }

    @GetMapping(value = "/whoami")
    @PreAuthorize("hasRole(" + ROLE_ADMIN + ") or hasRole(" + ROLE_CLIENT + ")")
    @Operation(summary  = "${UserController.whoami}", responses = { @ApiResponse(content = @Content(schema = @Schema(implementation = UserResponseDTO.class)))} )
    @ApiResponses(value = {
          @ApiResponse(responseCode  = "400", description  = "Something went wrong"),
          @ApiResponse(responseCode  = "403", description  = "Access denied"),
          @ApiResponse(responseCode  = "500", description  = "Expired or invalid JWT token")})
//    @Parameters(
//          @Parameter(name = "Authorization", /*value = "Access Token",*/ required = true, 
//          allowEmptyValue = false, /*paramType = "header", dataTypeClass = String.class,*/
//          example = "Bearer access_token",in=ParameterIn.HEADER)
//    		)
    @SecurityRequirement(name="Authorization")
    public UserResponseDTO whoami(HttpServletRequest req) {
        return modelMapper.map(userService.whoami(req), UserResponseDTO.class);
    }

    @GetMapping("/refresh")
    @PreAuthorize("hasRole(" + ROLE_ADMIN + ") or hasRole(" + ROLE_CLIENT + ")")
    public String refresh(HttpServletRequest req) {
        return userService.refresh(req.getRemoteUser());
    }

}
