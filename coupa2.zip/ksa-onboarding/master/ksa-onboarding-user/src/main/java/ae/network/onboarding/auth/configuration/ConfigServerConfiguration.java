package ae.network.onboarding.auth.configuration;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@ConfigurationProperties//("config")
@RefreshScope
@Data
public class ConfigServerConfiguration {

    private List<String> supportedAcquirers;

//    private String supportedAcquirers22;

  
}