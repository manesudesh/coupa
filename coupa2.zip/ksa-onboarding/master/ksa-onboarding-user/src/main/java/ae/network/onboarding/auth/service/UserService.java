package ae.network.onboarding.auth.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import ae.network.onboarding.auth.configuration.ConfigServerConfiguration;
import ae.network.onboarding.auth.exception.CustomException;
import ae.network.onboarding.auth.model.User;
import ae.network.onboarding.auth.repository.UserRepository;
import ae.network.onboarding.auth.security.JwtTokenProvider;
import ae.network.onboarding.auth.security.WebSecurityConfig;
import jakarta.servlet.http.HttpServletRequest;

@Service
@RefreshScope
public class UserService {

    private final UserRepository userRepository;

    private final JwtTokenProvider jwtTokenProvider;

    private WebSecurityConfig webSecurityConfig;

    @Value("${login.default-password}")
    private String defaultPassword;

    @Value("${supportedAcquirers}")
    private List<String> supportedAcquirers;
    
    @Value("${login.keey}")
    private String keey;
    
    @Autowired
    ConfigServerConfiguration configServer;

    public UserService(UserRepository userRepository, JwtTokenProvider jwtTokenProvider, WebSecurityConfig webconfig) {
        this.userRepository = userRepository;
        this.jwtTokenProvider = jwtTokenProvider;
        this.webSecurityConfig = webconfig;
    }

   
    public String signin(String username, String password) {
        try {
        	webSecurityConfig.authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
            User loginUser = userRepository.findByUsername(username);
            loginUser.setLatestAccess(new Date());
            userRepository.save(loginUser);
            return jwtTokenProvider.createToken(loginUser);
        } catch (AuthenticationException e) {
            throw new CustomException("Invalid username/password supplied", HttpStatus.UNPROCESSABLE_ENTITY);
        }
    }

    public void changePassword(String username, String password) {
        if (!userRepository.existsByUsername(username)) {
            throw new CustomException("Invalid username", HttpStatus.UNPROCESSABLE_ENTITY);
        }
        if (!validatePassword(password)) {
            throw new CustomException("Invalid password", HttpStatus.UNPROCESSABLE_ENTITY);
        }
        User user = userRepository.findByUsername(username);
        user.setPassword(passwordEncoder().encode(password));
        userRepository.save(user);
    }

    private boolean validatePassword(String password) {
        if (password == null || password.length() < 8 || password.length() > 16) {
            return false;
        }
        boolean upperCase = false;
        boolean lowerCase = false;
        boolean digit = false;
        boolean specialChar = false;
        for (char ch : password.toCharArray()) {
            if (Character.isDigit(ch)) {
                digit = true;
            } else if (Character.isUpperCase(ch)) {
                upperCase = true;
            } else if (Character.isLowerCase(ch)) {
                lowerCase = true;
            } else if ("!@#$%^&*".contains(String.valueOf(ch))) {
                specialChar = true;
            } else {
                // not valid char
                return false;
            }
        }
        return upperCase && lowerCase && digit && specialChar;
    }

    public String signup(User user) {
    	if (!configServer.getSupportedAcquirers().contains(user.getAcquirer())) {
//        if (!supportedAcquirers.contains(user.getAcquirer())) {
            throw new CustomException("Acquirer is not supported", HttpStatus.BAD_REQUEST);
        } else if (userRepository.existsByUsername(user.getUsername())) {
            throw new CustomException("Username is already in use", HttpStatus.UNPROCESSABLE_ENTITY);
        } else {
            user.setPassword(passwordEncoder().encode(defaultPassword));
            userRepository.save(user);
            return jwtTokenProvider.createToken(user);
        }
    }

    public void delete(String username) {
        userRepository.deleteByUsername(username);
    }

    public User search(String username) {
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new CustomException("The user doesn't exist", HttpStatus.NOT_FOUND);
        }
        return user;
    }

    public User whoami(HttpServletRequest req) {
        return userRepository.findByUsername(jwtTokenProvider.getUsername(jwtTokenProvider.resolveToken(req)));
    }

    public String refresh(String username) {
        return jwtTokenProvider.createToken(userRepository.findByUsername(username));
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);
    }

}
