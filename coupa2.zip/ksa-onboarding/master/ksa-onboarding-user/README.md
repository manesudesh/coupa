# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.2.4.RELEASE/maven-plugin/)

### Onboarding a new acquirer:-
No changes are mandatory, but you may need to remember changing in the following files:-
* MongoInitialSetup.java (add new script for non-production environments to make testing easy)
* In production, create a new user document in "users" collection, either through a database change or through the admin APIs
* Acquirer supported include NI, TYME (set config property: supportedAcquirers)

#### Example

`curl --location --request POST 'http://192.168.67.159:8011/users/signup' \
 --header 'Content-Type: application/json' \
 --header 'Authorization: Bearer $BEARER' \
 --data-raw '{
     "username": "username",
     "email": "test@ni.ae",
     "acquirer": "NI",
     "roles": [
         "CLIENT"
     ],
     "backendSystems": [
         "PP"
     ]
 }'`
 
