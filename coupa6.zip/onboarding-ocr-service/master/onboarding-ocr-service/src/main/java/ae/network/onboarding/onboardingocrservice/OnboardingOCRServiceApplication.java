package ae.network.onboarding.onboardingocrservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import ae.network.onboarding.onboardingocrservice.controllers.OCRController;

@SpringBootApplication
public class OnboardingOCRServiceApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(OnboardingOCRServiceApplication.class, args);
	}

	@Autowired
	OCRController controller;
	
	@Override
	public void run(String... args) throws Exception {
//		String[] cmd1 = {"sudo", "apt-get", "update"}; 
//        Process process1 = Runtime.getRuntime().exec(cmd1);
//        int exitCode1 = process1.waitFor(); 
//        
//        String[] cmd2 = {"sudo", "apt-get", "install", "tesseract"}; 
//        Process process2 = Runtime.getRuntime().exec(cmd2);
//        int exitCode2 = process2.waitFor(); 
////		System.setProperty("jna.library.path", "/libs");
        
//		 System.loadLibrary("tesseract");
//		RestTemplate restTemplate = new RestTemplate();
//		String fooResourceUrl = "http://localhost:8041/ocr-service/readlicense";
//		ResponseEntity<String> response  = restTemplate.getForEntity(fooResourceUrl, String.class);	
//		
		controller.readLicenseBydefault();
	}

}
