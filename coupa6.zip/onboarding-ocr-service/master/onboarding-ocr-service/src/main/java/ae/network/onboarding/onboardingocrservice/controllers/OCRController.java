package ae.network.onboarding.onboardingocrservice.controllers;

import java.io.IOException;
import java.net.URISyntaxException;

import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ae.network.onboarding.onboardingocrservice.dto.ScanRequest;
import ae.network.onboarding.onboardingocrservice.services.OCRService;
import ae.network.onboarding.onboardingocrservice.services.utils.LicenseDocument;
import lombok.RequiredArgsConstructor;
import net.sourceforge.tess4j.TesseractException;

@RestController
@RequestMapping("/ocr-service")
@RequiredArgsConstructor
public class OCRController {
    private final OCRService ocrService;
    private final LicenseDocument licDocument;
    
    @Value ("${ocr.license.fileProcessInterval}") 
    public String fileProcessIntervalProperty;
    
    @Value ("${ocr.license.manualDate.manualDateFlag}") 
    public boolean manualDateFlagProperty;
    @Value ("${ocr.license.manualDate.dd}") 
    public int ddProperty;    
    @Value ("${ocr.license.manualDate.mm}") 
    public int mmProperty;
    @Value ("${ocr.license.manualDate.yyyy}") 
    public int yyyyProperty;

    
    @GetMapping(value = "/scan")
    ResponseEntity<String> scanImage() throws IOException, TesseractException, URISyntaxException {
    	ScanRequest scanRequest = new ScanRequest();
    	String ocrText = ocrService.scanImage(scanRequest);
    	return new ResponseEntity<>(ocrText, HttpStatus.OK);
    }
    
    
    @GetMapping(value = "/readlicense/{calendarDiffIdentifer}/dd-{dd}/mm-{mm}/yyyy-{yyyy}")
    ResponseEntity<String> readLicense(@PathVariable("calendarDiffIdentifer") String calendarDiffIdentifer,
    		@PathVariable("dd") String dd, @PathVariable("mm") String mm, @PathVariable("yyyy") String yyyy) throws IOException  {
    	try {
    		if (! validateCalendarSelection(calendarDiffIdentifer)) {
    			return new ResponseEntity<>("Files selctions are only based on day or week or month or year", HttpStatus.BAD_REQUEST);
    		}
    		LocalDate processingDateFile = new LocalDate(Integer.valueOf(yyyy), Integer.valueOf(mm), Integer.valueOf(dd) ); 
	    	licDocument.readFiles(processingDateFile, calendarDiffIdentifer);
    	return new ResponseEntity<>( HttpStatus.OK);
    	}catch(NumberFormatException ne) {
    		return new ResponseEntity<>("Date Number issue", HttpStatus.BAD_REQUEST);
    	}
    }


	public boolean validateCalendarSelection(String calendarDiffIdentifer) {
		if(!calendarDiffIdentifer.equalsIgnoreCase("day") && !calendarDiffIdentifer.equalsIgnoreCase("week") && !calendarDiffIdentifer.equalsIgnoreCase("month") && !calendarDiffIdentifer.equalsIgnoreCase("year"))
		{
			return false;
		}
		return true;
	}
    
    @GetMapping(value = "/readlicense/{fileProcessInterval}")
    ResponseEntity<String> readLicense(@PathVariable("fileProcessInterval") String fileProcessInterval) throws IOException  {
    	try {
    		if (! validateCalendarSelection(fileProcessInterval)) {
    			return new ResponseEntity<>("Files selctions are only based on day or week or month or year", HttpStatus.BAD_REQUEST);
    		}
    		LocalDate processingDateFile = LocalDate.now(); 
	    	licDocument.readFiles(processingDateFile, fileProcessInterval);
    	return new ResponseEntity<>( HttpStatus.OK);
    	}catch(NumberFormatException ne) {
    		return new ResponseEntity<>("Date Number issue", HttpStatus.BAD_REQUEST);
    	}
    }
    
    @GetMapping(value = "/readlicense")
    public ResponseEntity<String> readLicenseBydefault() throws IOException  {
    	try {
    		System.out.println("manualDateFlagProperty "+ manualDateFlagProperty);
    		System.out.println("dd "+ ddProperty);
    		System.out.println("MM "+ mmProperty);
    		System.out.println("yyyy "+ yyyyProperty);
    		if (! validateCalendarSelection(fileProcessIntervalProperty)) {
    			return new ResponseEntity<>("Files selections are only based on day or week or month or year", HttpStatus.BAD_REQUEST);
    		}
    		LocalDate processingDateFile; 
    		if(manualDateFlagProperty) {
    			processingDateFile = new LocalDate(yyyyProperty, mmProperty, ddProperty); 
    		}else {
    			processingDateFile = LocalDate.now(); 
    		}
    		
    		System.out.println("Processing LocalDate "+ processingDateFile);
    		
//	    	licDocument.readFiles(processingDateFile, fileProcessIntervalProperty);
    		licDocument.initiateProcess(processingDateFile, fileProcessIntervalProperty);
	    	return new ResponseEntity<>( HttpStatus.OK);
    	}catch(NumberFormatException ne) {
    		return new ResponseEntity<>("Date Number issue", HttpStatus.BAD_REQUEST);
    	}
    }
    
}
