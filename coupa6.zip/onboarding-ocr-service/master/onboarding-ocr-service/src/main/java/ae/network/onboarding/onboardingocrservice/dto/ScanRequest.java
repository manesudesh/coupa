package ae.network.onboarding.onboardingocrservice.dto;

import lombok.Data;

@Data
public class ScanRequest {
//	String frontFileName = "C:/Users/Sudesh_Mane/Downloads/EID.doc";
	String frontFileName = "https://onboarding-uat.network.ae/files/shared/sob-ni-1723/Sample Emirate Id1.PNG?accessKey=388efbfdf25edeba43e0e2ce2d4841a94d348c2bc81f2ecbf36e3d213cdd1174";
//	String backFileName = "https://onboarding-uat.network.ae/files/shared/sob-ni-1723/Sample Emirate Id2.PNG?accessKey=d6eae6c7f891f19be24b85c302f99b31d297a615c42fe5da98910390ecc05700";
	String backFileName = "C:/Users/Sudesh_Mane/Downloads/EID.doc";
}
