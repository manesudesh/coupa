package ae.network.onboarding.onboardingocrservice.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import ae.network.onboarding.onboardingocrservice.dao.User;

public interface UserRepository extends MongoRepository<User, Integer> {
    User findByUsername(String username);
}
