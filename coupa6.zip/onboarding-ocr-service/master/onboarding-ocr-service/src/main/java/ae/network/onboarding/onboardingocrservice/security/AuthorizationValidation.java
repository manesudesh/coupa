package ae.network.onboarding.onboardingocrservice.security;

import org.springframework.stereotype.Service;

import ae.network.onboarding.onboardingocrservice.dao.User;
import ae.network.onboarding.onboardingocrservice.services.impl.UserService;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthorizationValidation {
    private final UserService userService;

    public boolean hasUserAuthorityOCR(String username) {
        User user = userService.findUserByUsername(username);

        if (user.getServices() == null || user.getServices().isEmpty()) {
            return false;
        }

        for (String service : user.getServices()) {
            if (service.contains("OCR_SERVICE")) {
                return true;
            }
        }

        return false;
    }
}
