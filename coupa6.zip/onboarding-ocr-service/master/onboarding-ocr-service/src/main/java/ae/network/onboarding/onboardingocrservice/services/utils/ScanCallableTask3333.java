package ae.network.onboarding.onboardingocrservice.services.utils;

import java.io.File;
import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

public class ScanCallableTask3333 implements Callable<List<File>> 
{

  private List<File> fileList;
  
 
  public ScanCallableTask3333(List<File> fileList) {
    this.fileList = fileList;
  }
 
  @Override
  public List<File> call() throws Exception 
  {
	  LicenseDocument licDoc = new LicenseDocument();  
    try {
    	fileList.forEach(taskfile -> licDoc.readSingleFile(taskfile)); 
    } catch (Exception e) {
      e.printStackTrace();
    }
 
    return fileList;
  }
}
