package ae.network.onboarding.onboardingocrservice.dao;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Document("users")
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Data
public class User {
    private String id;
    private String username;
    private String ocr;
    private List<String> services;
}
