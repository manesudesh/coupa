package ae.network.onboarding.onboardingocrservice.exceptions;

public class ValidationFailedException extends Exception {

    public ValidationFailedException(String failedParam) {
        super("Validation failed for " + failedParam);
    }
}
