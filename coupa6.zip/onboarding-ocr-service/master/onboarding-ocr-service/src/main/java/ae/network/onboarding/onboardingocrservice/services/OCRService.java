package ae.network.onboarding.onboardingocrservice.services;

import java.io.IOException;
import java.net.URISyntaxException;

import ae.network.onboarding.onboardingocrservice.dto.ScanRequest;
import net.sourceforge.tess4j.TesseractException;

public interface OCRService {
    String scanImage(ScanRequest scanRequest ) throws IOException, TesseractException, URISyntaxException;
}
