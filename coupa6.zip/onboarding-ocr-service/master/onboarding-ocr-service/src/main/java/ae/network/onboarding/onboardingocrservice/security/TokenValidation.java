package ae.network.onboarding.onboardingocrservice.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;

@Service
public class TokenValidation {

    @Value("${jwt.token.secret-key}")
    private String secretKey;

    @Value("${jwt.token.enabled}")
    private boolean authenticationRequired;

    public boolean isTokenValid(String token) {

        if (!authenticationRequired) {
            return true;
        }

        String clearToken = token.substring(7);
        try {
            Jwts.parser().setSigningKey(secretKey.getBytes()).parseClaimsJws(clearToken);
            return true;
        } catch (JwtException ex) {
            return false;
        }
    }
}
