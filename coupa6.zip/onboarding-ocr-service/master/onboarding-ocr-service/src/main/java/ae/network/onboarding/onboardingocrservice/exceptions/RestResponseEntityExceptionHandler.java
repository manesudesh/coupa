package ae.network.onboarding.onboardingocrservice.exceptions;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import net.sourceforge.tess4j.TesseractException;

@RestControllerAdvice
public class RestResponseEntityExceptionHandler {

	@ExceptionHandler(value = { URISyntaxException.class, MalformedURLException.class, IOException.class })
	protected ResponseEntity<Object> handleConflict( RuntimeException ex, WebRequest request) {
		String bodyOfResponse = "Image Path URL not found";
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("An error occurred: " + bodyOfResponse+" "+ex.getMessage());
	}
	
	@ExceptionHandler(value = { TesseractException.class })
	protected ResponseEntity<Object> handleImageReader( RuntimeException ex, WebRequest request) {
		String bodyOfResponse = "Image Reader";
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body("An error occurred: " + bodyOfResponse+" "+ex.getMessage() );
	}
	
	@ExceptionHandler(value = { UnsupportedEncodingException.class })
	protected ResponseEntity<Object> handleSupportedEncoding (RuntimeException ex, WebRequest request) {
		String bodyOfResponse = "Encoding Not Supported";
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body("An error occurred: " + bodyOfResponse+" "+ex.getMessage() );
	}
}
