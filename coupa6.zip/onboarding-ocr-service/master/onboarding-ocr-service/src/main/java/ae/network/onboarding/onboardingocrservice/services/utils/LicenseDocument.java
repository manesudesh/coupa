package ae.network.onboarding.onboardingocrservice.services.utils;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiPredicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.tika.detect.DefaultDetector;
import org.apache.tika.detect.Detector;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.joda.time.Period;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.spire.doc.Document;
import com.spire.doc.FileFormat;

import lombok.extern.slf4j.Slf4j;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

@Service
@Slf4j
public class LicenseDocument {

	 private static AtomicInteger counter = new AtomicInteger();
	 @Value("${ocr.license.source}")
	 public String sourceFolder ;
	 @Value("${ocr.license.destination}")
	 public String  destinationFolder;
	 @Value("${ocr.license.batchSize}")
	 public int  batchSize;
	 @Value("${ocr.license.tessj.trainedData}")
	 public String  trainedData;
	 @Value("${ocr.license.tessj.lang}")
	 public String  tess4jLang;
	 
	 private static final Map<String, String> extensionMap = new HashMap<String, String>();

	 static {
		 extensionMap.put("application/octet-stream", "pdf");
		 extensionMap.put("application/msword", "doc");
		 extensionMap.put("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "docx");
		 extensionMap.put("image/jpeg", "jpeg");
		 extensionMap.put("image/png", "png");
		 extensionMap.put("application/pdf", "pdf");
		 extensionMap.put("image/tiff", "tiff");
	 };
	 
	 
	public String detectFileTypeUsingDetector(InputStream inStream) throws IOException {
		
		Detector detector = new DefaultDetector();
		Metadata metadata = new Metadata();

		MediaType mediaType = detector.detect(inStream, metadata);
		String extension = mediaType.toString();
		return extension;
	}
	
	public void readFiles(LocalDate date, String fileSelectionBasisOf) throws IOException  {
        	BiPredicate<Path, String> dateSelectionPredicate = (path, dayWeekMonthYearStr) -> {
        		Period p = new Period(date, new LocalDate(path.toFile().lastModified()));
                System.out.print("last Modified date "+path.toFile().lastModified());
        		if(dayWeekMonthYearStr.equalsIgnoreCase("day") && p.getDays() == 0 &&  p.getMonths() == 0 && p.getYears() == 0 ) {System.out.println(path.getFileName()+" File selected basis on day criteria"); return true; }
                if(dayWeekMonthYearStr.equalsIgnoreCase("week") && p.getDays() >= 0 && p.getWeeks() == 0 && p.getMonths() == 0 && p.getYears() == 0 ) {System.out.println(path.getFileName()+" File selected basis on week criteria"); return true; }
                if(dayWeekMonthYearStr.equalsIgnoreCase("month") && p.getDays() >= 0 && p.getMonths() == 0 && p.getYears() == 0 ) {System.out.println(path.getFileName()+" File selected basis on month criteria"); return true;}
                if(dayWeekMonthYearStr.equalsIgnoreCase("year") && p.getMonths() >= 0 && p.getYears() == 0) {System.out.println(path.getFileName()+" File selected basis on year criteria"); return true;}
                else {return false;}
        	};
        	
        	Path startDir = Paths.get(sourceFolder); 
            List<File> filesList = Files.walk(startDir)
                                        .filter(Files::isRegularFile)
                                        .filter(path -> dateSelectionPredicate.test(path, fileSelectionBasisOf))
                                        .map(path -> path.toFile())
                                        .sorted(Comparator.comparingLong(File::lastModified).reversed())
                                        .collect(Collectors.toList());
            filesList.forEach(file -> {
            	
						try {
							log.info("reading file "+file.getAbsolutePath() + " Last "+new LocalDateTime(file.lastModified()) );
							readSingleFile(file);
						} catch (Throwable e) {
							e.printStackTrace();
						}
					} 
			);
            log.info("*********reading finish*********");
    }
	
	
	public void readSingleFile(File file)  {
		try {
		String ocrText = scanFile(file.getAbsolutePath());
		System.out.println(ocrText);
		String licNumber = readTextLicenseNumber(file, ocrText);
		if(! licNumber.equalsIgnoreCase("NOT_FOUND"))
		 {
			moveFile(file, licNumber);
		 }
		}catch(Throwable e) {
			log.error(e.getMessage());
		}
	}

	public String readTextLicenseNumber(File file, String ocrText) throws IOException {
		String regex = "License N.*[\\d]*"; 
        Pattern pattern = Pattern.compile(regex); 
        Matcher matcher = pattern.matcher((CharSequence)ocrText);
        String scanLicenseText = "";
        boolean licFound = false;
        while(matcher.find()) {
        	scanLicenseText = scanLicenseText+ " "+matcher.group();
            log.info("Found   "+file.getPath()+" License  " + scanLicenseText);
            licFound = true;
             
        }
        String licNumber = "";
        if(licFound)
        {
        	regex = "[a-zA-z\\-]*\\d+";
            pattern = Pattern.compile(regex); 
            matcher = pattern.matcher((CharSequence)scanLicenseText);
            
            while(matcher.find()) {
           	 licNumber = licNumber+"_"+matcher.group();
            }
            if(licNumber.trim().equals("")) { //if license not readable then filename will autoincremented 
            	licNumber = "AutoNumber"+counter.getAndIncrement()+"";
            }
        }else {
        	log.info("Not Found License in  "+file.getAbsolutePath());
        	licNumber = "NOT_FOUND"; 	
        }
        return licNumber;
	}

	public void moveFile(File file, String licNumber) throws IOException {
		InputStream inStream = this.getClass()
			      .getResourceAsStream(file.getAbsolutePath());
		String extension = detectFileTypeUsingDetector(inStream);
		if(inStream != null) {inStream.close();}
		Path destination = Paths.get(destinationFolder+"\\"+file.getParentFile().getParentFile().getName()+"__"+licNumber+"."+extensionMap.get(extension));
		FileUtils.copyFile(file, destination.toFile());
	}
	
	/*
	public static void main(String [] args) throws Exception{
//		LicenseDocument licDoc = new LicenseDocument();
//		licDoc.readFiles(new LocalDate(), "month");
		
//		LocalDate date1 = new LocalDate(2024, 04, 30);
//		LocalDate date2 = new LocalDate(2024, 05, 30);
//		Period p = new Period(date1, date2);
//		System.out.println(p.getDays());
//		System.out.println(p.getWeeks());
//		System.out.println(p.getMonths());
//		System.out.println(p.getYears());
		
//		String ocrText = "License No 529934 any psy C-12345";
//		String regex = "License N.*[\\d]*"; 
//        Pattern pattern = Pattern.compile(regex); 
//        Matcher matcher = pattern.matcher((CharSequence)ocrText);
//        String licNumber = "";
//        while(matcher.find()) {
//        	licNumber = licNumber+" "+matcher.group();
//        }
//        regex = "[a-zA-z\\-]*\\d+";
//        pattern = Pattern.compile(regex); 
//        matcher = pattern.matcher((CharSequence)licNumber);
//        while(matcher.find()) {
//       	 licNumber = licNumber+" "+matcher.group();
//        }
//        if(licNumber.trim().equals("")) { //if license not readable then filename will autoincremented 
//        	licNumber = "AutoNumber";
//        }
//		System.out.println(licNumber);

		
//		String ocrText = fUtility.readFile("\\app\\backend\\uploads\\62996b56-6693-4967-b666-0af76c6097a8\\application\\0a1123ae-3b75-4cc9-af46-b3331c2ed018");
//		System.out.println(ocrText);
//		String regex = "License No.[a-zA-z\s]*[\\d]*"; 
//        Pattern pattern = Pattern.compile(regex); 
//        Matcher matcher = pattern.matcher((CharSequence)ocrText);
//        while(matcher.find()) {
//            System.out.println(" License  " + matcher.group());
//        }
	}
	*/
	
	private String scanFile( String filePath)
			throws Throwable {
		String ocrText = "";
		if(StringUtils.isEmpty(filePath) ) { return ocrText;}
		filePath = filePath.replaceAll(" ", "%20");
		File file = new File(filePath);
		try {
			InputStream inStream = LicenseDocument.class.getClassLoader()
				      .getResourceAsStream(filePath);
			
			String extension = detectFileTypeUsingDetector(inStream);
			
//			if(extension.equalsIgnoreCase("application/octet-stream")) {
			if(extensionMap.get(extension).equalsIgnoreCase("pdf")
					|| extensionMap.get(extension).equalsIgnoreCase("tiff")) {
				PDDocument document = Loader.loadPDF(file);
			    PDFRenderer pdfRenderer = new PDFRenderer(document);
			    for (int page = 0; page < document.getNumberOfPages(); ++page) {
			        BufferedImage bim = pdfRenderer.renderImageWithDPI(page, 300, ImageType.RGB);
			        ocrText = ocrText + processOCRImage(bim);
			        if(bim != null ) {bim.flush(); bim=null;}
			    }
				
			}else if(  extensionMap.get(extension).equalsIgnoreCase("doc")
					|| extensionMap.get(extension).equalsIgnoreCase("docx")) {
		        Document document = new Document();
		        document.loadFromStream(inStream, FileFormat.Auto); 
		        //set the image resolution and save to image
		        BufferedImage[] image = document.saveToImages(0, 1, com.spire.doc.documents.ImageType.Bitmap, 300, 300);
		        for (int page = 0; page < image.length; ++page) {
		        	ocrText = ocrText + processOCRImage(image[page]);
		        	if(image[page] != null) {image[page].flush(); image[page] = null;}
		        }
		        
			} else {
				BufferedImage ipimage;
				ipimage = ImageIO.read(inStream);
				ocrText = processOCRImage(ipimage);
				if(ipimage != null) {ipimage.flush(); ipimage= null;}
	
			}
			if(inStream != null) {inStream.close(); inStream=null;}
		}catch(Exception e) {System.out.println(filePath +" has error while scan document "+ e.getMessage());}
    	finally {
    		super.finalize();
    		Runtime.getRuntime().gc();
    	}
		return ocrText;
	}

	private String processOCRImage(BufferedImage ipimage) throws IOException, TesseractException {
		String ocrText = "";
		double d = ipimage.getRGB(ipimage.getTileWidth() / 2, ipimage.getTileHeight() / 2); 

    	if (d >= -1.4211511E7 && d < -7254228) { 
    		ocrText = processImg(ipimage, 3f, -10f); 
        } 
        else if (d >= -7254228 && d < -2171170) { 
        	ocrText = processImg(ipimage, 1.455f, -47f); 
        } else if (d >= -2171170 && d < -1907998) { 
        	ocrText = processImg(ipimage, 1.35f, -10f); 
        } 
        else if (d >= -1907998 && d < -257) { 
        	ocrText = processImg(ipimage, 1.19f, 0.5f); 
        } 
        else if (d >= -257 && d < -1) { 
        	ocrText = processImg(ipimage, 1f, 0.5f); 
        } 
        else if (d >= -1 && d < 2) { 
        	ocrText = processImg(ipimage, 1f, 0.35f); 
        } 
    	
    	return ocrText;
	}
    
    public String processImg(BufferedImage ipimage, 
               float scaleFactor, 
               float offset) 
        throws IOException, TesseractException 
    { 
        BufferedImage opimage = new BufferedImage(1050, 1024, ipimage.getType());
        
        Graphics2D graphic = opimage.createGraphics(); 
  
        graphic.drawImage(ipimage, 0, 0, 1050, 1024, null); 
        graphic.dispose(); 
  
        // rescale OP object for gray scaling images 
        RescaleOp rescale = new RescaleOp(scaleFactor, offset, null); 
        BufferedImage fopimage = rescale.filter(opimage, null); 
        Tesseract it = new Tesseract(); 
  
        it.setDatapath(trainedData);
        
        it.setLanguage(tess4jLang);
        String str = it.doOCR(fopimage); 
        if(fopimage != null ) {fopimage.flush(); fopimage=null; }
        return str;
    }

	
    
    public void initiateProcess(LocalDate targetDate, String fileSelectionBasisOf) throws IOException {
        try (Stream<Path> paths = Files.walk(Paths.get(sourceFolder))) {
            List<File> fileList = paths
            		.filter(Files::isRegularFile)
            		.map(path -> path.toFile())
            		.filter(file -> filterFilesByDate(file, targetDate, fileSelectionBasisOf))
                    .sorted(Comparator.comparingLong(File::lastModified).reversed())
                                        .collect(Collectors.toList());
            
            
            ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
            List<ScanCallableTask> tasks = new ArrayList<>();
            for (int i = 0; i < fileList.size(); i += batchSize) {
                int endIndex = Math.min(i + batchSize, fileList.size());
                List<File> batch = fileList.subList(i, endIndex);
//                List<File> filterFileList = filterFilesByDate(batch, targetDate);
//                tasks.add(new ScanCallableTask(filterFileList));
//                filterFileList.forEach(taskfile -> tasks .add(() -> {readSingleFile(taskfile); return taskfile;}));
                tasks.add(new ScanCallableTask(batch));
            }
            List<Future<List<File>>> results = executor.invokeAll(tasks);
            executor.shutdown();
            for (Future<List<File>> result : results) {
                try {
                	for(File file : result.get()) {
//                    File file = result.get();
                    if (file != null) {
                    	log.info("get() file "+file.getAbsolutePath() + " Last "+new LocalDateTime(file.lastModified()) );
                    }
                }
                } catch (Throwable e) {
                	log.error(e.getMessage());
                }
            }
            log.info("*********reading finish*********");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
/*
	private List<File> filterFilesByDate(List<File> files, LocalDate targetDate) {
		List <File> list = new ArrayList<>();
        for (File file : files) {
            try {
//                BasicFileAttributes attr = Files.readAttributes(file, BasicFileAttributes.class);
                LocalDateTime fileLastmodifiedTime = new LocalDateTime(file.lastModified());
                
                if (fileLastmodifiedTime.getMonthOfYear() == targetDate.getMonthOfYear() && fileLastmodifiedTime.getYear() == targetDate.getYear()) {
                	System.out.println("File Last Date "+fileLastmodifiedTime+" Filter Date "+targetDate);
                    log.info("File Last Date "+fileLastmodifiedTime+" Filter Date "+targetDate);
                    
                	list.add(file);
//                	return file;
                }
            } catch (Throwable e) {
            	log.error(e.getMessage());
            }
        }
        return list;
    }
    */
	
	private boolean filterFilesByDate(File file, LocalDate targetDate, String fileSelectionBasisOf) {
            try {
//                BasicFileAttributes attr = Files.readAttributes(file, BasicFileAttributes.class);
                LocalDateTime fileLastmodifiedTime = new LocalDateTime(file.lastModified());
                
                if (fileSelectionBasisOf.equalsIgnoreCase("day") && fileLastmodifiedTime.getDayOfMonth() == targetDate.getDayOfMonth() && fileLastmodifiedTime.getMonthOfYear() == targetDate.getMonthOfYear() && fileLastmodifiedTime.getYear() == targetDate.getYear()) {
                	System.out.println("File Last Date "+fileLastmodifiedTime+" Filter Date "+targetDate);
                    log.info(fileSelectionBasisOf+" File Last Date "+fileLastmodifiedTime+" Filter Date "+targetDate);
                	return true;
                }
                else if (fileSelectionBasisOf.equalsIgnoreCase("month") && fileLastmodifiedTime.getMonthOfYear() == targetDate.getMonthOfYear() && fileLastmodifiedTime.getYear() == targetDate.getYear()) {
                	System.out.println("File Last Date "+fileLastmodifiedTime+" Filter Date "+targetDate);
                    log.info(fileSelectionBasisOf+" File Last Date "+fileLastmodifiedTime+" Filter Date "+targetDate);
                	return true;
                }else if (fileSelectionBasisOf.equalsIgnoreCase("year") && fileLastmodifiedTime.getYear() == targetDate.getYear()) {
                	System.out.println("File Last Date "+fileLastmodifiedTime+" Filter Date "+targetDate);
                    log.info(fileSelectionBasisOf+" File Last Date "+fileLastmodifiedTime+" Filter Date "+targetDate);
                	return true;
                }

            } catch (Throwable e) {
            	log.error(e.getMessage());
            }
            return false;
        }
    

	
	class ScanCallableTask implements Callable<List<File>> 
	{
	  private List<File> fileList;
	  
	  public ScanCallableTask(List<File> fileList) {
	    this.fileList = fileList;
	  }
	 
	  @Override
	  public List<File> call() throws Exception 
	  {
	    try {
	    	fileList.forEach(taskfile -> readSingleFile(taskfile)); 
	    } catch (Exception e) {
	      e.printStackTrace();
	    }
	    return fileList;
	  }
	}
	
}
