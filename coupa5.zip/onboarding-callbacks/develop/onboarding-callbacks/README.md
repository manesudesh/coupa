# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.2.4.RELEASE/maven-plugin/)

### Onboarding a new acquirer:-
You need to change in the following files:-
* Acquirer.java (add new key code)
* MongoInitialSetup.java (add new script for non-production environments to make testing easy)
* In production, create a new callbackconfiguration document in "CallbackConfiguration" collection, either through a database change or through the admin APIs

#### Example
