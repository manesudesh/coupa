package ae.network.onboarding.onboardingcallbacks.model.database;


/**
 * @author Yousry
 * @version 1.0
 */
public enum IntegrationType {
    HTTP, SMS, EMAIL;
}
