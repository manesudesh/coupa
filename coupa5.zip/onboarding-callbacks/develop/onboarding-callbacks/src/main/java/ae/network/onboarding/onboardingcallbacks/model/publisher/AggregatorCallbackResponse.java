package ae.network.onboarding.onboardingcallbacks.model.publisher;

import ae.network.onboarding.onboardingcallbacks.common.StringTemplateHelper;
import ae.network.onboarding.onboardingcallbacks.model.AggregatorCallbackMessage;
import ae.network.onboarding.onboardingcallbacks.model.ProcessingResult;
import ae.network.onboarding.onboardingcallbacks.model.RequestStatus;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import static ae.network.onboarding.onboardingcallbacks.common.DateFormat.SIMPLE_FORMAT;

@Data
@ToString
@Slf4j
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AggregatorCallbackResponse {

    private String acquirer;
    private String applicationId;
    private String requestId;
    private String requestType;
    private String requestStatus;
    private String lastUpdate;
    private String errorMessages;
    private Map<String, ProcessingResult> resultsMap = new HashMap<>();

    public AggregatorCallbackResponse(AggregatorCallbackMessage aggregatorCallbackMessage) {
        this.setAggregatorCallbackResponse(aggregatorCallbackMessage);
    }

    private void setAggregatorCallbackResponse(AggregatorCallbackMessage aggregatorCallbackMessage) {
        log.info("Mapping AggregatorCallbackMessage to AggregatorCallbackResponse {}", aggregatorCallbackMessage);

        this.requestId = aggregatorCallbackMessage.getRequestId();
        this.applicationId = aggregatorCallbackMessage.getApplicationId();
        this.requestStatus = aggregatorCallbackMessage.getRequestStatus().toString();
        this.requestType = aggregatorCallbackMessage.getRequestType();
        this.resultsMap = aggregatorCallbackMessage.getResultsMap();

        // override status if any backend system fails (partially completed case)
        if (aggregatorCallbackMessage.getResultsMap().values().stream()
                .anyMatch(res -> res.getFinalStatus().isErrorStatus())) {
            this.requestStatus = RequestStatus.FAILED.toString();
        }

        if (aggregatorCallbackMessage.getLastModifiedDate() != null) {
            this.lastUpdate = new SimpleDateFormat(SIMPLE_FORMAT).format(aggregatorCallbackMessage.getLastModifiedDate());
        }

        if (!CollectionUtils.isEmpty(aggregatorCallbackMessage.getResultsMap()) &&
                aggregatorCallbackMessage.getRequestStatus() != RequestStatus.COMPLETED ) {
            StringTemplateHelper stringTemplateHelper = new StringTemplateHelper();
            this.errorMessages = stringTemplateHelper.getErrorMessagesForBackendSystems(aggregatorCallbackMessage.getResultsMap());
            log.error("##### errorMessages = " + errorMessages + " .....>> applicationId=" + this.applicationId);
        }

        log.info("Mapping completed {}", this);
    }
}
