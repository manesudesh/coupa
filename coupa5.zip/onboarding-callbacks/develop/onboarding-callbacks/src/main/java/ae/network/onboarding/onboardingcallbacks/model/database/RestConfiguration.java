package ae.network.onboarding.onboardingcallbacks.model.database;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;

/**
 * @author Success.Otto
 * @since 15/03/2020
 */
@Data
@Slf4j
public class RestConfiguration extends IntegrationConfiguration {

    /**
     * AuthenticationRequired for integration with services
     */
    private boolean isAuthenticationRequired;
    /**
     * If Authentication is required, username is required
     */
    private String username;
    /**
     * If Authentication is required, password is required
     */
    private String password;
    /**
     * Oauth2 client id
     */
    private String clientId;
    /**
     * Oauth2 client secret
     */
    private String clientSecret;
    /**
     * Oauth2 grant type
     */
    private String grantType;
    /**
     * Oauth2 access token Url
     */
    private String accessTokenUri;
    /**
     * HttpMethod of the server endpoint
     */
    private HttpMethod httpMethod;
    /**
     * End point of the acquirer's server
     */
    private String url;
}
