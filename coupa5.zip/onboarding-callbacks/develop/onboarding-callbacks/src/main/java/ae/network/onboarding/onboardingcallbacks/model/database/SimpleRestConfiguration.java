package ae.network.onboarding.onboardingcallbacks.model.database;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;

/**
 * @author Success.Otto
 * @since 15/03/2020
 */
@Slf4j
public class SimpleRestConfiguration extends RestConfiguration {
    public SimpleRestConfiguration(String url) {
        this.setAuthenticationRequired(false);
        this.setHttpMethod(HttpMethod.POST);
        this.setUrl(url);
    }
}
