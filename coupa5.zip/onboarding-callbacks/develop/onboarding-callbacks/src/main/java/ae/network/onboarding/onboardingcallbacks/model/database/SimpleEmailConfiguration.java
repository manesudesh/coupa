package ae.network.onboarding.onboardingcallbacks.model.database;

import lombok.extern.slf4j.Slf4j;

import java.util.Collections;

/**
 * @author Success.Otto
 * @since 25/03/2020
 */
@Slf4j
public class SimpleEmailConfiguration extends EmailConfiguration {
    public SimpleEmailConfiguration(String from, String to) {
        super(from, Collections.singletonList(to), null, null, "Application Update");
    }
}
