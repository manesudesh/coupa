package ae.network.onboarding.onboardingcallbacks.model.mintoak;

import lombok.Data;

@Data
public class ApplicationStatusResponse {
    private String status;
    private String respMessage;
    private String statusCode;

}
