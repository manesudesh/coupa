package ae.network.onboarding.onboardingcallbacks.model.mintoak;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

import java.util.List;

@SuperBuilder
@Data
@EqualsAndHashCode(callSuper = true)
public class PosStatusInfoResponse extends ProductStatus {
    private String deliveryDate;
    private List<TerminalStatus> subStatuses;

}
