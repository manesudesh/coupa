package ae.network.onboarding.onboardingcallbacks.model;

import ae.network.onboarding.onboardingcallbacks.exception.MessageRejectionException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class CallbackFactory {

    private static final String ERROR_MESSAGE = "Invalid JSON content";
    private static final String NOQODI_PARAM = "NOQODI";
    private static final String MINTOAK_APP = "mintoak";

    public CommonCallbackMessage createCallbackFromMessage(Message message) {
        CommonCallbackMessage commonCallbackMessage;
        try {
            String messageContent = new String(message.getBody());
            commonCallbackMessage = new ObjectMapper().readValue(messageContent, CommonCallbackMessage.class);
        } catch (JsonProcessingException e) {
            throw new MessageRejectionException(ERROR_MESSAGE, e);
        }

        String acquirer = commonCallbackMessage.getAcquirer();

        if (NOQODI_PARAM.equals(acquirer)) {
            return mapMessageToAggregatorCallback(message);
        } else if (MINTOAK_APP.equals(acquirer)) {
            return mapMessageToMintOakMessage(message);
        } else {
            return mapMessageToSalesforceCallback(message);
        }
    }

    private MintOakCallbackMessage mapMessageToMintOakMessage(Message message) {
        log.debug("Mapping message object to mintOakCallbackMessage ");
        MintOakCallbackMessage mintOakCallbackMessage;
        mintOakCallbackMessage = convertMessageToObject(message, MintOakCallbackMessage.class);
        log.info("Mapped mintOakCallbackMessage {}", mintOakCallbackMessage);
        return mintOakCallbackMessage;
    }

    private static <T> T convertMessageToObject(Message message, Class<T> clazz) {
        T mintOakCallbackMessage;
        try {
            String messageContent = new String(message.getBody());
            log.info("messageContent {}", messageContent);
            mintOakCallbackMessage = new ObjectMapper().readValue(messageContent, clazz);
        } catch (JsonProcessingException e) {
            log.error(ERROR_MESSAGE, e);
            throw new MessageRejectionException(ERROR_MESSAGE, e);
        }
        return mintOakCallbackMessage;
    }

    private SalesforceCallbackMessage mapMessageToSalesforceCallback(Message message) {
        log.debug("Mapping message object to salesforceCallbackMessage ");
        SalesforceCallbackMessage salesforceCallbackMessage = convertMessageToObject(message, SalesforceCallbackMessage.class);
        log.info("Mapped callbackMessage {}", salesforceCallbackMessage);
        return salesforceCallbackMessage;
    }

    private AggregatorCallbackMessage mapMessageToAggregatorCallback(Message message) {
        log.debug("Mapping message object to aggregatorCallbackMessage ");
        AggregatorCallbackMessage aggregatorCallbackMessage = convertMessageToObject(message, AggregatorCallbackMessage.class);
        log.info("Mapped aggregatorCallbackMessage {}", aggregatorCallbackMessage);
        return aggregatorCallbackMessage;
    }
}
