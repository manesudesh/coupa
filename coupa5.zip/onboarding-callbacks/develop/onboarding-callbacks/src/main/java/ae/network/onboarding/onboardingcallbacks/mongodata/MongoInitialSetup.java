package ae.network.onboarding.onboardingcallbacks.mongodata;

import ae.network.onboarding.onboardingcallbacks.model.database.*;
import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpMethod;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Creating mongodb initial data
 *
 * @author walid.sewaify
 * @since 12-02-2020
 */
@ChangeLog(order = "001")
@Slf4j
public class MongoInitialSetup {

    @ChangeSet(order = "01", author = "callbacks", id = "01-createDefaultConfiguration", runAlways = false)
    public void createDefaultAdminUser(MongoTemplate mongoTemplate) {
        CallbackConfiguration niConfig = createConfig("NI");
        mongoTemplate.save(niConfig);
    }

    private CallbackConfiguration createConfig(String acquirer) {
        RestConfiguration restConfig = new RestConfiguration();
        restConfig.setHttpMethod(HttpMethod.POST);
        restConfig.setAuthenticationRequired(true);
        restConfig.setUrl("https://network-international--devlopenv.my.salesforce.com/services/apexrest/boardingStatusCallback");
        restConfig.setAccessTokenUri("https://test.salesforce.com/services/oauth2/token");
        restConfig.setClientId("3MVG9Lf04EwncL7mOf8fdrWEYGYvshilWIx8VBOBJicyJ2Sxqe.Dmt.h1n9kSj3wgmTAQYCujdkfrwRWnLT.O");
        restConfig.setClientSecret("E9F42A8ADA204021394057643F51E59D4E9150A1D849D782A82558E0D4296FCD");
        restConfig.setGrantType("password");
        restConfig.setUsername("intuser@nwi.com.devlopenv");
        restConfig.setPassword("NI@12345wS1TiH34HZMSCglLJmwQ81xd");

        EmailConfiguration emailConfiguration = new EmailConfiguration();
        emailConfiguration.setSubject("Application Update");
        emailConfiguration.setFrom("onboarding@network.ae");
        emailConfiguration.setTo(Collections.emptyList());

        Map<IntegrationType, IntegrationConfiguration> map = new HashMap<>();
        map.put(IntegrationType.HTTP, restConfig);
        map.put(IntegrationType.EMAIL, emailConfiguration);

        return CallbackConfiguration.builder().acquirer(acquirer).configurationMap(map).build();
    }

    @ChangeSet(order = "02", author = "callbacks", id = "02-paytabs-webhook", runAlways = false)
    public void paytabsConfig(MongoTemplate mongoTemplate) {
        RestConfiguration restConfig = new RestConfiguration();
        restConfig.setHttpMethod(HttpMethod.POST);
        restConfig.setUrl("https://plugins.paytabs.com/screening/api/ni/webhook");
        restConfig.setAuthenticationRequired(false);

        Map<IntegrationType, IntegrationConfiguration> map = new HashMap<>();
        map.put(IntegrationType.HTTP, restConfig);

        CallbackConfiguration callbackConfiguration = CallbackConfiguration.builder().acquirer("PAYTABS").configurationMap(map).build();
        mongoTemplate.save(callbackConfiguration);

    }
}