package ae.network.onboarding.onboardingcallbacks.rabbitmq.config;

import java.util.Arrays;
import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
public enum RabbitQueue {
    // Working Queues
    NOTIFICATIONS("notifications", "routing.notifications"),
    // RPC Queues
    UTILS("utils", "routing.utils");

    private final String queueName;
    private final String[] routingKeys;

    RabbitQueue(String queueName, String... routingKeys) {
        this.queueName = queueName;
        this.routingKeys = routingKeys;
    }

    public String getQueueName() {
        return queueName;
    }

    public List<String> getRoutingKeys() {
        return Arrays.asList(routingKeys);
    }
}