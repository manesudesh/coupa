package ae.network.onboarding.onboardingcallbacks.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author walid.sewaify
 * @since 2020-05-14
 */
@Data
public class Attachment implements Serializable {
    private String fileName;

    private String contentType;

    private byte[] content;
}
