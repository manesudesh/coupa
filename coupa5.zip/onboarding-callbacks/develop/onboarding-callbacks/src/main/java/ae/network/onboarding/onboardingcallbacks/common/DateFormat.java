package ae.network.onboarding.onboardingcallbacks.common;

/**
 * @author walid.sewaify
 * @since 2020-01-26
 */
public interface DateFormat {
    String FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
    String SIMPLE_FORMAT = "yyyy-MM-dd HH:mm:ss";
}
