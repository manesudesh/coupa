package ae.network.onboarding.onboardingcallbacks.exception;

public class MintoakEncryptorException extends Exception {

    public MintoakEncryptorException(Throwable cause) {
        super("Mintoak Encryptor Exception",cause);
    }
}
