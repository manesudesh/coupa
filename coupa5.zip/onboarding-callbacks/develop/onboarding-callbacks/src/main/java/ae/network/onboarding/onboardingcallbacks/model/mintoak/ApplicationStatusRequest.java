package ae.network.onboarding.onboardingcallbacks.model.mintoak;

import ae.network.onboarding.onboardingcallbacks.model.TaskStatus;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class ApplicationStatusRequest {
    private String requestId;
    private TaskStatus status;
    private SalesforceStatusResponse salesForceStatus;
    private PosStatusInfoResponse posStatus;
    private EcommStatusInfo ecommStatus;
    private SoftPosStatus softPosStatus;
}
