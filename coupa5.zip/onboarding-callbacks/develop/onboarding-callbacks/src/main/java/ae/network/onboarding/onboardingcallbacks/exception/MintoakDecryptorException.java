package ae.network.onboarding.onboardingcallbacks.exception;

public class MintoakDecryptorException extends Exception {

    public MintoakDecryptorException(Throwable cause) {
        super("Mintoak Decryptor Exception", cause);
    }
}
