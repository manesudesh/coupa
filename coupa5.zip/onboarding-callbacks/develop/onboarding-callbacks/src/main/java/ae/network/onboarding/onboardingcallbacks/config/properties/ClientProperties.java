package ae.network.onboarding.onboardingcallbacks.config.properties;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ClientProperties {
    private String baseUrl;
}
