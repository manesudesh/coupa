package ae.network.onboarding.onboardingcallbacks.model;

import ae.network.onboarding.onboardingcallbacks.model.database.IntegrationConfiguration;
import ae.network.onboarding.onboardingcallbacks.service.integration.AggregatorRestService;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
public class AggregatorCallbackMessage extends CommonCallbackMessage {

    /**
     * Partner acquirer
     */
    private String acquirer;
    /**
     * unique global id
     */
    private String applicationId;
    /**
     * acquirer request id (unique across each acquirer)
     */
    private String requestId;
    /**
     * Request type
     */
    private String requestType;
    /**
     * Application status
     */
    private RequestStatus requestStatus;
    /**
     * List of tasks
     */
    @Builder.Default
    private Map<String, ProcessingResult> resultsMap = new HashMap<>();

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private Date lastModifiedDate;

    /**
     * Screening result
     */
    private String screeningResult;

    @Override
    public void sendRest(IntegrationConfiguration configuration) {
        AggregatorRestService aggregatorRestService = new AggregatorRestService();
        aggregatorRestService.aggregatorWebClientSend(this, configuration);
    }
}
