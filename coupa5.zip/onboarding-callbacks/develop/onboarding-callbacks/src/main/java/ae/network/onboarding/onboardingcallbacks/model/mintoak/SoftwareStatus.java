package ae.network.onboarding.onboardingcallbacks.model.mintoak;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

import java.util.List;

@SuperBuilder
@Data
@EqualsAndHashCode(callSuper = true)
public class SoftwareStatus extends ProductStatus {
    private String completionDate;
    private List<TerminalStatus> subStatuses;
}
