package ae.network.onboarding.onboardingcallbacks.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationPayload implements Serializable {
    private List<Merchant> merchants;

}
