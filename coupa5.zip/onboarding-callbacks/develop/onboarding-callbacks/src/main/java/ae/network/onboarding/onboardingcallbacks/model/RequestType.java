package ae.network.onboarding.onboardingcallbacks.model;

public enum RequestType {
    ONBOARDING, AMENDMENT, MERCHANT_CLOSURE, TERMINAL_CLOSURE, SCREENING, 
    PAYOUT_ONBOARDING, PAYOUT_AMENDMENT
}
