package ae.network.onboarding.onboardingcallbacks.model;

import com.fasterxml.jackson.annotation.*;
import com.mongodb.DBObject;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.*;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Document("applications")
public class ApplicationRequest {
    @Id
    @EqualsAndHashCode.Include
    private String id;

    @Version
    private Integer version;
    /**
     * Partner acquirer
     */
    private String acquirer;
    /**
     * Skip callback
     */
    private boolean skipCallback;
    /**
     * Request type (Create-update-close)
     */
    private RequestType requestType;
    /**
     * Default is API
     */
    private Source source;
    /**
     * Application status
     */
    private RequestStatus requestStatus;
    /**
     * unique global id
     */
    private String applicationId;
    /**
     * acquirer request id (unique across each acquirer)
     */
    private String requestId;
    /**
     * application content
     */
    private DBObject payload;
    /**
     * List of tasks
     */
    private Map<BackendSystem, ProcessingResult> resultsMap = new HashMap<>();
    /**
     * List of attachments
     */
    private Map<BackendSystem, Attachment> attachmentsMap = new HashMap<>();
    /**
     * List of attachments
     */
    private Map<BackendSystem, Collection<ScreeningResult>> screeningMap = new HashMap<>();
    /**
     * List of Additional Data received from backend systems
     */
    private Map<String, AdditionalData> additionalDataMap = new HashMap<>();
    /**
     * User who created the application
     */
    private String username;
    /**
     * Ip of the application sender
     */
    private String ip;
    /**
     * Callback url
     */
    private String callbackUrl;
    /**
     * Callback email
     */
    private String callbackEmail;
    /**
     * List of authorized Onboarding systems.
     */
    private List<BackendSystem> authorizedSystems;

    /**
     * history of application id (in case the application reposted for error corrections)
     */
    private List<String> otherIds = new ArrayList<>();

    /**
     * URL for displaying screening result
     */
    private String screeningResult;

    /**
     * Dry run request (not backend changes are done)
     */
    private boolean dryRun;

    /**
     * enable retry for an existing request
     */
    private boolean retry;

    /**
     * payload version
     */
    private String payloadVersion;

    public enum BackendSystem {
        // stage one (has no dependencies)
        D2C(RabbitQueue.D2C),WAY4(RabbitQueue.WAY4), BASE24(RabbitQueue.BASE24), MATCH(RabbitQueue.MATCH), FISERV(RabbitQueue.FISERV), TRUSTWAVE(RabbitQueue.TRUSTWAVE),
        // stage two (dependent on stage one system)
        NGO(RabbitQueue.NGO), NGT(RabbitQueue.NGT), MCSEC(RabbitQueue.MCSEC), PP(RabbitQueue.PP), MCP(RabbitQueue.MCP),
        FXCO(RabbitQueue.FXCO), POSINV(RabbitQueue.POSINV), SS(RabbitQueue.SS), TEST(RabbitQueue.TEST),
        ALIPAY(RabbitQueue.ALIPAY), QRPAY(RabbitQueue.QRPAY), WECHAT(RabbitQueue.WECHAT), G2(RabbitQueue.G2),
        LOYALTY(RabbitQueue.LOYALTY), VERIFONE(RabbitQueue.VERIFONE), SOFTPOS(RabbitQueue.SOFTPOS),_3ds2(RabbitQueue._3ds2),MPGS(RabbitQueue.MPGS),SOFTPOS_MOSAMBEE(RabbitQueue.SOFTPOS_MOSAMBEE),AMLOCK(RabbitQueue.AMLOCK),
        VISA(RabbitQueue.VISA), POS(RabbitQueue.POS),
        PAYOUT(RabbitQueue.PAYOUT);

        private final RabbitQueue rabbitQueue;

        BackendSystem(RabbitQueue rabbitQueue) {
            this.rabbitQueue = rabbitQueue;
        }
    }

    private enum RabbitQueue {
        // Backend Queues
        D2C("d2c", "routing.backend.d2c"),
        WAY4("way4", "routing.backend.way4"),
        BASE24("base24", "routing.backend.base24"),
        NGO("ngo", "routing.backend.ngo"),
        NGT("ngt", "routing.backend.ngt"),
        MCSEC("mcsec", "routing.backend.mcsec"),
        PP("pp", "routing.backend.pp"),
        MCP("mcp", "routing.backend.mcp"),
        FXCO("fxco", "routing.backend.fxco"),
        POSINV("posinv", "routing.backend.posinv"),
        SS("ss", "routing.backend.ss"),
        ALIPAY("alipay", "routing.backend.alipay"),
        QRPAY("qrpay", "routing.backend.qrpay"),
        WECHAT("wechat", "routing.backend.wechat"),
        G2("g2", "routing.backend.g2"),
        LOYALTY("loyalty", "routing.backend.loyalty"),
        VERIFONE("verifone", "routing.backend.verifone"),
        SOFTPOS("softpos", "routing.backend.softpos"),
        _3ds2("3ds2.0", "routing.backend.3ds2.0"),
        AMLOCK("amlock","routing.backend.amlock"),
        MPGS("mpgs", "routing.backend.mpgs"),
        SOFTPOS_MOSAMBEE("softpos_mosambee", "routing.backend.softpos_mosambee"),
        // Screening Queues
        MATCH("mcmatch", "routing.backend.mcmatch"),
        FISERV("fiserv", "routing.backend.fiserv"),
        VISA("visa", "routing.backend.visa"),
        TRUSTWAVE("trustwave", "routing.backend.trustwave"),
        PAYOUT("payout", "routing.backend.payout"),
        // processing queues
        UPDATES("updates", "routing.updates"),
        NOTIFICATIONS("notifications", "routing.notifications"),
        // RPC Queues
        UTILS("utils", "routing.utils"),
        // Testing Queues
        TEST("test", "routing.backend.test"),
        // Failure Queues
        FAILS("failures"),
        POS("pos");

        private final String queueName;
        private final String[] routingKeys;

        RabbitQueue(String queueName, String... routingKeys) {
            this.queueName = queueName;
            this.routingKeys = routingKeys;
        }
    }

    private enum Source {
        API
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    private static class ScreeningResult {
        @NonNull
        private String entityId;
        @NonNull
        private String result;
        private String matchedMerchants;
        private String downloadReport;
    }
}
