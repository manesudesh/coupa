package ae.network.onboarding.onboardingcallbacks.repository;

import ae.network.onboarding.onboardingcallbacks.model.database.CallbackConfiguration;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

/**
 * @author Yousry
 * @version 1.0
 */
public interface CallbackRepository extends MongoRepository<CallbackConfiguration, String> {
    /**
     * find the first document by acquirer id.
     *
     * @return acquirer callback configuration document
     */
    Optional<CallbackConfiguration> findFirstByAcquirer(String acquirer);
}