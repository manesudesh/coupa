package ae.network.onboarding.onboardingcallbacks.model.publisher;

import static ae.network.onboarding.onboardingcallbacks.common.DateFormat.SIMPLE_FORMAT;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

import ae.network.onboarding.onboardingcallbacks.common.StringTemplateHelper;
import ae.network.onboarding.onboardingcallbacks.model.AdditionalData;
import ae.network.onboarding.onboardingcallbacks.model.RequestStatus;
import ae.network.onboarding.onboardingcallbacks.model.SalesforceCallbackMessage;
import ae.network.onboarding.onboardingcallbacks.model.RequestStatus;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static ae.network.onboarding.onboardingcallbacks.common.DateFormat.SIMPLE_FORMAT;

/**
 * @author Yousry
 * @author Success.Otto
 * @version 1.0
 */
@Data
@ToString(includeFieldNames = true)
@Slf4j
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SalesforceCallbackResponse {

    private static final String Acquirer_NI = "NI";
    private String requestId;
    private String applicationId;
    private String requestStatus;
    private String lastUpdate;
    private String screeningResult;

    /**
     * List of Additional Data received from backend systems
     */
    private Map<String, SFAdditionalData> additionalDataMap = new HashMap<>();

    private String errorMessages;

    public SalesforceCallbackResponse(SalesforceCallbackMessage salesforceCallbackMessage) {
        this.setCallbackResponse(salesforceCallbackMessage);
    }

    /**
     * Maps CallbackMessage to CallbackResponse object
     */
    private void setCallbackResponse(SalesforceCallbackMessage salesforceCallbackMessage) {
        log.info("Mapping CallbackMessage to CallbackResponse {}", salesforceCallbackMessage);

        this.requestId = salesforceCallbackMessage.getRequestId();
        this.applicationId = salesforceCallbackMessage.getApplicationId();
        this.requestStatus = salesforceCallbackMessage.getRequestStatus().toString();
        
        // override status if any backend system fails (partially completed case)
        if (salesforceCallbackMessage.getResultsMap().values().stream().anyMatch(res -> res.getFinalStatus().isErrorStatus())) {
            this.requestStatus = RequestStatus.FAILED.toString();
        }
        if (salesforceCallbackMessage.getLastModifiedDate() != null) {
            this.lastUpdate = new SimpleDateFormat(SIMPLE_FORMAT).format(salesforceCallbackMessage.getLastModifiedDate());
        }
        if (salesforceCallbackMessage.getRequestStatus() == RequestStatus.COMPLETED && salesforceCallbackMessage.getScreeningResult() != null) {
            screeningResult = salesforceCallbackMessage.getScreeningResult();
        }

        if (salesforceCallbackMessage.getResultsMap() != null && salesforceCallbackMessage.getResultsMap().size() > 0 &&
                salesforceCallbackMessage.getRequestStatus() != RequestStatus.COMPLETED ) {
            StringTemplateHelper stringTemplateHelper = new StringTemplateHelper();
            this.errorMessages = stringTemplateHelper.getErrorMessagesForBackendSystems(salesforceCallbackMessage.getResultsMap());
            log.error("##### errorMessages = " + errorMessages + " .....>> applicationId=" + this.applicationId);
        }

        if ((!salesforceCallbackMessage.getRequestType().equals("SCREENING")) && salesforceCallbackMessage.getAdditionalDataMap() != null
                && salesforceCallbackMessage.getAdditionalDataMap().size() > 0) {
        	
        	Map<String, AdditionalData>  requestAdditionMap = salesforceCallbackMessage.getAdditionalDataMap();
        	
        	log.info("Request Additional data :{}",requestAdditionMap);
            
            Object[] keys = requestAdditionMap.keySet().toArray();
           
            log.info("Key Set :{}",keys);
            
            for(Object key:keys) {
            	
            	if(requestAdditionMap.get(key)==null) {
            		requestAdditionMap.remove(key);
            	}else {
            		AdditionalData additionalData = requestAdditionMap.get(key);
            		log.info("Key {}, value {}",key,additionalData.getDataMap());
            		if(additionalData.getDataMap()==null || additionalData.getDataMap().isEmpty()) {
            			requestAdditionMap.remove(key);
            		}
            	}
            }
            
            log.info("additional Data map after cleaning : {}",requestAdditionMap);
            
            if(requestAdditionMap.isEmpty()||requestAdditionMap.keySet().size()==0) {
            	this.additionalDataMap = null;
            }else {
            	
            	this.additionalDataMap = new HashMap<String, SalesforceCallbackResponse.SFAdditionalData>();
            	for(String key: requestAdditionMap.keySet()) {
            		this.additionalDataMap.put(key, cloneRequestDataMap(requestAdditionMap.get(key)));
            	}
            }
        }else {
        	this.additionalDataMap=null;
        }

        log.info("Mapping completed {}", this);
    }
    
    private SalesforceCallbackResponse.SFAdditionalData cloneRequestDataMap(AdditionalData additionalData) {
    	SalesforceCallbackResponse.SFAdditionalData sfAdditionalData = new SalesforceCallbackResponse.SFAdditionalData();
    	sfAdditionalData.setDataMap(additionalData.getDataMap());
		return sfAdditionalData;
	}

	@Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class SFAdditionalData{
    	 private Map<String, Object> dataMap;
    }
    
}
