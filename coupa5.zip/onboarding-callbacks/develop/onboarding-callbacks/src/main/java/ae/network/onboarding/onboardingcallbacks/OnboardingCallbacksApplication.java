package ae.network.onboarding.onboardingcallbacks;

import io.micrometer.core.aop.TimedAspect;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * @author Success.Otto
 * @author Walid
 * @since 25/03/2020
 */
@EnableFeignClients
@SpringBootApplication
@EnableAsync(proxyTargetClass = true)
public class OnboardingCallbacksApplication {

    /**
     * Runs onboarding callbacks through commandline runner
     */
    public static void main(String[] args) {
        SpringApplication.run(OnboardingCallbacksApplication.class, args);
    }

    /* io.micrometer.core.aop.TimedAspect
    org.springframework.context.annotation.Bean
   io.micrometer.core.instrument.MeterRegistry */
    @Bean
    public TimedAspect timedAspect(MeterRegistry registry) {
        return new TimedAspect(registry);
    }
}
