package ae.network.onboarding.onboardingcallbacks.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
public class AggregatorAccessToken {
    @JsonProperty("access_token")
    private String accessToken;
}
