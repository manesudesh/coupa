package ae.network.onboarding.onboardingcallbacks.model.database;

/**
 * @author Success.Otto
 * @since 15/03/2020
 */
public class IntegrationConfiguration {
}
