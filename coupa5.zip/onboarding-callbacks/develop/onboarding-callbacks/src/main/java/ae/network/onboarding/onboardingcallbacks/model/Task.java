package ae.network.onboarding.onboardingcallbacks.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collection;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Task {
    private Long id;
    private String name;
    private String entityId;
    private TaskStatus taskStatus;
    private Collection<TaskHistory> taskHistory;
}