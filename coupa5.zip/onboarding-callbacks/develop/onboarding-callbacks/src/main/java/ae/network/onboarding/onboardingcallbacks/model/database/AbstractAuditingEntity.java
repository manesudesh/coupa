package ae.network.onboarding.onboardingcallbacks.model.database;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

import static ae.network.onboarding.onboardingcallbacks.common.DateFormat.FORMAT;

/**
 * Base abstract class for entities which will hold definitions for created, last modified by and created,
 * last modified by date.
 *
 * @author walid.sewaify
 * @since 18-01-2020
 */
@Data
public abstract class AbstractAuditingEntity implements Serializable {

    @CreatedDate
    @JsonFormat(pattern = FORMAT)
    @DateTimeFormat(pattern = FORMAT)
    private Date createdDate = new Date();

    @LastModifiedDate
    @JsonFormat(pattern = FORMAT)
    @DateTimeFormat(pattern = FORMAT)
    private Date lastModifiedDate = new Date();
}