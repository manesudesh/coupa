package ae.network.onboarding.onboardingcallbacks.model;


import java.util.Arrays;
import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
public enum TaskStatus {
    COMPLETED, PARTIALLY_COMPLETED, FAILED, CANCELLED;

    private static final List<TaskStatus> errorStatues = Arrays.asList(FAILED, PARTIALLY_COMPLETED);

    public boolean isErrorStatus() {
        return errorStatues.contains(this);
    }

}