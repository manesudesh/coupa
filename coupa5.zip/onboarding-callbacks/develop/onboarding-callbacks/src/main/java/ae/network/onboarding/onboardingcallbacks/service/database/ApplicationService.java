package ae.network.onboarding.onboardingcallbacks.service.database;

import ae.network.onboarding.onboardingcallbacks.model.ApplicationRequest;
import ae.network.onboarding.onboardingcallbacks.model.SalesforceCallbackMessage;

public interface ApplicationService {
    ApplicationRequest applicationRequestById(String applicationId);
    boolean checkSkipCallback(SalesforceCallbackMessage salesforceCallbackMessage);
    SalesforceCallbackMessage addAdditionalDataForWeChat(SalesforceCallbackMessage salesforceCallbackMessage);
}
