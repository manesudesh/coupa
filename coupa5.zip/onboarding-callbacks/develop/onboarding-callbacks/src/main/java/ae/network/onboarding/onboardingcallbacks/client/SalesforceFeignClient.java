package ae.network.onboarding.onboardingcallbacks.client;

import ae.network.onboarding.onboardingcallbacks.model.mintoak.SalesforceStatusResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "onboarding-salesforce", url = "${client.sales-force.base-url}")
public interface SalesforceFeignClient {

    @GetMapping(path = "/onboarding-salesforce/api/v1/applications/{requestId}")
    SalesforceStatusResponse getSalesforceStatusResponse(
            @PathVariable("requestId") String requestId
    );
}
