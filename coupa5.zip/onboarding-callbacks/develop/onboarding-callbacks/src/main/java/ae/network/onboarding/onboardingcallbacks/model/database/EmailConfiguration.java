package ae.network.onboarding.onboardingcallbacks.model.database;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Collection;

/**
 * @author Success.Otto
 * @since 25/03/2020
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class EmailConfiguration extends IntegrationConfiguration {

    /**
     * where the mail is
     * coming from and connect
     * be null
     */
    private String from;
    /**
     * Mails can be sent to multiple
     * recipients. Specifies recipients
     * of the mail
     */
    private Collection<String> to;
    /**
     * References are sometimes in a
     * mail. Email address to keep
     * in the loop of the mail
     */
    private Collection<String> cc;
    /**
     * Similar to cc but this mail
     * won't be displayed in the recipients
     * mail
     */
    private Collection<String> bcc;
    /**
     * Heading of the mail
     */
    private String subject;
}
