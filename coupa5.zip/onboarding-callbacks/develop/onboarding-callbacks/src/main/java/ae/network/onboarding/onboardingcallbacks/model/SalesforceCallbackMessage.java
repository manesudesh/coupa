package ae.network.onboarding.onboardingcallbacks.model;

import ae.network.onboarding.onboardingcallbacks.model.database.IntegrationConfiguration;
import ae.network.onboarding.onboardingcallbacks.service.integration.SalesforceRestService;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
public class SalesforceCallbackMessage extends CommonCallbackMessage {
    /**
     * Partner acquirer
     */
    private String acquirer;
    /**
     * Skip callback
     */
    private boolean skipCallback;
    /**
     * Request type
     */
    private String requestType;
    /**
     * Application status
     */
    private RequestStatus requestStatus;
    /**
     * unique global id
     */
    private String applicationId;
    /**
     * acquirer request id (unique across each acquirer)
     */
    private String requestId;
    /**
     * Callback url
     */
    private String callbackUrl;
    /**
     * Callback email
     */
    private String callbackEmail;
    /**
     * List of tasks
     */
    @Builder.Default
    private Map<String, ProcessingResult> resultsMap = new HashMap<>();
    /**
     * List of tasks
     */
    @Builder.Default
    private Map<String, Attachment> attachmentsMap = new HashMap<>();

    /**
     * List of Additional Data received from backend systems
     */
    @Builder.Default
    private Map<String, AdditionalData> additionalDataMap = new HashMap<>();
    /**
     * Time of last update
     */

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private Date lastModifiedDate;
    /**
     * URL for displaying screening result
     */
    private String screeningResult;

    @Override
    public void sendRest(IntegrationConfiguration configuration) {
        SalesforceRestService salesforceRestService = new SalesforceRestService();
        salesforceRestService.salesforceRestSend(this, configuration);
    }
}
