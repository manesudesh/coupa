package ae.network.onboarding.onboardingcallbacks.model.mintoak;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class EncryptedRequest {
    private String requestMsg;
}
