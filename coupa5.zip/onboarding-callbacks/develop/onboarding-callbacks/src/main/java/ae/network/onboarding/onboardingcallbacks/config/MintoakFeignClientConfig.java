package ae.network.onboarding.onboardingcallbacks.config;

import ae.network.onboarding.onboardingcallbacks.config.properties.MintoakClientProperties;
import feign.RequestInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MintoakFeignClientConfig {
    private final MintoakClientProperties mintoakClientProperties;

    public MintoakFeignClientConfig(MintoakClientProperties mintoakClientProperties) {
        this.mintoakClientProperties = mintoakClientProperties;
    }

    @Bean
    public RequestInterceptor mintoakRequestInterceptor() {
        return requestTemplate -> requestTemplate.header("apiKey", mintoakClientProperties.getApiKey());
    }
}
