package ae.network.onboarding.onboardingcallbacks.model;

import ae.network.onboarding.onboardingcallbacks.model.mintoak.TerminalStatus;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-03-05
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProcessingResult {
    private TaskStatus finalStatus;
    private Collection<Task> tasks = new ArrayList<>();
    private Boolean mergeToExisting;

    //These field for POS status
    private String deliveryDate;
    private String message;
    private List<TerminalStatus> subStatuses;
}