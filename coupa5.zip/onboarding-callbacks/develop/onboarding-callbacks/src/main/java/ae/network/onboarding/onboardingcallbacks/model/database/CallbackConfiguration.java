package ae.network.onboarding.onboardingcallbacks.model.database;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Map;


/**
 * @author Yousry
 * @version 1.0
 */

@EqualsAndHashCode(callSuper = true)
@Data
@ToString(includeFieldNames = true)
@Builder
@Document(collection = "callbacks_config")
public class CallbackConfiguration extends AbstractAuditingEntity {

    @Id
    private String acquirer;
    private Map<IntegrationType, IntegrationConfiguration> configurationMap;
}
