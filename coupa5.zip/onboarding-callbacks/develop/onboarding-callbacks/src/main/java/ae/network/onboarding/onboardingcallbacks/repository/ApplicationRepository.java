package ae.network.onboarding.onboardingcallbacks.repository;

import ae.network.onboarding.onboardingcallbacks.model.ApplicationRequest;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface ApplicationRepository extends MongoRepository<ApplicationRequest, Long> {
    Optional<ApplicationRequest> findFirstByApplicationId(String applicationId);
}
