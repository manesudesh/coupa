package ae.network.onboarding.onboardingcallbacks.service.database;

import ae.network.onboarding.onboardingcallbacks.exception.NotFoundException;
import ae.network.onboarding.onboardingcallbacks.model.AdditionalData;
import ae.network.onboarding.onboardingcallbacks.model.ApplicationRequest;
import ae.network.onboarding.onboardingcallbacks.model.RequestType;
import ae.network.onboarding.onboardingcallbacks.model.SalesforceCallbackMessage;
import ae.network.onboarding.onboardingcallbacks.repository.ApplicationRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Slf4j
@Service
public class ApplicationServiceImpl implements ApplicationService{

    private final ApplicationRepository applicationRepository;

    @Autowired
    public ApplicationServiceImpl(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }

    @Override
    public ApplicationRequest applicationRequestById(String applicationId) {
        return applicationRepository.findFirstByApplicationId(applicationId).orElseThrow(
                () -> new NotFoundException("Application not found")
        );
    }

    @Override
    public boolean checkSkipCallback(SalesforceCallbackMessage salesforceCallbackMessage) {
        if (salesforceCallbackMessage == null) {
            return false;
        } else {
            ApplicationRequest applicationRequest
                    = applicationRequestById(salesforceCallbackMessage.getApplicationId());
            return applicationRequest.isSkipCallback();
        }
    }

    @Override
    public SalesforceCallbackMessage addAdditionalDataForWeChat(SalesforceCallbackMessage salesforceCallbackMessage) {

        Optional<ApplicationRequest> possibleApplicationRequest =
                applicationRepository.findFirstByApplicationId(salesforceCallbackMessage.getApplicationId());

        if (!possibleApplicationRequest.isPresent()) {
            return salesforceCallbackMessage;
        }

        ApplicationRequest applicationRequest = possibleApplicationRequest.get();
        Map<String, AdditionalData> additionalDataMap = applicationRequest.getAdditionalDataMap();
        if (additionalDataMap == null || additionalDataMap.isEmpty()) {
            return salesforceCallbackMessage;
        }
        // not-WeChat additional data map is broken. For delivery purposes lets make build a 100% valid map. See jira NASSC-6116
        if (!additionalDataMap.containsKey("WECHAT")) {
            return salesforceCallbackMessage;
        }
        Map<String, AdditionalData> wechatAdditionalData = new HashMap<>();
        wechatAdditionalData.put(ApplicationRequest.BackendSystem.WECHAT.toString(),
                additionalDataMap.get("WECHAT"));
        salesforceCallbackMessage.setAdditionalDataMap(wechatAdditionalData);
        return salesforceCallbackMessage;
    }
}
