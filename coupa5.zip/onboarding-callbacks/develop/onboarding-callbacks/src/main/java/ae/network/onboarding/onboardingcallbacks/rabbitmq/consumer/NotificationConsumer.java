package ae.network.onboarding.onboardingcallbacks.rabbitmq.consumer;

import ae.network.onboarding.onboardingcallbacks.common.MdcUtils;
import ae.network.onboarding.onboardingcallbacks.exception.MessageRejectionException;
import ae.network.onboarding.onboardingcallbacks.model.AggregatorCallbackMessage;
import ae.network.onboarding.onboardingcallbacks.model.CallbackFactory;
import ae.network.onboarding.onboardingcallbacks.model.CommonCallbackMessage;
import ae.network.onboarding.onboardingcallbacks.model.MintOakCallbackMessage;
import ae.network.onboarding.onboardingcallbacks.model.SalesforceCallbackMessage;
import ae.network.onboarding.onboardingcallbacks.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.onboardingcallbacks.rabbitmq.service.RabbitService;
import ae.network.onboarding.onboardingcallbacks.rabbitmq.service.impl.RabbitServiceImpl;
import ae.network.onboarding.onboardingcallbacks.service.mintoak.MintOakClientService;
import ae.network.onboarding.onboardingcallbacks.service.notification.NotificationService;
import ae.network.onboarding.onboardingcallbacks.service.notification.NotificationServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * @author Success.Otto
 * @since 15/03/2020
 */
@Slf4j
@Component
public class NotificationConsumer implements MessageListener {

    /**
     * Injection of AMQP, i.e rabbitMQ
     */
    private final RabbitService rabbitService;
    /**
     * Injection of Notification Service
     */
    private final NotificationService notificationService;
    /**
     * Injection of callback factory
     */
    private final CallbackFactory callbackFactory;

    private final MintOakClientService mintOakClientService;

    /**
     * When a reschedule is perform during a fail update, RETRY_DELAY_SECONDS tells number of seconds to wait
     * before making a retry
     */
    @Value("${octopus.consumer.error-retry-in-seconds}")
    private int RETRY_DELAY_SECONDS;

    private static final String MINTOAK_APP = "mintoak";

    private static final String ERROR_MESSAGE = "Processing Error Received";

    public NotificationConsumer(NotificationServiceImpl notificationService,
                                RabbitServiceImpl rabbitService,
                                CallbackFactory callbackFactory,
                                MintOakClientService mintOakClientService ) {
        this.notificationService = notificationService;
        this.rabbitService = rabbitService;
        this.callbackFactory = callbackFactory;
        this.mintOakClientService = mintOakClientService;
    }

    /**
     * Bean to configure replyListener Configuration of what queue to listen to when a publish is made by any producer
     */
    @Bean
    SimpleMessageListenerContainer replyListener(ConnectionFactory connectionFactory) {
        SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
        container.setConnectionFactory(connectionFactory);
        container.setQueueNames(RabbitQueue.NOTIFICATIONS.getQueueName());
        container.setMessageListener(this);
        return container;
    }

    /**
     * When a new message enters the queue listened by this component, this method is called instantaneously
     * and is populated with the queued message.
     * The message is parsed to check if the object model tallies with CallbackMessage or
     * AggregatorCallbackMessage object.
     * If tally then the message is processed
     */
    @Override
    public void onMessage(Message message) {
        MdcUtils.setCorrId(message.getMessageProperties().getCorrelationId());
        log.info("Received message : " + message.getMessageProperties());

        CommonCallbackMessage commonCallbackMessage = callbackFactory.createCallbackFromMessage(message);

        if (commonCallbackMessage instanceof SalesforceCallbackMessage) {
            SalesforceCallbackMessage salesforceCallbackMessage = (SalesforceCallbackMessage) commonCallbackMessage;
            try {
                this.notificationService.salesforcePublish(salesforceCallbackMessage);
                if(MINTOAK_APP.equals(salesforceCallbackMessage.getAcquirer())){
                    MintOakCallbackMessage mintOakCallbackMessage = (MintOakCallbackMessage) salesforceCallbackMessage;
                    mintOakClientService.invokeMintOakCallback(mintOakCallbackMessage);
                }
            } catch (Exception e) {
                log.error(ERROR_MESSAGE, e);
                rabbitService.retryMessage(message, this.RETRY_DELAY_SECONDS);
            }
        } else if (commonCallbackMessage instanceof AggregatorCallbackMessage){
            AggregatorCallbackMessage aggregatorCallbackMessage = (AggregatorCallbackMessage) commonCallbackMessage;
            try {
                this.notificationService.aggregatorPublish(aggregatorCallbackMessage);
            } catch (Exception e) {
                log.error(ERROR_MESSAGE, e);
                rabbitService.retryMessage(message, this.RETRY_DELAY_SECONDS);
            }
        } else {
            throw new MessageRejectionException("Invalid JSON content");
        }
    }
}
