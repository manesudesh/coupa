package ae.network.onboarding.onboardingcallbacks.model.mintoak;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
public class ProductStatus {
    private String status;
    private String message;
}
