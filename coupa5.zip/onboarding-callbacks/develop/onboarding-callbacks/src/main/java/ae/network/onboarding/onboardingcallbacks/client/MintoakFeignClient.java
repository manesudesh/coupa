package ae.network.onboarding.onboardingcallbacks.client;

import ae.network.onboarding.onboardingcallbacks.config.MintoakFeignClientConfig;
import ae.network.onboarding.onboardingcallbacks.model.mintoak.EncryptedRequest;
import ae.network.onboarding.onboardingcallbacks.model.mintoak.EncryptedResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(
        name = "MintoakService",
        url = "${client.mintoak.base-url}",
        configuration = MintoakFeignClientConfig.class
)
public interface MintoakFeignClient {

    @PostMapping(path = "/mio/application-status-update-callback")
    EncryptedResponse invokeMintOakCallback(@RequestBody EncryptedRequest encryptedRequest);
}