package ae.network.onboarding.onboardingcallbacks.config.properties;

import lombok.Getter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Configuration
@ConfigurationProperties(prefix = "client.sales-force")
public class SalesforceClientProperties extends ClientProperties {

}
