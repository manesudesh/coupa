package ae.network.onboarding.onboardingcallbacks.rabbitmq.config;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
public enum RabbitExchange {
    /**
     * RabbitMQ exchange name for onboarding project
     */
    ONBOARDING("onboarding-exchange"),
    /**
     * RabbitMQ exchange name for retries (onboarding project)
     */
    ONBOARDING_RETRY("onboarding-delayed-exchange");

    private final String exchangeName;

    RabbitExchange(String exchangeName) {
        this.exchangeName = exchangeName;
    }

    public String getExchangeName() {
        return exchangeName;
    }
}
