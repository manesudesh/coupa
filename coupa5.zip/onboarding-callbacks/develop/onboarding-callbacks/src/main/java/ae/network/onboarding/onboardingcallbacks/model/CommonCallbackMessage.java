package ae.network.onboarding.onboardingcallbacks.model;

import ae.network.onboarding.onboardingcallbacks.model.database.IntegrationConfiguration;
import ae.network.onboarding.onboardingcallbacks.rabbitmq.message.QueueMessage;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@NoArgsConstructor
public class CommonCallbackMessage implements QueueMessage {
    /**
     * Partner acquirer
     */
    private String acquirer;
    /**
     * unique global id
     */
    private String applicationId;

    public void sendRest(IntegrationConfiguration configuration) {
        throw new UnsupportedOperationException();
    }
}
