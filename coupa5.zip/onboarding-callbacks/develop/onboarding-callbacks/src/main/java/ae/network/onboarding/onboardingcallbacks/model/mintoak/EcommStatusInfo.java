package ae.network.onboarding.onboardingcallbacks.model.mintoak;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
@EqualsAndHashCode(callSuper = true)
public class EcommStatusInfo extends SoftwareStatus {

}
