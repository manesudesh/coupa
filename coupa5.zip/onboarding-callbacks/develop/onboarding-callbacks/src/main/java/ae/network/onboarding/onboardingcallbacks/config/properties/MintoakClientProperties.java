package ae.network.onboarding.onboardingcallbacks.config.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Setter
@Getter
@Configuration
@ConfigurationProperties(prefix = "client.mintoak")
public class MintoakClientProperties extends ClientProperties {

    private String mockUrl;
    private String secretKey;
    private String apiKey;

}
