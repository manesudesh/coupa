package ae.network.onboarding.onboardingcallbacks.common;
import ae.network.onboarding.onboardingcallbacks.model.ProcessingResult;
import ae.network.onboarding.onboardingcallbacks.model.Task;
import ae.network.onboarding.onboardingcallbacks.model.TaskHistory;
import ae.network.onboarding.onboardingcallbacks.model.TaskStatus;
import lombok.extern.slf4j.Slf4j;
import org.stringtemplate.v4.*;

import java.util.*;
import java.util.stream.Collectors;
@Slf4j
public class StringTemplateHelper {
     private static final char SEMI_COLON = ';';

    public String getErrorMessagesForBackendSystems(Map<String, ProcessingResult> resultMap) {
        if (resultMap == null || resultMap.isEmpty()) {
            return null;
        }

        TreeMap<String, TreeSet<String>> backendSysWithErrors = prepareErrorMessagesFromResultMap(resultMap);

        if (backendSysWithErrors.isEmpty()) {
            return null;
        }

        StringBuilder result = new StringBuilder();
        for (Map.Entry<String, TreeSet<String>> entry : backendSysWithErrors.entrySet()) {
            String backEndSystem = entry.getKey();
            TreeSet<String> errors = entry.getValue();
            result.insert(0, constructErrorMessage(backEndSystem, errors));
        }

        if(!result.toString().trim().isEmpty() && lastChar(result.toString()) == SEMI_COLON) {
            result = new StringBuilder(removeLastCharacter(result.toString()));
        }

        return result.toString();
    }

    private synchronized String constructErrorMessage(String backEndSystem,
                                                      TreeSet<String> errors) {
        if (backEndSystem == null || errors == null) {
            return null;
        }

        // Convert the TreeSet of String to String
        String errorsData = String.join(",", errors);

        ST errorsForBackendSystem = new ST("['<BackEndSystem>', '<Errors>'];");
        errorsForBackendSystem.add("BackEndSystem", backEndSystem);
        errorsForBackendSystem.add("Errors", errorsData);

        return errorsForBackendSystem.render();
    }

    private TreeMap<String, TreeSet<String>> prepareErrorMessagesFromResultMap(Map<String, ProcessingResult> resultMap) {
        if (resultMap == null) {
            return new TreeMap<>();
        }

        //Filter Map with TaskStatus.FAILED only.
        Map<String, ProcessingResult> collectMap = resultMap.entrySet().stream()
                .filter(x -> x.getValue().getFinalStatus() != TaskStatus.COMPLETED)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        TreeMap<String, TreeSet<String>> backendSysWithErrors = new TreeMap<>();

        for (Map.Entry<String, ProcessingResult> entry : collectMap.entrySet()) {
            ProcessingResult processingResult = entry.getValue();
            String backendSystem = entry.getKey();
            TreeSet<String> responseErrorMessages = new TreeSet<>();
            if (processingResult.getTasks() == null) {
                continue;
            }

            for (Task task : processingResult.getTasks()) {
                {
                    for (TaskHistory taskHistory : task.getTaskHistory()) {
                        responseErrorMessages.add(taskHistory.getResponse());
                    }
                }
            }

            backendSysWithErrors.put(backendSystem, responseErrorMessages);
        }
        return backendSysWithErrors;
    }

    public static String removeLastCharacter(String str) {
        return Optional.ofNullable(str)
                .filter(sStr -> !sStr.isEmpty())
                .map(sStr -> sStr.substring(0, sStr.length() - 1))
                .orElse(str);
    }

    public static char lastChar(String s) {
        if (Objects.equals(s, "") || s == null) {
            return ' ';
        }
        return s.charAt(s.length() - 1);
    }

    public static void main (String[]args) {
            ST errorsForBackendSystem = new ST("['<BackEndSystem>', '<Errors>'];");
            errorsForBackendSystem.add("BackEndSystem", "BASE24");
            errorsForBackendSystem.add("Errors", "record not found, Error2");

            StringTemplateHelper stringTemplateHelper = new StringTemplateHelper();
            TreeSet<String> errors = new TreeSet<>();
            errors.add("test1");
            errors.add("test2");
            errors.add("record not found");
            String data = stringTemplateHelper.constructErrorMessage("Way4", errors);
            String result = errorsForBackendSystem.render() + data;

            log.info(result);
        }

}