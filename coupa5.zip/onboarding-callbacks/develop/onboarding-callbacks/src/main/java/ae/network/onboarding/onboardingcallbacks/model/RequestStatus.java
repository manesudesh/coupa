package ae.network.onboarding.onboardingcallbacks.model;

public enum RequestStatus {
    COMPLETED, FAILED
}
