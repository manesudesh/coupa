package ae.network.onboarding.onboardingcallbacks.model;


import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class MintOakCallbackMessage extends SalesforceCallbackMessage {
    private Payload payload;
}
