package ae.network.onboarding.onboardingcallbacks.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Terminal implements Serializable {
    private String terminalId;
    private String terminalType;
    private String maker;
    private String terminalModel;
    private String communicationMethod;
    private boolean dccEnabled;

}
