package ae.network.onboarding.onboardingcallbacks.exception;

import org.springframework.amqp.AmqpRejectAndDontRequeueException;

/**
 * Reject message altogether, and send it to failure queue for investigation.
 * Use when there is no way to recover the error.
 *
 * @author walid.sewaify
 * @since 2020-01-27
 */
public class MessageRejectionException extends AmqpRejectAndDontRequeueException {

    public MessageRejectionException(String message) {
        super(message);
    }

    public MessageRejectionException(String message, Throwable cause) {
        super(message, cause);
    }
}
