package ae.network.onboarding.onboardingcallbacks.model.mintoak;

import lombok.Data;

@Data
public class EncryptedResponse {
    private String responseMsg;
}
