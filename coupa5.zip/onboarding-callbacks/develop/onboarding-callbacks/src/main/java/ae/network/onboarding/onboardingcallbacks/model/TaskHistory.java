package ae.network.onboarding.onboardingcallbacks.model;

import ae.network.onboarding.onboardingcallbacks.common.DateFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskHistory {
    private TaskStatus taskStatus;
    private String statusCode;
    private String response;
    @JsonFormat(pattern = DateFormat.FORMAT)
    @DateTimeFormat(pattern = DateFormat.FORMAT)
    private Date createdDate;
    @JsonFormat(pattern = DateFormat.FORMAT)
    @DateTimeFormat(pattern = DateFormat.FORMAT)
    private Date lastModifiedDate;
}
