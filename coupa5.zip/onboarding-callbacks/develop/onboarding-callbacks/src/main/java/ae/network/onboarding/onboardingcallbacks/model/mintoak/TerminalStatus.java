package ae.network.onboarding.onboardingcallbacks.model.mintoak;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class TerminalStatus {

    private String terminalId;
    private String merchantId;
    private String deliveryDate;

}
