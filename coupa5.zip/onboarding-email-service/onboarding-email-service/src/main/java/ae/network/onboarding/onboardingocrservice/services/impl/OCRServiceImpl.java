package ae.network.onboarding.onboardingocrservice.services.impl;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.spire.doc.Document;
import com.spire.doc.FileFormat;

import ae.network.onboarding.onboardingocrservice.dto.ScanRequest;
import ae.network.onboarding.onboardingocrservice.services.OCRService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

@Service
@Slf4j
@RequiredArgsConstructor
public class OCRServiceImpl implements OCRService {
	
    @Override
    public String scanImage(ScanRequest scanRequest) throws IOException, TesseractException, URISyntaxException {
    	String ocrText = "";
    	
    	String frontFilePath = scanRequest.getFrontFileName();
    	String backFilePath = scanRequest.getBackFileName();
    	ocrText = readFile(frontFilePath) + readFile(backFilePath);
    	readData(ocrText);
    	return ocrText;
    }

	private String readFile( String filePath)
			throws UnsupportedEncodingException, MalformedURLException, IOException, TesseractException, URISyntaxException {
		String ocrText = "";
		if(StringUtils.isEmpty(filePath) ) { return ocrText;}
		filePath = filePath.replaceAll(" ", "%20");
		File file = new File(filePath);
		InputStream inStream;
		if(filePath.startsWith("http")){
			URL url = new URL(filePath);
			inStream = url.openStream();
		}else {
			inStream = new FileInputStream(filePath);
		}
		
//		URL imageURL = new URL( filePath );
//		//new File(imageURL.getFile())
		if(file.getName().toLowerCase().endsWith(".pdf")) {
			PDDocument document = Loader.loadPDF(file);
		    PDFRenderer pdfRenderer = new PDFRenderer(document);
		    for (int page = 0; page < document.getNumberOfPages(); ++page) {
		        BufferedImage bim = pdfRenderer.renderImageWithDPI(page, 300, ImageType.RGB);
		        ocrText = ocrText + processOCRImage(bim);
		    }
			
		}else if(file.getName().toLowerCase().endsWith(".docx") 
				|| file.getName().toLowerCase().endsWith(".doc")
				|| file.getName().toLowerCase().endsWith(".rtf")
				) {
	        Document document = new Document();
//	        document.loadFromFile(file.getPath()); 
	        document.loadFromStream(inStream, FileFormat.Auto); 
	        //set the image resolution and save to image
	        BufferedImage[] image= document.saveToImages(0, 1, com.spire.doc.documents.ImageType.Bitmap, 300, 300);
	        for (int page = 0; page < image.length; ++page) {
	        	ocrText = ocrText + processOCRImage(image[page]);
	        }
	        
		} else {
			BufferedImage ipimage;
			ipimage = ImageIO.read(inStream);
			ocrText = processOCRImage(ipimage);
			ipimage.flush();

		}
		inStream.close();
    	return ocrText;
	}

	private String processOCRImage(BufferedImage ipimage) throws IOException, TesseractException {
		String ocrText = "";
		double d = ipimage.getRGB(ipimage.getTileWidth() / 2, ipimage.getTileHeight() / 2); 

    	if (d >= -1.4211511E7 && d < -7254228) { 
    		ocrText = processImg(ipimage, 3f, -10f); 
        } 
        else if (d >= -7254228 && d < -2171170) { 
        	ocrText = processImg(ipimage, 1.455f, -47f); 
        } else if (d >= -2171170 && d < -1907998) { 
        	ocrText = processImg(ipimage, 1.35f, -10f); 
        } 
        else if (d >= -1907998 && d < -257) { 
        	ocrText = processImg(ipimage, 1.19f, 0.5f); 
        } 
        else if (d >= -257 && d < -1) { 
        	ocrText = processImg(ipimage, 1f, 0.5f); 
        } 
        else if (d >= -1 && d < 2) { 
        	ocrText = processImg(ipimage, 1f, 0.35f); 
        } 
    	
    	return ocrText;
	}
    
    public static String processImg(BufferedImage ipimage, 
               float scaleFactor, 
               float offset) 
        throws IOException, TesseractException 
    { 
        BufferedImage opimage = new BufferedImage(1050, 1024, ipimage.getType());
        
        Graphics2D graphic = opimage.createGraphics(); 
  
        graphic.drawImage(ipimage, 0, 0, 1050, 1024, null); 
        graphic.dispose(); 
  
        // rescale OP object for gray scaling images 
        RescaleOp rescale = new RescaleOp(scaleFactor, offset, null); 
        BufferedImage fopimage = rescale.filter(opimage, null); 
        Tesseract it = new Tesseract(); 
  
        it.setDatapath("src/main/resources/");
        
        it.setLanguage("eng");
        String str = it.doOCR(fopimage); 
        System.out.println(str); 
        
        return str;
    }

	private static void readData(String str) {
		List<Date> dateArr = new ArrayList<Date>();
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String regex = "(3[01]"
                + "|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}"; 
        Pattern pattern = Pattern.compile(regex); 
        Matcher matcher = pattern.matcher((CharSequence)str); 
        
        while(matcher.find()) {
        	try {
        		String dateStr = matcher.group();
        		
        		Date date = formatter.parse(dateStr);
				dateArr.add(date);
				System.out.println(date);
			} catch (ParseException e) {
			}
         }
        Collections.sort(dateArr);
        
        List<String> strArr = new ArrayList<String>(); 
        dateArr.stream().forEachOrdered(date -> strArr.add(formatter.format(date)));
        System.out.println(strArr);
        
         regex = "Name[a-zA-z\s:\"]*|784.*-.*-.*-[\\d]*|Nationality[a-zA-z\\s:\\\"]*"; 
        pattern = Pattern.compile(regex); 
        matcher = pattern.matcher((CharSequence)str); 
       while(matcher.find()) {
       System.out.println(matcher.group());
       }
	} 
}
