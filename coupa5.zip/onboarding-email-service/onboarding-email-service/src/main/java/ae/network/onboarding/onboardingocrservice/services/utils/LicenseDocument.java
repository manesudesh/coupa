package ae.network.onboarding.onboardingocrservice.services.utils;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiPredicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.tika.detect.DefaultDetector;
import org.apache.tika.detect.Detector;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;
import org.joda.time.LocalDate;
import org.joda.time.Period;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.spire.doc.Document;
import com.spire.doc.FileFormat;

import lombok.extern.slf4j.Slf4j;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

@Service
@Slf4j
public class LicenseDocument {

	 private final AtomicInteger counter = new AtomicInteger();
	 @Value("${ocr.license.source}")
	 private String sourceFolder ;
	 @Value("${ocr.license.destination}")
	 private String  destinationFolder;
	 
	 private static final Map<String, String> extensionMap = new HashMap<String, String>();

	 static {
		 extensionMap.put("application/octet-stream", "pdf");
		 extensionMap.put("application/msword", "doc");
		 extensionMap.put("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "docx");
		 extensionMap.put("image/jpeg", "jpeg");
		 extensionMap.put("image/png", "png");
		 extensionMap.put("application/pdf", "pdf");
		 extensionMap.put("image/tiff", "tiff");
	 };
	 
	 
	public String detectFileTypeUsingDetector(InputStream inStream) throws IOException {
		
		Detector detector = new DefaultDetector();
		Metadata metadata = new Metadata();

		MediaType mediaType = detector.detect(inStream, metadata);
		String extension = mediaType.toString();
		return extension;
	}
	
	public void readFiles(LocalDate date, String fileSelectionBasisOf) throws IOException  {
        	
        	BiPredicate<Path, String> dateSelectionPredicate = (path, dayWeekMonthYearStr) -> {
        		Period p = new Period(date, new LocalDate(path.toFile().lastModified()));
                if(dayWeekMonthYearStr.equalsIgnoreCase("day") && p.getDays() == 0 &&  p.getMonths() == 0 && p.getYears() == 0 ) {System.out.println(path.getFileName()+" File selected basis on day criteria"); return true; }
                if(dayWeekMonthYearStr.equalsIgnoreCase("week") && p.getDays() >= 0 && p.getWeeks() == 0 && p.getMonths() == 0 && p.getYears() == 0 ) {System.out.println(path.getFileName()+" File selected basis on week criteria"); return true; }
                if(dayWeekMonthYearStr.equalsIgnoreCase("month") && p.getDays() >= 0 && p.getMonths() == 0 && p.getYears() == 0 ) {System.out.println(path.getFileName()+" File selected basis on month criteria"); return true;}
                if(dayWeekMonthYearStr.equalsIgnoreCase("year") && p.getMonths() >= 0 && p.getYears() == 0) {System.out.println(path.getFileName()+" File selected basis on year criteria"); return true;}
                else {return false;}
        	};
        	
        	Path startDir = Paths.get(sourceFolder); 
            List<File> filesList = Files.walk(startDir)
                                        .filter(Files::isRegularFile)
                                        .filter(path -> dateSelectionPredicate.test(path, fileSelectionBasisOf))
                                        .map(path -> path.toFile())
                                        .sorted(Comparator.comparingLong(File::lastModified).reversed())
                                        .collect(Collectors.toList());
            filesList.forEach(file -> {
            	
						try {
							log.info("reading file "+file.getAbsolutePath());
//							readSingleFile(file);
						} catch (Exception e) {
							e.printStackTrace();
						}
					} 
			);
            
            log.info("*********reading finish*********");
    }
	
	
	public void readSingleFile(File file) throws Exception {
		LicenseDocument licDoc = new LicenseDocument();
		String ocrText = licDoc.scanFile(file.getAbsolutePath());
		String licNumber = readTextLicenseNumber(file, ocrText);
		if(! licNumber.equals("NOT_FOUND"))
		 {
			moveFile(file, licNumber);
		 }
	}

	public String readTextLicenseNumber(File file, String ocrText) throws IOException {
		String regex = "License N.*[\\d]*"; 
        Pattern pattern = Pattern.compile(regex); 
        Matcher matcher = pattern.matcher((CharSequence)ocrText);
        String scanLicenseText = "";
        boolean licFound = false;
        while(matcher.find()) {
        	scanLicenseText = scanLicenseText+ " "+matcher.group();
            log.info("Found   "+file.getPath()+" License  " + scanLicenseText);
            licFound = true;
             
        }
        String licNumber = "";
        if(licFound)
        {
        	regex = "[a-zA-z\\-]*\\d+";
            pattern = Pattern.compile(regex); 
            matcher = pattern.matcher((CharSequence)scanLicenseText);
            
            while(matcher.find()) {
           	 licNumber = licNumber+"_"+matcher.group();
            }
            if(licNumber.trim().equals("")) { //if license not readable then filename will autoincremented 
            	licNumber = "AutoNumber"+counter.getAndIncrement()+"";
            }
        }else {
        	log.info("Not Found License in  "+file.getAbsolutePath());
        	licNumber = "NOT_FOUND"; 	
        }
        return licNumber;
	}

	public void moveFile(File file, String licNumber) throws IOException {
		InputStream inStream = LicenseDocument.class.getClassLoader()
			      .getResourceAsStream(file.getAbsolutePath());
		String extension = detectFileTypeUsingDetector(inStream);
		if(inStream != null) {inStream.close();}
		Path destination = Paths.get(destinationFolder+"\\"+file.getParentFile().getParentFile().getName()+"__"+licNumber+"."+extensionMap.get(extension));
		FileUtils.copyFile(file, destination.toFile());
	}
	
	public static void main(String [] args) throws Exception{
//		LicenseDocument licDoc = new LicenseDocument();
//		licDoc.readFiles(new LocalDate(), "month");
		
//		LocalDate date1 = new LocalDate(2024, 04, 30);
//		LocalDate date2 = new LocalDate(2024, 05, 30);
//		Period p = new Period(date1, date2);
//		System.out.println(p.getDays());
//		System.out.println(p.getWeeks());
//		System.out.println(p.getMonths());
//		System.out.println(p.getYears());
		
//		String ocrText = "License No 529934 any psy C-12345";
//		String regex = "License N.*[\\d]*"; 
//        Pattern pattern = Pattern.compile(regex); 
//        Matcher matcher = pattern.matcher((CharSequence)ocrText);
//        String licNumber = "";
//        while(matcher.find()) {
//        	licNumber = licNumber+" "+matcher.group();
//        }
//        regex = "[a-zA-z\\-]*\\d+";
//        pattern = Pattern.compile(regex); 
//        matcher = pattern.matcher((CharSequence)licNumber);
//        while(matcher.find()) {
//       	 licNumber = licNumber+" "+matcher.group();
//        }
//        if(licNumber.trim().equals("")) { //if license not readable then filename will autoincremented 
//        	licNumber = "AutoNumber";
//        }
//		System.out.println(licNumber);

		
//		String ocrText = fUtility.readFile("\\app\\backend\\uploads\\62996b56-6693-4967-b666-0af76c6097a8\\application\\0a1123ae-3b75-4cc9-af46-b3331c2ed018");
//		System.out.println(ocrText);
//		String regex = "License No.[a-zA-z\s]*[\\d]*"; 
//        Pattern pattern = Pattern.compile(regex); 
//        Matcher matcher = pattern.matcher((CharSequence)ocrText);
//        while(matcher.find()) {
//            System.out.println(" License  " + matcher.group());
//        }
	}
	
	
	private String scanFile( String filePath)
			throws UnsupportedEncodingException, MalformedURLException, IOException, TesseractException, URISyntaxException {
		String ocrText = "";
		if(StringUtils.isEmpty(filePath) ) { return ocrText;}
		filePath = filePath.replaceAll(" ", "%20");
		File file = new File(filePath);
		try {
			InputStream inStream = LicenseDocument.class.getClassLoader()
				      .getResourceAsStream(filePath);
			
			String extension = detectFileTypeUsingDetector(inStream);
			
//			if(extension.equalsIgnoreCase("application/octet-stream")) {
			if(extensionMap.get(extension).equalsIgnoreCase("pdf")
					|| extensionMap.get(extension).equalsIgnoreCase("tiff")) {
				PDDocument document = Loader.loadPDF(file);
			    PDFRenderer pdfRenderer = new PDFRenderer(document);
			    for (int page = 0; page < document.getNumberOfPages(); ++page) {
			        BufferedImage bim = pdfRenderer.renderImageWithDPI(page, 300, ImageType.RGB);
			        ocrText = ocrText + processOCRImage(bim);
			    }
				
			}else if(  extensionMap.get(extension).equalsIgnoreCase("doc")
					|| extensionMap.get(extension).equalsIgnoreCase("docx")) {
		        Document document = new Document();
		        document.loadFromStream(inStream, FileFormat.Auto); 
		        //set the image resolution and save to image
		        BufferedImage[] image= document.saveToImages(0, 1, com.spire.doc.documents.ImageType.Bitmap, 300, 300);
		        for (int page = 0; page < image.length; ++page) {
		        	ocrText = ocrText + processOCRImage(image[page]);
		        }
		        
			} else {
				BufferedImage ipimage;
				ipimage = ImageIO.read(inStream);
				ocrText = processOCRImage(ipimage);
				ipimage.flush();
	
			}
			if(inStream != null)inStream.close();
		}catch(Exception e) {System.out.println(filePath +" has error while scan document "+ e.getMessage());}
    	return ocrText;
	}

	private String processOCRImage(BufferedImage ipimage) throws IOException, TesseractException {
		String ocrText = "";
		double d = ipimage.getRGB(ipimage.getTileWidth() / 2, ipimage.getTileHeight() / 2); 

    	if (d >= -1.4211511E7 && d < -7254228) { 
    		ocrText = processImg(ipimage, 3f, -10f); 
        } 
        else if (d >= -7254228 && d < -2171170) { 
        	ocrText = processImg(ipimage, 1.455f, -47f); 
        } else if (d >= -2171170 && d < -1907998) { 
        	ocrText = processImg(ipimage, 1.35f, -10f); 
        } 
        else if (d >= -1907998 && d < -257) { 
        	ocrText = processImg(ipimage, 1.19f, 0.5f); 
        } 
        else if (d >= -257 && d < -1) { 
        	ocrText = processImg(ipimage, 1f, 0.5f); 
        } 
        else if (d >= -1 && d < 2) { 
        	ocrText = processImg(ipimage, 1f, 0.35f); 
        } 
    	
    	return ocrText;
	}
    
    public static String processImg(BufferedImage ipimage, 
               float scaleFactor, 
               float offset) 
        throws IOException, TesseractException 
    { 
        BufferedImage opimage = new BufferedImage(1050, 1024, ipimage.getType());
        
        Graphics2D graphic = opimage.createGraphics(); 
  
        graphic.drawImage(ipimage, 0, 0, 1050, 1024, null); 
        graphic.dispose(); 
  
        // rescale OP object for gray scaling images 
        RescaleOp rescale = new RescaleOp(scaleFactor, offset, null); 
        BufferedImage fopimage = rescale.filter(opimage, null); 
        Tesseract it = new Tesseract(); 
  
        it.setDatapath("src/main/resources/");
        
        it.setLanguage("eng");
        String str = it.doOCR(fopimage); 
        
        return str;
    }

	
}
