package ae.network.onboarding.onboardingocrservice.dao;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document("users")
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Data
public class User {
    private String id;
    private String username;
    private String ocr;
    private List<String> services;
}
