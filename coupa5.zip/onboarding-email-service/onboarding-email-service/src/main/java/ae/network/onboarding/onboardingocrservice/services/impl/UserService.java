package ae.network.onboarding.onboardingocrservice.services.impl;

import ae.network.onboarding.onboardingocrservice.dao.User;
import ae.network.onboarding.onboardingocrservice.exceptions.CustomException;
import ae.network.onboarding.onboardingocrservice.repositories.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public User findUserByUsername(String username) {
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new CustomException("The user doesn't exist", HttpStatus.NOT_FOUND);
        }
        return user;
    }
}
