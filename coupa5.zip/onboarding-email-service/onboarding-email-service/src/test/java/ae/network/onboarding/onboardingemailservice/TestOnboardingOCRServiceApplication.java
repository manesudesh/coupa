package ae.network.onboarding.onboardingemailservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.context.annotation.Bean;
import org.testcontainers.containers.MongoDBContainer;
import org.testcontainers.utility.DockerImageName;

import ae.network.onboarding.onboardingocrservice.OnboardingOCRServiceApplication;

@TestConfiguration(proxyBeanMethods = false)
public class TestOnboardingOCRServiceApplication {

	@Bean
	@ServiceConnection
	MongoDBContainer mongoDbContainer() {
		return new MongoDBContainer(DockerImageName.parse("mongo:latest"));
	}

	public static void main(String[] args) {
		SpringApplication.from(OnboardingOCRServiceApplication::main).with(TestOnboardingOCRServiceApplication.class).run(args);
	}

}
