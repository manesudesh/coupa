# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.2.4.RELEASE/maven-plugin/)

### Document management service:-
general service for managing onboarding documents


Example For rest API:

http://localhost:8014/files/v1/list/1233

Swagger URL : 

http://localhost:8014/swagger-ui/#/file-storage-controller