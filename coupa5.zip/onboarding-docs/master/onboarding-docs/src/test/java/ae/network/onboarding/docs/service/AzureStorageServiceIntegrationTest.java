package ae.network.onboarding.docs.service;

import ae.network.onboarding.docs.azure.AzureStorageService;
import ae.network.onboarding.docs.model.FileProperties;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

/**
 * @author walid.sewaify
 * @since 12-Dec-20
 */
@SpringBootTest
@Tag("IT")
class AzureStorageServiceIntegrationTest {

    @Autowired
    private AzureStorageService azureStorageService;

    @Test
    void testUploadDownloadDelete() {
        String fileContent = "Hello, World!";
        String containerName = "test-container";
        String fileName = "hello.txt";

        MockMultipartFile file = new MockMultipartFile(
            "file", fileName, MediaType.TEXT_PLAIN_VALUE, fileContent.getBytes());

        HashMap<String, String> metadata = new HashMap<>();
        metadata.put("type", "TRADE_LICENSE");
        FileProperties properties = azureStorageService.uploadFile(containerName, file, metadata);
        assertEquals(containerName, properties.getContainerName());
        assertFalse(properties.getMetadata().isEmpty());

        byte[] downloadedFile = azureStorageService.downloadFile(containerName, fileName);
        assertEquals(fileContent, new String(downloadedFile));

        azureStorageService.deleteFile(containerName, fileName);
    }
}
