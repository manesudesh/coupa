package ae.network.onboarding.docs.azure;

import ae.network.onboarding.docs.security.AccessKeyService;
import com.azure.core.http.HttpClient;
import com.azure.core.http.ProxyOptions;
import com.azure.core.http.netty.NettyAsyncHttpClientBuilder;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.common.StorageSharedKeyCredential;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.net.InetSocketAddress;

/**
 * @author walid.sewaify
 * @since 12-Dec-20
 */
@Configuration
@AllArgsConstructor
public class BlobClientConfig {
    private final StorageConfig storageConfig;

    @Bean
    BlobServiceClient getBlobServiceClient() {
        // Create a blobServiceClient
        BlobServiceClientBuilder builder = new BlobServiceClientBuilder()
            .credential(new StorageSharedKeyCredential(storageConfig.getAccountName(), storageConfig.getAccountKey()))
            .endpoint(storageConfig.getEndpoint());

        // check proxy settings
        String host = System.getProperty("https.proxyHost");
        if (!StringUtils.isEmpty(host)) {
            int port = Integer.parseInt(System.getProperty("https.proxyPort"));

            HttpClient client = new NettyAsyncHttpClientBuilder()
                .proxy(new ProxyOptions(ProxyOptions.Type.HTTP, new InetSocketAddress(host, port)))
                .build();

            return builder.httpClient(client)
                .buildClient();

        }

        return builder.buildClient();
    }

    @Bean
    AccessKeyService getAccessKeyService() {
        return new AccessKeyService(storageConfig.getAccountKey());
    }
}
