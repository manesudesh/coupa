package ae.network.onboarding.docs.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * @author walid.sewaify
 * @since 12-Dec-20
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileProperties {
    private String containerName;
    private String fileName;
    private String fileType;
    private long size;
    private String version;
    private String contentMd5;
    private String accessKey;
    private Map<String, String> metadata;
}
