package ae.network.onboarding.docs.controller;

import ae.network.onboarding.docs.model.FileProperties;
import ae.network.onboarding.docs.model.view.FileResponse;
import ae.network.onboarding.docs.service.FileStorageService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.ByteArrayInputStream;
import java.net.URLConnection;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author walid.sewaify
 * @since 12-Dec-20
 */
@RestController
@RequestMapping({FileStorageController.PATH, FileStorageController.VERSION})
@Slf4j
@RequiredArgsConstructor
public class FileStorageController {
    public static final String PATH = "files";
    public static final String VERSION = PATH + "/v1";

    private final FileStorageService azureStorageService;

    @PutMapping("/upload/{containerName}")
    public FileResponse uploadFile(@PathVariable String containerName,
                                   @RequestParam MultipartFile file,
                                   @RequestParam(required = false) Map<String, String> metadata) {
        if (file == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Multipart file metadata not included");
        }

        FileProperties properties = azureStorageService.uploadFile(containerName, file, metadata);
        log.info("file uploaded successfully with following details : {}", properties);

        return toView(properties);
    }

    @PutMapping("/uploadMany/{containerName}")
    public List<FileResponse> uploadMultipleFiles(@PathVariable String containerName,
                                                  @RequestParam MultipartFile[] files,
                                                  @RequestParam(required = false) Map<String, String> metadata) {
        return Arrays.stream(files).map(file -> uploadFile(containerName, file, metadata)).collect(Collectors.toList());
    }

    /**
     * Resource must be secured on API Gateway level
     */
    @GetMapping("/download/{containerName}/{fileName}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String containerName,
                                                 @RequestParam String fileName) {
        byte[] resource = azureStorageService.downloadFile(containerName, fileName);

        String contentType = Optional.ofNullable(URLConnection.guessContentTypeFromName(fileName))
            .orElse(MediaType.APPLICATION_OCTET_STREAM_VALUE);

        return ResponseEntity.ok()
            .contentType(MediaType.parseMediaType(contentType))
            .header(HttpHeaders.CONTENT_DISPOSITION, String.format("attachment; filename=\"%s\"", fileName))
            .body(new InputStreamResource(new ByteArrayInputStream(resource)));
    }

    /**
     * Public download to file using access key
     */
    @GetMapping("/shared/{containerName}/{fileName}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String containerName, @PathVariable String fileName,
                                                 @RequestParam String accessKey) {
        log.info("requesting file {} from container {}", fileName, containerName);
        if (azureStorageService.verifyAccessKey(containerName, fileName, accessKey)) {
            return downloadFile(containerName, fileName);
        }
        log.warn("invalid access attempt");
        throw new ResponseStatusException(HttpStatus.NOT_FOUND, "File Not Found");
    }

    @GetMapping("/list/{containerName}")
    public List<FileProperties> listFiles(@PathVariable String containerName) {
        return azureStorageService.listContainer(containerName)
            .stream().map(this::toView).collect(Collectors.toList());
    }

    @DeleteMapping("/delete/{containerName}/{fileName}")
    public void deleteFile(@PathVariable String containerName, @PathVariable String fileName) {
        azureStorageService.deleteFile(containerName, fileName);
    }

    private FileResponse toView(FileProperties properties) {
        String downloadUri = ServletUriComponentsBuilder.fromCurrentRequest().scheme("https")
            .replacePath("/" + PATH + "/shared/")
            .pathSegment(properties.getContainerName(), properties.getFileName())
            .queryParam("accessKey", properties.getAccessKey()).toUriString();

        return new FileResponse(properties, downloadUri);
    }
}
