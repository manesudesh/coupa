package ae.network.onboarding.docs.config.intercepters;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author walid.sewaify
 * @since 2021-01-06
 */
@Component
@Slf4j
public class AcquirerInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        String acquirer = request.getHeader("X-OCTOPUS-ACQUIRER");
        // allow request for internal communication (no acquirer is set)
        boolean allowRequest = acquirer == null || "NI".equals(acquirer);
        if (!allowRequest) {
            log.error("acquirer {} is not permitted to use this service", acquirer);
        }
        return allowRequest;
    }
}
