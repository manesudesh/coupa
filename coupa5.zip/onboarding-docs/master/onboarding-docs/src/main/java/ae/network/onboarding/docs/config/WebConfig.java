package ae.network.onboarding.docs.config;

import ae.network.onboarding.docs.config.intercepters.LoggingInterceptor;
import ae.network.onboarding.docs.config.intercepters.AcquirerInterceptor;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.ForwardedHeaderFilter;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author walid.sewaify
 * @since 15-Nov-20
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    /**
     * Bean for overriding remote host (if request comes through a proxy)
     */
    @Bean
    FilterRegistrationBean<ForwardedHeaderFilter> forwardedHeaderFilter() {
        FilterRegistrationBean<ForwardedHeaderFilter> bean = new FilterRegistrationBean<>();
        bean.setFilter(new ForwardedHeaderFilter());
        return bean;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new LoggingInterceptor());
        registry.addInterceptor(new AcquirerInterceptor());
    }
}
