package ae.network.onboarding.gateway;

import ae.network.onboarding.gateway.security.Role;
import ae.network.onboarding.gateway.security.TokenUtil;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.integration.ClientAndServer;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static org.mockserver.integration.ClientAndServer.startClientAndServer;
import static org.mockserver.matchers.Times.exactly;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

@SpringBootTest(webEnvironment = RANDOM_PORT)
class OctopusApiGatewayApplicationTests {
    private static final String LOGIN_URI = "/users/signin";
    private static final String APPLICATION_URL = "/onboarding/application";
    private static final int usersServicePort = 19012;
    private static final int applicationsServicePort = 19013;

    private static ClientAndServer usersServiceServer;
    private static ClientAndServer applicationServiceServer;

    @LocalServerPort
    private int port = 0;
    private WebTestClient webClient;

    @BeforeAll
    static void beforeClass() {
        usersServiceServer = startClientAndServer(usersServicePort);
        applicationServiceServer = startClientAndServer(applicationsServicePort);
        setUpApplicationPosting();
    }

    @AfterAll
    static void afterClass() {
        usersServiceServer.stop();
        applicationServiceServer.stop();
    }

    @BeforeAll
    private static void setUpApplicationPosting() {
        applicationServiceServer.when(request()
                .withMethod(HttpMethod.POST.name())
                .withPath(APPLICATION_URL), exactly(1))
                .respond(response()
                        .withStatusCode(200)
                        .withBody("Onboarded Successfully")
                        .withDelay(TimeUnit.MILLISECONDS, 100));
    }

    private static void setUpLogin(String password, int httpCode) {
        usersServiceServer.when(request()
                .withMethod(HttpMethod.POST.name())
                .withPath(LOGIN_URI).withQueryStringParameter("username", "admin")
                .withQueryStringParameter("password", password), exactly(1))
                .respond(response()
                        .withStatusCode(httpCode)
                        .withBody("Any Content")
                        .withDelay(TimeUnit.MILLISECONDS, 100));
    }

    @BeforeEach
    void setup() {
        String baseUri = "http://localhost:" + port;
        webClient = WebTestClient.bindToServer().responseTimeout(Duration.ofSeconds(10)).baseUrl(baseUri).build();
    }

    @Test
    void contextLoads() {
        webClient.get().uri("/get").exchange().expectStatus().isUnauthorized();
    }

    @Test
    void testSuccessfulLogin() {
        final String password = "correct";
        setUpLogin(password, 200);
        webClient.post().uri(uriBuilder -> uriBuilder
                .path(LOGIN_URI)
                .queryParam("username", "admin")
                .queryParam("password", password).build())
                .exchange().expectStatus().isOk();
    }

    @Test
    void testInvalidLogin() {
        final String password = "wrong";
        setUpLogin(password, 401);
        webClient.post().uri(uriBuilder -> uriBuilder
                .path(LOGIN_URI)
                .queryParam("username", "admin")
                .queryParam("password", password).build())
                .exchange().expectStatus().isUnauthorized();
    }

    @Test
    void testValidTokenAccess() {
        webClient.post().uri(APPLICATION_URL).header(HttpHeaders.AUTHORIZATION, "Bearer "
                + TokenUtil.createToken("admin", Role.CLIENT.id()))
                .exchange().expectStatus().isOk();
    }

    @Test
    void testInvalidRoleAccess() {
        webClient.post().uri(APPLICATION_URL).header(HttpHeaders.AUTHORIZATION, "Bearer "
                + TokenUtil.createToken("admin", Role.ADMIN.id()))
                .exchange().expectStatus().isForbidden();
    }

    @Test
    void testInvalidAccess() {
        webClient.post().uri(APPLICATION_URL).header(HttpHeaders.AUTHORIZATION, "Bearer Bee")
                .exchange().expectStatus().isUnauthorized();
    }

    @Test
    void testMissingTokenAccess() {
        webClient.post().uri(APPLICATION_URL)
                .exchange().expectStatus().isUnauthorized();
    }

}
