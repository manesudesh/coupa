package ae.network.onboarding.gateway.security;

/**
 * List of application authorities
 *
 * @author walid.sewaify
 * @since 11-02-2020
 */
public enum Role {
    ADMIN("ROLE_ADMIN"), CLIENT("ROLE_CLIENT"),
    NGO_REFUND_SERVICE("ROLE_NGO_REFUND_SERVICE"),
    GAMECHANGE_SERVICE("ROLE_GAMECHANGE_SERVICE");

    private final String id;

    Role(String id) {
        this.id = id;
    }

    public String id() {
        return id;
    }
}
