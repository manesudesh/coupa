package ae.network.onboarding.gateway.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.method.configuration.EnableReactiveMethodSecurity;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;
import reactor.core.publisher.Mono;


/**
 * @author Otto Success Joseph
 * @since 25 January 2020
 */
@Configuration
@EnableWebFluxSecurity
@EnableReactiveMethodSecurity
public class WebSecurity {

    private final SecurityContextRepository securityContextRepository;

    public WebSecurity(SecurityContextRepository securityContextRepository) {
        this.securityContextRepository = securityContextRepository;
    }

    /**
     * Security filter that pipes request based on authentication and authorization
     */
    @Bean
    public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http) {
        return http
                .addFilterAt(new LoggingFilter(), SecurityWebFiltersOrder.FIRST)
                .exceptionHandling()
                .authenticationEntryPoint((swe, e) -> Mono.fromRunnable(() -> {
                    swe.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                })).accessDeniedHandler((swe, e) -> Mono.fromRunnable(() -> {
                    swe.getResponse().setStatusCode(HttpStatus.FORBIDDEN);
                })).and()
                .csrf().disable()
                .formLogin().disable()
                .httpBasic().disable()
                .authenticationManager(securityContextRepository.getAuthenticationManager())
                .securityContextRepository(securityContextRepository)
                .authorizeExchange()
                .pathMatchers(HttpMethod.OPTIONS).permitAll()
                .pathMatchers(HttpMethod.POST, "/users/signin").permitAll()
                .pathMatchers(HttpMethod.GET, "/actuator/health").permitAll()
                .pathMatchers(HttpMethod.POST, "/jenkins/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers(HttpMethod.GET, "/jenkins/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers(HttpMethod.OPTIONS, "/jenkins/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers(HttpMethod.PUT, "/jenkins/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers(HttpMethod.GET, "/users/refresh").hasAuthority(Role.CLIENT.id())
                .pathMatchers("/users/**").hasAuthority(Role.ADMIN.id())
                .pathMatchers(HttpMethod.GET, "/files/shared/**").permitAll()
                .pathMatchers("/files/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers("/onboarding/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers("/data/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers("/reporting/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers("/amlock/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers("/norbloc/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers("/email/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers("/api/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers("/pos/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers("/email-service/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers("/dob-backend-test-automation/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers(
                    "/archived-storage",
                    "/archived-storage/login",
                    "/archived-storage/download",
                    "/archived-storage/download-all",
                    "/archived-storage/logout",
                    "/archived-storage/search",
                    "/archived-storage/css/**",
                    "/archived-storage/js/**"
                ).permitAll()
                .pathMatchers(HttpMethod.POST, "/onboarding-admin/auth/v1/login").permitAll()
                .pathMatchers(HttpMethod.GET, "/onboarding-admin/public/**").permitAll()
                .pathMatchers("/onboarding-admin/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers("/ngo-refund-service/**").hasAuthority(Role.NGO_REFUND_SERVICE.id())
                .pathMatchers("/gamechange-service/**").hasAuthority(Role.GAMECHANGE_SERVICE.id())
                .pathMatchers("/contract-generation-service/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers("/onboarding-salesforce/**").hasAuthority(Role.CLIENT.id())
                .pathMatchers("/contract-signing-service/**").hasAuthority(Role.CLIENT.id())
                .anyExchange()
                .authenticated()
                .and().build();
    }
}
