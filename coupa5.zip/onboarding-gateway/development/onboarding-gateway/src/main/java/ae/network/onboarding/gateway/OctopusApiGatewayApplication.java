package ae.network.onboarding.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OctopusApiGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(OctopusApiGatewayApplication.class, args);
    }

}
