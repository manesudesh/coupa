package ae.network.dob.adapter.base24.database.model.acquirer;

import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Success.Otto
 * @since 02-04-2020
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public abstract class AbstractAcquirer {
    private Acquirer acquirer;
}
