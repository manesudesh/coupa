package ae.network.dob.adapter.base24.database.repository;

import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
public interface ApplicationRequestRepository extends MongoRepository<ApplicationRequest, String> {

    Optional<ApplicationRequest> findByApplicationId(String applicationId);

    Optional<ApplicationRequest> findFirstByApplicationId(String applicationId);
}
