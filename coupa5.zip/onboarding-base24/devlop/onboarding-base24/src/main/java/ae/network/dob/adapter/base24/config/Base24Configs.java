package ae.network.dob.adapter.base24.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Data
@Configuration
public class Base24Configs {

    @Value("${base24adapter.dir.arch}")
    private String arch;

    @Value("${base24adapter.dir.in}")
    private String in;

    @Value("${base24adapter.dir.out}")
    private String out;

    @Value("${base24adapter.cron.file.export-schedule}")
    private List<String> exportSchedule;

    @Value("${base24adapter.cron.file.export-enabled}")
    private Boolean exportEnabled;

    @Value("${base24adapter.cron.file.import-enabled}")
    private Boolean importEnabled;

    @Value("${base24adapter.valid-merchant-segments}")
    private List<String> validMerchantSegments;

    @Value("${base24adapter.pay-by-qr-ids}")
    private List<String> payByQrIds;

    @Value("${base24adapter.pay-by-link-ids}")
    private List<String> payByLinkIds;

    @Value("${base24adapter.tab-to-pay-ids}")
    private List<String> tabToPayIds;

}
