package ae.network.dob.adapter.base24.exception;

import org.springframework.amqp.AmqpRejectAndDontRequeueException;

/**
 * Reject message altogether, and send it to failure queue for investigation.
 * Use when there is no way to recover the error.
 *
 * @author walid.sewaify
 * @since 2020-01-27
 */
public class MessageRejectionException extends AmqpRejectAndDontRequeueException {
    private final String applicationId;


    public MessageRejectionException(String message) {
        super(message);
        applicationId = "1";
    }

    public MessageRejectionException(String applicationId, String message) {
        super(message);
        this.applicationId = applicationId;
    }

    public MessageRejectionException(String applicationId, String message, Throwable cause) {
        super(message, cause);
        this.applicationId = applicationId;
    }

    public String getApplicationId() {
        return applicationId;
    }
}
