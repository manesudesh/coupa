package ae.network.dob.adapter.base24.service.acquirer;

import ae.network.dob.adapter.base24.database.model.acquirer.CurrencyAcr;
import ae.network.dob.adapter.base24.database.model.acquirer.EcomConfig;
import ae.network.dob.adapter.base24.database.model.acquirer.MerchantTypeConfig;
import ae.network.dob.adapter.base24.model.application.Merchant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @author Success.Otto
 * @since 27/03/2020
 */
@Service("ecomConfigService")
@Slf4j
public class EcomConfigServiceImpl implements MerchantTypeConfigService {

    @Override
    public String getFiId(Merchant merchant, MerchantTypeConfig merchantTypeConfig) {
        return getEcomConfig(merchantTypeConfig).getFiId();
    }

    /**
     * Ecom implementation of getting
     * PRD Template ID using the merchant
     * currency
     */
    @Override
    public String getPRDFTemplateID(Merchant merchant, MerchantTypeConfig acquirerConfig) {
        return getEcomConfig(acquirerConfig)
                .getCurrencyAcrDeviceDetails()
                .get(CurrencyAcr.valueOf(merchant.getMerchantCurrency()))
                .getPrdf();
    }

    /**
     * Ecom implementation of getting
     * PTD Template ID using the merchant
     * currency
     */
    @Override
    public String getPTDTemplateId(Merchant merchant, MerchantTypeConfig merchantTypeConfig) {
        return getEcomConfig(merchantTypeConfig)
                .getCurrencyAcrDeviceDetails()
                .get(CurrencyAcr.valueOf(merchant.getMerchantCurrency()))
                .getPtd();
    }

    /**
     * Ecom implementation of getting
     * CSECD Template ID using the merchant
     * currency
     */
    @Override
    public String getCSECDTemplateId(Merchant merchant, MerchantTypeConfig merchantTypeConfig) {
        return getEcomConfig(merchantTypeConfig)
                .getCurrencyAcrDeviceDetails()
                .get(CurrencyAcr.valueOf(merchant.getMerchantCurrency()))
                .getCsecd();
    }

    /**
     * Gets an instance of EconConfig from
     * parent MerchantTypeConfig
     */
    private EcomConfig getEcomConfig(MerchantTypeConfig merchantTypeConfig) {
        return (EcomConfig) merchantTypeConfig;
    }
}
