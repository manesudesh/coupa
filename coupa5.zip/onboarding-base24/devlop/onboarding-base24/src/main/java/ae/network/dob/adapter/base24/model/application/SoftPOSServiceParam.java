package ae.network.dob.adapter.base24.model.application;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class SoftPOSServiceParam extends MerchantService {

}
