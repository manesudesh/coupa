package ae.network.dob.adapter.base24.model.application;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class Terminal {


    @Size(max = 16, min = 8, message = "Terminal ID length is more than 16 or less than 8 characters")
    @NotBlank(message = "Terminal ID is blank")
    @Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Terminal ID contains invalid characters")
    @NotNull(message = "Terminal ID is null")
    private String terminalId;

    private boolean dccEnabled;

    private String terminalModel;

    @JsonIgnore
    private String merchantId;
    @JsonIgnore
    private String merchantCurrency;
    @JsonIgnore
    private ActionType actionType;


}
