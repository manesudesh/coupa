package ae.network.dob.adapter.base24.database.model.acquirer;

import lombok.Builder;
import lombok.Data;

/**
 * @author Success.Otto
 * @since 26/03/2020
 */
@Data
@Builder
public class DeviceDetails {
    /**
     * the template ID of the Merchant
     */
    private String prdf;
    /**
     * Template ID return the template ID of the terminal
     */
    private String ptd;
    /**
     *
     */
    private String csecd;

    private String eprd;
}
