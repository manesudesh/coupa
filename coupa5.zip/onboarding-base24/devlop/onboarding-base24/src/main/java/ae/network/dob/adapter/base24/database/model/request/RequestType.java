package ae.network.dob.adapter.base24.database.model.request;

public enum RequestType {
    ONBOARDING("A"), AMENDMENT("C"), MERCHANT_CLOSURE("D"), TERMINAL_CLOSURE("D"), SCREENING("S");

    private final String base24OpType;

    RequestType(String base24OpType) {
        this.base24OpType = base24OpType;
    }

    public String toString() {
        return this.base24OpType;
    }

}
