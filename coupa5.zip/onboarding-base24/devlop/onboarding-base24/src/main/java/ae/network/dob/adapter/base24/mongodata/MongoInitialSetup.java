package ae.network.dob.adapter.base24.mongodata;

import ae.network.dob.adapter.base24.database.model.acquirer.AcquirerConfig;
import ae.network.dob.adapter.base24.database.model.acquirer.ComplexAcquirer;
import ae.network.dob.adapter.base24.database.model.acquirer.CurrencyAcr;
import ae.network.dob.adapter.base24.database.model.acquirer.DeviceDetails;
import ae.network.dob.adapter.base24.database.model.acquirer.EcomConfig;
import ae.network.dob.adapter.base24.database.model.acquirer.MerchantTypeConfig;
import ae.network.dob.adapter.base24.database.model.acquirer.PosConfig;
import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import ae.network.dob.adapter.base24.database.model.templates.KeyMerchantTemplate;
import ae.network.dob.adapter.base24.model.application.MerchantType;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Creating mongodb initial data
 *
 * @author walid.sewaify
 * @author Success.Otto
 * @since 12-02-2020
 */
@ChangeLog(order = "001")
@Slf4j
public class MongoInitialSetup {

    private static final String KEY_MERCHANTS_TEMPLATES_JSON = "KEY_MERCHANTS_TEMPLATES.json";
    private static final String ADDITIONAL_MERCHANTS_TEMPLATES_JSON = "ADDITIONAL_MERCHANTS_TEMPLATES.json";

    @ChangeSet(order = "01", author = "octopus", id = "01-createDefaultConfiguration")
    public void createDefaultAdminUser(MongoTemplate mongoTemplate) {
        mongoTemplate.save(createNiConfig());
    }

    @ChangeSet(order = "02", author = "octopus", id = "02-createDefaultTemplates")
    public void createDefaultTemplates(MongoTemplate mongoTemplate) {
        saveKeyMerchantsDummyTemplates(mongoTemplate, KEY_MERCHANTS_TEMPLATES_JSON);
    }

    @ChangeSet(order = "03", author = "octopus", id = "03-addAdditionalKeyMerchantTemplae")
    public void addAdditionalKeyMerchantTemplae(MongoTemplate mongoTemplate) {
        saveKeyMerchantsDummyTemplates(mongoTemplate, ADDITIONAL_MERCHANTS_TEMPLATES_JSON);
    }

    @ChangeSet(order = "04", author = "octopus", id = "03-updateChainIds")
    public void updateChainIds(MongoTemplate mongoTemplate) {
        List<KeyMerchantTemplate> terminalTemplates = mongoTemplate.findAll(KeyMerchantTemplate.class);
        if (!CollectionUtils.isEmpty(terminalTemplates))
            for (KeyMerchantTemplate keyMernchantTemplate : terminalTemplates) {
                if (keyMernchantTemplate.getChainId() != null && !keyMernchantTemplate.getChainId().startsWith("200"))
                    keyMernchantTemplate.setChainId("200" + keyMernchantTemplate.getChainId());
                mongoTemplate.save(keyMernchantTemplate);
            }

    }

    @ChangeSet(order = "05", author = "octopus", id = "05-createTymeBanSsttings")
    public void createTymeBanSsttings(MongoTemplate mongoTemplate) {
        mongoTemplate.save(createTymeConfig());
    }

    private void saveKeyMerchantsDummyTemplates(MongoTemplate mongoTemplate, String dataFile) {
        try {
            ObjectMapper mapper = new ObjectMapper();

            String tidDefaultCardsJson = getFileContent(dataFile);
            List<KeyMerchantTemplate> terminalTemplates = mapper.readValue(tidDefaultCardsJson, new TypeReference<List<KeyMerchantTemplate>>() {
            });
            terminalTemplates.forEach(terminalTemplate -> {
                UUID uuid = UUID.randomUUID();
                terminalTemplate.setId(uuid.toString());
                mongoTemplate.save(terminalTemplate);
            });


        } catch (JsonProcessingException e) {
            log.error("Error Parsing json content", e);
        }
    }


    private AcquirerConfig createNiConfig() {

        EcomConfig ecomConfig = new EcomConfig();
        Map<CurrencyAcr, DeviceDetails> detailsMap = new HashMap<>();

        detailsMap.put(CurrencyAcr.AUD, DeviceDetails.builder().prdf("025036000000").ptd("43036000").csecd("").build());
        detailsMap.put(CurrencyAcr.USD, DeviceDetails.builder().prdf("002840000000").ptd("43840000").csecd("").build());
        detailsMap.put(CurrencyAcr.EUR, DeviceDetails.builder().prdf("007978000000").ptd("43978000").csecd("").build());
        detailsMap.put(CurrencyAcr.BHD, DeviceDetails.builder().prdf("013048000000").ptd("43048000").csecd("").build());
        detailsMap.put(CurrencyAcr.XAF, DeviceDetails.builder().prdf("103950000000").ptd("43950000").csecd("").build());
        detailsMap.put(CurrencyAcr.XOF, DeviceDetails.builder().prdf("069952000000").ptd("43952000").csecd("").build());
        detailsMap.put(CurrencyAcr.INR, DeviceDetails.builder().prdf("015356000000").ptd("43356000").csecd("").build());
        detailsMap.put(CurrencyAcr.CAD, DeviceDetails.builder().prdf("005124000000").ptd("43124000").csecd("").build());
        detailsMap.put(CurrencyAcr.EGP, DeviceDetails.builder().prdf("009818000000").ptd("43818000").csecd("").build());
        detailsMap.put(CurrencyAcr.GBP, DeviceDetails.builder().prdf("006826000000").ptd("43826000").csecd("").build());
        // detailsMap.put(CurrencyAcr.IRR,DeviceDetails.builder().prdf("ORG Required").ptd("4326400000").csecd("").build());
        detailsMap.put(CurrencyAcr.JOD, DeviceDetails.builder().prdf("010400000000").ptd("43400000").csecd("").build());
        detailsMap.put(CurrencyAcr.KWD, DeviceDetails.builder().prdf("021414000000").ptd("43414000").csecd("").build());
        detailsMap.put(CurrencyAcr.LBP, DeviceDetails.builder().prdf("026422000000").ptd("43422000").csecd("").build());
        detailsMap.put(CurrencyAcr.CHF, DeviceDetails.builder().prdf("008756000000").ptd("43756000").csecd("").build());
        detailsMap.put(CurrencyAcr.OMR, DeviceDetails.builder().prdf("014512000000").ptd("43512000").csecd("").build());
        detailsMap.put(CurrencyAcr.NAD, DeviceDetails.builder().prdf("221516000000").ptd("43516000").csecd("").build());
        detailsMap.put(CurrencyAcr.QAR, DeviceDetails.builder().prdf("024634000000").ptd("43634000").csecd("").build());
        detailsMap.put(CurrencyAcr.SAR, DeviceDetails.builder().prdf("012682000000").ptd("43682000").csecd("").build());
        detailsMap.put(CurrencyAcr.SGD, DeviceDetails.builder().prdf("043702000000").ptd("43702000").csecd("").build());
        detailsMap.put(CurrencyAcr.AED, DeviceDetails.builder().prdf("200000000000").ptd("43000000").csecd("").build());
        ecomConfig.setCurrencyAcrDeviceDetails(detailsMap);
        ecomConfig.setFiId("NGEN");
        ecomConfig.setEnabled(true);


        PosConfig posConfig = new PosConfig();
        posConfig.setFiId("NPOS");
        posConfig.setDeviceDetails(DeviceDetails.builder().prdf("200000000001").ptd("90000001").csecd("000090000001").build());
        posConfig.setEnabled(true);
        Map<MerchantType, MerchantTypeConfig> map = new HashMap<>();
        map.put(MerchantType.ECOM, ecomConfig);
        map.put(MerchantType.POS, posConfig);

        ComplexAcquirer complexAcquirer = new ComplexAcquirer(Acquirer.NI);
        complexAcquirer.setConfigs(map);

        return AcquirerConfig.builder()
                .orgId("MC75")
                .acquirer(complexAcquirer)
                .build();
    }

    private AcquirerConfig createTymeConfig() {
        EcomConfig ecomConfig = new EcomConfig();
        Map<CurrencyAcr, DeviceDetails> detailsMap = new HashMap<>();
        ecomConfig.setEnabled(true);

        List<CurrencyAcr> currencyList = new ArrayList<>(EnumSet.allOf(CurrencyAcr.class));

        for (CurrencyAcr currency : currencyList) {
//            (FIID, PRDF Template ID, PTD Template ID) for TymeBank ECOM-South African RAND(ZAR).
//								FIID: NGTM
//								TEMPLATE MID(PRDF): 451710000000
//								TEMPLATE TID (PTD): 57100000
            detailsMap.put(currency, DeviceDetails.builder().prdf("451710000000").ptd("57100000").csecd("000057100000").build());
        }

        ecomConfig.setCurrencyAcrDeviceDetails(detailsMap);
//        CSECD is not required as we are not onboarding TYME BANK SOFT POS TID
        ecomConfig.setFiId("NGTM");

        PosConfig posConfig = new PosConfig();
//        (FIID, PRDF Template ID, PTD Template ID, CSECD Template ID?) for TymeBank SoftPOS.
//								TEMPLATE TID (PTD and CSECD) is not required as we are not onboarding TYME BANK SOFT POS TID
//								TEMPLATE MID (PRDF): 451000000014
//								FIID: TMBK
        posConfig.setFiId("TMBK");
        posConfig.setDeviceDetails(DeviceDetails.builder().prdf("451000000014").ptd("90400000").csecd("000090400000").build());
        posConfig.setEnabled(true);

        Map<MerchantType, MerchantTypeConfig> map = new HashMap<>();
        map.put(MerchantType.ECOM, ecomConfig);
        map.put(MerchantType.POS, posConfig);

        ComplexAcquirer complexAcquirer = new ComplexAcquirer(Acquirer.TYME);
        complexAcquirer.setConfigs(map);

        return AcquirerConfig.builder()
                .orgId("001")
                .acquirer(complexAcquirer)
                .build();

    }

    private String getFileContent(String resourceName) {

        try (InputStream inputStream = new ClassPathResource("data/" + resourceName).getInputStream()) {
            return IOUtils.toString(inputStream, Charset.defaultCharset());
        } catch (IOException e) {
            log.error("Error processing currencies data File", e);
        }
        return "";
    }
}