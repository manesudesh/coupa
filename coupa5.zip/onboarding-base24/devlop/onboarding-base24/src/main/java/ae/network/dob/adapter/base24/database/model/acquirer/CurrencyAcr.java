package ae.network.dob.adapter.base24.database.model.acquirer;

/**
 * @author Success.Otto
 * @since 26/03/2020
 */
public enum CurrencyAcr {
    AUD,
    USD,
    EUR,
    BHD,
    XAF,
    XOF,
    INR,
    CAD,
    EGP,
    GBP,
    IRR,
    JOD,
    KWD,
    LBP,
    CHF,
    NAD,
    OMR,
    QAR,
    SAR,
    SGD,
    AED,
    ZAR
}