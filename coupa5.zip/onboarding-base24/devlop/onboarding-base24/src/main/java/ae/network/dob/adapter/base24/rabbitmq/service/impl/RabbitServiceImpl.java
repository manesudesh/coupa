package ae.network.dob.adapter.base24.rabbitmq.service.impl;

import ae.network.dob.adapter.base24.rabbitmq.config.RabbitQueue;
import ae.network.dob.adapter.base24.rabbitmq.message.QueueMessage;
import ae.network.dob.adapter.base24.rabbitmq.service.RabbitService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Random;

import static ae.network.dob.adapter.base24.rabbitmq.config.RabbitExchange.ONBOARDING;
import static ae.network.dob.adapter.base24.rabbitmq.config.RabbitExchange.ONBOARDING_RETRY;
import static ae.network.dob.adapter.base24.rabbitmq.message.QueueMessage.DELAY_HEADER;


@Service
@Slf4j
public class RabbitServiceImpl implements RabbitService {
    private final RabbitTemplate rabbitTemplate;
    private final int defaultRetryInSeconds;

    public RabbitServiceImpl(RabbitTemplate rabbitTemplate,
                             @Value("${octopus.consumer.error-retry-in-seconds}") int defaultRetryInSeconds) {
        this.rabbitTemplate = rabbitTemplate;
        this.defaultRetryInSeconds = defaultRetryInSeconds;

    }

    @Override
    public void sendMessage(RabbitQueue queue, QueueMessage message) {
        logQueueMessage(queue, message);
        MessagePostProcessor corrIdSetter = m -> {
            m.getMessageProperties().setCorrelationId(message.getApplicationId());
            return m;
        };
        rabbitTemplate.convertAndSend(ONBOARDING.getExchangeName(), getDefaultRoutingKey(queue), message, corrIdSetter);
    }

    @Override
    public void retryMessage(Message message, int seconds) {
        // add randomness (uo to 10 seconds) to better handle optimistic lock failed cases
        int random = new Random().nextInt(10000);
        int delay = seconds * 1000 + random;
        MessageProperties messageProperties = message.getMessageProperties();
        messageProperties.setDelay(delay);
        log.info("Scheduling retry in {} seconds to message {}", delay / 1000, messageProperties);
        rabbitTemplate.send(ONBOARDING_RETRY.getExchangeName(), messageProperties.getReceivedRoutingKey(), message);
    }

    @Override
    public void retryMessage(Message message) {
        MessageProperties messageProperties = message.getMessageProperties();
        Object currentDelayHeader = messageProperties.getHeader(DELAY_HEADER);
        int seconds = currentDelayHeader == null ? defaultRetryInSeconds : Integer.parseInt(currentDelayHeader.toString());

        retryMessage(message, seconds);
    }

    private void logQueueMessage(RabbitQueue queue, QueueMessage message) {
        try {
            log.info("Sending to queue {} message {}", queue.getQueueName(), new ObjectMapper().writeValueAsString(message));
        } catch (JsonProcessingException ignored) {
        }
    }

    private String getDefaultRoutingKey(RabbitQueue queue) {
        if (queue.getRoutingKeys().isEmpty()) {
            throw new AmqpException("Invalid destination");
        }
        return queue.getRoutingKeys().get(0);
    }
}
