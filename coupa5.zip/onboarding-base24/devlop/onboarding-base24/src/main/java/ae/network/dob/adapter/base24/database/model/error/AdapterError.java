package ae.network.dob.adapter.base24.database.model.error;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author : Yousry
 * @version :1.0
 */

@Data
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class AdapterError {

    private String name;
    private String code;
    private String message;
}
