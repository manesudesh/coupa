package ae.network.dob.adapter.base24.service.file;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.time.Clock;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import lombok.Setter;
import org.springframework.stereotype.Service;

import ae.network.dob.adapter.base24.config.Base24Configs;
import ae.network.dob.adapter.base24.database.model.request.Base24File;
import lombok.extern.slf4j.Slf4j;

import static ae.network.dob.adapter.base24.database.model.request.FileType.EPRD;
import static ae.network.dob.adapter.base24.service.file.EprdGenerationService.EPRD_RECORD_TYPE;

/**
 * @author WaseemAARI
 *
 */
@Slf4j
@Service
public class Base24FileManager {

	@Setter
	private Clock clock = Clock.systemDefaultZone();

	private final Base24Configs base24Configs;

	public Base24FileManager(Base24Configs base24Configs) {
		this.base24Configs = base24Configs;
	}

	public File exportFileToBase24Dir(Base24File base24FileEntity,String fileNumber) throws IOException {

		log.info("exportFileToBase24Dir started FileContent :{}", base24FileEntity.getFileContent());
		log.info("Current Request File Number {}", fileNumber);

		if(!exportDirEmpty(base24FileEntity, base24FileEntity.getAcquirer(),fileNumber)) {
			log.warn("Export Directory for acquirer {}, contains other non processed files",
					base24FileEntity.getAcquirer());
		}

		File base24File = getCurrentFileName(base24FileEntity, base24FileEntity.getAcquirer(),fileNumber);
		FileOutputStream fileOutputStream = null;
		OutputStreamWriter filewriter = null;
		String lineSeperator = System.lineSeparator();
		try {

			if (base24File.exists()) {
				log.info("File {} still in Directory, appending new records to the existing file..",
						base24File.getAbsolutePath());
				fileOutputStream = new FileOutputStream(base24File, true);
			} else {
				log.info("File {} is not exists, records will be added to a new File",
						base24File.getAbsolutePath());
				fileOutputStream = new FileOutputStream(base24File);
			}

			filewriter = new OutputStreamWriter(fileOutputStream);
			filewriter.append(base24FileEntity.getFileContent() + lineSeperator);
			base24FileEntity.setFileName(base24File.getName());
			base24FileEntity.setExported(Boolean.TRUE);
		} finally {

			log.info("Closing FileOutput Streams");
			if (filewriter != null) {
				filewriter.close();
			}
			if (fileOutputStream != null) {
				fileOutputStream.close();
			}
		}

		return base24File;
	}

	/**
	 * Check if specific Acquire export Directory contains unprocessed files.
	 */
	private boolean exportDirEmpty(Base24File base24File, String acquirer,String fileNumber) {

		log.info("Check if Acquirer {} export directory contains unprocessed files", acquirer);

		File currentFile = getCurrentFileName(base24File, acquirer,fileNumber);
		log.info("Exporting File number {} for Acquirer {}",fileNumber,acquirer);
		File[] dirFiles = new File(currentFile.getParent()).listFiles();

		if (dirFiles == null || dirFiles.length == 0) {
			return true;
		}

		if (dirFiles.length == 1 && dirFiles[0].getName().equals(currentFile.getName())) {
			return true;
		}

		log.warn("{} export directory contains unprocessed files ", acquirer);

		return false;
	}

	public File getCurrentFileName(Base24File base24File, String acquirer,String fileNumber) {
		log.info("Exporting File number {} for Acquirer {}",fileNumber,acquirer);
		Date date = Date.from(clock.instant());
		Calendar cal = Calendar.getInstance(TimeZone.getDefault());
		cal.setTime(date);
		int month = cal.get(Calendar.MONTH) + 1; // `+1` to align with human-friendly month numeration
		int day = cal.get(Calendar.DAY_OF_MONTH);

		String fileNamePrefix = base24File.getFileType() == EPRD
				? EPRD_RECORD_TYPE.toLowerCase()
				: "rf";

		return new File(base24Configs.getIn()+acquirer + File.separator+fileNamePrefix + (month < 10 ? "0" + month : month) + (day < 10 ? "0" + day : day)
				+ fileNumber);
	}
}
