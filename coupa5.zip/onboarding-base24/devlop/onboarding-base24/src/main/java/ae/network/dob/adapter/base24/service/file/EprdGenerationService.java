package ae.network.dob.adapter.base24.service.file;

import ae.network.dob.adapter.base24.common.Base24FileGenerationHelper;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.database.model.request.Base24File;
import ae.network.dob.adapter.base24.database.model.request.FileType;
import ae.network.dob.adapter.base24.database.model.response.Base24Response;
import ae.network.dob.adapter.base24.database.repository.Base24ResponseFileRepository;
import ae.network.dob.adapter.base24.model.application.Merchant;
import ae.network.dob.adapter.base24.model.application.MerchantType;
import ae.network.dob.adapter.base24.model.application.base24.EprdRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.encoder.org.apache.commons.lang.StringUtils;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.StringJoiner;

@Component
@Slf4j
@RequiredArgsConstructor
public class EprdGenerationService {

    private final Base24ResponseFileRepository base24ResponseFileRepository;
    private final Base24FileGenerationHelper base24FileGenerationHelper;
    /**
     * {@link EprdRequest} signature.
     * Specification: https://networkinternational.atlassian.net/wiki/spaces/NAACE/pages/2567733567/EPRD+record+structure
     */
    public static final String EPRD_RECORD_TYPE = "EP";

    /**
     * Default value of Brighterion flag in {@link EprdRequest}.
     */
    private static final String DEFAULT_BRIGHTERION_FLAG = "3";

    /**
     * Default value of PREAUTH_DEST in {@link EprdRequest}.
     */
    private static final String DEFAULT_PREAUTH_DEST = "Q6-BRPR";

    /**
     * Default value of PREAUTH_DEST in {@link EprdRequest}.
     */
    private static final String DEFAULT_POSTAUTH_DEST = "Q6-BRPO";

    /**
     * Default operation code in {@link EprdRequest}.
     */
    private static final String ADD_OPERATION_CODE = "A";
    private static final String CHANGE_OPERATION_CODE = "U";

    /**
     * Default FIID in {@link EprdRequest}.
     */
    private static final String NPOS_FIID = "NPOS";

    /**
     * Default FIID in {@link EprdRequest}.
     */
    private static final String NGEN_FIID = "NGEN";

    /**
     * Default Override MCC flag in {@link EprdRequest}.
     */
    private static final String DEFAULT_OVERRIDE_MCC = "N";

    /**
     * Size of the card type in {@link EprdRequest}.
     */
    private static final Integer CARD_TYPE_NUMBER = 30;

    /**
     * Size of the MCC in {@link EprdRequest}.
     */
    private static final Integer MCC_NUMBER = 30;

    /**
     * Size of the PROC CODE in {@link EprdRequest}.
     */
    private static final Integer PROC_CODE_NUMBER = 20;

    /**
     * Default value of the AFT Flag in {@link EprdRequest}.
     */
    private static final String DEFAULT_AFT_FLAG = "N";

    /**
     * Default BAI in {@link EprdRequest}.
     */
    private static final String DEFAULT_BAI = "FP";

    /**
     * Default MCC value in {@link EprdRequest}.
     */
    private static final String DEFAULT_MCC = "";

    /**
     * Default TXH PATH in {@link EprdRequest}.
     */
    private static final String DEFAULT_TXN_PATH = "";

    /**
     * Number of SRV in {@link EprdRequest}.
     */
    private static final Integer SRV_AND_SM_NUMBER = 40;

    /**
     * Default PROC codes in {@link EprdRequest}.
     */
    private static final List<String> DEFAULT_PROC_CODES = Arrays.asList("10", "11", "12", "14", "21");

    /**
     * Default DECLINED flag value in {@link EprdRequest}.
     */
    private static final String DEFAULT_DECLINED = "D";

    /**
     * Default TIMEOUT value in {@link EprdRequest}.
     */
    private static final String DEFAULT_TIMEOUT = "B";

    /**
     * Value of the BNPL-ENABLE flag in {@link EprdRequest}.
     */
    private static final String BNPL_ENABLE = "Y";

    /**
     * Value of the BNPL-ENABLE flag in {@link EprdRequest}.
     */
    private static final String BNPL_DISABLE = "N";

    /**
     * Default Base24 file cell value in case if not values present.
     */
    private static final String DEFAULT_VALUE = "";

    /**
     * Default value of the BNPL-ENABLE and BNPL-MAID in {@link EprdRequest}.
     */
    private static final String DEFAULT_BNPL_VALUE = " ";

    public Base24File generateEprdBase24File(ApplicationRequest applicationRequest,
                                             Merchant merchant) {

        log.info("generate EPRD File started for ApplicationID {}, Merchant {}",
                applicationRequest.getApplicationId(), merchant.getMerchantId());

        EprdRequest eprdRequest = generateEprdFile(merchant);

        String eprdFileContent = buildEprdContent(eprdRequest);

        log.info("EPRD file generation finished for ApplicationID {}, Merchant {}, content: {}",
                applicationRequest.getApplicationId(), merchant.getMerchantId(), eprdFileContent);

        return Base24File
                .builder()
                .fileType(FileType.EPRD)
                .applicationId(applicationRequest.getApplicationId())
                .fileContent(eprdFileContent)
                .recordId(merchant.getMerchantId())
                .exported(Boolean.FALSE)
                .completed(Boolean.FALSE)
                .acquirer(applicationRequest.getAcquirer().name())
                .build();
    }

    EprdRequest generateEprdFile(Merchant merchant) {

        String opType = buildOpType(merchant);

        List<String> cardTypes = new ArrayList<>();
        extendToSize(cardTypes, CARD_TYPE_NUMBER);

        List<String> mccs = new ArrayList<>(MCC_NUMBER);
        extendToSize(mccs, MCC_NUMBER);

        List<String> srvAndSmCodes = new ArrayList<>();
        extendToSize(srvAndSmCodes, SRV_AND_SM_NUMBER);

        List<String> procCodes = new ArrayList<>(DEFAULT_PROC_CODES);
        extendToSize(procCodes, PROC_CODE_NUMBER);

        String bnplEnable = getBnplEnable(merchant, opType);
        String bnplMaid = getBnplMaid(merchant);

        String tti = buildTti(merchant);
        String countryOrigin = base24FileGenerationHelper.getCountryOfOrigin(merchant.getCountryOrigin());
        
        String mc_moneysend_enable = base24FileGenerationHelper.appendSuffix("", ' ', 1);
        String mc_moneysend_TTI = base24FileGenerationHelper.appendSuffix("", ' ', 3);
        String mc_moneysend_MCC = base24FileGenerationHelper.appendSuffix("", ' ', 4);
        String mc_moneysend_DebitCard_enable = base24FileGenerationHelper.appendSuffix("", ' ', 1);
        String mc_moneysend_CreditCard_enable = base24FileGenerationHelper.appendSuffix("", ' ', 1);
        String mc_moneysend_PrepaidCard_enable = base24FileGenerationHelper.appendSuffix("", ' ', 1);
        String mc_moneysend_TransactionPath = base24FileGenerationHelper.appendSuffix("", ' ', 1);

        return EprdRequest.builder()
                .recType(EPRD_RECORD_TYPE)
                .opType(opType)
                .retailedId(merchant.getMerchantId())
                .fiid(getFiid(merchant))
                .overrideMcc(DEFAULT_OVERRIDE_MCC)
                .aft(DEFAULT_AFT_FLAG)
                .cardType(cardTypes)
                .mcc(mccs)
                .bai(DEFAULT_BAI)
                .mcc2(DEFAULT_MCC)
                .txnPath(DEFAULT_TXN_PATH)
                .srvAndSmFlags(srvAndSmCodes)
                .procCode(procCodes)
                .brighterionFlag(DEFAULT_BRIGHTERION_FLAG)
                .declined(DEFAULT_DECLINED)
                .timeout(DEFAULT_TIMEOUT)
                .preauthDest(DEFAULT_PREAUTH_DEST)
                .postauthDest(DEFAULT_POSTAUTH_DEST)
                .bnplEnable(bnplEnable)
                .bnplMaid(bnplMaid)
                .visaInstlSppt(merchant.isVisaInstallmentsEnabled() ? "Y" : (opType.equals("U") ? "" : "N"))
                .tti(tti)
                .countryOrigin(countryOrigin)
                .mcMoneysendEnable(mc_moneysend_enable)
                .mcMoneysendTTI(mc_moneysend_TTI)
                .mcMoneysendMCC(mc_moneysend_MCC)
                .mcMoneysendDebitCardEnable(mc_moneysend_DebitCard_enable)
                .mcMoneysendCreditCardEnable(mc_moneysend_CreditCard_enable)
                .mcMoneysendPrepaidCardEnable(mc_moneysend_PrepaidCard_enable)
                .mcMoneysendTransactionPath(mc_moneysend_TransactionPath)
                .build();
    }

    private String buildOpType(Merchant merchant) {
        boolean atLeastOneRecordSuccess = base24ResponseFileRepository.findByRecordId(merchant.getMerchantId())
                .stream()
                .filter(Base24Response::getStatus)
                .map(Base24Response::getFileType)
                .map(successResponseType -> successResponseType.equals(FileType.EPRD.toString()))
                .findFirst().isPresent();

        return atLeastOneRecordSuccess ? CHANGE_OPERATION_CODE : ADD_OPERATION_CODE;
    }

    private String getBnplEnable(Merchant merchant, String buildOpType) {
        boolean isMcippDisabled = merchant.getMcippOptIn() == null
                && merchant.getMaid() == null;
        boolean isAmendment = buildOpType != null && buildOpType.equalsIgnoreCase(CHANGE_OPERATION_CODE);

        if (isMcippDisabled) {
            if (isAmendment) { //request is for amendment
                return DEFAULT_BNPL_VALUE;
            }

            return BNPL_DISABLE;
        }

        if (merchant.getMcippOptIn() != null) {
            return merchant.getMcippOptIn() ? BNPL_DISABLE : BNPL_ENABLE;
        }

        return DEFAULT_BNPL_VALUE;
    }

    private String getBnplMaid(Merchant merchant) {
        if (merchant.getMcippOptIn() == null
                || merchant.getMcippOptIn()) {
            return DEFAULT_BNPL_VALUE;
        }

        return merchant.getMaid();
    }

    private String getFiid(Merchant merchant) {
        MerchantType merchantType = merchant.getMerchantType();
        if (merchantType.equals(MerchantType.POS)
                || merchantType.equals(MerchantType.SoftPOS)
                || merchantType.equals(MerchantType.PaybyQR)) {
            return NPOS_FIID;
        } else if (merchantType.equals(MerchantType.ECOM)
                || merchantType.equals(MerchantType.PaybyLink)) {
            return NGEN_FIID;
        }

        throw new RuntimeException("No FIID found for merchant type " + merchantType);
    }

    String buildTti(Merchant merchant) {
        Integer mcc = merchant.getMcc();
        String securityNature = merchant.getSecurityNature();
        if (securityNature == null) {
            return StringUtils.EMPTY;
        }

        if (securityNature.equals("CRYPTOCURRENCY")
                && mcc == 6051) {
            return "7";
        }

        if (securityNature.equals("HIGH_RISK") && mcc == 6211) {
            return "S";
        }

        return StringUtils.EMPTY;
    }

    private String buildEprdContent(EprdRequest eprdRequest) {
        StringJoiner recordBuilder = new StringJoiner(Base24FileGenerationService.BASE24_FILE_SEPARATOR);

        recordBuilder.add(eprdRequest.getRecType());
        recordBuilder.add(eprdRequest.getOpType());
        recordBuilder.add(eprdRequest.getRetailedId());
        recordBuilder.add(eprdRequest.getFiid());
        recordBuilder.add(eprdRequest.getOverrideMcc());
        recordBuilder.add(eprdRequest.getAft());
        eprdRequest.getCardType().forEach(recordBuilder::add);
        eprdRequest.getMcc().forEach(recordBuilder::add);
        recordBuilder.add(eprdRequest.getBai());
        recordBuilder.add(eprdRequest.getMcc2());
        recordBuilder.add(eprdRequest.getTxnPath());
        eprdRequest.getSrvAndSmFlags().forEach(recordBuilder::add);
        eprdRequest.getProcCode().forEach(recordBuilder::add);
        recordBuilder.add(eprdRequest.getBrighterionFlag());
        recordBuilder.add(eprdRequest.getDeclined());
        recordBuilder.add(eprdRequest.getTimeout());
        recordBuilder.add(eprdRequest.getPreauthDest());
        recordBuilder.add(eprdRequest.getPostauthDest());
        recordBuilder.add(eprdRequest.getBnplEnable());
        recordBuilder.add(eprdRequest.getBnplMaid());
        recordBuilder.add(eprdRequest.getVisaInstlSppt());
        recordBuilder.add(eprdRequest.getTti());
        recordBuilder.add(eprdRequest.getCountryOrigin());
        recordBuilder.add(eprdRequest.getMcMoneysendEnable());
        recordBuilder.add(eprdRequest.getMcMoneysendTTI());
        recordBuilder.add(eprdRequest.getMcMoneysendMCC());
        recordBuilder.add(eprdRequest.getMcMoneysendDebitCardEnable());
        recordBuilder.add(eprdRequest.getMcMoneysendCreditCardEnable());
        recordBuilder.add(eprdRequest.getMcMoneysendPrepaidCardEnable());
        recordBuilder.add(eprdRequest.getMcMoneysendTransactionPath());

        return recordBuilder + Base24FileGenerationService.BASE24_FILE_SEPARATOR;
    }

    private void extendToSize(Collection<String> values, int expectedSize) {
        while (values.size() < expectedSize) {
            values.add(DEFAULT_VALUE);
        }
    }
}
