package ae.network.dob.adapter.base24.service.acquirer;

import ae.network.dob.adapter.base24.database.model.acquirer.AbstractAcquirer;
import ae.network.dob.adapter.base24.model.application.Merchant;

/**
 * @author Success.Otto
 * @since 01-04-2020
 */
public interface AcquirerService {
    /**
     * Gets FiId of merchant
     */
    String getFiId(Merchant merchant, AbstractAcquirer abstractAcquirer);

    /**
     * Gets PRDF Template Id of merchant
     */
    String getPRDFTemplateId(Merchant merchant, AbstractAcquirer abstractAcquirer);

    /**
     * Gets PTD Template Id of merchant
     */
    String getPTDTemplateId(Merchant merchant, AbstractAcquirer abstractAcquirer);
}
