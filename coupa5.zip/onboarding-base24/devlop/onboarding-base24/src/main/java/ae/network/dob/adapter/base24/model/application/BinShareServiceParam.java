package ae.network.dob.adapter.base24.model.application;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author Waseem
 * @version 1.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BinShareServiceParam extends MerchantService {

    @NotNull(message = "binShareOffers is Empty")
    private List<BinShareOffer> binShareOffers;

}
