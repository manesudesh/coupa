package ae.network.dob.adapter.base24.common;

import ae.network.dob.adapter.base24.config.Base24Configs;
import ae.network.dob.adapter.base24.database.model.acquirer.AcquirerConfig;
import ae.network.dob.adapter.base24.database.model.acquirer.ComplexAcquirer;
import ae.network.dob.adapter.base24.database.model.acquirer.EcomConfig;
import ae.network.dob.adapter.base24.database.model.acquirer.MerchantTypeConfig;
import ae.network.dob.adapter.base24.database.model.acquirer.PosConfig;
import ae.network.dob.adapter.base24.database.model.cards.MerchantTemplate;
import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.database.model.request.FileType;
import ae.network.dob.adapter.base24.database.model.templates.KeyMerchantTemplate;
import ae.network.dob.adapter.base24.database.repository.MerchantTemplateRepository;
import ae.network.dob.adapter.base24.model.application.AcceptedCardParam;
import ae.network.dob.adapter.base24.model.application.Address;
import ae.network.dob.adapter.base24.model.application.Application;
import ae.network.dob.adapter.base24.model.application.BinShareOffer;
import ae.network.dob.adapter.base24.model.application.CardSchema;
import ae.network.dob.adapter.base24.model.application.Merchant;
import ae.network.dob.adapter.base24.model.application.MerchantType;
import ae.network.dob.adapter.base24.model.application.Terminal;
import ae.network.dob.adapter.base24.model.application.amendment.AmendmentType;
import ae.network.dob.adapter.base24.service.acquirer.AcquirerComponent;
import ae.network.dob.adapter.base24.service.rpc.LookupService;
import ae.network.dob.adapter.base24.service.template.KeyMerchantTemplateService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.StringJoiner;

/**
 * @author Waseem
 * @author Success.Otto
 * @since 26/03/2020
 */
@Slf4j
@AllArgsConstructor
@Component
public class Base24FileGenerationHelper {

    private static final String ORG_USD = "002 (USD)";

    /**
     * Injection of acquirer type config component for
     * getting abstracted acquirer config details
     */
    @Qualifier("acquirerComponent")
    private final AcquirerComponent acquirerComponent;

    private LookupService lookupService;

    private MerchantTemplateRepository merchantTemplateRepository;

    private KeyMerchantTemplateService keyMerchantTemplateService;

    private Base24Configs base24Configs;

    private final int PLACEHOLDERS_LIMIT = 30;

    /**
     * Gets FIID of specified acquirer.
     */
    public String getFiId(Application application, Merchant merchant, Acquirer runningBank) {

        log.info("getFIID for Merchant: {}, and Acquirer: {} started.", merchant.getMerchantId(), runningBank.name());

//        Optional<KeyMerchantTemplate> merchantTemplateOptional = getMerchantTemplate(runningBank, application, merchant);
//        if(merchantTemplateOptional.isPresent())
//        	return merchantTemplateOptional.get().getFiid();
//
        if (validateMerchant(merchant, runningBank)) {
            return "";
        }

        return acquirerComponent.getFiId(merchant, runningBank);
    }


    /**
     * Gets PRdFTemplateID from underlying acquirer config
     */
    public String getPRDFTemplateId(Application application, Merchant merchant, Acquirer runningBank) {

        log.info("getPRDFTemplateID for Merchant: {}, and Acquierer: {} started.", merchant.getMerchantId(),
                runningBank.name());

//        Optional<KeyMerchantTemplate> merchantTemplateOptional = getMerchantTemplate(runningBank, application, merchant);
//        if(merchantTemplateOptional.isPresent())
//        	return merchantTemplateOptional.get().getDummyMID();

        if (validateMerchant(merchant, runningBank)) {
            return "";
        }

        return acquirerComponent.getPRDFTemplateId(merchant, runningBank);
    }


    private Optional<KeyMerchantTemplate> getMerchantTemplate(Acquirer acquirer, Application application, Merchant merchant) {

        if (acquirer != Acquirer.NI || merchant.getMerchantType() == MerchantType.ECOM)
            return Optional.empty();

        if ("USD".equals(merchant.getMerchantCurrency())) {
            return keyMerchantTemplateService.findMerchantTemplateByOrganizationName(ORG_USD);

        }

        if (validMerchantSegment(merchant.getMerchantSegment())) {
            return keyMerchantTemplateService.findMerchantTemplateBySegment(merchant.getMerchantSegment());

        }

        return Optional.empty();

    }


    /**
     * Gets PTDTemplateId from the underlying acquirer config
     */
    public String getPTDTemplateId(Application application, Merchant merchant, Acquirer runningBank) {

        log.info("getPTDTemplateId for Merchant: {}, and Acquierer: {} started.", merchant.getMerchantId(),
                runningBank.name());


//        Optional<KeyMerchantTemplate> merchantTemplateOptional = getMerchantTemplate(runningBank, application, merchant);
//        if(merchantTemplateOptional.isPresent())
//        	return merchantTemplateOptional.get().getDummyTID();
//
        if (validateMerchant(merchant, runningBank)) {
            return "";
        }

        return acquirerComponent.getPTDTemplateId(merchant, runningBank);
    }


    /**
     * Gets CSECDTemplateId from the underlying acquirer config
     */
    public String getCSECDTemplateId(Application application, Merchant merchant, Acquirer runningBank) {

        log.info("getCSECDTemplateId for Merchant: {}, and Acquierer: {} started.", merchant.getMerchantId(),
                runningBank.name());

//        Optional<KeyMerchantTemplate> merchantTemplateOptional = getMerchantTemplate(runningBank, application, merchant);
//        if(merchantTemplateOptional.isPresent())
//        	return merchantTemplateOptional.get().getDummyTID();

        if (validateMerchant(merchant, runningBank)) {
            return "";
        }

        return acquirerComponent.getCSECDTemplateId(merchant, runningBank);
    }

    public String getMerchantCardTypesStr(Merchant merchant, String templateId, FileType fileType) {

        log.info("getMerchantCardTypesStr for Merchant: {} started.", merchant.getMerchantId());
        List<CardSchema> cardSchemes = new ArrayList<>(buildCardSchemsList(merchant, templateId));

        if (merchant.getConfigurations() == null || merchant.getConfigurations().getAcceptedCardSchemes() == null) {
            if (fileType == FileType.PRDF)
                return CardSchema.UK + "|" + getEmptyPlaceHolders(PLACEHOLDERS_LIMIT);
            else
                return CardSchema.UK + "|" + getEmptyPlaceHolders(PLACEHOLDERS_LIMIT - 2);
        }

        StringJoiner cardTypes = new StringJoiner("|");

        if (cardSchemes.stream()
                .noneMatch(cardParam -> (cardParam != null && cardParam.equals(CardSchema.UK))))
            cardSchemes.add(0, CardSchema.UK);

        for (int i = 0; i < PLACEHOLDERS_LIMIT; i++) {
            if (i > cardSchemes.size() - 1) {
                cardTypes.add("");
            } else {
                CardSchema schema = cardSchemes.get(i);
                cardTypes.add(schema != null ? schema.toString() : "");
            }
        }

        log.info("Merchant Card Types :{}", cardTypes);
        return cardTypes.toString();
    }

    public CharSequence getBinShareStr(List<BinShareOffer> binShareOffers) {

        StringJoiner binShareStr = new StringJoiner("|");
        for (int i = 0; i < 30; i++) {
            if (i > binShareOffers.size() - 1) {
                binShareStr.add("");
            } else {
                BinShareOffer binShareOffer = binShareOffers.get(i);
                String binCode = binShareOffer.getBinShare();
                String offerId = binShareOffer.getOfferId();
                binShareStr.add(
                        (StringUtils.isEmpty(binCode) ? "" : binCode)
                                + (StringUtils.isEmpty(offerId) ? "" : offerId));
            }
        }

        return binShareStr.toString();
    }

    /**
     * generated Empty place holders,
     * needed in case the needed values not available
     */
    public String getEmptyPlaceHolders(int count) {
        char c = '|';
        char[] repeat = new char[count];
        Arrays.fill(repeat, c);
        return new String(repeat);
    }

    public Boolean validAmendment(Merchant merchant) {
        List<String> merchantAmendmentList = merchant.getAmendmentList();
        return validAmendment(merchantAmendmentList);
    }

    public Boolean validAmendment(List<String> merchantAmendmentList) {

        if (merchantAmendmentList == null || merchantAmendmentList.isEmpty())
            return false;

        List<AmendmentType> validMerchantAmendments = Arrays
                .asList(AmendmentType.ACCEPTED_CARDS, AmendmentType.TERMINAL_ACCEPTED_CARDS, AmendmentType.ADDING_TERMINALS,
                        AmendmentType.ADDRESS, AmendmentType.MCC, AmendmentType.MERCHANT_NAME, AmendmentType.LEGAL_NAME,
                        AmendmentType.COUNTRY_ORIGIN, AmendmentType.FEES);

        return merchantAmendmentList.stream().anyMatch(am -> validMerchantAmendments.contains(AmendmentType.getAmendmentType(am)));
    }


    /**
     * validate if this amendment list contains
     * a valid merchant file amendment
     */
    public boolean validMerchantAmendment(Merchant merchant) {
        if (merchant.getAmendmentList() == null || merchant.getAmendmentList().isEmpty())
            return true;

        List<AmendmentType> validMerchantAmendments = Arrays.asList(AmendmentType.ACCEPTED_CARDS,
                AmendmentType.ADDRESS, AmendmentType.MCC, AmendmentType.LEGAL_NAME, AmendmentType.MERCHANT_NAME);

        return merchant.getAmendmentList().stream().anyMatch(am -> validMerchantAmendments.contains(AmendmentType.valueOf(am)));

    }

    /**
     * Check if the merchantType (ECOM/POS) is supported for a specific Acquirer
     * based on the data we have in the DB
     */
    public boolean isMerchantTypeSupported(Acquirer acquirer, Merchant merchant) {

        AcquirerConfig acquirerConfig = acquirerComponent.getAcquirerConfig(acquirer);
        ComplexAcquirer complexAcquirer = (ComplexAcquirer) acquirerConfig.getAcquirer();
        MerchantTypeConfig merchantTypeConfig = complexAcquirer.getConfigs().get(merchant.getMerchantType());

        if (merchantTypeConfig == null)
            return false;

        if (merchantTypeConfig instanceof EcomConfig)
            return ((EcomConfig) merchantTypeConfig).isEnabled();
        else
            return ((PosConfig) merchantTypeConfig).isEnabled();
    }

    /**
     * validate if this amendment list contains a valid merchant file amendment
     */
    public boolean validTerminalAmendment(Merchant merchant) {

        if (merchant.getAmendmentList() == null || merchant.getAmendmentList().isEmpty())
            return true;

        List<AmendmentType> validTerminalAmendments = Arrays
                .asList(AmendmentType.ADDING_TERMINALS, AmendmentType.TERMINAL_ACCEPTED_CARDS,
                        AmendmentType.ACCEPTED_CARDS, AmendmentType.ADDRESS, AmendmentType.MERCHANT_NAME,
                        AmendmentType.MCC,
                        AmendmentType.TERMINAL_CLOSURE);

        return merchant.getAmendmentList().stream().anyMatch(am -> validTerminalAmendments.contains(AmendmentType.getAmendmentType(am)));

    }

    /**
     * Check if the Merchant is valid to return predefined templates Ids
     */
    private boolean validateMerchant(Merchant merchant, Acquirer runningBank) {
        return runningBank == null || (
                StringUtils.isEmpty(merchant.getMerchantCurrency()) &&
                        runningBank == Acquirer.NI &&
                        merchant.getMerchantType() == MerchantType.ECOM);
    }

    /**
     * @param countryCode alpha3 country code
     * @return alpha2 country code
     */
    public String getAlpha2CountryCode(String countryCode) {
        if (StringUtils.isEmpty(countryCode))
            return "";

        String countryCodeAlpha2;
        try {
            countryCodeAlpha2 = lookupService.countryCodeToAlpha2(countryCode);
        } catch (Exception e) {
            log.error("\nError while doing RPC lookup service", e);
            throw new RuntimeException(e);
        }
        return countryCodeAlpha2;

    }

    public String getCountryOfOrigin(String countryCode) {
        if (StringUtils.isEmpty(countryCode))
            return "   ";
        Integer numericCountryCode;
        try {
        	numericCountryCode = lookupService.countryCodeAlpha3ToNumeric(countryCode);
        } catch (Exception e) {
            log.error("\nError while doing RPC lookup service", e);
            throw new RuntimeException(e);
        }
        return appendSuffix(String.valueOf(numericCountryCode), ' ', 3);
    }

    public String appendSuffix(String str, char suffix, int occurance) {
    	String rightPadStr = "";
    	try {
	    	if (str == null) {
	            str = "";
	        }
	        
	        if(str.length() > occurance) {
	        	str = str.substring(0, occurance);
	        }
	        rightPadStr = net.logstash.logback.encoder.org.apache.commons.lang.StringUtils.rightPad(str, occurance, suffix);
    	}catch(Exception e) {
    		
    	}
        return rightPadStr;
    }
    
    private Set<CardSchema> buildCardSchemsList(Merchant merchant, String templateId) {

        List<AcceptedCardParam> acceptedCardSchemes = new ArrayList<>();

        if (merchant.getConfigurations() != null && merchant.getConfigurations().getAcceptedCardSchemes() != null) {
            acceptedCardSchemes = merchant.getConfigurations().getAcceptedCardSchemes();
        }

        List<CardSchema> excludedCardsSchems = new ArrayList<>();
        if (merchant.getConfigurations() != null && merchant.getConfigurations().getExcludedCardSchemes() != null) {
            excludedCardsSchems = merchant.getConfigurations().getExcludedCardSchemes();
        }

        List<CardSchema> defaultCardsSchemes = loadTemplateDefaultSchemsList(templateId);


        Set<CardSchema> finalList = new LinkedHashSet<>(defaultCardsSchemes);
        acceptedCardSchemes.forEach(acceptedScheme -> finalList.add(acceptedScheme.getCardScheme()));
        if (merchant.isAmexService()) {
            finalList.add(CardSchema.AMEX);
        }

        excludedCardsSchems.forEach(finalList::remove);

        return finalList;
    }


    private List<CardSchema> loadTemplateDefaultSchemsList(String templateId) {
        Optional<MerchantTemplate> templateCardsOptional = merchantTemplateRepository.findTopByTemplateId(templateId);

        if (templateCardsOptional.isPresent())
            return templateCardsOptional.get().getDefaultCards();

        return new ArrayList<>();
    }

    private boolean validMerchantSegment(String merchantSegment) {
        if (StringUtils.isEmpty(merchantSegment))
            return false;

        return base24Configs.getValidMerchantSegments().contains(merchantSegment);
    }

    private String getTerminalModel(Merchant merchant) {

        if (CollectionUtils.isEmpty(merchant.getTerminals()))
            return null;
        //NASSC-3032 handling the situation if Model is not in the terminal object
        Optional<Terminal> firstTerminal = merchant.getTerminals()
                .stream()
                .filter(terminal -> terminal.getTerminalModel() != null)
                .findFirst();
        return firstTerminal.map(Terminal::getTerminalModel).orElse(null);
    }


    public boolean containsValidAmendment(ApplicationRequest request) {
        List<Merchant> merchants = new ArrayList<>();
        request.getPayload().getApplications().forEach(application -> merchants.addAll(application.getMerchants()));
        boolean validAmendment = merchants.stream().anyMatch(this::validAmendment);
        Merchant merchant = merchants.get(0);

        if (merchant.getAmendmentList().contains(AmendmentType.ADDRESS.toString())) {

            List<String> merchantAmendments = new ArrayList<>(merchant.getAmendmentList());
            merchantAmendments.remove(AmendmentType.ADDRESS.toString());

            if (validAmendment(merchantAmendments)) {
                return true;
            }

            return merchant.getAddresses().stream().anyMatch(Address::validForAmendment);
        } else {
            return validAmendment;
        }
    }

}