package ae.network.dob.adapter.base24.service.response;

import ae.network.dob.adapter.base24.config.Base24Configs;
import ae.network.dob.adapter.base24.database.model.acquirer.AcquirerConfig;
import ae.network.dob.adapter.base24.database.model.response.Base24Response;
import ae.network.dob.adapter.base24.database.repository.AcquirerConfigRepository;
import ae.network.dob.adapter.base24.service.file.ResponseFileListener;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

import static ae.network.dob.adapter.base24.service.file.EprdGenerationService.EPRD_RECORD_TYPE;

@Component
@Slf4j
public class Base24ResponseFileProcessor {

    private static final String FILE_ORIGINAL_FILE = "file_originalFile";
    private static final String HEADER_FILE_NAME = "file_name";

    private final Base24ResponseFileService base24ResponseFileService;
    private final Base24Configs base24Configs;
    private final AcquirerConfigRepository acquirerConfigRepository;

    public Base24ResponseFileProcessor(Base24ResponseFileService base24ResponseFileService,
                                       Base24Configs base24Configs, AcquirerConfigRepository acquirerConfigRepository) {
        this.base24ResponseFileService = base24ResponseFileService;
        this.base24Configs = base24Configs;
        this.acquirerConfigRepository = acquirerConfigRepository;
    }

    @PostConstruct
    public void init() {
        List<AcquirerConfig> acquirers = acquirerConfigRepository.findAll();
        String outDir = base24Configs.getOut();
        String inDir = base24Configs.getIn();
        String archDir = base24Configs.getArch();
        acquirers.forEach(acquirer -> checkDirExist(acquirer.getAcquirer().getAcquirer().name(), outDir, inDir, archDir));
    }

    /**
     * @implNote used in {@link ResponseFileListener#processNIFileFlow()}
     */
    @SuppressWarnings("unused")
    public void processResponseFile(Message<String> msg) {

        if (!base24Configs.getImportEnabled()) {
            log.info("File Available, But this node is not enabled to process Response Files");
            return;
        }

        log.info(msg.toString());
        String acquirerFilePath = (String) msg.getHeaders().get("file_relativePath");
        assert acquirerFilePath != null;
        processResponseFile(msg, acquirerFilePath.substring(0, acquirerFilePath.indexOf(File.separator)));
    }


    private void processResponseFile(Message<String> msg, String acquirer) {

        log.info("Base24 Response File {} under processing", msg.getHeaders().get(HEADER_FILE_NAME));

        File file = new File(Objects.requireNonNull(msg.getHeaders().get(FILE_ORIGINAL_FILE)).toString());

        String content = msg.getPayload();
        Collection<Base24Response> responseRecords = createArrayOfResponseObjects(content, file.getName());

        for (Base24Response base24Response : responseRecords) {

            String fileNamePrefix = base24Response.getFileType().equals(EPRD_RECORD_TYPE)
                    ? EPRD_RECORD_TYPE.toLowerCase()
                    : "rf";

            base24Response.setResponseFileName(file.getName());
            base24Response.setRequestFileName(fileNamePrefix + file.getName().substring(2));
            base24ResponseFileService.processBase24ResponseFile(base24Response, acquirer);
        }

        log.info("Finished processing the File {} .", msg.getHeaders().get(HEADER_FILE_NAME));

        moveFileToArchiveDir(file, acquirer);
    }

    private Collection<Base24Response> createArrayOfResponseObjects(String content, String fileName) {
        log.info("createArrayOfResponseObjects started for file: {}, \n File Content :\n{}", fileName, content);
        String[] lines = content.split("\\r?\\n");

        log.info("Number of Records :{}", lines.length);

        ArrayList<Base24Response> base24ResponseReport = new ArrayList<>();

        for (String line : lines) {
			
        	if (StringUtils.isEmpty(line)) {
				continue;
			}
			
        	if (line.substring(33, 38).equals("8888")||line.substring(33, 38).equals("9999")) {
				continue;
			}
            
        	Base24Response base24Response = Base24Response.builder().fileType(line.substring(0, 2))
                    .actionType(line.substring(3, 4)).recordId(line.substring(5, 24).trim())
                    .errorCode(line.substring(33, 38)).errorDescription(line.substring(38))
                    .status("0000".equals(line.substring(33, 38).trim())).responseFileName(fileName).build();

            log.info("File Entity Created {}", base24Response.toString());

            base24ResponseReport.add(base24Response);
        }

        log.info("createArrayOfResponseObjects Completed for file: {}, \n File Content :\n{}", fileName, content);

        return base24ResponseReport;
    }

    private void moveFileToArchiveDir(File file, String acquirer) {

        log.info("moveFileToArchiveDir started File {}: to the Archive Directory {}", file.getAbsolutePath(),
                base24Configs.getArch());

        Path temp;
        try {

            if (!Files.exists(Paths.get(base24Configs.getArch() + acquirer + File.separator + file.getName())))
                temp = Files.move(Paths.get(file.getAbsolutePath()),
                        Paths.get(base24Configs.getArch() + acquirer + File.separator + file.getName()));
            else
                temp = Files.move(Paths.get(file.getAbsolutePath()),
                        Paths.get(base24Configs.getArch() + acquirer + File.separator + file.getName() + System.currentTimeMillis()));
            // TODO: Not needed if statement
            if (temp != null) {
                log.info("Moved successfully the Response File {}: to the Archive Directory {}", file.getAbsolutePath(),
                        base24Configs.getArch());
            } else {
                log.info("Failed to move the Response File {}: to the Archive Directory {}", file.getAbsolutePath(),
                        base24Configs.getArch());
                file.delete();
            }

        } catch (IOException e) {
            log.error("Failed to move the Response File {}: to the Archive Directory {}, Hence Deleting the File....", file.getAbsolutePath(),
                    base24Configs.getArch() + acquirer);
            file.delete();
        }

    }

    /**
     * will Check if the files processing dirs exist or not and create if they are not there.
     *
     * @param acquirer
     * @param outDir
     * @param inDir
     * @param archDir
     */
    private void checkDirExist(String acquirer, String outDir, String inDir, String archDir) {
        log.info("checkDirExist for Acquirer :{}", acquirer);

        createFilePath(acquirer, outDir);

        createFilePath(acquirer, inDir);

        createFilePath(acquirer, archDir);

    }

    private void createFilePath(String acquirer, String fileDir) {

        log.info("createFilePath Path :{}", fileDir);
        Path filePath = Paths.get(fileDir + File.separator + acquirer);
        if (!Files.exists(filePath)) {
            File file = new File(filePath.toUri());
            boolean dirCreated = file.mkdirs();

            if (dirCreated) {
                log.info("Path {} created successfully", file);
            } else {
                log.info("Path {} not created, please create manually", file);
            }

        } else {
            log.info("Path {} already exist", filePath);
        }
    }
}
