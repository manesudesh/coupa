package ae.network.dob.adapter.base24.database.model.acquirer;

import lombok.Data;

import java.util.Map;

/**
 * @author Success.Otto
 * @since 26/03/2020
 */
@Data
public class EcomConfig implements MerchantTypeConfig {
    /**
     * Merchant ifId
     */
    private String fiId;
    /**
     * Attribute specific for ECOM, and has
     * key value of currency and device details
     * object necessary to get ptd and prdf id
     */
    private boolean enabled;
    private Map<CurrencyAcr, DeviceDetails> currencyAcrDeviceDetails;
}
