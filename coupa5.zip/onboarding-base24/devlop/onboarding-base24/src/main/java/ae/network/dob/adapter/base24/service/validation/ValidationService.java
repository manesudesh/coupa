package ae.network.dob.adapter.base24.service.validation;


import ae.network.dob.adapter.base24.validation.ValidationResult;
import ae.network.dob.adapter.base24.validation.Validator;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : yousry
 * @version : 1.0
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ValidationService {

    public static Initiator getValidator() {
        return new ValidationService().new Initiator();
    }

    public class Initiator {
        private List<ValidationResult> validationResults = new ArrayList<>();

        private Initiator() {
            //private constructor
        }

        public <T> Initiator validate(Validator<T> validator, T objectToValidate) {
            ValidationResult result = validator.validate(objectToValidate);

            validationResults.add(result);

            return this;
        }

        public List<ValidationResult> getValidationResult() {
            if (validationResults.isEmpty()) {
                throw new RuntimeException("Please use validate method before getting validations");
            } else {
                return validationResults;
            }
        }
    }

}
