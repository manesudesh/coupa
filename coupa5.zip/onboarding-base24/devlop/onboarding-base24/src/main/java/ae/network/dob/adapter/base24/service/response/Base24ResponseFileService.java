package ae.network.dob.adapter.base24.service.response;

import ae.network.dob.adapter.base24.common.Base24StatusHelper;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.database.model.request.Base24File;
import ae.network.dob.adapter.base24.database.model.request.FileType;
import ae.network.dob.adapter.base24.database.model.request.Task;
import ae.network.dob.adapter.base24.database.model.request.TaskHistory;
import ae.network.dob.adapter.base24.database.model.request.TaskName;
import ae.network.dob.adapter.base24.database.model.request.TaskStatus;
import ae.network.dob.adapter.base24.database.model.response.Base24Response;
import ae.network.dob.adapter.base24.database.repository.ApplicationRequestRepository;
import ae.network.dob.adapter.base24.database.repository.Base24FileRepository;
import ae.network.dob.adapter.base24.database.repository.Base24ResponseFileRepository;
import ae.network.dob.adapter.base24.rabbitmq.config.RabbitQueue;
import ae.network.dob.adapter.base24.rabbitmq.service.RabbitService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;

import static ae.network.dob.adapter.base24.service.file.EprdGenerationService.EPRD_RECORD_TYPE;

@Slf4j
@Service
public class Base24ResponseFileService {

    private final Base24ResponseFileRepository base24ResponseFileRepository;
    private final ApplicationRequestRepository applicationRequestRepository;
    private final Base24FileRepository base24FileRepository;
    private final Base24StatusHelper base24StatusHelper;
    private final RabbitService rabbitService;


    public Base24ResponseFileService(Base24ResponseFileRepository base24ResponseFileRepository,
                                     ApplicationRequestRepository applicationRequestRepository, Base24FileRepository base24FileRepository,
                                     Base24StatusHelper base24StatusHelper, RabbitService rabbitService) {
        this.base24ResponseFileRepository = base24ResponseFileRepository;
        this.applicationRequestRepository = applicationRequestRepository;
        this.base24FileRepository = base24FileRepository;
        this.base24StatusHelper = base24StatusHelper;
        this.rabbitService = rabbitService;
    }


    public void processBase24ResponseFile(Base24Response base24Response, String acquirer) {

        log.info("processBase24ResponseFile method started , File {}", base24Response);

        Optional<Base24File> base24FileOpt = findBase24File(base24Response, acquirer);

        if (!base24FileOpt.isPresent()) {

            String errorMessage = String.format(
                    "Base24File not found in DB, Response File %s, Expected Request File: %s, Record ID %s, File Type %s",
                    base24Response.getResponseFileName(), base24Response.getRequestFileName(),
                    base24Response.getRecordId(), base24Response.getFileType());

            log.error(errorMessage);
            base24Response.setErrorDescription(errorMessage);

        } else {

            Base24File base24File = base24FileOpt.get();

            Optional<ApplicationRequest> applicationRequestOpt = applicationRequestRepository
                    .findByApplicationId(base24File.getApplicationId());

            if (!applicationRequestOpt.isPresent()) {
                log.warn(
                        "ApplicationRequest Not Found with ID: {} in for the Record in ResponseFile {}, \n"
                                + "matched with Request File {}",
                        base24File.getApplicationId(), base24Response.getResponseFileName(), base24File.getFileName());
                base24File.setCompleted(Boolean.TRUE);

            } else {

                ApplicationRequest applicationRequest = applicationRequestOpt.get();

                for (Task task : applicationRequest.getTasks()) {
                    if (task.getTaskStatus() != TaskStatus.IN_PROGRESS)
                        continue;

                    if (task.getEntityId().equals(base24File.getFileType() + ":" + base24File.getRecordId())
                            && task.getName().equals(getTaskName(base24Response))) {

                        if (base24Response.getStatus()) {
                            task.setTaskStatus(TaskStatus.COMPLETED);
                        } else {
                            task.setTaskStatus(TaskStatus.FAILED);
                            task.setTaskHistory(new ArrayList<>());
                            task.getTaskHistory().add(createTaskHistory(
                                    base24Response.getErrorCode(), base24Response.getErrorDescription()));
                        }
                    }
                }

                applicationRequestRepository.save(applicationRequest);

                base24File.setCompleted(Boolean.TRUE);
                base24Response.setApplicationId(applicationRequest.getApplicationId());

                if (base24StatusHelper.applicationRequestCompleted(applicationRequest)) {
                    rabbitService.sendMessage(RabbitQueue.UPDATES, base24StatusHelper.createApplicationResponse(applicationRequest));
                }
            }

            base24FileRepository.save(base24File);

        }

        base24ResponseFileRepository.save(base24Response);

        log.info("processBase24ResponseFile method Completed , File {}", base24Response);
    }


    private String getTaskName(Base24Response base24Response) {

        switch (base24Response.getFileType()) {
            case "PR":
                return TaskName.RECEIVE_MERCHANT_RESPONSE.name();
            case "PT":
                return TaskName.RECEIVE_TERMINAL_RESPONSE.name();
            case "CS":
                return TaskName.RECEIVE_POS_TERMINAL_RESPONSE.name();
            case EPRD_RECORD_TYPE:
                return TaskName.RECEIVE_EPRD_RESPONSE.name();
            default:
                return "";
        }
    }

    private TaskHistory createTaskHistory(String statusCode, String response) {
        return TaskHistory.builder()
                .createdDate(new Date())
                .lastModifiedDate(new Date())
                .statusCode(statusCode)
                .taskStatus(TaskStatus.FAILED)
                .response(response)
                .build();
    }


    /**
     * @param base24Response
     * @param acquirer
     * @return
     */
    private Optional<Base24File> findBase24File(Base24Response base24Response, String acquirer) {

        Optional<Base24File> base24FileOpt = base24FileRepository
                .findTopByFileNameAndRecordIdAndFileTypeAndExportedAndCompletedAndAcquirer(base24Response.getRequestFileName(),
                        base24Response.getRecordId(), FileType.get(base24Response.getFileType()).name(), Boolean.TRUE,
                        Boolean.FALSE, acquirer);

        if (!base24FileOpt.isPresent())
            base24FileOpt = base24FileRepository
                    .findTopByFileNameAndTemplateIdAndFileTypeAndExportedAndCompletedAndAcquirer(base24Response.getRequestFileName(),
                            base24Response.getRecordId(), FileType.get(base24Response.getFileType()).name(), Boolean.TRUE,
                            Boolean.FALSE, acquirer);


        return base24FileOpt;
    }

}
