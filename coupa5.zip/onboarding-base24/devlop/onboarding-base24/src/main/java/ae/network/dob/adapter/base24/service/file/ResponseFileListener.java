package ae.network.dob.adapter.base24.service.file;

import ae.network.dob.adapter.base24.config.Base24Configs;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.file.FileReadingMessageSource;
import org.springframework.integration.file.filters.SimplePatternFileListFilter;
import org.springframework.integration.file.transformer.FileToStringTransformer;
import org.springframework.messaging.MessageChannel;

import java.io.File;

@Slf4j
@Configuration
@EnableIntegration
public class ResponseFileListener {

    public static final String FILE_PATTERN = "*";
    private final Base24Configs base24Configs;

    public ResponseFileListener(Base24Configs base24Configs) {
        this.base24Configs = base24Configs;
    }

    @Bean
    public MessageChannel fileChannel() {
        return new DirectChannel();
    }

    @Bean
    @InboundChannelAdapter(value = "FileChannel", poller = @Poller(fixedDelay = "10000"))
    public MessageSource<File> niFileReadingMessageSource() {
        log.info("NI Response file Service Started ....");
        FileReadingMessageSource sourceReader = new FileReadingMessageSource();
        sourceReader.setDirectory(new File(base24Configs.getOut()));
        sourceReader.setFilter(new SimplePatternFileListFilter(FILE_PATTERN));
        sourceReader.setUseWatchService(true);
        sourceReader.setScanEachPoll(true);
        return sourceReader;
    }

    @Bean
    public IntegrationFlow processNIFileFlow() {
        return IntegrationFlows
                .from("FileChannel")
                .transform(fileToStringTransformer())
                .handle("base24ResponseFileProcessor", "processResponseFile")
                .get();
    }

    @Bean
    public FileToStringTransformer fileToStringTransformer() {
        return new FileToStringTransformer();
    }
} 