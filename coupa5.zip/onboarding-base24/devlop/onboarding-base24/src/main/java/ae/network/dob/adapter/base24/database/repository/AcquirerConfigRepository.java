package ae.network.dob.adapter.base24.database.repository;

import ae.network.dob.adapter.base24.database.model.acquirer.AcquirerConfig;
import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

/**
 * @author Waseem
 * @author Success.Otto
 */
public interface AcquirerConfigRepository extends MongoRepository<AcquirerConfig, String> {

    Optional<AcquirerConfig> findByAcquirerAcquirer(Acquirer acquirer);

}
