package ae.network.dob.adapter.base24.database.model.request;

import ae.network.dob.adapter.base24.database.model.AbstractAuditingEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "base24_File")
public class Base24File extends AbstractAuditingEntity {

    @Id
    private String id;
    private String applicationId;
    private String templateId;
    private String recordId;
    private String fileName;
    private FileType fileType;
    private String fileContent;
    private Boolean exported;
    private Boolean completed;
    private String acquirer;

}