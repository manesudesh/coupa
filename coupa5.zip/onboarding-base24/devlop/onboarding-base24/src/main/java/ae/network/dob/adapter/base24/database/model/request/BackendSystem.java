package ae.network.dob.adapter.base24.database.model.request;

/**
 * List of all onboarding backend systems
 */
public enum BackendSystem {
    BASE24
}
