package ae.network.dob.adapter.base24.rabbitmq.consumer;

import ae.network.dob.adapter.base24.config.Base24Configs;
import ae.network.dob.adapter.base24.database.model.reply.ValidationError;
import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.database.model.request.BackendSystem;
import ae.network.dob.adapter.base24.database.model.request.RequestType;
import ae.network.dob.adapter.base24.model.application.Merchant;
import ae.network.dob.adapter.base24.rabbitmq.config.RabbitQueue;
import ae.network.dob.adapter.base24.rabbitmq.service.RabbitService;
import ae.network.dob.adapter.base24.service.request.Base24RequestProcessor;
import ae.network.dob.adapter.base24.validation.ValidationResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Waseem.Ismail
 * @since 2020-02-04
 */
@Component
@Slf4j
public class Base24ApplicationConsumer extends AbstractConsumer {

    private final Base24RequestProcessor base24RequestProcessor;
    private final Base24Configs base24Configs;

    public Base24ApplicationConsumer(Base24RequestProcessor base24RequestProcessor, RabbitService rabbitService, Base24Configs base24Configs) {
        super(RabbitQueue.BASE24, rabbitService);
        this.base24RequestProcessor = base24RequestProcessor;
        this.base24Configs = base24Configs;
    }

    @Override
    public Optional<Collection<ValidationError>> validateApplication(ApplicationRequest applicationRequest) {

        List<ValidationResult> validationResult = base24RequestProcessor.validateRequest(applicationRequest);
        base24RequestProcessor.updateRequestWithValidationStatus(validationResult, applicationRequest);

        boolean validationPassed = validationResult.stream().allMatch(ValidationResult::isPassed);

        if (validationPassed) {
            return Optional.empty();
        } else {
            return Optional.of(validationResult.stream()
                    .map(validation -> ValidationError.builder().errorCode(validation.getCode())
                            .errorMessage(validation.getMessage()).fieldName("*").build())
                    .collect(Collectors.toList()));
        }

    }

    @Override
    public void processApplication(ApplicationRequest applicationRequest) {
        base24RequestProcessor.processApplication(applicationRequest);
    }

    @Override
    public BackendSystem getBackendSystem() {
        return BackendSystem.BASE24;
    }

    @Override
    public boolean isRequestSupported(ApplicationRequest applicationRequest) {
        final RequestType requestType = applicationRequest.getRequestType();

        if (Arrays.asList(RequestType.values()).contains(requestType)) {
            if (requestType == RequestType.SCREENING) {
                return false;
            }

            return validateNGOneMerchants(applicationRequest) && validateCountryOrigin(applicationRequest);
        } else {
            log.warn("Unsupported Request Type: {} for Application: {}", requestType,
                    applicationRequest.getApplicationId());
            return false;
        }
    }

    /**
     * QR merchants will always be onboarded on base24
     * PayByLink Merchants will be onboarded on base24 based on eComAuthorization system
     * TabToPay will be onboarded on Base24 based on the softPosAuthorization system.
     * as discussed with Mohammed if the merchant not supported it will be removed from the payload
     */
    private boolean validateNGOneMerchants(ApplicationRequest applicationRequest) {

        if (applicationRequest.getRequestType() != RequestType.ONBOARDING) {
            return true;
        }

        if (applicationRequest.getAcquirer() != Acquirer.NI) {
            return true;
        }

        return applicationRequest.getPayload().getApplications().stream()
                .flatMap(application -> application.getMerchants().stream()).collect(Collectors.toList()).stream()
                .anyMatch(merchant -> merchant.validNGOneMerchant(base24Configs));
    }

    private boolean validateCountryOrigin(ApplicationRequest applicationRequest) {
        boolean countryOriginFlag = applicationRequest.getPayload().getApplications().stream()
                .flatMap(application -> application.getMerchants().stream()).collect(Collectors.toList()).stream()
                .allMatch(Merchant::validCountryOriginMerchant);

        if (!countryOriginFlag) {
            log.error("ApplicationId " + applicationRequest.getApplicationId() + " : country of origin merchant dont have valid Auth System");
        }

        return countryOriginFlag;

    }
}
