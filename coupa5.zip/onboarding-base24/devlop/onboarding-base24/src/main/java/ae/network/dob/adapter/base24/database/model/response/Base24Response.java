package ae.network.dob.adapter.base24.database.model.response;

import ae.network.dob.adapter.base24.database.model.AbstractAuditingEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

//PT|A|13005308 |ERROR : 0000 [ENOERR] The operation completed successfully.

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "base24_response")
@Builder(access = AccessLevel.PUBLIC)
public class Base24Response extends AbstractAuditingEntity {

    @Id
    private String recordId;
    private String fileType;
    private String actionType;
    private Boolean status;
    private String errorCode;
    private String errorDescription;
    private String responseFileName;
    private String requestFileName;
    private String applicationId;
}
