package ae.network.dob.adapter.base24.database.model.acquirer;

import ae.network.dob.adapter.base24.database.model.AbstractAuditingEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author yousry
 * @author Success.Otto
 * @version 1.0
 * @since 26/03/2020
 */

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@Builder
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "base24_acquirerConfig")
public class AcquirerConfig extends AbstractAuditingEntity {

    /**
     * Unique identifier of the document
     */
    @Id
    private String id;
    private String orgId;
    private String name;
    private boolean complexTariffStructure;
    /**
     * An acquirer i.e NI, TYME bank
     * can inherit from the base abstract class
     */
    private AbstractAcquirer acquirer;

}
