package ae.network.dob.adapter.base24.service.file;

import ae.network.dob.adapter.base24.config.Base24Configs;
import ae.network.dob.adapter.base24.database.model.request.Base24File;
import ae.network.dob.adapter.base24.database.repository.Base24FileRepository;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Slf4j
@EnableScheduling
@Component
public class FileCronService {

    @Setter
    private Clock clock = Clock.systemDefaultZone();

    private final Base24FileRepository base24FileRepository;
    private final Base24FileManager base24FileManager;
    private final Base24Configs base24Configs;

    public FileCronService(Base24FileRepository base24FileRepository, Base24FileManager base24FileManager, Base24Configs base24Configs) {
        this.base24FileRepository = base24FileRepository;
        this.base24FileManager = base24FileManager;
        this.base24Configs = base24Configs;
    }

    @Scheduled(fixedDelayString = "${base24adapter.cron.file.export-fixed-delay}")
    public void loadFilesFromRepository() {

        Optional<String> exportSchedule = timeMatch();
        if ((!exportSchedule.isPresent()) || (!base24Configs.getExportEnabled())) {
            log.debug("Current Time :{} not in File Export Schedule :{} or export not anabled on this Node", LocalDateTime.now(),
                    base24Configs.getExportSchedule());
            return;
        }

        String fileNumber = "" + (base24Configs.getExportSchedule().indexOf(exportSchedule.get()) + 1);
        if (fileNumber.length() < 2)
            fileNumber = "0" + fileNumber;

        log.info("Cron Method loadFilesFromRepository started, time {}", new Date());
        List<Base24File> base24FilesList = new ArrayList<>(base24FileRepository.findByExported(Boolean.FALSE));

        log.info("Records Loaded from DB, records Count {}", base24FilesList.size());

        for (Base24File base24File : base24FilesList) {
            sendFileToBase24(base24File, fileNumber);
        }
    }

    private void sendFileToBase24(Base24File base24File, String fileNumber) {
        try {
            log.info("Export File to the IN Directory Content {}, FilePath {}", base24File.getFileContent(),
                    base24FileManager.getCurrentFileName(base24File, base24File.getAcquirer(), fileNumber).getAbsolutePath());

            base24FileManager.exportFileToBase24Dir(base24File, fileNumber);
            base24FileRepository.save(base24File);

        } catch (Exception exception) {
            base24File.setExported(Boolean.FALSE);
            log.error(
                    "Error generating the Base24File content of ApplicationID: {}, fileType: {}, ID {},\n fileContent: {}",
                    base24File.getApplicationId(), base24File.getFileType(), base24File.getRecordId(),
                    base24File.getFileContent());
        }
    }

    private Optional<String> timeMatch() {
        LocalDateTime currentTime = LocalDateTime.now(clock);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH.mm");
        String currentTimeString = currentTime.format(formatter);

        List<String> exportSchedule = base24Configs.getExportSchedule();
        return exportSchedule.stream().filter(time -> time.startsWith(currentTimeString)).findFirst();
    }
}