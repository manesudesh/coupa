package ae.network.dob.adapter.base24.model.application.amendment;

/**
 * @author : Yousry
 * @version : 1.0
 */
public enum AmendmentType {

    MERCHANT_NAME("MERCHANT_NAME"),
    LEGAL_NAME("LEGAL_NAME"),
    LINKED_CHAIN("LINKED_CHAIN"),
    MCC("MCC"),
    SCHEMES_OVERRIDING("SCHEMES_OVERRIDING"),
    ADDRESS("ADDRESS"),
    ACCEPTED_CARDS("ACCEPTED_CARDS"),
    FEES("FEES"),
    SERVICES("SERVICES"),
    CLOSURE("CLOSURE"),
    HOLD("HOLD"),
    RELEASE("RELEASE"),
    ADDING_TERMINALS("ADDING_TERMINALS"),
    IBAN("IBAN"),
    TERMINAL_CLOSURE("TERMINAL_CLOSURE"),
    TERMINAL_REACTIVATING("TERMINAL_REACTIVATING"),
    MERCHANT_REACTIVATING("MERCHANT_REACTIVATING"),
    SETTLEMENT("SETTLEMENT"),
    FLEXI_CUT_OFF("FLEXI_CUT_OFF"),
    LIABILITY("LIABILITY"),
    DISABLE_SCHEME("DISABLE_SCHEME"),
    TERMINAL_ADDRESS("TERMINAL_ADDRESS"),
    TERMINAL_DCC("TERMINAL_DCC"),
    TERMINAL_ACCEPTED_CARDS("TERMINAL_ACCEPTED_CARDS"),
    COUNTRY_ORIGIN("COUNTRY_ORIGIN"),
    OTHER("OTHER");

    private final String value;

    AmendmentType(String value) {
        this.value = value;
    }

    public static AmendmentType getAmendmentType(String value) {
        for (AmendmentType v : values())
            if (v.getValue().equalsIgnoreCase(value)) return v;
        return AmendmentType.OTHER;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return value;
    }
}

