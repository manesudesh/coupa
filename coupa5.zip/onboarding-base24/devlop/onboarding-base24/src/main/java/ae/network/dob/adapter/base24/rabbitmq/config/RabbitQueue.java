package ae.network.dob.adapter.base24.rabbitmq.config;

import java.util.Arrays;
import java.util.List;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
public enum RabbitQueue {
    // Working Queues
    BASE24("base24", "routing.backend.base24"),
    // RPC Queues
    UTILS("utils", "routing.utils"),
    // Response Queues
    UPDATES("updates", "routing.updates");

    private final String queueName;
    private final String[] routingKeys;

    RabbitQueue(String queueName, String... routingKeys) {
        this.queueName = queueName;
        this.routingKeys = routingKeys;
    }

    public String getQueueName() {
        return queueName;
    }

    public List<String> getRoutingKeys() {
        return Arrays.asList(routingKeys);
    }
}
