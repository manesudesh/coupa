package ae.network.dob.adapter.base24.model.application;

import ae.network.dob.adapter.base24.common.TextUtils;
import ae.network.dob.adapter.base24.config.Base24Configs;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.StringUtils;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.List;
import java.util.Optional;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Merchant {

    /**
     * Brighterion service name.
     * See <a href="https://brighterion.com/">Brighterion</a>
     */
    public static final String BRIGHTERION_SERVICE = "BRIGHTERION";
    public static final String MPGS_SERVICE = "MPGS";
    public static final String QRPAY_SERVICE = "QRPAY";
    public static final String VISA_INSTALLMENT = "VISA_INSTALLMENT";

    @NotNull(message = "MerchantId is NULL.")
    @Size(max = 19, message = "Merchant Id should not exceed 19 characters length.")
    @NotBlank(message = "Merchant Id cannot be Empty")
    @Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Merchant Id should only consist of alphanumeric string. No Spaces")
    private String merchantId;

    @NotNull(message = "Merchant Name is NULL.")
    @Size(max = 40, message = "Merchant Name must not exceed 40 characters.")
    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Merchant Name should only consist of alphanumeric string.")
    @NotBlank(message = "Merchant Name is Blank.")
    private String merchantName;

    @NotNull(message = "Legal Name is NULL.")
    @Size(max = 40, message = "Legal Name must not exceed 40 characters.")
    @Pattern(regexp = "^[a-zA-Z0-9\\s]+$", message = "Legal Name should only consist of alphanumeric string.")
    @NotBlank(message = "Legal Name is Blank.")
    private String legalName;

    @NotNull(message = "Merchant Type is NULL, should be (ECOM or POS).")
    private MerchantType merchantType;

    @NotNull(message = "MCC code is NULL.")
    @Max(value = 9999, message = "MCC must not Exceed 4 digits.")
    private Integer mcc;

    @NotNull(message = "Merchant Currency is NULL.")
    private String merchantCurrency;

    @NotNull(message = "Empty Address List.")
    private List<Address> addresses;

    @NotNull(message = "Empty MerchantConfig")
    private MerchantConfig configurations;

    private List<MerchantService> services;
    private List<Terminal> terminals;
    private List<String> amendmentList;
    private String cutOffStart;
    private String cutOffEnd;
    private String merchantSegment;

    @JsonIgnore
    private String chainId;

    @JsonIgnore
    private ActionType actionType;

    private boolean defaultCardSchemes;

    private Boolean mcippOptIn;

    private String maid;

    private String securityNature;

    private String countryOrigin;

    /**
     * checks if the merchant has Amex option or not
     *
     * @return true/false
     */
    public boolean isAmexService() {

        if (services != null && !services.isEmpty())
            return services.stream().anyMatch(merchantService -> merchantService.getServiceType().equals("SERVICE_ESTABLSIHMENT"));
        else
            return false;
    }

    /**
     * checks if the merchant has SOFTPOS service or not
     *
     * @return true/false
     */
    public boolean isSOFTPOSService() {

        if (services != null && !services.isEmpty())
            return services.stream().anyMatch(merchantService -> "SOFTPOS".equalsIgnoreCase(merchantService.getServiceType()));
        else
            return false;
    }


    /**
     * get the Amex service parameters
     */
    public Optional<MerchantService> getAmexServiceParams() {

        return services.stream()
                .filter(merchantService -> merchantService.getServiceType().equals("SERVICE_ESTABLSIHMENT")).findFirst();
    }

    public boolean isBinShareService() {
        if (services != null && !services.isEmpty()) {
            return services.stream().anyMatch(merchantService -> merchantService.getServiceType().equals("BINSHARE"));
        } else {
            return false;
        }
    }

    public boolean isSoftPosService() {
        if (services != null && !services.isEmpty()) {
            return services.stream().anyMatch(merchantService -> merchantService.getServiceType().equals("SOFTPOS"));
        } else {
            return false;
        }
    }

    public boolean isBrighterionService() {
        return services != null
                && !services.isEmpty()
                && services.stream().anyMatch(merchantService -> BRIGHTERION_SERVICE.equals(merchantService.getServiceType()));
    }

    /**
     * get the BINSHARE service parameters
     */
    public Optional<MerchantService> getBinShareServiceParams() {

        return services.stream()
                .filter(merchantService -> merchantService.getServiceType().equals("BINSHARE")).findFirst();
    }

    public Optional<MerchantService> getBrighterionServiceParams() {

        return services.stream()
                .filter(merchantService -> merchantService.getServiceType().equals(BRIGHTERION_SERVICE)).findFirst();

    }

    public void setMerchantName(String merchantName) {
        String modifiedMName = TextUtils.toAlphaNumeric(merchantName);
        this.merchantName = TextUtils.truncate(modifiedMName, 40);
    }

    public void setLegalName(String legalName) {
        String modifiedLName = TextUtils.toAlphaNumeric(legalName);
        this.legalName = TextUtils.truncate(modifiedLName, 40);
    }

    /**
     * checks if the merchant has QR option or not
     *
     * @return true/false
     */
    public boolean isQrPay() {
        if (services != null && !services.isEmpty()) {
            return services.stream().anyMatch(merchantService -> merchantService.getServiceType().equalsIgnoreCase(QRPAY_SERVICE));
        } else {
            return false;
        }
    }

    /**
     * checks if the merchant has VISA Installments option or not
     *
     * @return true/false
     */
    public boolean isVisaInstallmentsEnabled() {
        if (services != null && !services.isEmpty()) {
            return services.stream().anyMatch(merchantService -> merchantService.getServiceType().equalsIgnoreCase(VISA_INSTALLMENT));
        } else {
            return false;
        }
    }

    /**
     * QR merchants will always be onboarded on base24
     * PayByLink Merchants will be onboarded on base24 based on ecomAuthorization system
     * TabToPay will be onboarded on Base24 based on the softPosAuthorizaton system.
     * as discussed with Mohammed if the merchant not supported it will be removed from the payload
     */
    public boolean validNGOneMerchant(Base24Configs base24Configs) {

        if (!isTabToPay(base24Configs) && !isPayByLink(base24Configs) && !isPayByQR(base24Configs)) {
            return true;
        }

        if (isPayByQR(base24Configs)) {
            return true;
        }

        if ((merchantType.equals(MerchantType.ECOM) && isPayByLink(base24Configs)
                && (configurations != null && configurations.getEcomAuthSystem() != null
                && configurations.getEcomAuthSystem().equalsIgnoreCase(MPGS_SERVICE)))) {
            return false;
        }

        return !merchantType.equals(MerchantType.POS) || !isTabToPay(base24Configs)
                || (configurations == null || (configurations.getSoftPosAuthSystem() == null
                || !configurations.getSoftPosAuthSystem().equalsIgnoreCase(MPGS_SERVICE)));
    }

    private boolean isTabToPay(Base24Configs base24Configs) {

        return Long.parseLong(base24Configs.getTabToPayIds().get(0)) <= Long.parseLong(getMerchantId())
                && Long.parseLong(base24Configs.getTabToPayIds().get(1)) >= Long.parseLong(getMerchantId());
    }

    private boolean isPayByLink(Base24Configs base24Configs) {

        return Long.parseLong(base24Configs.getPayByLinkIds().get(0)) <= Long.parseLong(getMerchantId())
                && Long.parseLong(base24Configs.getPayByLinkIds().get(1)) >= Long.parseLong(getMerchantId());
    }

    private boolean isPayByQR(Base24Configs base24Configs) {

        if (Long.parseLong(base24Configs.getPayByQrIds().get(0)) <= Long.parseLong(getMerchantId())
                && Long.parseLong(base24Configs.getPayByQrIds().get(1)) >= Long.parseLong(getMerchantId())) {
            return true;
        }

        return isQrPay();
    }

    public boolean validCountryOriginMerchant() {
        if (!StringUtils.isEmpty(countryOrigin)) {
            if (merchantType.equals(MerchantType.ECOM)) {
                return (configurations != null && configurations.getEcomAuthSystem() != null
                        && configurations.getEcomAuthSystem().equalsIgnoreCase("BASE24"));
            }

            if (merchantType.equals(MerchantType.POS)) {
                return (configurations != null && configurations.getSoftPosAuthSystem() != null
                        && configurations.getSoftPosAuthSystem().equalsIgnoreCase("BASE24"));
            }
        }
        return true;
    }
}
