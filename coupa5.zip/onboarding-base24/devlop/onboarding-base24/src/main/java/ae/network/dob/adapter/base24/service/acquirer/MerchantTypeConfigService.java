package ae.network.dob.adapter.base24.service.acquirer;

import ae.network.dob.adapter.base24.database.model.acquirer.MerchantTypeConfig;
import ae.network.dob.adapter.base24.model.application.Merchant;

/**
 * @author Success.Otto
 * @since 27/03/2020
 */
public interface MerchantTypeConfigService {

    String getFiId(Merchant merchant, MerchantTypeConfig merchantTypeConfig);

    String getPRDFTemplateID(Merchant merchant, MerchantTypeConfig merchantTypeConfig);

    String getPTDTemplateId(Merchant merchant, MerchantTypeConfig merchantTypeConfig);

    String getCSECDTemplateId(Merchant merchant, MerchantTypeConfig merchantTypeConfig);
}
