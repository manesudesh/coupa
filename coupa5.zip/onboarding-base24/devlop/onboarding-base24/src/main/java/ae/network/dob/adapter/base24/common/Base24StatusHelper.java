package ae.network.dob.adapter.base24.common;

import ae.network.dob.adapter.base24.database.model.reply.ApplicationUpdate;
import ae.network.dob.adapter.base24.database.model.reply.ProcessingResult;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.database.model.request.BackendSystem;
import ae.network.dob.adapter.base24.database.model.request.TaskStatus;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author WaseemAARI
 * Class will be used by Both FileGeneration and
 * ResponseServices to validate the final status of a request
 */
@Slf4j
@AllArgsConstructor
@Component
public class Base24StatusHelper {

    public ApplicationUpdate createApplicationResponse(ApplicationRequest request) {

        return ApplicationUpdate.builder().applicationId(request.getApplicationId()).backendSystem(BackendSystem.BASE24)
                .processingResult(ProcessingResult.builder().finalStatus(calculateFinalStatus(request))
                        .tasks(request.getTasks()).build())
                .build();
    }

    public TaskStatus calculateFinalStatus(ApplicationRequest request) {

        if (request.getTasks().stream().allMatch(task -> task.getTaskStatus().equals(TaskStatus.FAILED))) {
            return TaskStatus.FAILED;
        } else if (request.getTasks().stream().allMatch(task -> (task.getTaskStatus().equals(TaskStatus.CANCELLED)))) {
            return TaskStatus.CANCELLED;
        } else if (request.getTasks().stream().allMatch(task -> (task.getTaskStatus().equals(TaskStatus.COMPLETED)
                || task.getTaskStatus().equals(TaskStatus.CANCELLED)))) {
            return TaskStatus.COMPLETED;
        } else {
            return TaskStatus.PARTIALLY_COMPLETED;
        }
    }

    public boolean applicationRequestCompleted(ApplicationRequest applicationRequest) {
        return applicationRequest.getTasks().stream().allMatch(
                task -> (task.getTaskStatus() == TaskStatus.COMPLETED) || (task.getTaskStatus() == TaskStatus.CANCELLED)
                        || ((task.getTaskStatus() == TaskStatus.FAILED)));
    }
}