package ae.network.dob.adapter.base24.model.application.base24;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * EPRD Structure.
 * Technical docs: https://networkinternational.atlassian.net/wiki/spaces/NAACE/pages/2615018862/Technical+Documentation+onboarding-base24
 */
/**
 * @author Sudesh_Mane
 *
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EprdRequest {

    /**
     * Record type indicating EPRD.
     */
    String recType;

    /**
     * A code indicating the operation to be performed.
     * Values:
     * A = Add
     * C = Change
     * D = Delete
     */
    String opType;

    String retailedId;

    String fiid;

    String overrideMcc;

    String aft;

    List<String> cardType;

    List<String> mcc;

    String bai;

    String mcc2;

    String txnPath;

    List<String> srvAndSmFlags;

    List<String> procCode;

    String brighterionFlag;

    String declined;

    String timeout;

    String preauthDest;

    String postauthDest;

    String bnplEnable;

    String bnplMaid;

    String visaInstlSppt;

    /**
     * Transaction Type Indicator.
     */
    String tti;

    /**
     * Merchant Country of Origin.
     */
    String countryOrigin;
    
    /**
     * Money Send
     */
    String mcMoneysendEnable;
    String mcMoneysendTTI;
    String mcMoneysendMCC;
    String mcMoneysendDebitCardEnable;
    String mcMoneysendCreditCardEnable;
    String mcMoneysendPrepaidCardEnable;
    String mcMoneysendTransactionPath;

}
