package ae.network.dob.adapter.base24.rabbitmq.message;

import java.io.Serializable;

/**
 * @author walid.sewaify
 * @since 4/3/2020
 * Marker interface for message sent to rabbit queues
 */

public interface QueueMessage extends Serializable {
    String MAX_RETRY_HEADER = "max_retry";
    String DELAY_HEADER = "retry_delay_seconds";

    String getApplicationId();
}
