package ae.network.dob.adapter.base24.database.repository;

import ae.network.dob.adapter.base24.database.model.request.Base24File;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Collection;
import java.util.Optional;

public interface Base24FileRepository extends MongoRepository<Base24File, String> {

    Collection<Base24File> findByExported(Boolean exported);

    Optional<Base24File> findTopByFileNameAndRecordIdAndFileTypeAndExportedAndCompletedAndAcquirer(String filename,
                                                                                                   String recordId, String fileType, Boolean exported, Boolean completed, String acquirer);

    Optional<Base24File> findTopByFileNameAndTemplateIdAndFileTypeAndExportedAndCompletedAndAcquirer(
            String requestFileName, String templateId, String name, Boolean true1, Boolean false1, String acquirer);
}
