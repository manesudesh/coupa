package ae.network.dob.adapter.base24.service.acquirer;

import ae.network.dob.adapter.base24.database.model.acquirer.MerchantTypeConfig;
import ae.network.dob.adapter.base24.database.model.acquirer.PosConfig;
import ae.network.dob.adapter.base24.model.application.Merchant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @author Success.Otto
 * @since 27/03/2020
 */
@Service("posConfigService")
@Slf4j
public class PosConfigServiceImpl implements MerchantTypeConfigService {

    @Override
    public String getFiId(Merchant merchant, MerchantTypeConfig merchantTypeConfig) {
        return ((PosConfig) merchantTypeConfig).getFiId();
    }

    /**
     * PosConfig implementation of getting
     * PRDF Template ID
     */
    @Override
    public String getPRDFTemplateID(Merchant merchant, MerchantTypeConfig merchantTypeConfig) {
        return ((PosConfig) merchantTypeConfig).getDeviceDetails().getPrdf();
    }

    /**
     * PosConfig implementation of getting
     * PTD Template ID
     */
    @Override
    public String getPTDTemplateId(Merchant merchant, MerchantTypeConfig merchantTypeConfig) {
        return ((PosConfig) merchantTypeConfig).getDeviceDetails().getPtd();
    }

    /**
     * PosConfig implementation of getting
     * CSECD Template ID
     */
    @Override
    public String getCSECDTemplateId(Merchant merchant, MerchantTypeConfig merchantTypeConfig) {
        return ((PosConfig) merchantTypeConfig).getDeviceDetails().getCsecd();
    }
}
