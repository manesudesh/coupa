package ae.network.dob.adapter.base24.service.acquirer;

import ae.network.dob.adapter.base24.database.model.acquirer.AbstractAcquirer;
import ae.network.dob.adapter.base24.database.model.acquirer.SimpleAcquirer;
import ae.network.dob.adapter.base24.model.application.Merchant;
import org.springframework.stereotype.Service;

/**
 * @author Success.Otto
 * @since 02-04-2020
 */
@Service("simpleAcquirerService")
public class SimpleAcquirerServiceImpl implements AcquirerService {

    @Override
    public String getFiId(Merchant merchant, AbstractAcquirer abstractAcquirer) {
        return ((SimpleAcquirer) abstractAcquirer).getFiId();
    }

    @Override
    public String getPRDFTemplateId(Merchant merchant, AbstractAcquirer abstractAcquirer) {
        return ((SimpleAcquirer) abstractAcquirer).getDeviceDetails().getPrdf();
    }

    @Override
    public String getPTDTemplateId(Merchant merchant, AbstractAcquirer abstractAcquirer) {
        return ((SimpleAcquirer) abstractAcquirer).getDeviceDetails().getPtd();
    }

}
