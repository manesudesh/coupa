package ae.network.dob.adapter.base24.service.acquirer;

import ae.network.dob.adapter.base24.database.model.acquirer.AcquirerConfig;
import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import ae.network.dob.adapter.base24.database.repository.AcquirerConfigRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * @author : Yousry
 * @author Success.Otto
 * @version : 1.0
 */

@Service("acquirerConfigService")
@AllArgsConstructor
public class AcquirerConfigService {

    /**
     * Injection of AcquirerConfig Repository
     */
    private AcquirerConfigRepository acquirerConfigRepository;

    /**
     * Finds an acquirer config by
     * an acquirer name
     */
    public Optional<AcquirerConfig> findByAcquirer(Acquirer acquirer) {
        return acquirerConfigRepository.findByAcquirerAcquirer(acquirer);
    }
}
