package ae.network.dob.adapter.base24.rabbitmq.config;

import ae.network.dob.adapter.base24.service.rpc.LookupService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.remoting.client.AmqpProxyFactoryBean;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@Configuration
@EnableRabbit
public class RabbitConfig {
    @Bean
    public AmqpAdmin rabbitAdmin(ConnectionFactory factory) {
        return new RabbitAdmin(factory);
    }

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory factory) {
        RabbitTemplate rabbitTemplate = new RabbitTemplate(factory);
        ObjectMapper jsonObjectMapper = new ObjectMapper();
        jsonObjectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        Jackson2JsonMessageConverter messageConverter = new Jackson2JsonMessageConverter(jsonObjectMapper);
        rabbitTemplate.setMessageConverter(messageConverter);
        return rabbitTemplate;
    }

    @Bean
    AmqpProxyFactoryBean lookupServiceFactory(ConnectionFactory factory) {
        AmqpProxyFactoryBean factoryBean = new AmqpProxyFactoryBean();
        factoryBean.setServiceInterface(LookupService.class);
        RabbitTemplate proxyTemplate = new RabbitTemplate(factory);
        proxyTemplate.setRoutingKey(RabbitQueue.UTILS.getRoutingKeys().get(0));
        proxyTemplate.setExchange(RabbitExchange.ONBOARDING.getExchangeName());
        factoryBean.setAmqpTemplate(proxyTemplate);
        return factoryBean;
    }
}
