package ae.network.dob.adapter.base24.database.model.reply;

import ae.network.dob.adapter.base24.database.model.request.BackendSystem;
import ae.network.dob.adapter.base24.rabbitmq.message.QueueMessage;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ApplicationUpdate implements QueueMessage {
    private String applicationId;
    private BackendSystem backendSystem;
    private ProcessingResult processingResult;
}
