package ae.network.dob.adapter.base24.database.repository;

import ae.network.dob.adapter.base24.database.model.templates.KeyMerchantTemplate;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface KeyMerchantTemplateRepository extends MongoRepository<KeyMerchantTemplate, String> {

    Optional<KeyMerchantTemplate> findTopByChainId(String chainId);

    boolean existsKeyMerchantTemplateByChainId(String chainId);

    Optional<KeyMerchantTemplate> findTopByMerchantSegment(String merchantSegment);

    Optional<KeyMerchantTemplate> findTopByOrgName(String orgName);

    Optional<KeyMerchantTemplate> findTopByChainIdAndTerminalModel(String chainId, String terminalModel);

    boolean existsKeyMerchantTemplateByChainIdAndTerminalModel(String chainId, String terminalModel);
}
