package ae.network.dob.adapter.base24.database.model.acquirer;

import lombok.Data;

/**
 * @author Success.Otto
 * @since 26/03/2020
 */
@Data
public class PosConfig implements MerchantTypeConfig {
    /**
     * Merchant fiId
     */
    private String fiId;
    /**
     * Different Template ID of the merchant
     */
    private boolean enabled;
    private DeviceDetails deviceDetails;
}
