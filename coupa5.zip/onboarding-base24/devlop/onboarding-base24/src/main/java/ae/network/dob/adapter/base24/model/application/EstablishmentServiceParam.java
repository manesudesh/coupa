package ae.network.dob.adapter.base24.model.application;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * @author Waseem
 * @version 1.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EstablishmentServiceParam extends MerchantService {

    @Size(max = 10, message = "Amex Code is longer than 10 characters")
    @Pattern(regexp = "^[a-zA-Z0-9]+$", message = "amexCode should only consist of alphanumeric string. No Spaces.")
    private String amexCode;

    @Size(min = 3, max = 3, message = "County should be 3 characters.")
    private String county;
}
