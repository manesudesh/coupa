package ae.network.dob.adapter.base24.service.file;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringJoiner;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import ae.network.dob.adapter.base24.common.Base24FileGenerationHelper;
import ae.network.dob.adapter.base24.config.Base24Configs;
import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.database.model.request.Base24File;
import ae.network.dob.adapter.base24.database.model.request.FileType;
import ae.network.dob.adapter.base24.database.model.request.RequestType;
import ae.network.dob.adapter.base24.database.model.request.Task;
import ae.network.dob.adapter.base24.database.model.request.TaskHistory;
import ae.network.dob.adapter.base24.database.model.request.TaskName;
import ae.network.dob.adapter.base24.database.model.request.TaskStatus;
import ae.network.dob.adapter.base24.database.repository.ApplicationRequestRepository;
import ae.network.dob.adapter.base24.database.repository.Base24FileRepository;
import ae.network.dob.adapter.base24.model.application.Address;
import ae.network.dob.adapter.base24.model.application.AddressType;
import ae.network.dob.adapter.base24.model.application.Application;
import ae.network.dob.adapter.base24.model.application.BinShareServiceParam;
import ae.network.dob.adapter.base24.model.application.EstablishmentServiceParam;
import ae.network.dob.adapter.base24.model.application.Merchant;
import ae.network.dob.adapter.base24.model.application.MerchantType;
import ae.network.dob.adapter.base24.model.application.OnboardingRequest;
import ae.network.dob.adapter.base24.model.application.Terminal;
import ae.network.dob.adapter.base24.model.application.amendment.AmendmentType;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Waseem.Ismail
 * @since 2020-01-29
 */
@Slf4j
@Service
public class Base24FileGenerationService {

	/**
	 * Base24 file separator.
	 * See https://networkinternational.atlassian.net/wiki/spaces/NAACE/pages/279020761/File+structure
	 */
	public static final String BASE24_FILE_SEPARATOR = "|";

	private final Base24FileRepository base24FileRepository;
	private final ApplicationRequestRepository applicationRequestRepository;
	private final Base24FileGenerationHelper base24FileGenerationHelper;
	private final Base24Configs base24Configs;
	private final EprdGenerationService eprdGenerationService;

	public Base24FileGenerationService(Base24FileRepository base24FileRepository,
									   ApplicationRequestRepository applicationRequestRepository,
									   Base24FileGenerationHelper base24FileGenerationHelper, Base24Configs base24Configs,
									   EprdGenerationService eprdGenerationService) {
		this.base24FileRepository = base24FileRepository;
		this.applicationRequestRepository = applicationRequestRepository;
		this.base24FileGenerationHelper = base24FileGenerationHelper;
		this.base24Configs = base24Configs;
		this.eprdGenerationService = eprdGenerationService;
	}


	public void generateBase24RequestRecords(ApplicationRequest applicationRequest) {

		log.info("generateBase24RequestFile started  for ApplicationRequest {}", applicationRequest.getApplicationId());
		OnboardingRequest requestPayLoad = applicationRequest.getPayload();

		for (Application application : requestPayLoad.getApplications()) {

			log.info("generating Files for Application: {}", application.toString());

			if (application.getMerchants() == null || application.getMerchants().isEmpty())
				continue;

			for (Merchant merchant : application.getMerchants()) {

				if (!(applicationRequest.getAcquirer() == Acquirer.NI
						&& merchant.validNGOneMerchant(base24Configs))) {
					if(applicationRequest.getRequestType()==RequestType.ONBOARDING) {
						continue;
					}
				}

				if(!base24FileGenerationHelper.isMerchantTypeSupported(applicationRequest.getAcquirer(), merchant)) {
					log.info("Merchant ID : {}, Merchant Type : {} for the Acquirer {} is not supported",
							merchant.getMerchantId(), merchant.getMerchantType(), applicationRequest.getAcquirer());
					handleUnsupportedOperation(applicationRequest, merchant,
							"Merchant Operation Not Supported (MerchantCurrency or MerchantType not provided), "
									+ "or MerchantType for This Acquirer not supported");
					continue;
				}

				// Add a failed Task for this specific Merchant,
				// and a task History to Describe the unsupported Amendment
				if (applicationRequest.getRequestType() == RequestType.AMENDMENT
						&& !base24FileGenerationHelper.validAmendment(merchant)) {
					boolean isEprdFileNeeded = isEprdFileNeeded(merchant);
					if (isEprdFileNeeded) {
						handleMerchantEprdFile(applicationRequest, merchant);
					} else {
						handleUnsupportedOperation(applicationRequest, merchant,"Merchant Amendmement Operation Not Supported");
					}
					continue;
				}

				if(applicationRequest.getRequestType()!=RequestType.TERMINAL_CLOSURE)
					handleMerchantPRDFFile(applicationRequest, application, merchant);

				boolean isEprdFileNeeded = isEprdFileNeeded(merchant);
				if (isEprdFileNeeded) {
					handleMerchantEprdFile(applicationRequest, merchant);
				}

				if(applicationRequest.getAcquirer()==Acquirer.TYME && merchant.isSoftPosService())
					continue;

				if (!merchant.isSOFTPOSService() && !CollectionUtils.isEmpty(merchant.getTerminals()) && base24FileGenerationHelper.validTerminalAmendment(merchant))

					for (Terminal terminal : merchant.getTerminals()) {

						handleTerminalPTDFile(applicationRequest,application, merchant, terminal);

						if (merchant.getMerchantType().equals(MerchantType.POS)) {

							handleTerminalCSECDFile(applicationRequest, application, merchant, terminal);
						}
					}
			}
		}

	}

	private boolean isEprdFileNeeded(Merchant merchant) {
		boolean ttiEnabled = !eprdGenerationService.buildTti(merchant).equals("");
		return merchant.isBrighterionService()
				|| (merchant.getMcippOptIn() != null && merchant.getMcippOptIn())
				|| (merchant.getMcippOptIn() != null && !merchant.getMcippOptIn() && merchant.getMaid() != null)
				|| ttiEnabled
				|| merchant.isVisaInstallmentsEnabled()
				|| (! StringUtils.isEmpty(merchant.getCountryOrigin()));
	}

	private void handleMerchantEprdFile(ApplicationRequest applicationRequest, Merchant merchant) {
		log.info("Generating EPRD File for Merchant: {}", merchant.getMerchantId());

		Base24File eprdFile = eprdGenerationService.generateEprdBase24File(applicationRequest, merchant);

		log.info("EPRD File Entity created {}", eprdFile);

		base24FileRepository.insert(eprdFile);
		createTask(applicationRequest, eprdFile, TaskName.SEND_EPRD_REQUEST, TaskStatus.COMPLETED);
		createTask(applicationRequest, eprdFile, TaskName.RECEIVE_EPRD_RESPONSE, TaskStatus.IN_PROGRESS);

		applicationRequestRepository.save(applicationRequest);

		log.info("ApplicationRequest Saved with the new Merchant Tasks: {}", applicationRequest.getApplicationId());
	}


	private void handleMerchantPRDFFile(ApplicationRequest applicationRequest,Application application, Merchant merchant) {

		log.info("generating PRDF File for Merchant: {}", merchant.getMerchantId());


		if (merchant.getMerchantName() == null) {
			merchant.setMerchantName("");
		}

		String prdfFileContent;
		if (applicationRequest.getRequestType() == RequestType.AMENDMENT
				&& !base24FileGenerationHelper.validMerchantAmendment(merchant)
				&& !base24FileGenerationHelper.containsValidAmendment(applicationRequest)) {
			prdfFileContent = "";
		}else
			prdfFileContent = generatePRDFRecord(applicationRequest,application, merchant);


		log.info("PRDF content for Merchant: {} : {}", merchant.getMerchantId(), prdfFileContent);

		String prdfTemplateID="";
		if(applicationRequest.getRequestType()==RequestType.ONBOARDING)
			prdfTemplateID = base24FileGenerationHelper.getPRDFTemplateId(application, merchant,
					applicationRequest.getAcquirer());


		Base24File prdfFile = createBase24FileEntity(applicationRequest.getApplicationId(),applicationRequest.getAcquirer().name(), FileType.PRDF,
				merchant.getMerchantId(), prdfTemplateID, prdfFileContent);

		log.info("PRDF File Entity created {}", prdfFile);


		if (!prdfFileContent.isEmpty()) {
			log.info("PRDF File Entity before Insert {}", prdfFile);
			base24FileRepository.insert(prdfFile);
			createTask(applicationRequest, prdfFile, TaskName.SEND_MERCHANT_REQUEST, TaskStatus.COMPLETED);
			createTask(applicationRequest, prdfFile, TaskName.RECEIVE_MERCHANT_RESPONSE, TaskStatus.IN_PROGRESS);
			log.info("PRDF File Entity saved Successfull {}", prdfFile);
		}else {
			prdfFile.setExported(true);
			prdfFile.setCompleted(true);
			createTask(applicationRequest, prdfFile, TaskName.FILE_GENERATION, TaskStatus.COMPLETED);
		}


		applicationRequestRepository.save(applicationRequest);

		log.info("ApplicationRequest Saved with the new Merchant Tasks: {}",
				applicationRequest.getApplicationId());
	}


	/**
	 * This Method will be used to updated the Application Request with a Task/Task History
	 * describing the unsupported Merchant, in case of not providing MerchantType or MerchantCurrency
	 * which is required for getting AcquirerConfigs
	 */
	private void handleUnsupportedOperation(ApplicationRequest applicationRequest, Merchant merchant,String errorMessage) {

		log.info("Handling Unsupported Merchant Operation for Merchant {}, Amendment List: {}", merchant.getMerchantId(),
				merchant.getAmendmentList());

		Base24File prdfFile = createBase24FileEntity(applicationRequest.getApplicationId(),applicationRequest.getAcquirer().name(), FileType.PRDF,
				merchant.getMerchantId(), "", "");

		Task task= createTask(applicationRequest, prdfFile, TaskName.SEND_MERCHANT_REQUEST,
				TaskStatus.CANCELLED);
		task.setEntityId("PRDF:"+merchant.getMerchantId());

		TaskHistory taskHistory = TaskHistory.builder().createdDate(new Date()).lastModifiedDate(new Date())
				.statusCode("1099").taskStatus(TaskStatus.CANCELLED)
				.response(errorMessage).build();
		task.getTaskHistory()
				.add(taskHistory);
		applicationRequestRepository.save(applicationRequest);
	}



	/**
	 * Terminal File Content and the related updates to the Application request
	 * to be handled here.
	 */
	private void handleTerminalPTDFile(ApplicationRequest applicationRequest,Application application, Merchant merchant, Terminal terminal) {
		log.info("generating PTD File for Merchant: {}, Terminal: {}", merchant.getMerchantId(),
				terminal.getTerminalId());

		String ptdFileContent = generatePTDRecord(applicationRequest, application, merchant, terminal);

		log.info("PTD content for Merchant: {} : Termina {} : {}", merchant.getMerchantId(),
				terminal.getTerminalId(), ptdFileContent);

		String ptdTemplateId = base24FileGenerationHelper.getPTDTemplateId(application, merchant,
				applicationRequest.getAcquirer());

		Base24File ptdFile = createBase24FileEntity(applicationRequest.getApplicationId(),applicationRequest.getAcquirer().name(), FileType.PTD,
				terminal.getTerminalId(), ptdTemplateId, ptdFileContent);

		log.info("PTD File Entity created {}", ptdFile);

		createTask(applicationRequest, ptdFile, TaskName.SEND_TERMINAL_REQUEST, TaskStatus.COMPLETED);
		createTask(applicationRequest, ptdFile, TaskName.RECEIVE_TERMINAL_RESPONSE,
				TaskStatus.IN_PROGRESS);


		applicationRequestRepository.save(applicationRequest);
		log.info("ApplicationRequest Saved with the new Terminal Tasks: {}",
				applicationRequest.getApplicationId());

		log.info("PTF File Entity before Insert {}", ptdFile);
		base24FileRepository.insert(ptdFile);
		log.info("PTF File Entity saved Successfull {}", ptdFile);
	}


	/**
	 * POS Terminal CSECD File content,
	 * and the related ApplicationRequest updates to be handled here
	 */
	private void handleTerminalCSECDFile(ApplicationRequest applicationRequest, Application application, Merchant merchant, Terminal terminal) {

		log.info("generating CSECD File for Merchant: {}, Terminal: {}", merchant.getMerchantId(),
				terminal.getTerminalId());
		if(applicationRequest.getRequestType()==RequestType.AMENDMENT &&
				!merchant.getAmendmentList().contains(AmendmentType.ADDING_TERMINALS.name()))
			return;


		String csecdFileContent = generateCSECDRecord(applicationRequest, application, merchant, terminal);
		log.info("CSEC content for Merchant: {} : Termina {} : {}", merchant.getMerchantId(),
				terminal.getTerminalId(), csecdFileContent);

		String csecdTemplateId = base24FileGenerationHelper.getCSECDTemplateId(application,merchant,
				applicationRequest.getAcquirer());

		Base24File csecFile = createBase24FileEntity(applicationRequest.getApplicationId(),applicationRequest.getAcquirer().name(),
				FileType.CSECD, terminal.getTerminalId(), csecdTemplateId, csecdFileContent);

		log.info("CSECD File Entity created {}", csecFile);
		createTask(applicationRequest, csecFile, TaskName.SEND_POS_TERMINAL_REQUEST,
				TaskStatus.COMPLETED);
		createTask(applicationRequest, csecFile, TaskName.RECEIVE_POS_TERMINAL_RESPONSE,
				TaskStatus.IN_PROGRESS);

		applicationRequestRepository.save(applicationRequest);
		log.info("ApplicationRequest Saved with the new POS Terminal Tasks: {}",
				applicationRequest.getApplicationId());

		log.info("CSECD File Entity before Insert {}", csecFile);
		base24FileRepository.insert(csecFile);
		log.info("CSECD File Entity saved Successfull {}", csecFile);
	}

	private String generatePRDFRecord(ApplicationRequest applicationRequest, Application application, Merchant merchant) {

		log.info("generatePRDFFile started for ApplicationID {}, Merchant {},", applicationRequest.getApplicationId(),
				merchant.getMerchantId());

		StringJoiner recordBuilder = new StringJoiner(BASE24_FILE_SEPARATOR);

		recordBuilder.add("PR");// Record\File type
		RequestType requestType = applicationRequest.getRequestType();

		recordBuilder.add(requestType.toString());

		////NASSC-3032 populating FFID and Template ID in PRDF records always
		String FIID = base24FileGenerationHelper.getFiId(application, merchant, applicationRequest.getAcquirer());
		String merchantTemplateId = base24FileGenerationHelper.getPRDFTemplateId(application ,merchant,
				applicationRequest.getAcquirer());

		if (requestType == RequestType.MERCHANT_CLOSURE) {

			recordBuilder.add(merchantTemplateId);//TemplateID place Holder
			recordBuilder.add(merchant.getMerchantId());
			recordBuilder.add(FIID);//FIID place Holder

			return recordBuilder
					.add(base24FileGenerationHelper.getEmptyPlaceHolders(87))
					.toString();

		} else if (requestType == RequestType.AMENDMENT) {

			recordBuilder.add(merchantTemplateId);//TemplateID place Holder
			recordBuilder.add(merchant.getMerchantId());
			recordBuilder.add(FIID);//FIID place Holder
		}else {

			String merchantId = merchant.getMerchantId();

			recordBuilder.add(merchantTemplateId);
			recordBuilder.add(merchantId);
			recordBuilder.add(FIID);

		}

		//Mapped with “Merchant name”
		if (requestType == RequestType.ONBOARDING || (requestType == RequestType.AMENDMENT
				&& (merchant.getAmendmentList().contains(AmendmentType.LEGAL_NAME.toString())
				|| merchant.getAmendmentList().contains(AmendmentType.MERCHANT_NAME.toString()))))
			recordBuilder.add(getAdjustedMerchantName(merchant));
		else
			recordBuilder.add("");


		if (requestType == RequestType.ONBOARDING || (requestType == RequestType.AMENDMENT
				&& merchant.getAmendmentList().contains(AmendmentType.ADDRESS.toString()))) {

			Address merchantDefaultAddress = getMerchantDefaultAddress(merchant);
			if(merchantDefaultAddress.getAddressLines().get(0).length()>25)
				recordBuilder.add(merchantDefaultAddress.getAddressLines().get(0).substring(0, 25));
			else
				recordBuilder.add(merchantDefaultAddress.getAddressLines().get(0));

			recordBuilder.add(merchantDefaultAddress.getCity()!=null?merchantDefaultAddress.getCity():"");// Mapped with “City”
			// "Statement address" for
			recordBuilder.add(merchantDefaultAddress.getState()!=null?merchantDefaultAddress.getState():"");// Mapped with “State / Country”

			recordBuilder.add(merchantDefaultAddress.getPhone() == null ? "" : merchantDefaultAddress.getPhone());
			// ITS PART OF THE ADDRESS ARRAY SIMILAR TO THE CITY, NEED to check y the phone
		}else {

			recordBuilder.add(base24FileGenerationHelper.getEmptyPlaceHolders(3));// 4 field separators
		}

		// After Working hours, Not applicable
		recordBuilder.add("");

		// SIC CODE
		if (requestType == RequestType.ONBOARDING
				|| (requestType == RequestType.AMENDMENT && merchant.getAmendmentList().contains(AmendmentType.MCC.toString()))) {

			String mccStr;
			mccStr = formatMCCCode(merchant);
			recordBuilder.add(mccStr);

			//recordBuilder.add(base24FileGenerationHelper.getEmptyPlaceHolders(3));
			recordBuilder.add("Y");// "PRE COMPL
			recordBuilder.add("Y");//"RETL VAL"
			recordBuilder.add("00");//"AMT"
			recordBuilder.add("");//The Automated Clearing House (ACH)

			recordBuilder.add(mccStr);// MAIL PHONE SIC CODE
		} else {
			recordBuilder.add("");
			// recordBuilder.add(base24FileGenerationHelper.getEmptyPlaceHolders(3));
			recordBuilder.add("Y");// "PRE COMPL
			recordBuilder.add("Y");// "RETL VAL"
			recordBuilder.add("00");// "AMT"
			recordBuilder.add("");// The Automated Clearing House (ACH)
			recordBuilder.add("");// MAIL PHONE SIC CODE
		}

		if (merchant.isAmexService()) {
			EstablishmentServiceParam establishmentServiceParam = (EstablishmentServiceParam)merchant.getAmexServiceParams().get();
			recordBuilder.add(establishmentServiceParam.getAmexCode()!=null?establishmentServiceParam.getAmexCode():"");// SERVICE ESTABLISHMENT,Not Applicable
		}else
			recordBuilder.add("");

		recordBuilder.add("");// CHECK MERSH ID,,Not Applicable
		recordBuilder.add("");// CHECK RTG GROUP,Not Applicable

		if (merchant.isBinShareService()) {
			recordBuilder.add("Y");// EPP Flag
		}else
			recordBuilder.add("");// EPP Flag

		//RETAILER CUTOVER/BALANCE START
		recordBuilder.add(StringUtils.isEmpty(merchant.getCutOffStart())?"":merchant.getCutOffStart().replace(":", ""));
		//RETAILER CUTOVER/BALANCE END
		recordBuilder.add(StringUtils.isEmpty(merchant.getCutOffEnd())?"":merchant.getCutOffEnd().replace(":", ""));

		recordBuilder.add(base24FileGenerationHelper.getEmptyPlaceHolders(3));
		//ACQUIRER TXN PROFILE
		//RETAILER TXN PROFILE
		//EMV CAPABLE
		//AMEX SE NUMBER CHECK

		if (merchant.isAmexService()) {
			EstablishmentServiceParam establishmentServiceParam = (EstablishmentServiceParam)merchant.getAmexServiceParams().get();
			recordBuilder.add(establishmentServiceParam.getCounty()!=null?establishmentServiceParam.getCounty():"");
		}else
			recordBuilder.add("");

		if (!merchant.isDefaultCardSchemes() && (requestType == RequestType.ONBOARDING
				|| (requestType == RequestType.AMENDMENT && merchant.getAmendmentList().contains(AmendmentType.ACCEPTED_CARDS.toString())))) {

			if(requestType == RequestType.ONBOARDING)
				recordBuilder.add("Y");// FLAG CARD TYPE UPDATE
			else
				recordBuilder.add("B");// FLAG CARD TYPE Append

			String cardTypes = base24FileGenerationHelper.getMerchantCardTypesStr(merchant,merchantTemplateId,FileType.PRDF);
			recordBuilder.add(cardTypes);
		}else {
			recordBuilder.add("N");// FLAG CARD TYPE UPDATE
			recordBuilder.add(base24FileGenerationHelper.getEmptyPlaceHolders(29));
		}

		if(merchant.isBinShareService()) {
			recordBuilder.add("Y");
		}else
			recordBuilder.add("N");

		// Note: Currently BIN tables are not supported during amendment flow, so set N
		// for amendment until it will be supported by flow. •Closure: always N

		if(merchant.isBinShareService()) {
			BinShareServiceParam binShareServiceParam = (BinShareServiceParam)merchant.getBinShareServiceParams().get();
			recordBuilder.add(base24FileGenerationHelper.getBinShareStr(binShareServiceParam.getBinShareOffers()));
			recordBuilder.add(base24FileGenerationHelper.getEmptyPlaceHolders(2));
		}
		else
			recordBuilder.add(base24FileGenerationHelper.getEmptyPlaceHolders(32));
		// End OF PRDF File

		log.info("generatePRDFFile finished for ApplicationID {}, Merchant {},", applicationRequest.getApplicationId(),
				merchant.getMerchantId());
		return recordBuilder.toString();

	}

	private String getAdjustedMerchantName(Merchant merchant) {
		if (StringUtils.isEmpty(merchant.getLegalName())) {
			return "";
		} else if (merchant.getLegalName().length() >= 25) {
			return merchant.getLegalName().substring(0, 24);
		} else {
			return merchant.getLegalName();
		}
	}

	private String generatePTDRecord(ApplicationRequest applicationRequest,Application application,Merchant merchant, Terminal terminal) {

		log.info("generatePTDFile started for ApplicationID {}, Merchant {}, Terminal {}",
				applicationRequest.getApplicationId(), merchant.getMerchantId(), terminal.getTerminalId());

		StringJoiner recordBuilder = new StringJoiner(BASE24_FILE_SEPARATOR);

		recordBuilder.add("PT");

		RequestType base24opType = applicationRequest.getRequestType();

		//NASSC-3032 using FIID and Template ID for all types of operations (CLOSURE|AMENDMENT) in addition to the original ONBOARDING
		String FIID = base24FileGenerationHelper.getFiId(application, merchant, applicationRequest.getAcquirer());
		String templateID = base24FileGenerationHelper.getPTDTemplateId(application, merchant, applicationRequest.getAcquirer());

		if (applicationRequest.getRequestType().equals(RequestType.AMENDMENT)
				&& merchant.getAmendmentList().contains(AmendmentType.ADDING_TERMINALS.toString())) {
			base24opType = RequestType.ONBOARDING;

		} else if ((applicationRequest.getRequestType() == RequestType.MERCHANT_CLOSURE
				|| applicationRequest.getRequestType() == RequestType.TERMINAL_CLOSURE)
				|| (applicationRequest.getRequestType() == RequestType.AMENDMENT
				&& merchant.getAmendmentList().contains(AmendmentType.TERMINAL_CLOSURE.toString()))) {

			recordBuilder.add("D");// Operation
			recordBuilder.add(templateID);// TemplateID
			recordBuilder.add(terminal.getTerminalId());
			recordBuilder.add(FIID);

			return recordBuilder.add(base24FileGenerationHelper.getEmptyPlaceHolders(6)).add(merchant.getMerchantId())
					.add(base24FileGenerationHelper.getEmptyPlaceHolders(46)).toString();

		}

		recordBuilder.add(base24opType.toString());// Operation

		if (base24opType == RequestType.ONBOARDING || (base24opType == RequestType.AMENDMENT
				&& merchant.getAmendmentList().contains(AmendmentType.ADDING_TERMINALS.toString()))) {
			recordBuilder.add(templateID);// TemplateID

			recordBuilder.add(terminal.getTerminalId());
			recordBuilder.add(FIID);//NASSC-3032 FIID

		} else {

			recordBuilder.add(templateID);// TemplateID
			recordBuilder.add(terminal.getTerminalId());
			recordBuilder.add(FIID); //NASSC-3032
		}

		recordBuilder.add("");// SITE ID, A value used to group terminals at a specific site, Keep Empty

		recordBuilder.add(getMerchantLocation(merchant));// LOCATION, Mapped with "Outlet (Merchant)"."Merchant Name"

		// getting the default merchant Address

		if (base24opType == RequestType.ONBOARDING || (base24opType == RequestType.AMENDMENT
				&& (merchant.getAmendmentList().contains(AmendmentType.ADDING_TERMINALS.toString())
				|| merchant.getAmendmentList().contains(AmendmentType.ADDRESS.toString())))) {

			Address merchantDefaultAddress = getMerchantDefaultAddress(merchant);
			String city = merchantDefaultAddress.getCity();
			if(city!=null && city.length()>13)
				city = city.substring(0,13);
			recordBuilder.add(city);// Mapped with “City” in "Address"
			recordBuilder.add(merchantDefaultAddress.getState()!=null?merchantDefaultAddress.getState():"");// STATE
			String countryCode = base24FileGenerationHelper
					.getAlpha2CountryCode(merchantDefaultAddress.getCountryCode());
			recordBuilder.add(countryCode);// make sure country code is 2 letters
			recordBuilder.add(merchantDefaultAddress.getPostalCode()!=null?merchantDefaultAddress.getPostalCode():"");// Postal code, keep empty

		}else {
			recordBuilder.add(base24FileGenerationHelper.getEmptyPlaceHolders(3));
		}


		if (base24opType == RequestType.ONBOARDING || (base24opType == RequestType.AMENDMENT
				&& (merchant.getAmendmentList().contains(AmendmentType.ADDING_TERMINALS.toString())
				|| merchant.getAmendmentList().contains(AmendmentType.MERCHANT_NAME.toString()))))
			recordBuilder.add(getTerminalOwner(merchant));// Terminal owner,Not Applicable
		else
			recordBuilder.add("");// Terminal owner,Not Applicable

		recordBuilder.add(merchant.getMerchantId());// Retail id, mapped with merchant ID

		if (base24opType == RequestType.AMENDMENT)
			recordBuilder.add("");// TERM STATUS
		else
			recordBuilder.add(base24opType.toString());

		recordBuilder.add(base24FileGenerationHelper.getEmptyPlaceHolders(9));
		// place holders for the following
		// BELLING INFO,Not Applicable
		// CLERK ID,Not Applicable
		// LANGUAGE ID,Not Applicable
		// PG ID,Not Applicable
		// TMS FLAG,Not Applicable
		// SEND B24 RCDE,Not Applicable
		// ROUTING GROUP,Not Applicable
		// DUAL SITE INDICATOR, KEEP EMPTY
		// LOAD FILE NAME,Not Applicable
		// TERMINAL CUT OVER,Not Applicable this can be provided

		if (base24opType == RequestType.ONBOARDING
				|| (base24opType == RequestType.AMENDMENT && merchant.getAmendmentList().contains(AmendmentType.MCC.toString()))) {
			String mccStr;
			mccStr = formatMCCCode(merchant);
			recordBuilder.add(mccStr);// TERMINAL SIC CODE

		} else
			recordBuilder.add("");// TERMINAL SIC CODE

		recordBuilder.add("");// CONTACT INPUT CAPABILITIES,Not Applicable
		// if this can be provided
		recordBuilder.add("");// CONTACTLESS INPUT CAPABILTIES,Not Applicable

		// FLAG CARD TYPE UPDATE, Y or No, need to check if this can be provided in the
		if ((!merchant.isDefaultCardSchemes()) && (base24opType == RequestType.ONBOARDING || (base24opType == RequestType.AMENDMENT
				&& (merchant.getAmendmentList().contains(AmendmentType.ACCEPTED_CARDS.toString()) || merchant
				.getAmendmentList().contains(AmendmentType.TERMINAL_ACCEPTED_CARDS.toString()))))) {

			recordBuilder.add("Y");
			recordBuilder.add(base24FileGenerationHelper.getMerchantCardTypesStr(merchant,templateID,FileType.PTD));// Accepted card Types,

		} else {
			recordBuilder.add("N");
			recordBuilder.add(base24FileGenerationHelper.getEmptyPlaceHolders(29));// Accepted card Types,
		}

		// we fetch this from the Merchant configs not the
		// terminal
		recordBuilder.add(base24FileGenerationHelper.getEmptyPlaceHolders(1));

		log.info("generatePTDFile Finished for ApplicationID {}, Merchant {}, Terminal {}",
				applicationRequest.getApplicationId(), merchant.getMerchantId(), terminal.getTerminalId());

		return recordBuilder.toString();
	}

	private String generateCSECDRecord(ApplicationRequest applicationRequest, Application application, Merchant merchant, Terminal terminal) {

		log.info("generateCSECDFile started for ApplicationID {}, Merchant {}, Terminal {}",
				applicationRequest.getApplicationId(), merchant.getMerchantId(), terminal.getTerminalId());
		StringJoiner recordBuilder = new StringJoiner(BASE24_FILE_SEPARATOR);
		recordBuilder.add("CS");

		RequestType base24opType = applicationRequest.getRequestType();

		if (applicationRequest.getRequestType().equals(RequestType.AMENDMENT)
				&& merchant.getAmendmentList().contains(AmendmentType.ADDING_TERMINALS.toString())) {
			base24opType = RequestType.ONBOARDING;

		} else if(applicationRequest.getRequestType() == RequestType.MERCHANT_CLOSURE
				|| applicationRequest.getRequestType() == RequestType.TERMINAL_CLOSURE) {
			base24opType = RequestType.MERCHANT_CLOSURE;
		}

		recordBuilder.add(base24opType.toString());

		String templateID = base24FileGenerationHelper.getCSECDTemplateId(application , merchant, applicationRequest.getAcquirer());
		recordBuilder.add(templateID);
		recordBuilder.add(terminal.getTerminalId());
		recordBuilder.add("");

		log.info("generateCSECDFile Finished for ApplicationID {}, Merchant {}, Terminal {}",
				applicationRequest.getApplicationId(), merchant.getMerchantId(), terminal.getTerminalId());

		return recordBuilder.toString();
	}

	private Task createTask(ApplicationRequest applicationRequest, Base24File file, TaskName taskName,
							TaskStatus taskStatus) {
		log.info("createTask started for ApplicationRequest {}, File {}, TaskName {}, TaskStatus {}",
				applicationRequest.getApplicationId(), file, taskName.name(), taskStatus.name());

		Task task = Task.builder().entityId(file.getFileType().name() + ":" + file.getRecordId()).name(taskName.name())
				.taskStatus(taskStatus).taskHistory(new ArrayList<>()).build();
		applicationRequest.getTasks().add(task);
		log.info("createTask Completed for ApplicationRequest {}, File {}, TaskName {}, TaskStatus {}",
				applicationRequest.getApplicationId(), file, taskName.name(), taskStatus.name());
		return task;
	}

	private Base24File createBase24FileEntity(String applicationId,String acquirer,FileType recordType, String recordId,
											  String templateId, String fileContent) {

		log.info("createBase24FileEntity started for ApplicationRequest {}, FileType {}, RecordID {}, TemplateID {}",
				applicationId, recordType.name(), recordId, templateId);

		Base24File base24File = Base24File.builder().fileType(recordType).applicationId(applicationId)
				.fileContent(fileContent).templateId(templateId).recordId(recordId).exported(Boolean.FALSE)
				.completed(Boolean.FALSE).acquirer(acquirer).build();

		log.info("createBase24FileEntity Completed for ApplicationRequest {}, FileType {}, RecordID {}, TemplateID {}",
				applicationId, recordType.name(), recordId, templateId);

		return base24File;
	}

	/**
	 * Will return the default address if its available, if its not available it
	 * otherwise will return the statement address, non of the addresses is available
	 * the first address in the list will be returned, if no Address provided,
	 * empty address returned.
	 * @return Address
	 */
	private Address getMerchantDefaultAddress(Merchant merchant) {
		log.info("getMerchantDefaultAddress started for Merchant {} ", merchant.getMerchantId());

		Address address;

		if (merchant.getAddresses() == null || merchant.getAddresses().isEmpty()) {
			ArrayList<String> addressLines= new ArrayList<>();
			addressLines.add("");
			address = Address.builder().city("").state("").
					countryCode("").postalCode("").phone("").
					pobox("").addressLines(addressLines).build();
			return address;
		}

		List<Address> addresses = merchant.getAddresses().stream()
				.filter(defAddress -> defAddress.getAddressType() == AddressType.DEFAULT).collect(Collectors.toList());

		if (addresses.isEmpty()) {
			addresses = merchant.getAddresses().stream()
					.filter(defAddress -> defAddress.getAddressType() == AddressType.STMT_ADDR).collect(Collectors.toList());
		}

		log.info("getMerchantDefaultAddress Completed for Merchant {} ", merchant.getMerchantId());

		if (!addresses.isEmpty()) {
			address = addresses.get(0);
		} else {
			address = merchant.getAddresses().get(0);
		}

		if(address.getAddressLines()==null || address.getAddressLines().isEmpty()) {
			ArrayList<String> addressLines= new ArrayList<>();
			addressLines.add("");
			address.setAddressLines(addressLines);
		}

		return address;
	}

	/**
	 * Logic to get the Merchant Location field,
	 * if merchantName is longer than 25 characters.
	 */
	private String getMerchantLocation(Merchant merchant) {
		String merchantLocation = merchant.getMerchantName();
		if(merchantLocation!=null && merchantLocation.length()>25) {

			merchantLocation = merchantLocation.substring(0,24);
		}
		return merchantLocation;
	}


	/**
	 * add leading 0's to MCC code if its less than 4 digits
	 */
	private String formatMCCCode(Merchant merchant) {
		String mccStr;
		if(merchant.getMcc()==null) {
			mccStr = "0000";
		}else {
			mccStr = new DecimalFormat("0000").format(merchant.getMcc());
		}

		return mccStr;
	}

	private String getTerminalOwner(Merchant merchant) {
		if (StringUtils.isEmpty(merchant.getMerchantName()))
			return "";
		else if (merchant.getMerchantName().length() > 22) {
			return merchant.getMerchantName().substring(0, 21);
		} else {
			return merchant.getMerchantName();
		}
	}
}