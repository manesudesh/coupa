package ae.network.dob.adapter.base24.rabbitmq.processors;

import ae.network.dob.adapter.base24.common.MdcUtils;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Date;
import java.util.UUID;

/**
 * @author walid.sewaify
 * @since 2020-01-15
 */
@Component
public class CorrelationDataProcessor implements MessagePostProcessor {
    private final RabbitTemplate rabbitTemplate;

    private final String appName;

    public CorrelationDataProcessor(RabbitTemplate rabbitTemplate, @Value("${spring.application.name}") String appName) {
        this.rabbitTemplate = rabbitTemplate;
        this.appName = appName;
    }

    @Override
    public Message postProcessMessage(Message message) throws AmqpException {
        MessageProperties messageProperties = message.getMessageProperties();
        String correlationId = messageProperties.getCorrelationId();
        if (correlationId == null) {
            correlationId = UUID.randomUUID().toString();
            messageProperties.setCorrelationId(correlationId);
        }
        if (messageProperties.getAppId() != null) {
            messageProperties.setAppId(appName);
        }
        if (messageProperties.getTimestamp() == null) {
            messageProperties.setTimestamp(new Date());
        }
        if (messageProperties.getContentType() == null) {
            messageProperties.setContentType(MessageProperties.CONTENT_TYPE_JSON);
        }
        MdcUtils.setCorrId(correlationId);
        return message;
    }

    @PostConstruct
    public void init() {
        rabbitTemplate.addBeforePublishPostProcessors(this);
    }
}