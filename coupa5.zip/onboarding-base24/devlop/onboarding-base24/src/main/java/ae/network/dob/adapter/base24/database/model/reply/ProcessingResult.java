package ae.network.dob.adapter.base24.database.model.reply;

import ae.network.dob.adapter.base24.database.model.request.Task;
import ae.network.dob.adapter.base24.database.model.request.TaskStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @author walid.sewaify
 * @since 2020-03-05
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProcessingResult {
    private TaskStatus finalStatus;
    private Collection<Task> tasks = new ArrayList<>();
}
