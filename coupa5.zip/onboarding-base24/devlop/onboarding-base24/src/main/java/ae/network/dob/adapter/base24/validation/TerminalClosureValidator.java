package ae.network.dob.adapter.base24.validation;

import ae.network.dob.adapter.base24.database.model.error.AdapterError;
import ae.network.dob.adapter.base24.database.model.error.ErrorName;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.database.repository.ApplicationRequestRepository;
import ae.network.dob.adapter.base24.model.application.OnboardingRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;
import java.util.HashSet;
import java.util.Set;
import java.util.StringJoiner;

/**
 * @author : Waseem Ismail
 * @version : 1.0
 */
@Slf4j
@Service
public class TerminalClosureValidator extends BasicValidator {

    private final ApplicationRequestRepository applicationRequestRepository;

    public TerminalClosureValidator(ApplicationRequestRepository applicationRequestRepository) {
        super();
        this.applicationRequestRepository = applicationRequestRepository;
    }

    @Override
    public ValidationResult validate(ApplicationRequest request) {

        log.info("Terminal-Closure Validator started");

        OnboardingRequest onRequest = request.getPayload();
        boolean applicationIdExist = applicationRequestRepository.findFirstByApplicationId(request.getApplicationId())
                .isPresent();

        log.info("applicationIdExist = {}", applicationIdExist);

        if (applicationIdExist) {
            AdapterError error = errorMessageConfig.getMessages().stream()
                    .filter(err -> err.getName().equals(ErrorName.APPLICATION_EXIST.name()))
                    .findFirst().orElse(defaultAdapterError);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }

        try (ValidatorFactory factory = Validation.buildDefaultValidatorFactory()) {
            javax.validation.Validator validator = factory.getValidator();

            Set<ConstraintViolation> terminalClosureViolations = new HashSet<>();
            onRequest.getApplications().forEach(application -> {
                if (application.getMerchants() != null)
                    application.getMerchants().stream().filter(merchant -> !CollectionUtils.isEmpty(merchant.getTerminals()))
                            .forEach(merchant -> merchant.getTerminals()
                                    .forEach(terminal -> terminalClosureViolations.addAll(validator.validate(terminal))));
            });

            log.info("Terminal Constraints validation passed: {}", terminalClosureViolations.size() == 0);
            if (terminalClosureViolations.size() > 0) {
                AdapterError error = errorMessageConfig.getMessages().stream()
                        .filter(err -> err.getName().equals(ErrorName.CONSTRAINTS_VIOLATION.name()))
                        .findFirst().orElse(defaultAdapterError);

                return ValidationResult.builder().passed(false).code(error.getCode())
                        .message(aggregateErrorMessage(terminalClosureViolations)).build();
            }
            return ValidationResult.builder().passed(true).code("000").message("Success").build();
        }
    }

    private String aggregateErrorMessage(Set<ConstraintViolation> violations) {

        StringJoiner errorBuilder = new StringJoiner("\n");
        violations.forEach(violation -> errorBuilder.add(violation.getMessage()));

        return errorBuilder.toString();
    }

    @Override
    public ValidatorType getType() {
        return ValidatorType.TERMINAL_CLOSURE;
    }

}
