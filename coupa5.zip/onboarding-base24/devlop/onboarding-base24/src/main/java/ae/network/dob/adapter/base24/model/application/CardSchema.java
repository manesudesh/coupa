package ae.network.dob.adapter.base24.model.application;

public enum CardSchema {
    VISA("V"),
    MC("M"),
    PL("PL"), // Private Label
    JCB("J"),
    CUP("CU"), // China Union Pay
    MER("NP"), // Mercury
    DCI("DC"), // Diners Club International
    AMEX("AX"),
    MIR("RM"),
    RUPAY("RP"),

    UK("UK"),//Unknown card Type for Base24 usage only
    P("P"), P1("P1"), P2("P2"), P8("P8"), P9("P9"),
    //unknown cards
    NO("NO"), C1("C1"), C2("C2"), JC("JC"), NB("NB"),

    TBOD(""), // Departments
    DODB(""),
    DOCR(""),
    DOHY(""),
    SBOC(""),
    SBOD(""),
    DOPR(""),
    TBOC(""),
    ACQ_BKOC(""),
    ACQ_BKOD(""),
    ACQ_OTIC(""),
    ACQ_OTID(""),
    ACQ_DOCR(""),
    ACQ_DODB(""),
    
    JAYWAN("CB");

    private final String base24Scheme;

    CardSchema(String base24Scheme) {
        this.base24Scheme = base24Scheme;
    }

    public String toString() {
        return this.base24Scheme;
    }

}
