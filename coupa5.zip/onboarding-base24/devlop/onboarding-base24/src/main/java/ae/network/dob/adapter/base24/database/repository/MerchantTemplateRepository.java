package ae.network.dob.adapter.base24.database.repository;

import ae.network.dob.adapter.base24.database.model.cards.MerchantTemplate;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface MerchantTemplateRepository extends MongoRepository<MerchantTemplate, String> {

    Optional<MerchantTemplate> findTopByTemplateId(String templateId);
}
