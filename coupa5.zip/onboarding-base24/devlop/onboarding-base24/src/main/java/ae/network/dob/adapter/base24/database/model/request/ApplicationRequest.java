package ae.network.dob.adapter.base24.database.model.request;

import ae.network.dob.adapter.base24.database.model.AbstractAuditingEntity;
import ae.network.dob.adapter.base24.model.application.OnboardingRequest;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @author yousry
 * @version 1.0
 */


@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "base24_request")
@Data
@EqualsAndHashCode(callSuper = true)
public class ApplicationRequest extends AbstractAuditingEntity {

    @Id
    private String id;

    @NotNull(message = "acquirer can not be null.")
    private Acquirer acquirer;

    @JsonProperty(required = true)
    private RequestType requestType;

    @NotNull(message = "applicationId can not be null.")
    private String applicationId;

    @NotNull(message = "requestId can not be null.")
    private String requestId;

    private boolean dryRun;

    private OnboardingRequest payload;

    private Collection<Task> tasks = new ArrayList<>();
}
