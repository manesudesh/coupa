package ae.network.dob.adapter.base24.model.application;

import ae.network.dob.adapter.base24.common.TextUtils;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Yousry
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {

    private AddressType addressType;

    @Size(max = 3, message = "Country Code is more than 3 characters")
    private String countryCode;

    private String name;

    @Size(max = 3, message = "State cannot exceed 3 characters.")
    private String state;

    @Size(max = 18, message = "Address City cannot exceed 18 characters.")
    @NotBlank(message = "City Blank.")
    private String city;

    private String postalCode;

    @Size(max = 20, message = "Phone number cannot exceed 20 characters")
    @NotBlank(message = "Phone Blank.")
    private String phone;

    @Size(max = 25, message = "P.O Box cannot exceed 25 characters")
    private String pobox;

    private List<String> addressLines;


    public void setAddressLines(List<String> addressLines) {

        this.addressLines = new ArrayList<>();

        if (addressLines == null || addressLines.isEmpty())
            return;

        addressLines.forEach(addressLine -> this.addressLines.add(TextUtils.truncate(TextUtils.toAlphaNumeric(addressLine), 25)));
    }

    public boolean validForAmendment() {
        //If state | country_code | city | addressLine
        //If phone != null - Generate Base24 files
        return !(StringUtils.isEmpty(state) && StringUtils.isEmpty(countryCode) && StringUtils.isEmpty(city)
                && CollectionUtils.isEmpty(getAddressLines()) && StringUtils.isEmpty(phone));
    }
}
