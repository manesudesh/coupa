package ae.network.dob.adapter.base24;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * @author Waseem.Ismail
 * @since 2020-02-05
 */
@SpringBootApplication
@ConfigurationPropertiesScan("ae.network.dob.adapter.base24.config")
public class OnboardingBase24Adapter implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(OnboardingBase24Adapter.class, args);
    }

    public void run(String... args) {
    }

}
