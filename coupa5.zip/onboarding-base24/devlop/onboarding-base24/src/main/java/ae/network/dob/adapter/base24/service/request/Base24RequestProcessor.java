package ae.network.dob.adapter.base24.service.request;

import ae.network.dob.adapter.base24.common.Base24FileGenerationHelper;
import ae.network.dob.adapter.base24.common.Base24StatusHelper;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.database.model.request.RequestType;
import ae.network.dob.adapter.base24.database.model.request.Task;
import ae.network.dob.adapter.base24.database.model.request.TaskHistory;
import ae.network.dob.adapter.base24.database.model.request.TaskName;
import ae.network.dob.adapter.base24.database.model.request.TaskStatus;
import ae.network.dob.adapter.base24.database.repository.ApplicationRequestRepository;
import ae.network.dob.adapter.base24.rabbitmq.config.RabbitQueue;
import ae.network.dob.adapter.base24.rabbitmq.service.RabbitService;
import ae.network.dob.adapter.base24.service.file.Base24FileGenerationService;
import ae.network.dob.adapter.base24.service.validation.ValidationService;
import ae.network.dob.adapter.base24.validation.AcquirerValidator;
import ae.network.dob.adapter.base24.validation.AmendmentValidator;
import ae.network.dob.adapter.base24.validation.CommonValidator;
import ae.network.dob.adapter.base24.validation.FiIdAndTemplateIdValidator;
import ae.network.dob.adapter.base24.validation.PrdfValidator;
import ae.network.dob.adapter.base24.validation.PtdValidator;
import ae.network.dob.adapter.base24.validation.TerminalClosureValidator;
import ae.network.dob.adapter.base24.validation.ValidationResult;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * @author Waseem.Ismail
 * @since 2020-01-29
 */
@Service
@Slf4j
@AllArgsConstructor
public class Base24RequestProcessor {

    public static final String SUCCESS_CODE = "OK";
    public static final String ERROR_CODE = "ERROR";

    private final ApplicationRequestRepository applicationRequestRepository;
    private Base24FileGenerationService base24FileGenerationService;
    private Base24FileGenerationHelper base24FileGenerationHelper;
    private Base24StatusHelper base24StatusHelper;

    private CommonValidator commonValidator;
    private PrdfValidator prdfValidator;
    private PtdValidator ptdValidator;
    private AcquirerValidator acquirerValidator;
    private FiIdAndTemplateIdValidator fIIDAndTemplateIDValidator;
    private AmendmentValidator amendmentValidator;
    private TerminalClosureValidator terminalClosureValidator;

    private RabbitService rabbitService;

    public void processApplication(ApplicationRequest request) {

        log.info("Application Request received {})", request.getApplicationId());

        if (request.getRequestType() == RequestType.AMENDMENT) {

            boolean containsValidAmendment = base24FileGenerationHelper.containsValidAmendment(request);
            if (!containsValidAmendment) {
                Optional<Task> validationTaskOpt = request.getTasks().stream().filter(task -> task.getName().equals(TaskName.VALIDATION.name())).findAny();
                if (validationTaskOpt.isPresent()) {
                    Task validationTask = validationTaskOpt.get();
                    validationTask.setTaskStatus(TaskStatus.CANCELLED);
                    applicationRequestRepository.save(request);
                    rabbitService.sendMessage(RabbitQueue.UPDATES, base24StatusHelper.createApplicationResponse(request));
                    return;
                }
            }
        }

        applicationRequestRepository.save(request);
        base24FileGenerationService.generateBase24RequestRecords(request);

        applicationRequestRepository.save(request);

        if (base24StatusHelper.applicationRequestCompleted(request)) {
            rabbitService.sendMessage(RabbitQueue.UPDATES, base24StatusHelper.createApplicationResponse(request));
        }

    }

    public List<ValidationResult> validateRequest(ApplicationRequest request) {

        log.info("validateRequest method started for Request : {}", request.getApplicationId());
        log.info("RequestType : {}", request.getRequestType().name());

        if (request.getRequestType() == RequestType.ONBOARDING) {
            return ValidationService.getValidator().validate(acquirerValidator, request)
                    .validate(commonValidator, request).validate(prdfValidator, request).validate(ptdValidator, request)
                    .validate(fIIDAndTemplateIDValidator, request).getValidationResult();
        }

        if (request.getRequestType() == RequestType.AMENDMENT) {
            return ValidationService.getValidator().validate(acquirerValidator, request)
                    .validate(amendmentValidator, request).getValidationResult();
        }

        if (request.getRequestType() == RequestType.MERCHANT_CLOSURE) {
            return ValidationService.getValidator().validate(acquirerValidator, request).getValidationResult();
        }

        if (request.getRequestType() == RequestType.TERMINAL_CLOSURE) {
            return ValidationService.getValidator().validate(terminalClosureValidator, request).getValidationResult();
        }

        return ValidationService.getValidator().validate(acquirerValidator, request).validate(commonValidator, request)
                .getValidationResult();
    }

    public void updateRequestWithValidationStatus(List<ValidationResult> validationResults,
                                                  ApplicationRequest request) {
        log.info("updateRequestWithValidationStatus method started for Request : {}", request.getApplicationId());
        log.info("ValidationResults :\n{}", validationResults);

        boolean validationPassed = validationResults.stream().allMatch(ValidationResult::isPassed);

        Task validationTask = Task.builder().taskStatus(validationPassed ? TaskStatus.COMPLETED : TaskStatus.FAILED)
                .name(TaskName.VALIDATION.name())
                .taskHistory(Collections.singletonList(createTaskHistory(validationPassed ? TaskStatus.COMPLETED : TaskStatus.FAILED,
                        validationPassed ? SUCCESS_CODE : ERROR_CODE,
                        Arrays.toString(validationResults.toArray())))).build();

        if (request.getTasks() == null) {
            request.setTasks(new ArrayList<>());
        }

        request.getTasks().add(validationTask);

        log.info("updateRequestWithValidationStatus method completed for Request : {}", request.getApplicationId());

        applicationRequestRepository.save(request);
    }

    private TaskHistory createTaskHistory(TaskStatus status, String statusCode, String response) {
        log.info("createTaskHistory method started... ");
        return TaskHistory.builder().createdDate(new Date()).lastModifiedDate(new Date()).statusCode(statusCode)
                .taskStatus(status).response(response).build();
    }
}
