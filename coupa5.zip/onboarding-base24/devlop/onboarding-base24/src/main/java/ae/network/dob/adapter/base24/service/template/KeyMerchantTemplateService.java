package ae.network.dob.adapter.base24.service.template;

import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import ae.network.dob.adapter.base24.database.model.templates.KeyMerchantTemplate;
import ae.network.dob.adapter.base24.database.repository.KeyMerchantTemplateRepository;
import ae.network.dob.adapter.base24.model.application.Chain;
import ae.network.dob.adapter.base24.model.application.Merchant;
import ae.network.dob.adapter.base24.model.application.MerchantType;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Optional;

@Slf4j
@Service
@AllArgsConstructor
public class KeyMerchantTemplateService {

    private KeyMerchantTemplateRepository keyMerchantTemplateRepository;

    public boolean validateTerminalId(Chain chain, String TID, Acquirer acquirer, Merchant merchant) {

        if (acquirer != Acquirer.NI || merchant.getMerchantType() == MerchantType.ECOM)
            return true;

        Optional<KeyMerchantTemplate> keyMerchantTemplateOptional = null;

        if ("USD".equals(merchant.getMerchantCurrency())) {
            keyMerchantTemplateOptional = findMerchantTemplateByOrganizationName("002 (USD)");
        } else if (!StringUtils.isEmpty(merchant.getMerchantSegment())) {
            keyMerchantTemplateOptional = findMerchantTemplateBySegment(merchant.getMerchantSegment());
        }

        if (!keyMerchantTemplateOptional.isPresent()) {
            String terminalModel = getTerminalModel(merchant);
            if (!StringUtils.isEmpty(terminalModel))
                keyMerchantTemplateOptional = findMerchantTemplateByChainIdAndTerminalModel(chain.getChainId(), terminalModel);

            if (!keyMerchantTemplateOptional.isPresent())
                keyMerchantTemplateOptional = findMerchantTemplateByChainId(chain.getChainId());
        }
        if (keyMerchantTemplateOptional.isPresent()) {
            String start = keyMerchantTemplateOptional.get().getTidRange().replaceAll("x", "");
            return TID.startsWith(start) && TID.length() == keyMerchantTemplateOptional.get().getTidRange().length();
        }

        return true;
    }

    public Optional<KeyMerchantTemplate> findMerchantTemplateByChainId(String chainId) {
        return keyMerchantTemplateRepository.findTopByChainId(chainId);
    }

    public boolean isKeyMerchantExist(String chainId) {
        return keyMerchantTemplateRepository.existsKeyMerchantTemplateByChainId(chainId);
    }

    public boolean isKeyMerchantExist(String chainId, String terminalModel) {
        if (StringUtils.isEmpty(terminalModel))
            return false;

        return keyMerchantTemplateRepository.existsKeyMerchantTemplateByChainIdAndTerminalModel(chainId, terminalModel);
    }

    public Optional<KeyMerchantTemplate> findMerchantTemplateBySegment(String merchantSegment) {
        return keyMerchantTemplateRepository.findTopByMerchantSegment(merchantSegment);
    }

    public Optional<KeyMerchantTemplate> findMerchantTemplateByOrganizationName(String organizationName) {
        return keyMerchantTemplateRepository.findTopByOrgName(organizationName);
    }

    public Optional<KeyMerchantTemplate> findMerchantTemplateByChainIdAndTerminalModel(String chainId, String terminalModel) {
        return keyMerchantTemplateRepository.findTopByChainIdAndTerminalModel(chainId, terminalModel);


    }

    private String getTerminalModel(Merchant merchant) {

        if (CollectionUtils.isEmpty(merchant.getTerminals()))
            return null;

        return merchant.getTerminals()
                .stream()
                .filter(terminal -> terminal.getTerminalModel() != null)
                .findFirst()
                .get().getTerminalModel();
    }
}
