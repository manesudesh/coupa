package ae.network.dob.adapter.base24.validation;

import ae.network.dob.adapter.base24.common.Base24FileGenerationHelper;
import ae.network.dob.adapter.base24.config.ErrorMessageConfig;
import ae.network.dob.adapter.base24.database.model.error.AdapterError;
import ae.network.dob.adapter.base24.database.model.error.ErrorName;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.database.repository.ApplicationRequestRepository;
import ae.network.dob.adapter.base24.model.application.OnboardingRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class FiIdAndTemplateIdValidator extends BasicValidator {

    private final Base24FileGenerationHelper base24FileGenerationHelper;
    private final ApplicationRequestRepository applicationRequestRepository;

    public FiIdAndTemplateIdValidator(Base24FileGenerationHelper base24FileGenerationHelper,
                                      ApplicationRequestRepository applicationRequestRepository, ErrorMessageConfig errorMessageConfig) {
        this.base24FileGenerationHelper = base24FileGenerationHelper;
        this.applicationRequestRepository = applicationRequestRepository;
        this.errorMessageConfig = errorMessageConfig;
    }

    @Override
    public ValidationResult validate(ApplicationRequest request) {

        log.info("FIIDAndTemplateIDValidator Validator started");

        OnboardingRequest onRequest = request.getPayload();

        boolean applicationIdExist = applicationRequestRepository.findFirstByApplicationId(request.getApplicationId()).isPresent();
        log.info("applicationIdExist = {}", applicationIdExist);

        if (applicationIdExist) {
            AdapterError error = errorMessageConfig.getMessages().stream()
                    .filter(err -> err.getName().equals(ErrorName.APPLICATION_EXIST.name()))
                    .findFirst().orElse(defaultAdapterError);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }

        boolean fIIDValidate = onRequest.getApplications().stream()
                .anyMatch(application -> application.getMerchants().stream()
                        .anyMatch(merchant -> (!base24FileGenerationHelper
                                .isMerchantTypeSupported(request.getAcquirer(), merchant))
                                || base24FileGenerationHelper.getFiId(application, merchant, request.getAcquirer()).isEmpty()));

        log.info("FIID for Acquirer {}, and Bank is Empty: {}", request.getAcquirer(), fIIDValidate);
        if (fIIDValidate) {
            AdapterError error = errorMessageConfig.getMessages().stream()
                    .filter(err -> err.getName().equals(ErrorName.FIID_NOT_FOUND.name()))
                    .findFirst().orElse(defaultAdapterError);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }

        return ValidationResult.builder().passed(true).code("000").message("Success").build();
    }

    @Override
    public ValidatorType getType() {
        return ValidatorType.FIID_AND_TEMPLATE;
    }
}
