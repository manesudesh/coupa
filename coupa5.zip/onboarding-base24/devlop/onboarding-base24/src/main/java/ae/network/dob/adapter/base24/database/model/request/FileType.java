package ae.network.dob.adapter.base24.database.model.request;

import java.util.HashMap;
import java.util.Map;

public enum FileType {

    PRDF("PR"), PTD("PT"), CSECD("CS"), EPRD("EP");

    private static final Map<String, FileType> lookup = new HashMap<>();

    //Populate the lookup table on loading time
    static {
        for (FileType fileType : FileType.values()) {
            lookup.put(fileType.label, fileType);
        }
    }

    public final String label;

    FileType(String label) {
        this.label = label;
    }

    public static FileType get(String label) {
        return lookup.get(label);
    }
}
