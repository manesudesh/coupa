package ae.network.dob.adapter.base24.validation;

/**
 * @param <T>
 * @author : yousry
 * @version 1.0
 */
public interface Validator<T> {

    /**
     * @return the type of validator
     */
    ValidatorType getType();

    /**
     * validate method
     */
    ValidationResult validate(T entity);
}
