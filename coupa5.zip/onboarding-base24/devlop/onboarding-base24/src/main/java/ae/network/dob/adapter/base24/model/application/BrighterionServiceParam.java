package ae.network.dob.adapter.base24.model.application;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class BrighterionServiceParam extends MerchantService {
}
