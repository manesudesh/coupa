package ae.network.dob.adapter.base24.service.acquirer;

import ae.network.dob.adapter.base24.database.model.acquirer.AbstractAcquirer;
import ae.network.dob.adapter.base24.database.model.acquirer.AcquirerConfig;
import ae.network.dob.adapter.base24.database.model.acquirer.SimpleAcquirer;
import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import ae.network.dob.adapter.base24.model.application.Merchant;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * @author Success.Otto
 * @since 01-04-2020
 */
@Slf4j
@Component("acquirerComponent")
@AllArgsConstructor
public class AcquirerComponent {

    /**
     * Injection of Acquirer Service
     */
    private AcquirerConfigService acquirerConfigService;
    /**
     * Injection of Tyme implementation of
     * Acquirer Type config service
     */
    @Qualifier("simpleAcquirerService")
    private AcquirerService simpleAcquirerService;
    /**
     * Injection of NI implementation of
     * Acquirer type config service
     */
    @Qualifier("complexAcquirerService")
    private AcquirerService complexAcquirerService;

    /**
     * FiId is returned based on underlying
     * implementation, different implementation
     * returns different value of fiId
     */
    public String getFiId(Merchant merchant, Acquirer acquirer) {
        AbstractAcquirer abstractAcquirer = acquirerConfig(acquirer).getAcquirer();
        return acquirerService(abstractAcquirer).getFiId(merchant, abstractAcquirer);
    }

    /**
     * PRDFTemplateId is returned based on underlying
     * implementation, different implementation
     * returns different value of PRDFTemplateId
     */
    public String getPRDFTemplateId(Merchant merchant, Acquirer acquirer) {
        AbstractAcquirer abstractAcquirer = acquirerConfig(acquirer).getAcquirer();
        return acquirerService(abstractAcquirer).getPRDFTemplateId(merchant, abstractAcquirer);
    }

    /**
     * PTDFTemplateId is returned based on underlying
     * implementation, different implementation
     * returns different value of PTDTemplateId
     */
    public String getPTDTemplateId(Merchant merchant, Acquirer acquirer) {
        AbstractAcquirer abstractAcquirer = acquirerConfig(acquirer).getAcquirer();
        return acquirerService(abstractAcquirer).getPTDTemplateId(merchant, abstractAcquirer);
    }


    /**
     * PTDFTemplateId is returned based on underlying
     * implementation, different implementation
     * returns different value of PTDTemplateId
     */
    public String getCSECDTemplateId(Merchant merchant, Acquirer acquirer) {
        AbstractAcquirer abstractAcquirer = acquirerConfig(acquirer).getAcquirer();
        return acquirerService(abstractAcquirer).getPTDTemplateId(merchant, abstractAcquirer);
    }


    /**
     * Return the acquirerConfig Object
     */
    public AcquirerConfig getAcquirerConfig(Acquirer acquirer) {
        return acquirerConfig(acquirer);
    }

    /**
     * Returns implementation of Acquirer service
     * based on the acquirer
     */
    public AcquirerService acquirerService(AbstractAcquirer abstractAcquirer) {
        if (abstractAcquirer instanceof SimpleAcquirer) {
            return simpleAcquirerService;
        }
        return complexAcquirerService;
    }

    /**
     * Gets acquirerConfig out of
     * Acquirer
     */
    private AcquirerConfig acquirerConfig(Acquirer acquirer) {
        Optional<AcquirerConfig> configOptional = acquirerConfigService.findByAcquirer(acquirer);
        return configOptional.orElse(null);
    }

}
