package ae.network.dob.adapter.base24.database.model.cards;

import ae.network.dob.adapter.base24.database.model.AbstractAuditingEntity;
import ae.network.dob.adapter.base24.model.application.CardSchema;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "base24_template")
@Data
@EqualsAndHashCode(callSuper = true)
public class MerchantTemplate extends AbstractAuditingEntity {

    @Id
    private String templateId;
    private List<CardSchema> defaultCards;

}
