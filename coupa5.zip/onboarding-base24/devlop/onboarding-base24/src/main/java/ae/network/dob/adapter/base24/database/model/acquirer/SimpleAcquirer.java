package ae.network.dob.adapter.base24.database.model.acquirer;

import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class SimpleAcquirer extends AbstractAcquirer {
    private String fiId;
    private DeviceDetails deviceDetails;

    public SimpleAcquirer(Acquirer acquirer) {
        super(acquirer);
    }
}
