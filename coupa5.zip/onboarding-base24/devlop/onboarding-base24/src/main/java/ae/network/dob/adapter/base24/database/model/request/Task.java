package ae.network.dob.adapter.base24.database.model.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collection;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Task {
    private Long id;
    private String name;
    private String entityId;
    private TaskStatus taskStatus;
    private Collection<TaskHistory> taskHistory;
}