package ae.network.dob.adapter.base24.validation;

import ae.network.dob.adapter.base24.config.ErrorMessageConfig;
import ae.network.dob.adapter.base24.database.model.acquirer.AcquirerConfig;
import ae.network.dob.adapter.base24.database.model.error.AdapterError;
import ae.network.dob.adapter.base24.database.model.error.ErrorName;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.service.acquirer.AcquirerConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * @author : Waseem Ismail
 * @version : 1.0
 */
@Slf4j
@Service
public class AcquirerValidator extends BasicValidator {

    private final AcquirerConfigService acquirerConfigService;

    public AcquirerValidator(AcquirerConfigService acquirerConfigService, ErrorMessageConfig errorMessageConfig) {
        this.acquirerConfigService = acquirerConfigService;
        this.errorMessageConfig = errorMessageConfig;
    }

    @Override
    public ValidationResult validate(ApplicationRequest request) {
        log.info("ACQUIRER Validator started");

        Optional<AcquirerConfig> acquirerConfig = acquirerConfigService.findByAcquirer(request.getAcquirer());

        if (!acquirerConfig.isPresent()) {
            AdapterError error = errorMessageConfig.getMessages().stream()
                    .filter(err -> err.getName().equals(ErrorName.ACQUIRER_NOT_FOUND.name()))
                    .findFirst().orElse(defaultAdapterError);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }

        return ValidationResult.builder().passed(true).code("000").message("Success").build();
    }

    @Override
    public ValidatorType getType() {
        return ValidatorType.ACQUIRER;
    }
}
