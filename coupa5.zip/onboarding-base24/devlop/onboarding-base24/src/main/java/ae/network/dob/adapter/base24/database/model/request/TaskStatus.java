package ae.network.dob.adapter.base24.database.model.request;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
public enum TaskStatus {
    COMPLETED, PARTIALLY_COMPLETED, FAILED, CANCELLED, IN_PROGRESS
}
