package ae.network.dob.adapter.base24.validation;

public enum ValidatorType {
    COMMON, NI, TYME, PRDF, PTD, ACQUIRER, AMENDMENT, FIID_AND_TEMPLATE, TERMINAL_CLOSURE
}
