package ae.network.dob.adapter.base24.database.repository;

import ae.network.dob.adapter.base24.database.model.response.Base24Response;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface Base24ResponseFileRepository extends MongoRepository<Base24Response, String> {

    List<Base24Response> findByRecordId(String recordId);

}
