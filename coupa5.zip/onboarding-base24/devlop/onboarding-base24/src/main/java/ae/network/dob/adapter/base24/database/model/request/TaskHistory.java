package ae.network.dob.adapter.base24.database.model.request;

import ae.network.dob.adapter.base24.common.DateFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author walid.sewaify
 * @since 2020-01-19
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaskHistory {
    private TaskStatus taskStatus;
    private String statusCode;
    private String response;
    @JsonFormat(pattern = DateFormat.FORMAT)
    @DateTimeFormat(pattern = DateFormat.FORMAT)
    private Date createdDate;
    @JsonFormat(pattern = DateFormat.FORMAT)
    @DateTimeFormat(pattern = DateFormat.FORMAT)
    private Date lastModifiedDate;
}
