package ae.network.dob.adapter.base24.database.model.templates;

import ae.network.dob.adapter.base24.database.model.AbstractAuditingEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "base24_keyMerchantTemplate")
@Builder(access = AccessLevel.PUBLIC)
public class KeyMerchantTemplate extends AbstractAuditingEntity {

    @Id
    private String id;
    private String chainId;
    private String fiId;
    private String orgName;
    private String terminalModel;
    private String merchantSegment;
    private String newOrgName;
    private String dummyMID;
    private String dummyTID;
    private String tidRange;
}
