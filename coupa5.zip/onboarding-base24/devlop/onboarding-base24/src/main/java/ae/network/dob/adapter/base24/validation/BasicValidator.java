package ae.network.dob.adapter.base24.validation;

import ae.network.dob.adapter.base24.config.ErrorMessageConfig;
import ae.network.dob.adapter.base24.database.model.error.AdapterError;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;

public abstract class BasicValidator implements Validator<ApplicationRequest> {

    protected ErrorMessageConfig errorMessageConfig;

    final AdapterError defaultAdapterError = AdapterError.builder()
            .message("Error occurred while performing request")
            .code("001")
            .name("Unhandled Error")
            .build();
}
