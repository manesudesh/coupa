package ae.network.dob.adapter.base24.model.application;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.Data;

import static ae.network.dob.adapter.base24.model.application.Merchant.BRIGHTERION_SERVICE;

/**
 * @author Yousry
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "serviceType", visible = true, defaultImpl = MerchantService.class)
@JsonSubTypes({@Type(value = EstablishmentServiceParam.class, name = "SERVICE_ESTABLSIHMENT"),
        @Type(value = SoftPOSServiceParam.class, name = "SOFTPOS"),
        @Type(value = QRServiceParam.class, name = "QRPAY"),
        @Type(value = BinShareServiceParam.class, name = "BINSHARE"),
        @Type(value = BrighterionServiceParam.class, name = BRIGHTERION_SERVICE),
        @Type(value = VISAInstallmentsServiceParam.class, name = "VISA_INSTALLMENT")})
@Data
public class MerchantService {

    @JsonProperty("serviceType")
    protected String serviceType;
}
