package ae.network.dob.adapter.base24.validation;

import ae.network.dob.adapter.base24.common.Base24FileGenerationHelper;
import ae.network.dob.adapter.base24.config.ErrorMessageConfig;
import ae.network.dob.adapter.base24.database.model.error.AdapterError;
import ae.network.dob.adapter.base24.database.model.error.ErrorName;
import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.model.application.OnboardingRequest;
import ae.network.dob.adapter.base24.service.template.KeyMerchantTemplateService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.StringJoiner;

/**
 * @author : Waseem Ismail
 * @version : 1.0
 */
@Slf4j
@Service
public class PtdValidator extends BasicValidator {

    private final Base24FileGenerationHelper base24FileGenerationHelper;
    private final KeyMerchantTemplateService keyMerchantTemplateService;

    public PtdValidator(ErrorMessageConfig errorMessageConfig, Base24FileGenerationHelper base24FileGenerationHelper,
                        KeyMerchantTemplateService keyMerchantTemplateService) {
        this.errorMessageConfig = errorMessageConfig;
        this.base24FileGenerationHelper = base24FileGenerationHelper;
        this.keyMerchantTemplateService = keyMerchantTemplateService;
    }

    @Override
    public ValidationResult validate(ApplicationRequest request) {

        log.info("PTD Validator started");
        OnboardingRequest onRequest = request.getPayload();

        try (ValidatorFactory factory = Validation.buildDefaultValidatorFactory()) {
            javax.validation.Validator validator = factory.getValidator();

            Set<ConstraintViolation> terminalViolations = new HashSet<>();
            ArrayList<String> terminalTemplateViolations = new ArrayList<>();

            boolean ptdTemplateValidate = onRequest.getApplications().stream().anyMatch(application -> application
                    .getMerchants().stream()
                    .anyMatch(merchant ->
                            !(request.getAcquirer() == Acquirer.TYME && merchant.isSoftPosService()) && (
                                    (!base24FileGenerationHelper.isMerchantTypeSupported(request.getAcquirer(), merchant))
                                            || base24FileGenerationHelper.getPTDTemplateId(application, merchant, request.getAcquirer()).isEmpty())));


            if (ptdTemplateValidate) {
                log.info("PTD TemplateID for Acquirer {}, and Bank is Empty: {}", request.getAcquirer(), ptdTemplateValidate);
                AdapterError error = errorMessageConfig.getMessages().stream()
                        .filter(err -> err.getName().equals(ErrorName.TEMPLATE_NOT_FOUND.name()))
                        .findFirst().orElse(defaultAdapterError);
                return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
            }

            onRequest.getApplications()
                    .forEach(appRequest -> appRequest.getMerchants().forEach(merchant -> {

                        if (base24FileGenerationHelper.isMerchantTypeSupported(request.getAcquirer(), merchant) && !merchant.isSOFTPOSService()
                                && !CollectionUtils.isEmpty(merchant.getTerminals())) {

                            merchant.getTerminals()
                                    .forEach(terminal -> terminalViolations.addAll(validator.validate(terminal)));

                        }
                    }));

            if (request.getAcquirer() == Acquirer.NI)
                onRequest.getApplications().stream()
                        .filter(application -> Objects.nonNull(application.getChain()))
                        .forEach(appRequest -> appRequest.getMerchants().stream()
                                .filter(merchant -> !CollectionUtils.isEmpty(merchant.getTerminals()) && !merchant.isSOFTPOSService()).forEach(merchant -> merchant.getTerminals().forEach(terminal -> {

                                    if ((keyMerchantTemplateService.isKeyMerchantExist(appRequest.getChain().getChainId())
                                            || keyMerchantTemplateService.isKeyMerchantExist(appRequest.getChain().getChainId(),
                                            terminal.getTerminalModel()))
                                            && !keyMerchantTemplateService.validateTerminalId(appRequest.getChain(),
                                            terminal.getTerminalId(), request.getAcquirer(), merchant)) {
                                        String errorMessage = "Terminal ID :" + terminal.getTerminalId() +
                                                " Not in a valid Terminals ID range for Key Merchant :" +
                                                merchant.getMerchantId() + " Chain ID:" +
                                                appRequest.getChain().getChainId();
                                        terminalTemplateViolations.add(errorMessage + "\n");

                                    }
                                })));

            log.info("Terminal Constraints validation passed: {}", terminalViolations.size() == 0);
            ValidationResult validationResult = ValidationResult.builder().passed(true).code("000").message("Success").build();

            if (terminalViolations.size() > 0 || terminalTemplateViolations.size() > 0) {

                AdapterError error = errorMessageConfig.getMessages().stream()
                        .filter(err -> err.getName().equals(ErrorName.CONSTRAINTS_VIOLATION.name()))
                        .findFirst().orElse(defaultAdapterError);
                validationResult = ValidationResult.builder().passed(false).code(error.getCode())
                        .message(aggregateErrorMessage(terminalViolations)
                                + "\n"
                                + aggregateTemplateViolations(terminalTemplateViolations))
                        .build();

            }
            return validationResult;
        }
    }

    private String aggregateTemplateViolations(ArrayList<String> terminalTemplateViolations) {
        StringJoiner errorBuilder = new StringJoiner("\n");
        terminalTemplateViolations.forEach(errorBuilder::add);
        return errorBuilder.toString();
    }


    private String aggregateErrorMessage(Set<ConstraintViolation> violations) {

        StringJoiner errorBuilder = new StringJoiner("\n");
        violations.forEach(violation -> errorBuilder.add(violation.getMessage()));

        return errorBuilder.toString();
    }

    @Override
    public ValidatorType getType() {
        return ValidatorType.PTD;
    }
}