package ae.network.dob.adapter.base24.service.acquirer;

import ae.network.dob.adapter.base24.database.model.acquirer.AbstractAcquirer;
import ae.network.dob.adapter.base24.database.model.acquirer.ComplexAcquirer;
import ae.network.dob.adapter.base24.database.model.acquirer.MerchantTypeConfig;
import ae.network.dob.adapter.base24.model.application.Merchant;
import ae.network.dob.adapter.base24.model.application.MerchantType;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Success.Otto
 * @since 02-04-2020
 */
@Service("complexAcquirerService")
@AllArgsConstructor
public class ComplexAcquirerServiceImpl implements AcquirerService {

    /**
     * Injection of MerchantTypeConfigService for
     * PosConfigService implementation
     */
    @Qualifier("posConfigService")
    private MerchantTypeConfigService posConfigService;
    /**
     * Injection of MerchantTypeConfigService for
     * eComConfigService implementation
     */
    @Qualifier("ecomConfigService")
    private MerchantTypeConfigService ecomConfigService;
    /**
     * MerchantTypeConfig map with MerchantType as key
     * and MerchantTypeConfigService implementation as
     * value
     */
    private Map<MerchantType, MerchantTypeConfigService> merchantTypeConfigMap;

    /**
     * Initializes Merchant Type map
     */
    @PostConstruct
    void initMerchantMap() {
        merchantTypeConfigMap = new HashMap<>();
        merchantTypeConfigMap.put(MerchantType.POS, posConfigService);
        merchantTypeConfigMap.put(MerchantType.ECOM, ecomConfigService);
    }

    @Override
    public String getFiId(Merchant merchant, AbstractAcquirer abstractAcquirer) {
        String fiId = null;
        ComplexAcquirer complexAcquirer = (ComplexAcquirer) abstractAcquirer;
        if (complexAcquirer.getConfigs() != null && complexAcquirer.getConfigs().size() > 0) {

            MerchantTypeConfig merchantTypeConfig = complexAcquirer.getConfigs().get(merchant.getMerchantType());
            fiId = merchantTypeConfigMap
                    .get(merchant.getMerchantType()).getFiId(merchant, merchantTypeConfig);
        }
        return fiId;
    }

    @Override
    public String getPRDFTemplateId(Merchant merchant, AbstractAcquirer abstractAcquirer) {
        String templateId = null;
        ComplexAcquirer complexAcquirer = (ComplexAcquirer) abstractAcquirer;
        if (complexAcquirer.getConfigs() != null && complexAcquirer.getConfigs().size() > 0) {

            MerchantTypeConfig merchantTypeConfig = complexAcquirer.getConfigs().get(merchant.getMerchantType());

            templateId = merchantTypeConfigMap.get(merchant.getMerchantType()).getPRDFTemplateID(merchant,
                    merchantTypeConfig);

        }
        return templateId;
    }

    @Override
    public String getPTDTemplateId(Merchant merchant, AbstractAcquirer abstractAcquirer) {
        String templateId = null;
        ComplexAcquirer complexAcquirer = (ComplexAcquirer) abstractAcquirer;

        if (complexAcquirer.getConfigs() != null && complexAcquirer.getConfigs().size() > 0) {

            MerchantTypeConfig merchantTypeConfig = complexAcquirer.getConfigs().get(merchant.getMerchantType());

            templateId = merchantTypeConfigMap.get(merchant.getMerchantType()).getPTDTemplateId(merchant,
                    merchantTypeConfig);

        }
        return templateId;
    }


}
