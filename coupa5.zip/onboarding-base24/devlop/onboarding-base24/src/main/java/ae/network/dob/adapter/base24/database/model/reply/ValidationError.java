package ae.network.dob.adapter.base24.database.model.reply;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ValidationError {
    private String fieldName;
    private String errorMessage;
    private String errorCode;
}
