package ae.network.dob.adapter.base24.model.application;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class BinShareOffer {

    @NotEmpty(message = "BinShareOffer binShare is Empty.")
    private String binShare;

    @NotEmpty(message = "BinShare offerId is Empty.")
    @Size(max = 30, message = "BinShare offerId is more than 30 chars.")
    private String offerId;

}
