package ae.network.dob.adapter.base24.model.application;

/**
 * @author Yousry
 * @version 1.0
 */

public enum AddressType {
    DEFAULT, STMT_ADDR, PAYM_ADDR, CORRESPONDING, TRADING
}
