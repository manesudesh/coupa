package ae.network.dob.adapter.base24.validation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringJoiner;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import ae.network.dob.adapter.base24.common.Base24FileGenerationHelper;
import ae.network.dob.adapter.base24.config.ErrorMessageConfig;
import ae.network.dob.adapter.base24.database.model.error.AdapterError;
import ae.network.dob.adapter.base24.database.model.error.ErrorName;
import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.database.repository.ApplicationRequestRepository;
import ae.network.dob.adapter.base24.model.application.Address;
import ae.network.dob.adapter.base24.model.application.Application;
import ae.network.dob.adapter.base24.model.application.Merchant;
import ae.network.dob.adapter.base24.model.application.OnboardingRequest;
import ae.network.dob.adapter.base24.model.application.amendment.AmendmentType;
import ae.network.dob.adapter.base24.service.template.KeyMerchantTemplateService;
import lombok.extern.slf4j.Slf4j;

/**
 * @author : Waseem Ismail
 * @version : 1.0
 */
@Slf4j
@Service
public class AmendmentValidator extends BasicValidator {
	
	private final ApplicationRequestRepository applicationRequestRepository;
	private final Base24FileGenerationHelper base24FileGenerationHelper;
	private final KeyMerchantTemplateService keyMerchantTemplateService;


	public AmendmentValidator(ErrorMessageConfig errorMessageConfig,ApplicationRequestRepository applicationRequestRepository,
			Base24FileGenerationHelper base24FileGenerationHelper,
			KeyMerchantTemplateService keyMerchantTemplateService) {
		this.errorMessageConfig = errorMessageConfig;
		this.applicationRequestRepository = applicationRequestRepository;
		this.base24FileGenerationHelper = base24FileGenerationHelper;
		this.keyMerchantTemplateService = keyMerchantTemplateService;
	}

	@Override
	public ValidationResult validate(ApplicationRequest request) {

		log.info("Amendment Validator started");
		OnboardingRequest onRequest = request.getPayload();

		boolean applicationIdExist = applicationRequestRepository.findFirstByApplicationId(request.getApplicationId())
				.isPresent();

		log.info("applicationIdExist = {}", applicationIdExist);

		if (applicationIdExist) {
			AdapterError error = errorMessageConfig.getMessages().stream()
					.filter(err -> err.getName().equals(ErrorName.APPLICATION_EXIST.name()))
					.findFirst().orElse(defaultAdapterError);
			return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
		}

		Set<String> amendmentViolations = new HashSet<>();

		onRequest.getApplications().forEach(application -> {
			if (application.getMerchants() != null)
				application.getMerchants().forEach(merchant -> {
					if (merchant != null
							&& base24FileGenerationHelper.isMerchantTypeSupported(request.getAcquirer(), merchant))
						amendmentViolations.addAll(validateMerchant(request.getAcquirer(),application,merchant));
				});
		});

		log.info("Terminal Constraints validation passed: {}", amendmentViolations.size() == 0);

		if (amendmentViolations.size() > 0) {
			AdapterError error = errorMessageConfig.getMessages().stream()
					.filter(err -> err.getName().equals(ErrorName.CONSTRAINTS_VIOLATION.name()))
					.findFirst().orElse(defaultAdapterError);

			return ValidationResult.builder().passed(false).code(error.getCode())
					.message(aggregateErrorMessage(amendmentViolations)).build();
		}

		return ValidationResult.builder().passed(true).code("000").message("Success").build();
	}
	
	private Set<String> validateMerchant(Acquirer acquirer, Application application, Merchant merchant) {

		log.info("validateMerchant started for Merchant {} ,{}", merchant.getMerchantId(), merchant.getMerchantName());

		log.info("Amendment List : {}", merchant.getAmendmentList());

		try (ValidatorFactory factory = Validation.buildDefaultValidatorFactory()) {

			javax.validation.Validator validator = factory.getValidator();

			Set<String> amendmentViolations = new HashSet<>();
			if (merchant.getAmendmentList() == null)
				return amendmentViolations;

			for (String amendment : merchant.getAmendmentList()) {

				AmendmentType amendmentType = AmendmentType.getAmendmentType(amendment);

				switch (amendmentType) {
					case ACCEPTED_CARDS:
					case TERMINAL_ACCEPTED_CARDS:
						merchant.getConfigurations().getAcceptedCardSchemes()
								.forEach(scheme -> amendmentViolations.addAll(transformErrorMessages(validator.validate(scheme))));
						amendmentViolations.addAll(transformErrorMessages(validator.validateProperty(merchant, "merchantType")));
						break;
					case TERMINAL_ADDRESS:
					case ADDRESS:
						merchant.getAddresses()
								.forEach(address -> amendmentViolations.addAll(validateAddress(validator, address)/*transformErrorMessages(validator.validate(address)*/));
						amendmentViolations.addAll(transformErrorMessages(validator.validateProperty(merchant, "merchantType")));
						break;
					case MCC:
						amendmentViolations.addAll(transformErrorMessages(validator.validateProperty(merchant, "mcc")));
						amendmentViolations.addAll(transformErrorMessages(validator.validateProperty(merchant, "merchantType")));
						break;
					case MERCHANT_NAME:
						amendmentViolations.addAll(transformErrorMessages(validator.validateProperty(merchant, "merchantName")));
						amendmentViolations.addAll(transformErrorMessages(validator.validateProperty(merchant, "merchantType")));
						break;
					case LEGAL_NAME:
						amendmentViolations.addAll(transformErrorMessages(validator.validateProperty(merchant, "legalName")));
						amendmentViolations.addAll(transformErrorMessages(validator.validateProperty(merchant, "merchantType")));
						break;
					case ADDING_TERMINALS:
						amendmentViolations.addAll(validateTerminals(merchant));
						amendmentViolations.addAll(validateTerminalIDRange(acquirer, application, merchant));
						break;
					case TERMINAL_CLOSURE:
						merchant.getTerminals().forEach(terminal -> amendmentViolations
								.addAll(transformErrorMessages(validator.validateProperty(terminal, "terminalId"))));
						break;
					case COUNTRY_ORIGIN:
						amendmentViolations.addAll(validateCountryOrigin(merchant));
						break;
					default:
						log.warn("Merchant {}, {}, Amendment of type {} Not Supported :", merchant.getMerchantId(),
								merchant.getMerchantName(), amendment);
				}
			}

			log.info("Violations for Merchant {} ,{}, is {}", merchant.getMerchantId(), merchant.getMerchantName(),
					amendmentViolations.size());

			return amendmentViolations;
		}
	}

	private Collection<? extends String> validateAddress(Validator validator, Address address) {

		List<String> addressViolations = new ArrayList<>();
		addressViolations.addAll(transformErrorMessages(validator.validateProperty(address, "countryCode")));
		addressViolations.addAll(transformErrorMessages(validator.validateProperty(address, "state")));
		addressViolations.addAll(transformErrorMessages(validator.validateProperty(address, "pobox")));
		
		if(!StringUtils.isEmpty(address.getPhone()) && address.getPhone().length()>20)
			addressViolations.add("Phone number cannot exceed 20 characters");
		
		if(!StringUtils.isEmpty(address.getCity()) && address.getCity().length()>18)
			addressViolations.add("Address City cannot exceed 18 characters.");
		
		return addressViolations;
	}

	private Collection<? extends String> validateCountryOrigin(Merchant merchant) {
		List<String> merchantViolations = new ArrayList<>();

		if(StringUtils.isEmpty(merchant.getCountryOrigin()))
			merchantViolations.add("Country of Origin is missing");

		return merchantViolations;
	}

	private List<String> transformErrorMessages(Set<ConstraintViolation<Object>> set) {

		return set.stream().map(ConstraintViolation::getMessage).collect(Collectors.toList());
	}


	private List<String> validateTerminalIDRange(Acquirer acquirer, Application application, Merchant merchant) {
		
		ArrayList<String> terminalTemplateViolations = new ArrayList<>();

		if (acquirer==Acquirer.NI && application.getChain() != null && !CollectionUtils.isEmpty(merchant.getTerminals()))
			merchant.getTerminals().forEach(terminal -> {

				if ((keyMerchantTemplateService.isKeyMerchantExist(application.getChain().getChainId())
						|| keyMerchantTemplateService.isKeyMerchantExist(application.getChain().getChainId(),
								terminal.getTerminalModel()))
						&& !keyMerchantTemplateService.validateTerminalId(application.getChain(), terminal.getTerminalId(),acquirer,merchant)) {
					String errorMessage = "Terminal ID :" + terminal.getTerminalId() +
							" Not in a valid Terminals ID range for Key Merchant :" +
							merchant.getMerchantId() + " Chain ID:" +
							application.getChain().getChainId();
					terminalTemplateViolations.add(errorMessage + "\n");
				}
			});
		
		return terminalTemplateViolations;
	}

	private String aggregateErrorMessage(Set<String> violations) {

		StringJoiner errorBuilder = new StringJoiner("\n");
		violations.forEach(errorBuilder::add);

		return errorBuilder.toString();
	}

	
	private List<String> validateTerminals(Merchant merchant) {
		log.info("Terminal  validation Started for Merchant: {}", merchant);
		List<String> terminalViolations = new ArrayList<>();

		try (ValidatorFactory factory = Validation.buildDefaultValidatorFactory()) {
			javax.validation.Validator validator = factory.getValidator();

			if (!CollectionUtils.isEmpty(merchant.getTerminals()))
				merchant.getTerminals()
						.forEach(terminal -> terminalViolations.addAll(transformErrorMessages(validator.validate(terminal))));

			return terminalViolations;
		}
	}

	@Override
	public ValidatorType getType() {
		return ValidatorType.AMENDMENT;
	}
	
}
