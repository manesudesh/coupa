package ae.network.dob.adapter.base24.database.model.acquirer;

/**
 * Empty Interface used as a flag for all Merchant implementation.
 *
 * @author Success.Otto
 * @since 26/03/2020
 */
public interface MerchantTypeConfig {
}
