package ae.network.dob.adapter.base24.validation;

import ae.network.dob.adapter.base24.config.ErrorMessageConfig;
import ae.network.dob.adapter.base24.database.model.error.AdapterError;
import ae.network.dob.adapter.base24.database.model.error.ErrorName;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.database.repository.ApplicationRequestRepository;
import ae.network.dob.adapter.base24.model.application.Address;
import ae.network.dob.adapter.base24.model.application.AddressType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author : Yousry
 * @version : 1.0
 */
@Slf4j
@Service
public class CommonValidator extends BasicValidator {

    private final ApplicationRequestRepository applicationRequestRepository;

    public CommonValidator(ApplicationRequestRepository applicationRequestRepository, ErrorMessageConfig errorMessageConfig) {
        super();
        this.applicationRequestRepository = applicationRequestRepository;
        this.errorMessageConfig = errorMessageConfig;
    }

    @Override
    public ValidationResult validate(ApplicationRequest request) {

        log.info("Common validator started.");

        // basic annotation validation
        try (ValidatorFactory factory = Validation.buildDefaultValidatorFactory()) {
            Validator validator = factory.getValidator();

            final Set<ConstraintViolation<ApplicationRequest>> violations = validator.validate(request);

            if (violations.size() > 0) {
                log.error("Config contains errors:");
                List<String> basicValidationErrors = violations.stream().map(ConstraintViolation::getMessage).collect(Collectors.toList());

                String basicErrors = String.join(",", basicValidationErrors);
                log.error("annotation basic errors: {}", basicErrors);

                return ValidationResult.builder().passed(false).code("001")
                        .message(basicErrors).build();
            }

            // check if the application ID is duplicate or not
            boolean applicationIdExist = applicationRequestRepository.findFirstByApplicationId(request.getApplicationId()).isPresent();

            if (applicationIdExist) {
                AdapterError error = errorMessageConfig.getMessages().stream()
                        .filter(err -> err.getName().equals(ErrorName.APPLICATION_EXIST.name()))
                        .findFirst().orElse(defaultAdapterError);
                return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
            }

            // checking the address
            boolean oneAddressAndNotDefault = request.getPayload().getApplications().stream()
                    .anyMatch(application -> application.getMerchants().stream()
                            .anyMatch(merchant -> {
                                List<Address> addresses = merchant.getAddresses();
                                Address actualAdd = null;
                                if (addresses.size() == 1) {
                                    actualAdd = addresses.get(0);
                                }
                                return actualAdd != null && !actualAdd.getAddressType().equals(AddressType.DEFAULT)
                                        && addresses.get(0).getAddressType().equals(AddressType.STMT_ADDR);
                            }));

            log.info("oneAddress NotDefault or Statement = {}", oneAddressAndNotDefault);

            if (oneAddressAndNotDefault) {
                AdapterError error = errorMessageConfig.getMessages().stream()
                        .filter(err -> err.getName().equals(ErrorName.BAD_ADDRESS.name()))
                        .findFirst().orElse(defaultAdapterError);
                return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
            }

            return ValidationResult.builder().passed(true).code("000").message("Success").build();
        }
    }

    @Override
    public ValidatorType getType() {
        return ValidatorType.COMMON;
    }
}
