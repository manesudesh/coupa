package ae.network.dob.adapter.base24.database.model.acquirer;

import ae.network.dob.adapter.base24.database.model.request.Acquirer;
import ae.network.dob.adapter.base24.model.application.MerchantType;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Map;

@Data
@EqualsAndHashCode(callSuper = true)
public class ComplexAcquirer extends AbstractAcquirer {

    private Map<MerchantType, MerchantTypeConfig> configs;

    public ComplexAcquirer(Acquirer acquirer) {
        super(acquirer);
    }
}
