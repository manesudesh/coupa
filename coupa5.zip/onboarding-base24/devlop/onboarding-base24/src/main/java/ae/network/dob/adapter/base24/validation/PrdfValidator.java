package ae.network.dob.adapter.base24.validation;

import ae.network.dob.adapter.base24.common.Base24FileGenerationHelper;
import ae.network.dob.adapter.base24.config.ErrorMessageConfig;
import ae.network.dob.adapter.base24.database.model.error.AdapterError;
import ae.network.dob.adapter.base24.database.model.error.ErrorName;
import ae.network.dob.adapter.base24.database.model.request.ApplicationRequest;
import ae.network.dob.adapter.base24.model.application.OnboardingRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;
import java.util.HashSet;
import java.util.Set;
import java.util.StringJoiner;

/**
 * @author : Waseem Ismail
 * @version : 1.0
 */
@Slf4j
@Service
public class PrdfValidator extends BasicValidator {

    Base24FileGenerationHelper base24FileGenerationHelper;

    public PrdfValidator(ErrorMessageConfig errorMessageConfig, Base24FileGenerationHelper base24FileGenerationHelper) {
        this.errorMessageConfig = errorMessageConfig;
        this.base24FileGenerationHelper = base24FileGenerationHelper;
    }

    @Override
    public ValidationResult validate(ApplicationRequest request) {

        log.info("PRDF Validator started");
        OnboardingRequest onRequest = request.getPayload();

        try (ValidatorFactory factory = Validation.buildDefaultValidatorFactory()) {
            javax.validation.Validator validator = factory.getValidator();

            boolean prdfTemplateValidate = onRequest.getApplications().stream().anyMatch(application -> application
                    .getMerchants().stream()
                    .anyMatch(merchant ->
                            ((!base24FileGenerationHelper.isMerchantTypeSupported(request.getAcquirer(), merchant)) ||
                                    base24FileGenerationHelper.getPRDFTemplateId(application, merchant, request.getAcquirer()).isEmpty())));


            log.info("PRDF TemplateID for Acquirer {}, and Bank is Empty: {}", request.getAcquirer(), prdfTemplateValidate);
            if (prdfTemplateValidate) {
                AdapterError error = errorMessageConfig.getMessages().stream()
                        .filter(err -> err.getName().equals(ErrorName.TEMPLATE_NOT_FOUND.name()))
                        .findFirst().orElse(defaultAdapterError);
                return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
            }


            Set<ConstraintViolation> merchantViolations = new HashSet<>();
            onRequest.getApplications()
                    .forEach(appRequest -> appRequest.getMerchants().forEach(merchant -> {
                        if (base24FileGenerationHelper.isMerchantTypeSupported(request.getAcquirer(), merchant)) {
                            merchantViolations.addAll(validator.validate(merchant));
                        }
                    }));

            log.info("Merchant Constraints validation passed: {}", merchantViolations.size() == 0);
            if (merchantViolations.size() > 0) {

                AdapterError error = errorMessageConfig.getMessages().stream()
                        .filter(err -> err.getName().equals(ErrorName.CONSTRAINTS_VIOLATION.name()))
                        .findFirst().orElse(defaultAdapterError);

                return ValidationResult.builder().passed(false).code(error.getCode())
                        .message(aggregateErrorMessage(merchantViolations)).build();
            }


            Set<ConstraintViolation> addressViolations = new HashSet<>();
            onRequest.getApplications()
                    .forEach(appRequest -> appRequest.getMerchants().forEach(merchant ->
                    {
                        if (base24FileGenerationHelper.isMerchantTypeSupported(request.getAcquirer(), merchant))
                            merchant.getAddresses().forEach(address -> addressViolations.addAll(validator.validate(address)));
                    }));

            log.info("MerchantsAddress Constraints validation passed: {}", addressViolations.size() == 0);
            if (addressViolations.size() > 0) {

                AdapterError error = errorMessageConfig.getMessages().stream()
                        .filter(err -> err.getName().equals(ErrorName.CONSTRAINTS_VIOLATION.name()))
                        .findFirst().orElse(defaultAdapterError);

                return ValidationResult.builder().passed(false).code(error.getCode())
                        .message(aggregateErrorMessage(addressViolations)).build();
            }


            Set<ConstraintViolation> merchantConfigViolations = new HashSet<>();
            onRequest.getApplications().forEach(appRequest -> appRequest.getMerchants().forEach(
                    merchant -> {
                        if (base24FileGenerationHelper.isMerchantTypeSupported(request.getAcquirer(), merchant))
                            merchantConfigViolations.addAll(validator.validate(merchant.getConfigurations()));
                    }));

            log.info("MerchantsConfig Constraints validation passed: {}", merchantConfigViolations.size() == 0);
            if (merchantConfigViolations.size() > 0) {
                AdapterError error = errorMessageConfig.getMessages().stream()
                        .filter(err -> err.getName().equals(ErrorName.CONSTRAINTS_VIOLATION.name()))
                        .findFirst().orElse(defaultAdapterError);
                return ValidationResult.builder().passed(false).code(error.getCode())
                        .message(aggregateErrorMessage(merchantConfigViolations)).build();
            }


            Set<ConstraintViolation> servicesConfigViolations = new HashSet<>();
            onRequest.getApplications().forEach(appRequest -> appRequest.getMerchants().forEach(
                    merchant -> {
                        if (base24FileGenerationHelper.isMerchantTypeSupported(request.getAcquirer(), merchant)) {

                            if (merchant.isAmexService()) {
                                servicesConfigViolations.addAll(validator.validate(merchant.getAmexServiceParams().get()));
                            }

                            if (merchant.isBinShareService()) {
                                servicesConfigViolations.addAll(validator.validate(merchant.getBinShareServiceParams().get()));
                            }
                        }

                    }));

            log.info("MerchantsServices Constraints validation passed: {}", servicesConfigViolations.size() == 0);
            if (servicesConfigViolations.size() > 0) {
                AdapterError error = errorMessageConfig.getMessages().stream()
                        .filter(err -> err.getName().equals(ErrorName.CONSTRAINTS_VIOLATION.name()))
                        .findFirst().orElse(defaultAdapterError);
                return ValidationResult.builder().passed(false).code(error.getCode())
                        .message(aggregateErrorMessage(servicesConfigViolations)).build();
            }

            Set<AdapterError> cutoffErrors = new HashSet<>();
            onRequest.getApplications().forEach(appRequest -> appRequest.getMerchants().forEach(
                    merchant -> {

                        if (!StringUtils.isEmpty(merchant.getCutOffStart())) {
                            if (!validateCutoffTime(merchant.getCutOffStart()))
                                cutoffErrors.add(AdapterError.builder().
                                        message("cutOffstart :" + merchant.getCutOffStart() + " not valid time string.").
                                        name(merchant.getMerchantId()).build());
                        }

                        if (!StringUtils.isEmpty(merchant.getCutOffEnd())) {
                            if (!validateCutoffTime(merchant.getCutOffEnd()))
                                cutoffErrors.add(AdapterError.builder().
                                        message("cutoffend " + merchant.getCutOffEnd() + " not valid time string.").
                                        name(merchant.getMerchantId()).build());
                        }
                    }
            ));

            log.info("Merchants Cutoff validation passed: {}", cutoffErrors.size() == 0);
            if (cutoffErrors.size() > 0) {
                return ValidationResult.builder().passed(false).message(aggregateErrors(cutoffErrors)).build();
            }

            return ValidationResult.builder().passed(true).code("000").message("Success").build();
        }
    }


    private String aggregateErrorMessage(Set<ConstraintViolation> violations) {

        StringJoiner errorBuilder = new StringJoiner("\n");
        violations.forEach(violation -> errorBuilder.add(violation.getMessage()));

        return errorBuilder.toString();
    }

    private String aggregateErrors(Set<AdapterError> cutoffErrors) {
        StringJoiner errorBuilder = new StringJoiner("\n");
        cutoffErrors.forEach(cutoffError -> errorBuilder.add("merchantID :" + cutoffError.getName() + ", " + cutoffError.getMessage()));

        return errorBuilder.toString();
    }

    private boolean validateCutoffTime(String cutOffEnd) {
        return cutOffEnd.matches("([01]?[0-9]|2[0-3]):[0-5][0-9]");
    }

    @Override
    public ValidatorType getType() {
        return ValidatorType.PRDF;
    }
}
