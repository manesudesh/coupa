# README #
Onboarding

Service documentation: https://networkinternational.atlassian.net/wiki/spaces/NAACE/pages/2615018862/Technical+Documentation+onboarding-base24


### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.2.4.RELEASE/maven-plugin/)

### Onboarding a new acquirer:-
You need to change in the following files:-
* Acquirer.java (add new key code)

## Set Up
Dependencies:
- JDK 1.8
- system variable JASYPT_ENCRYPTOR_PASSWORD
- maven 3.8.6+
- for running application you'll require a MongoDB and RabbitMQ
  You can get them by running [dependencies.sh](dependencies.sh)
> ./dependencies.sh
- for the workflow to work you'll require the [onboarding-utils](https://bitbucket.org/network-international/onboarding-utils/src/master/) service up&running. 
It's used for PRC call via RabbitMQ.
