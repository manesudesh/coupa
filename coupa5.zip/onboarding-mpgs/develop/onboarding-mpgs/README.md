# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.2.4.RELEASE/maven-plugin/)

### Onboarding a Merchant:-
There will be a new adaptor for the MPGS and necessary API’s will be used for onboarding new merchant.
The related information should be passed via payload to MPGS Adapter.
The MPGS Adaptor would be called after the processing of the WAY4 and BASE24 successfully.

MPGS portal URL:
Ecommerce merchant: https://test-network.mtf.gateway.mastercard.com/mm/main.s
SoftPOS merchant: https://test-gateway.mastercard.com/mm/login.s 


MPGS API documentation and Analysis:
https://test-network.mtf.gateway.mastercard.com/api/documentation/mso/apiDocumentation/index.html?locale=en_US
Collection of JSON params for below 2 operations required for onboarding merchant in MPGS:
Merchant CreateOrUpdate: https://test-network.mtf.gateway.mastercard.com/mm/login.s?mappedUrl=%2Fapi%2Fdocumentation%2Fmso%2FapiDocumentation%2Frest-json%2Fversion%2Flatest%2Foperation%2FMerchant%3A%2520%2520CreateOrUpdate.html
Merchant Approvalhttps://test-network.mtf.gateway.mastercard.com/mm/login.s?mappedUrl=%2Fapi%2Fdocumentation%2Fmso%2FapiDocumentation%2Frest-json%2Fversion%2Flatest%2Foperation%2FMerchant%3A%2520%2520CreateOrUpdate.html
