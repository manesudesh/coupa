package ae.network.dob.adapter.mpgs.rabbitmq.config;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import ae.network.dob.adapter.mpgs.exception.MaxRetryReachedException;
import ae.network.dob.adapter.mpgs.model.reply.ApplicationUpdate;
import ae.network.dob.adapter.mpgs.model.reply.ProcessingResult;
import ae.network.dob.adapter.mpgs.model.task.AdditionalData;
import ae.network.dob.adapter.mpgs.model.task.BackendSystem;
import ae.network.dob.adapter.mpgs.model.task.TaskStatus;
import ae.network.dob.adapter.mpgs.rabbitmq.message.QueueMessage;
import ae.network.dob.adapter.mpgs.rabbitmq.processors.CorrelationDataProcessor;
import ae.network.dob.adapter.mpgs.rabbitmq.processors.MaxRetryProcessor;
import ae.network.dob.adapter.mpgs.rabbitmq.service.impl.RabbitServiceImpl;

@SpringBootTest
public class RabbitQueueTest {

	RabbitServiceImpl rabbitServiceImpl;
    @MockBean
    private RabbitTemplate rabbitTemplate;
    @InjectMocks
    CorrelationDataProcessor correlationDataProcessor;
    
	@Test
    void postProcessMessage()  {
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	Message msg = new Message(null, msgProperties);
    	correlationDataProcessor = new CorrelationDataProcessor(rabbitTemplate, null);
    	Message retMessage = correlationDataProcessor.postProcessMessage(msg);
    	Assertions.assertNotNull(retMessage);
    }
    
    @Test
    void postProcessMessageNull()  {
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setAppId("AppId");
    	msgProperties.setContentType(null);
    	Message msg = new Message(null, msgProperties);
    	correlationDataProcessor = new CorrelationDataProcessor(rabbitTemplate, null);
    	Message retMessage = correlationDataProcessor.postProcessMessage(msg);
    	Assertions.assertNotNull(retMessage);
    }
    @Test
    void retryMessageDelay()  {
    	rabbitServiceImpl = new RabbitServiceImpl(rabbitTemplate);
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setMessageId("123456");
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	Message msg = new Message(null, msgProperties);
    	rabbitServiceImpl.retryMessage(msg, 1000);
    	Assertions.assertNotNull(msg.getMessageProperties().getMessageId());
    }

    @Test
    void sendMessage()  {
    	rabbitServiceImpl = new RabbitServiceImpl(rabbitTemplate);
    	
    	AdditionalData additionalData = new AdditionalData();
    	additionalData.setDataMap("101010", "MerchantName");; 
        ApplicationUpdate appUpdate = ApplicationUpdate.builder().applicationId("applicationId1234")
                .backendSystem(BackendSystem.MPGS)
                .additionalData(additionalData)
                .processingResult(ProcessingResult.builder().finalStatus(TaskStatus.COMPLETED).build() )
                .build();
    	
    	rabbitServiceImpl.sendMessage(RabbitQueue.MPGS, appUpdate);
    	Assertions.assertNotNull(appUpdate.getApplicationId());
    }

    @Test
    void testLogMessage() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException  {
    	rabbitServiceImpl = new RabbitServiceImpl(rabbitTemplate);
    	Method method = rabbitServiceImpl.getClass().getDeclaredMethod("logQueueMessage", RabbitQueue.class, QueueMessage.class);
		method.setAccessible(true);
		ApplicationUpdate appUpdate = ApplicationUpdate.builder().applicationId("123456").backendSystem(BackendSystem.MPGS).build();
		method.invoke(rabbitServiceImpl, RabbitQueue.MPGS, appUpdate);
    	Assertions.assertNotNull(appUpdate.getApplicationId());
    }
    
    @Test
    void testDefaultRoutingKeyEmpty() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException  {
    	rabbitServiceImpl = new RabbitServiceImpl(rabbitTemplate);
    	Method method = rabbitServiceImpl.getClass().getDeclaredMethod("getDefaultRoutingKey", RabbitQueue.class);
		method.setAccessible(true);
		
		RabbitQueue rabitQueue = RabbitQueue.UPDATES;
		
		Field f = RabbitQueue.class.getDeclaredField("routingKeys");
        f.setAccessible(true);            
        f.set(rabitQueue, new String [] {});
        Assertions.assertThrows(InvocationTargetException.class, () -> {
        	method.invoke(rabbitServiceImpl, rabitQueue);
        }, "Invalid destination");
    }
    
    @Test
    void maxRetryPostMessageRetry()  {
    	MaxRetryProcessor maxRetry = new MaxRetryProcessor(rabbitTemplate, 6);
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	Message msg = new Message(null, msgProperties);
    	msgProperties.setHeader("MAX_RETRY_HEADER","5");
    	Message retMessage = maxRetry.postProcessMessage(msg);
    	Assertions.assertSame(retMessage.getMessageProperties().getHeader("MAX_RETRY_HEADER"),"5");    
    }
    
    @Test
    void maxRetryPostMessageDelay()  {
    	MaxRetryProcessor maxRetry = new MaxRetryProcessor(rabbitTemplate, 6);
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	Message msg = new Message(null, msgProperties);
    	msgProperties.setHeader("DELAY_HEADER", "5");
    	Message retMessage = maxRetry.postProcessMessage(msg);
    	Assertions.assertSame(retMessage.getMessageProperties().getHeader("DELAY_HEADER"),"5");
    }
    
    @Test
    void maxRetryPostMessageNull()  {
    	MaxRetryProcessor maxRetry = new MaxRetryProcessor(rabbitTemplate, 6);
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	Message msg = new Message(null, msgProperties);
    	Message retMessage = maxRetry.postProcessMessage(msg);
    	Assertions.assertNotNull(retMessage);
    }
    
    @Test
    void maxRetryPostMessageNonNullRetry()  {
    	MaxRetryProcessor maxRetry = new MaxRetryProcessor(rabbitTemplate, 6);
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setHeader(MaxRetryProcessor.MAX_RETRY_HEADER, "3");
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	byte [] body = new byte[] {'t','h','i','s',' ', 'i','s', ' ' , 'b','o','d','y'}; 
    	Message msg = new Message(body, msgProperties);
    	Message retMessage = maxRetry.postProcessMessage(msg);
    	Assertions.assertEquals((int)retMessage.getMessageProperties().getHeader(MaxRetryProcessor.MAX_RETRY_HEADER), 2);
    }
    
    @Test
    void maxRetryPostMessageNegative()  {
    	MaxRetryProcessor maxRetry = new MaxRetryProcessor(rabbitTemplate, 6);
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setHeader(MaxRetryProcessor.MAX_RETRY_HEADER, "-1");
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	byte [] body = new byte[] {'t','h','i','s',' ', 'i','s', ' ' , 'b','o','d','y'}; 
    	Message msg = new Message(body, msgProperties);
    	Assertions.assertThrows(MaxRetryReachedException.class, () -> maxRetry.postProcessMessage(msg));
    }
    
    
    @Test
    void maxRetryPostMessageNonNumber()  {
    	MaxRetryProcessor maxRetry = new MaxRetryProcessor(rabbitTemplate, 6);
    	MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setHeader(MaxRetryProcessor.MAX_RETRY_HEADER, "a");
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	byte [] body = new byte[] {'t','h','i','s',' ', 'i','s', ' ' , 'b','o','d','y'}; 
    	Message msg = new Message(body, msgProperties);
    	Assertions.assertThrows(MaxRetryReachedException.class, () -> maxRetry.postProcessMessage(msg));
    }
    
    @Test
    void backendSystem()  {
    	BackendSystem backendSys = BackendSystem.MPGS;
    	Assertions.assertEquals(backendSys.getRabbitQueue(), RabbitQueue.MPGS);
    }
    
}
