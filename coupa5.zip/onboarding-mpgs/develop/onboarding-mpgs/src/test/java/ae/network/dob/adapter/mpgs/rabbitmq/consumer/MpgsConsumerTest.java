package ae.network.dob.adapter.mpgs.rabbitmq.consumer;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.context.annotation.Import;

import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.dob.adapter.mpgs.DummyRabbit;
import ae.network.dob.adapter.mpgs.api.request.APICreateUpdateRequest;
import ae.network.dob.adapter.mpgs.config.APIConfig;
import ae.network.dob.adapter.mpgs.config.APIConfig.ServiceConfig;
import ae.network.dob.adapter.mpgs.database.MPGSConfigDBEntity;
import ae.network.dob.adapter.mpgs.database.repository.MPGSConfigRepository;
import ae.network.dob.adapter.mpgs.database.service.ConfigDBService;
import ae.network.dob.adapter.mpgs.database.service.MPGSRequestDBService;
import ae.network.dob.adapter.mpgs.exception.MessageCancelledException;
import ae.network.dob.adapter.mpgs.exception.MessageRejectionException;
import ae.network.dob.adapter.mpgs.model.application.Merchant;
import ae.network.dob.adapter.mpgs.model.reply.ApplicationUpdate;
import ae.network.dob.adapter.mpgs.model.reply.ValidationError;
import ae.network.dob.adapter.mpgs.model.request.ApplicationRequest;
import ae.network.dob.adapter.mpgs.rabbitmq.service.RabbitService;
import ae.network.dob.adapter.mpgs.service.MPGSHelper;
import ae.network.dob.adapter.mpgs.service.RequestProcessor;
import ae.network.dob.adapter.mpgs.service.utils.ProcessingHelper;
import ae.network.dob.adapter.mpgs.service.validate.ValidationExecutor;

@SpringBootTest
@Import({DummyRabbit.class})
public class MpgsConsumerTest {
	private static final String REQUESTS_PATH = "src/test/resources/requests/";
	@MockBean
    private RabbitService rabbitService;
	
	@SpyBean
    private RequestProcessor requestProcessor;

	@MockBean MPGSRequestDBService appRequestDB;
	
	@Autowired ValidationExecutor validationExecutor;
	@Autowired ProcessingHelper processingHelper;
	@Autowired ObjectMapper objectMapper;
	MPGSConsumer consumer2;
	
	@BeforeEach
    void init() {
		consumer2 = new MPGSConsumer(rabbitService, 0, requestProcessor, objectMapper);
    }
	@AfterEach
    void teardown() {
		consumer2 = null;
    }
	
	public static ApplicationRequest getApplicationRequest(String filename) throws IOException {
        String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + filename)));
        return new ObjectMapper().readValue(messageContent, ApplicationRequest.class);
    }
	
	@Test
	public void testPOSMPGSActualFlow() throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + "onboard-POS-merchant.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
		AbstractConsumer consumer = new MPGSConsumer(rabbitService, 0,  requestProcessor, objectMapper);
		ObjectMapper mapper = new ObjectMapper();
		Field field1 = consumer.getClass().getSuperclass().getDeclaredField("objectmapper");
		field1.setAccessible(true);
		field1.set(consumer, mapper);
		consumer.onMessage(msg);
	}
	
	@Test
    void testForOnMessageInvalidRequestSupported() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException, InstantiationException {
        MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + "onboard-POS-merchant.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
    	
    	ObjectMapper mapper = new ObjectMapper();
		Field field1 = consumer2.getClass().getSuperclass().getDeclaredField("objectmapper");
		field1.setAccessible(true);
		field1.set(consumer2, mapper);
    	MPGSConsumer consumer  = PowerMockito.spy(consumer2);
    	Mockito.doReturn(false).when(consumer).isRequestSupported(Mockito.any(ApplicationRequest.class));
    	
		consumer.onMessage(msg);
    }
	
	@Test
    void testForOnMessageValidationException() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException, InstantiationException {
        MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + "onboard-POS-merchant.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
    	
    	ObjectMapper mapper = new ObjectMapper();
		Field field1 = consumer2.getClass().getSuperclass().getDeclaredField("objectmapper");
		field1.setAccessible(true);
		field1.set(consumer2, mapper);
    	MPGSConsumer consumer  = PowerMockito.spy(consumer2);
    	Mockito.doReturn(true).when(consumer).isRequestSupported(Mockito.any(ApplicationRequest.class));
    	Mockito.doThrow(RuntimeException.class).when(consumer).validateApplication(Mockito.any(ApplicationRequest.class));
    	Assertions.assertThrows(MessageRejectionException.class, () -> consumer.onMessage(msg));
    }
	
	@Test
    void testForOnMessageValidationElse() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException, InstantiationException {
        MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + "onboard-POS-merchant.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
    	
    	ObjectMapper mapper = new ObjectMapper();
		Field field1 = consumer2.getClass().getSuperclass().getDeclaredField("objectmapper");
		field1.setAccessible(true);
		field1.set(consumer2, mapper);
    	MPGSConsumer consumer  = PowerMockito.spy(consumer2);
    	Mockito.doReturn(true).when(consumer).isRequestSupported(Mockito.any(ApplicationRequest.class));
    	List<ValidationError> list = new ArrayList<ValidationError>(); list.add(ValidationError.builder().build());
    	Mockito.doReturn(Optional.of(list)).when(consumer).validateApplication(Mockito.any(ApplicationRequest.class));
		consumer.onMessage(msg);
    }
	
	@Test
    void testForvalidateRequestContentJsonException() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException, InstantiationException {
        MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	Message msg = new Message("InvalidaContent Testing".getBytes(), msgProperties);
    	
    	ObjectMapper mapper = new ObjectMapper();
		Field field1 = consumer2.getClass().getSuperclass().getDeclaredField("objectmapper");
		field1.setAccessible(true);
		field1.set(consumer2, mapper);
    	MPGSConsumer consumer  = PowerMockito.spy(consumer2);
		Assertions.assertThrows(MessageRejectionException.class, ()->consumer.onMessage(msg));
    }
	
	@Test
    void testForOnMessageIsSupportedException() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException, InstantiationException {
        MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + "onboard-POS-merchant.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
    	
    	ObjectMapper mapper = new ObjectMapper();
		Field field1 = consumer2.getClass().getSuperclass().getDeclaredField("objectmapper");
		field1.setAccessible(true);
		field1.set(consumer2, mapper);
    	MPGSConsumer consumer  = PowerMockito.spy(consumer2);
    	Mockito.doThrow(RuntimeException.class).when(consumer).isRequestSupported(Mockito.any(ApplicationRequest.class));
    	Assertions.assertThrows(MessageRejectionException.class, () -> consumer.onMessage(msg));
    }
	
	@Test
    void testForOnMessageIsProcessMsgCancelException() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException, InstantiationException {
        MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + "onboard-POS-merchant.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
    	
    	ObjectMapper mapper = new ObjectMapper();
		Field field1 = consumer2.getClass().getSuperclass().getDeclaredField("objectmapper");
		field1.setAccessible(true);
		field1.set(consumer2, mapper);
    	MPGSConsumer consumer  = PowerMockito.spy(consumer2);
    	Mockito.doThrow(MessageCancelledException.class).when(consumer).processApplication(Mockito.any(ApplicationRequest.class));
    	consumer.onMessage(msg);
	}
	
	@Test
    void testForOnMessageIsProcessMsgRejectException() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException, InstantiationException {
        MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + "onboard-POS-merchant.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
    	
    	ObjectMapper mapper = new ObjectMapper();
		Field field1 = consumer2.getClass().getSuperclass().getDeclaredField("objectmapper");
		field1.setAccessible(true);
		field1.set(consumer2, mapper);
    	MPGSConsumer consumer  = PowerMockito.spy(consumer2);
    	Mockito.doThrow(MessageRejectionException.class).when(consumer).processApplication(Mockito.any(ApplicationRequest.class));
    	Assertions.assertThrows(MessageRejectionException.class, () -> consumer.onMessage(msg));
    }
	
	@Test
    void testForOnMessageIsProcessException() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException, InstantiationException {
        MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + "onboard-POS-merchant.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
    	
    	ObjectMapper mapper = new ObjectMapper();
		Field field1 = consumer2.getClass().getSuperclass().getDeclaredField("objectmapper");
		field1.setAccessible(true);
		field1.set(consumer2, mapper);
    	MPGSConsumer consumer  = PowerMockito.spy(consumer2);
    	Mockito.doThrow(RuntimeException.class).when(consumer).processApplication(Mockito.any(ApplicationRequest.class));
    	consumer.onMessage(msg);
	}
	
	@Autowired MPGSHelper mpgsHelper;
	
	@Test
    void testForAmendment() throws Exception {
		MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + "Amendment.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
    	
    	MPGSHelper mpgsHelper2 = PowerMockito.spy(mpgsHelper);
    	
    	Field f1 = RequestProcessor.class.getDeclaredField("MPGSHelper");
        f1.setAccessible(true); 
        f1.set(requestProcessor, mpgsHelper2);
        
    	MPGSConsumer consumer = new MPGSConsumer(rabbitService, 0,  requestProcessor, objectMapper);
		Field field1 = consumer.getClass().getSuperclass().getDeclaredField("objectmapper");
		field1.setAccessible(true);
		field1.set(consumer, objectMapper);
		Optional<Collection<ValidationError>> op = Optional.empty();
    	MPGSConsumer consumer2  = PowerMockito.spy(consumer);
    	Mockito.doReturn(op).when(consumer2).validateApplication(Mockito.any(ApplicationRequest.class));
    	consumer2.onMessage(msg);
    }
	
	@Test
    void testForOnMessageIsDryRun() throws Exception {
        MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	
    	ObjectMapper mapper = new ObjectMapper();
		Field field1 = consumer2.getClass().getSuperclass().getDeclaredField("objectmapper");
		field1.setAccessible(true);
		field1.set(consumer2, mapper);
		
		AbstractConsumer consumer  = PowerMockito.spy(consumer2);
    	ApplicationRequest applicationRequest = getApplicationRequest("onboard-POS-merchant.json");
    	applicationRequest.setDryRun(true);
    	String applicationStr = new ObjectMapper().writeValueAsString(applicationRequest);
    	Message msg = new Message(applicationStr.getBytes(), msgProperties);    	
    	
    	Mockito.doReturn(true).when(consumer).isRequestSupported(Mockito.any(ApplicationRequest.class));
    	consumer.onMessage(msg);
    	Assertions.assertTrue(true);
    }
	
	@Test
    void testForOnMessageIsDryRunWithAppUpdate() throws Exception {
        MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	
    	ObjectMapper mapper = new ObjectMapper();
		Field field1 = consumer2.getClass().getSuperclass().getDeclaredField("objectmapper");
		field1.setAccessible(true);
		field1.set(consumer2, mapper);
		
		AbstractConsumer consumer  = PowerMockito.spy(consumer2);
    	ApplicationRequest applicationRequest = getApplicationRequest("onboard-POS-merchant.json");
    	applicationRequest.setDryRun(true);
    	String applicationStr = new ObjectMapper().writeValueAsString(applicationRequest);
    	Message msg = new Message(applicationStr.getBytes(), msgProperties);    	
    	
    	Mockito.doReturn(true).when(consumer).isRequestSupported(Mockito.any(ApplicationRequest.class));
    	Mockito.doReturn(Optional.of(ApplicationUpdate.builder().build())).when(consumer).druRun(Mockito.any(ApplicationRequest.class));
    	
    	consumer.onMessage(msg);
    }
	
	@Autowired APIConfig apiConfigProperties;
	@Autowired private ConfigDBService configDB;
	
	@Test
	public void testProcessExceptionFlow() throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException, NoSuchMethodException {
		ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
		
        MPGSConfigDBEntity dummyMpgsConfig = configDB.findFirstByAcquirerAndMerchantType("NI","ECOM");
        
        Field f1 = RequestProcessor.class.getDeclaredField("configDB");
        f1.setAccessible(true); 
        f1.set(requestProcessor, configDB);
        
        //assign unauthorised user name
        String basicAuthUserNAme = dummyMpgsConfig.getApiBasicAuthNameJASYPTENC();
        dummyMpgsConfig.setApiBasicAuthNameJASYPTENC("UnAuthorized UserName");
		
		requestProcessor.process(applicationRequest);
		//reset basic auth
		dummyMpgsConfig.setApiBasicAuthNameJASYPTENC(basicAuthUserNAme);
	}
	
	@Autowired APIConfig apiConfigPropertiesPaymentNull;
	
	@Test
	public void testProcessFail() throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException, NoSuchMethodException {
		ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
        Field f = RequestProcessor.class.getDeclaredField("configProperties");
        f.setAccessible(true); 
        f.set(requestProcessor, apiConfigPropertiesPaymentNull);
        
        Field f1 = RequestProcessor.class.getDeclaredField("configDB");
        f1.setAccessible(true); 
        f1.set(requestProcessor, configDB);
        //assign paymentType null, so response will get FAIL with description
        ServiceConfig serConfig = apiConfigPropertiesPaymentNull.getApiConfig().get("NI").get("ECOM");
        String paymentType = serConfig.getPaymentType();
        serConfig.setPaymentType(null);
		
		requestProcessor.process(applicationRequest);
		//reset paymenttype
		serConfig.setPaymentType(paymentType);
	}
	
	
	@Test
	public void testProcessFailMerchantZero() throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException, NoSuchMethodException {
		ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
		applicationRequest.getPayload().getApplications().get(0).setMerchants( (List<Merchant>) ( new ArrayList<Merchant>()));
		Assertions.assertThrows(MessageCancelledException.class, ()-> requestProcessor.process(applicationRequest));
	}
	
	@Test
	public void testProcessSuccess() throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException, NoSuchMethodException {
		ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
		requestProcessor.process(applicationRequest);
	}
	
}
