package ae.network.dob.adapter.mpgs.rabbitmq.consumer;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Optional;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.context.annotation.Import;

import ae.network.dob.adapter.mpgs.DummyRabbit;
import ae.network.dob.adapter.mpgs.database.repository.RequestRepository;
import ae.network.dob.adapter.mpgs.model.application.Merchant;
import ae.network.dob.adapter.mpgs.model.request.ApplicationRequest;
import ae.network.dob.adapter.mpgs.model.request.RequestType;
import ae.network.dob.adapter.mpgs.rabbitmq.service.RabbitService;
import ae.network.dob.adapter.mpgs.service.RequestProcessor;
import ae.network.dob.adapter.mpgs.service.utils.ProcessingHelper;
import ae.network.dob.adapter.mpgs.service.validate.AmendmentValidationRule;
import ae.network.dob.adapter.mpgs.service.validate.BoardingValidationRule;
import ae.network.dob.adapter.mpgs.service.validate.ValidationExecutor;
import ae.network.dob.adapter.mpgs.service.validate.ValidationResult;

@SpringBootTest
@Import({DummyRabbit.class})
public class ValidatorTest {
	@MockBean
    private RabbitService rabbitService;
	
	@SpyBean
    private RequestProcessor requestProcessor;

	@MockBean RequestRepository repository;
	
	@Autowired ValidationExecutor validationExecutor;
	@Autowired ProcessingHelper processingHelper;
	
	@Autowired AmendmentValidationRule amendmentValidationRule;
	@Autowired BoardingValidationRule onBoardingtValidationRule;
	
	
	@Test
	public void testAcquirerIdInvalid() throws IOException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("onboard-merchant.json");
		applicationRequest.setAcquirer(null);
		ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.getMessage(), "Acquirer Id is invalid.");
	}
	
	@Test
	public void testOnboardingValidateApplicationRequest() throws IOException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("onboard-merchant.json");
		ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.isPassed(), true);
	}
	
	@Test
	public void testOnboardingAlreadyExist() throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("onboard-merchant.json");
		
		Field f = validationExecutor.getClass().getDeclaredField("validationRule");
        f.setAccessible(true); 
        f.set(validationExecutor, onBoardingtValidationRule);
        
        Field f2 = onBoardingtValidationRule.getClass().getDeclaredField("requestRepository");
        f2.setAccessible(true); 
        f2.set(onBoardingtValidationRule, repository);
        
        Mockito.doReturn(Optional.of(applicationRequest)).when(repository).findFirstByApplicationId( Mockito.any(String.class));
        ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.getMessage(), "Application Id is already Exist.");
	}
	
	@Test
	public void testAmendmentAlreadyExist() throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("Amendment.json");
		
		Field f = validationExecutor.getClass().getDeclaredField("amendmentValidationRule");
        f.setAccessible(true); 
        f.set(validationExecutor, amendmentValidationRule);
        
        Field f2 = amendmentValidationRule.getClass().getDeclaredField("requestRepository");
        f2.setAccessible(true); 
        f2.set(amendmentValidationRule, repository);
        
        Mockito.doReturn(Optional.of(applicationRequest)).when(repository).findFirstByApplicationId( Mockito.any(String.class));
        ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.getMessage(), "Application Id is already Exist.");
	}
	
	@Test
	public void testAmendementSucees() throws IOException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("Amendment.json");
		ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.isPassed(), true);
	}
	
	@Test
	public void testAmendementAddressEmpty() throws IOException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("Amendment.json");
		applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).setAddresses(null);
		ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.getMessage(), "Address list can not be null or empty while address amendment is requested.");
	}
	
	@Test
	public void testAmendementAddressInfoMiss() throws IOException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("Amendment.json");
		Merchant merchant = applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0);
				merchant.setAddresses(  merchant.getAddresses().stream().map(address-> {
					address.setPhone(null); address.setEmail(null); address.setCountryCode(null);
					address.setCity(null); address.setPostalCode(null);
				return address;}).collect(Collectors.toList()));
		ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.isPassed(), false);
	}
	
	@Test
	public void testAmendementAllAddressMissed() throws IOException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("Amendment.json");
		Merchant merchant = applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0);
				merchant.setAddresses(  merchant.getAddresses().stream().map(address-> {
					address = null;
				return address;}).collect(Collectors.toList()));
		ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.isPassed(), false);
	}
	
	@Test
	public void testAmendementListNull() throws IOException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("Amendment.json");
		applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).setAmendmentList(null);
		ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.getCode(), "000");
	}
	
	@Test
	public void testAmendementApplicationNull() throws IOException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("Amendment.json");
		applicationRequest.getPayload().getApplications().set(0, null);
		ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.getCode(), "3");
	}
	
	@Test
	public void testAmendementValidateMerchantIdNull() throws IOException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("Amendment.json");
		applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).setMerchantId(null);
		ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.getMessage(), "merchantId can not be null.");
	}
	
	@Test
	public void testAmendementValidateMerchantNameNull() throws IOException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("Amendment.json");
		applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).setMerchantName(null);
		ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.getMessage(), "merchantName can not be null while merchant name amendment is requested.");
	}
	
	@Test
	public void testAmendementValidateLegalNameNull() throws IOException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("Amendment.json");
		applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).setLegalName(null);
		ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.getMessage(), "legalName can not be null while merchant legal Name amendment is requested.");
	}
	
	@Test
	public void testAmendementValidateMCCNull() throws IOException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("Amendment.json");
		applicationRequest.getPayload().getApplications().get(0).getMerchants().get(0).setMcc(null);
		ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.getMessage(), "mcc can not be null while MCC amendment is requested.");
	}
	
	@Test
	public void testMerchantClosureValidateApplicationRequest() throws IOException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("Amendment.json");
		applicationRequest.setRequestType(RequestType.MERCHANT_CLOSURE);
		ValidationResult result = validationExecutor.execute(applicationRequest);
		assertEquals(result.isPassed(), true);
	}
	
}
