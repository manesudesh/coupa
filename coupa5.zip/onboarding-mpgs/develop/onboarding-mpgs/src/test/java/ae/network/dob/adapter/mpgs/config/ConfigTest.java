package ae.network.dob.adapter.mpgs.config;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

import ae.network.dob.adapter.mpgs.config.APIConfig.ServiceConfig;

public class ConfigTest {
	
	@Test
	void testAPICOnfig()
	{
		APIConfig config  = new APIConfig();
		
		
		APIConfig.ServiceConfig serviceConfig = new ServiceConfig();
		serviceConfig.setAccountUpdaterEnabled(false);
		serviceConfig.setAcquirerId(null);
		serviceConfig.setAcquirerLinkId(null);
		serviceConfig.setAdministrativePassword(null);
		serviceConfig.setAllowableTransactionFrequency(null);
		serviceConfig.setAllowableTransactionSource(null);
		serviceConfig.setApiCrUpdOperation(null);
		
		serviceConfig.setCardMaskingFormat(null);
		serviceConfig.setCardType(null);
		serviceConfig.setCertificateSetId(null);
		serviceConfig.setCurrency(null);
		
		serviceConfig.setDefaultOrderCertainty(null);
		serviceConfig.setDefaultTransactionFrequency(null);
		serviceConfig.setDefaultTransactionSource(null);
		
		serviceConfig.setEnforceCscOnTransactionSource(null);
		serviceConfig.setIpRejectAnonymousProxy(false);
		serviceConfig.setIpRejectUnknownCountry(false);
		serviceConfig.setMerchantLocale(null);
		serviceConfig.setMerchantTimeZone(null);
		serviceConfig.setMsoId(null);
		serviceConfig.setPaymentType(null);
		serviceConfig.setPrivilege(null);
		serviceConfig.setRiskprivilege(null);
		serviceConfig.setService(null);
		serviceConfig.setState(null);
		serviceConfig.setStatus(null);
		serviceConfig.setSystemCapturedCardMaskingFormat(null);
		serviceConfig.setTransactionFilterDynamic3DSecure(false);
		serviceConfig.setTransactionRiskAssessment(null);
		serviceConfig.setUserName(null);
		serviceConfig.setUserPass(null);
		serviceConfig.setUrl("httpd://mpgd.url.com");
		
		Map<String, ServiceConfig> map = new HashMap<>();
		map.put("POS", serviceConfig);
		config.setApiConfig(null);
		
		config.equals(config);
		serviceConfig.equals(serviceConfig);
		
		config.getApiConfig();
		serviceConfig.isAccountUpdaterEnabled();
		serviceConfig.getAcquirerId();
		serviceConfig.getAcquirerLinkId();
		serviceConfig.getAdministrativePassword();
		serviceConfig.getAllowableTransactionFrequency();
		serviceConfig.getAllowableTransactionSource();
		serviceConfig.getApiCrUpdOperation();
		
		serviceConfig.getCardMaskingFormat();
		serviceConfig.getCardType();
		serviceConfig.getCertificateSetId();
		serviceConfig.getCurrency();
		
		serviceConfig.getDefaultOrderCertainty();
		serviceConfig.getDefaultTransactionFrequency();
		serviceConfig.getDefaultTransactionSource();
		
		serviceConfig.getEnforceCscOnTransactionSource();
		serviceConfig.isIpRejectAnonymousProxy();
		serviceConfig.isIpRejectUnknownCountry();
		serviceConfig.getMerchantLocale();
		serviceConfig.getMerchantTimeZone();
		serviceConfig.getMsoId();
		serviceConfig.getPaymentType();
		serviceConfig.getPrivilege();
		serviceConfig.getRiskprivilege();
		serviceConfig.getService();
		serviceConfig.getState();
		serviceConfig.getStatus();
		serviceConfig.getSystemCapturedCardMaskingFormat();
		serviceConfig.isTransactionFilterDynamic3DSecure();
		serviceConfig.getTransactionRiskAssessment();
		serviceConfig.getUserName();
		serviceConfig.getUserPass();
	}
	
}
