package ae.network.dob.adapter.mpgs.database.service;

import java.io.IOException;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import ae.network.dob.adapter.mpgs.database.MPGSConfigDBEntity;
import ae.network.dob.adapter.mpgs.model.request.ApplicationRequest;
import ae.network.dob.adapter.mpgs.rabbitmq.consumer.MpgsConsumerTest;

@SpringBootTest
public class DatabaseTest {

	@Autowired MPGSRequestDBService mpgsdbService;
	@Autowired ConfigDBService configdbService;
	
	@Test
	public void testMPGSReqSave() throws IOException {
		ApplicationRequest applicationRequest = MpgsConsumerTest.getApplicationRequest("onboard-merchant.json");
		applicationRequest.setApplicationId("1234000789");
		ApplicationRequest savedRequest = mpgsdbService.save(applicationRequest);
		Optional<ApplicationRequest> storedRequest = mpgsdbService.findByAppReqId(applicationRequest.getApplicationId());
		
		Assertions.assertTrue(storedRequest.get().getApplicationId().equals(applicationRequest.getApplicationId()) );
	}
	
	@Test
	public void testConfigFindByMerchantType() throws IOException {
		MPGSConfigDBEntity entity = configdbService.findFirstByMerchantType("ECOM");
		Assertions.assertNotNull(entity );
	}
	
	@Test
	public void testConfigFind() throws IOException {
		MPGSConfigDBEntity entity = configdbService.findFirstByAcquirerAndMerchantType("NI", "ECOM");
		Assertions.assertTrue("NI".equals(entity.getAcquirer()) && "ECOM".equals(entity.getMerchantType()) );
	}
}
