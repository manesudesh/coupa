package ae.network.dob.adapter.mpgs.rabbitmq.consumer;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.context.annotation.Import;

import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.dob.adapter.mpgs.DummyRabbit;
import ae.network.dob.adapter.mpgs.database.service.MPGSRequestDBService;
import ae.network.dob.adapter.mpgs.exception.MaxRetryReachedException;
import ae.network.dob.adapter.mpgs.model.reply.ApplicationUpdate;
import ae.network.dob.adapter.mpgs.model.reply.ValidationError;
import ae.network.dob.adapter.mpgs.model.request.ApplicationRequest;
import ae.network.dob.adapter.mpgs.rabbitmq.service.RabbitService;
import ae.network.dob.adapter.mpgs.service.RequestProcessor;
import ae.network.dob.adapter.mpgs.service.utils.ProcessingHelper;
import ae.network.dob.adapter.mpgs.service.validate.ValidationExecutor;

@SpringBootTest
@Import({DummyRabbit.class})
public class ApplicationValidationTest {
	private static final String REQUESTS_PATH = "src/test/resources/requests/";
	@MockBean
    private RabbitService rabbitService;
	
	@SpyBean
    private RequestProcessor requestProcessor;

	@MockBean MPGSRequestDBService appRequestDB;
	
	@Autowired ValidationExecutor validationExecutor;
	@Autowired ProcessingHelper processingHelper;
	@Autowired ObjectMapper  objectMapper;
	
	AbstractConsumer consumer;
	
	@BeforeEach
    void init() {
		consumer = new MPGSConsumer(rabbitService, 0, requestProcessor, objectMapper);
    }
	@AfterEach
    void teardown() {
		consumer = null;
    }
	
	@Test
    void validateValidApplication() throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
        boolean isRequestSupported = consumer.isRequestSupported(applicationRequest);
        assertTrue(isRequestSupported);
        Optional<Collection<ValidationError>> errors = Optional.empty();
        if(isRequestSupported) {
        	Field f = RequestProcessor.class.getDeclaredField("appRequestDB");
            f.setAccessible(true); 
            f.set(requestProcessor, appRequestDB);
            
            
            Field f2 = RequestProcessor.class.getDeclaredField("validationExecutor");
            f2.setAccessible(true); 
            f2.set(requestProcessor, validationExecutor);
            
            Field f3 = RequestProcessor.class.getDeclaredField("processingHelper");
            f3.setAccessible(true); 
            f3.set(requestProcessor, processingHelper);
            
        	errors = consumer.validateApplication(applicationRequest);
        }
        assertTrue(!errors.isPresent());
    }
	
	@Test
    void validateInvalidApplication() throws IOException {
        ApplicationRequest applicationRequest = getApplicationRequest("invalid-onboard-merchant.json");
        Optional<Collection<ValidationError>> errors = consumer.validateApplication(applicationRequest);
        assertTrue(errors.isPresent());
    }
	
	@Test
    void testForRequestValidity() throws IOException {
        ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
        boolean isRequestSupported = consumer.isRequestSupported(applicationRequest);
        Assertions.assertTrue(isRequestSupported);
    }
	
	@Test
    void testForRequestSupportedInvalidRequestType() throws IOException {
        ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
        applicationRequest.setRequestType(null);
        boolean isRequestSupported = consumer.isRequestSupported(applicationRequest);
        Assertions.assertFalse(isRequestSupported);
    }

    @Test
    void testForRequestInvalidity() throws IOException {
        ApplicationRequest applicationRequest = getApplicationRequest("NonSupported-onboard-merchant.json");
        boolean isRequestSupported = consumer.isRequestSupported(applicationRequest);
        Assertions.assertFalse(isRequestSupported);
    }

    @Test
    void testForClosureRequestValidity() throws IOException {
        ApplicationRequest applicationRequest = getApplicationRequest("merchant-closure.json");
        boolean isRequestSupported = consumer.isRequestSupported(applicationRequest);
        Assertions.assertTrue(isRequestSupported);
    }
    
	public static ApplicationRequest getApplicationRequest(String filename) throws IOException {
        String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + filename)));
        return new ObjectMapper().readValue(messageContent, ApplicationRequest.class);
    }
	
	@Test
	public void testProcessApplicationRequest() throws IOException {
		ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
        consumer.processApplication(applicationRequest);
	}
	
	@Test
	public void testDryRun() throws IOException {
		ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
		Optional<ApplicationUpdate> update = consumer.druRun(applicationRequest);
		Assertions.assertTrue(! update.isPresent());
	}
	
	@Test
	public void testAbstractHandler() throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + "onboard-merchant.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
    	ObjectMapper mapper = new ObjectMapper();
		Field field1 = consumer.getClass().getSuperclass().getDeclaredField("objectmapper");
		field1.setAccessible(true);
		field1.set(consumer, mapper);
		Mockito.doNothing().when(requestProcessor).process(Mockito.any(ApplicationRequest.class));
		consumer.onMessage(msg);
	}
	
	@Test
	public void testAbstractRetry() throws IOException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		Method method = AbstractConsumer.class.getDeclaredMethod("retryMessage", Message.class);
		method.setAccessible(true);
		MessageProperties msgProperties = new MessageProperties();
    	msgProperties.setReceivedRoutingKey("routing.backend.mpgs");
    	msgProperties.setCorrelationId("1234");
    	msgProperties.setAppId("AppId");
    	msgProperties.setTimestamp(new Date());
    	msgProperties.setContentType("application/json");
    	String messageContent = new String(Files.readAllBytes(Paths.get(REQUESTS_PATH + "onboard-merchant.json")));
    	Message msg = new Message(messageContent.getBytes(), msgProperties);
		method.invoke(consumer, msg); 
	}
	
	@Test
	public void testHandleError() throws InstantiationException, IllegalAccessException   {
		consumer.handleError(new Throwable(new MaxRetryReachedException("1234"))); 
	}
	
	@Test
	public void testAbsractMapErrTaskHist() throws IOException, IllegalAccessException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException {
		Collection<ValidationError> validationErrors = new ArrayList<ValidationError>();
		Method method = AbstractConsumer.class.getDeclaredMethod("sendApplicationInvalid", String.class,
				Collection.class);
		method.setAccessible(true);
		validationErrors.add(ValidationError.builder().errorCode("01").errorMessage("Error Message").fieldName("Field is empty").build());
		method.invoke(consumer, "1234", validationErrors); 
	}
	 
	@Test
	public void testAbsractTaskHist() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		Method method = AbstractConsumer.class.getDeclaredMethod("mapErrorToTaskHistory", ValidationError.class);
		method.setAccessible(true);
		method.invoke(consumer, ValidationError.builder().errorCode("01").errorMessage("Error Message").fieldName("Field is empty").build());
	}
	
	@Test
	public void testAbsractAppCancelled() throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		Method method = AbstractConsumer.class.getDeclaredMethod("sendApplicationCancelled", String.class);
		method.setAccessible(true);
		method.invoke(consumer, "1234");
	}
			
	@Test
	public void testProcessSuccess() throws IOException, NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException, NoSuchMethodException {
		ApplicationRequest applicationRequest = getApplicationRequest("onboard-merchant.json");
		requestProcessor.process(applicationRequest);
	}
}
