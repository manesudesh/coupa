package ae.network.dob.adapter.mpgs.model.application;

public enum PaymentModeType {

    EFT,
    EQ, // Emirates Islamic
    FN, // Emirates NBD
    IFT,
    MC,
    NN, // No payment
    OB, // Other banks
    TT // Telegraphic transfers
}
