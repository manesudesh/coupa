package ae.network.dob.adapter.mpgs.api.request;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 
 * @version 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class APIAddress implements Serializable {

    @NotNull
    private String street1;
    @NotNull
    private String street2;
    @NotNull
    private String city;
    @NotNull
    private String stateProvince;
    @NotNull
    private String postcode;
    @NotNull
    private String countryCode;
   
}
