package ae.network.dob.adapter.mpgs.model.application;

/**
 * @author 
 * @version
 */
public enum ActionType {
    Add, Update, AddOrUpdate, CLOSURE
}