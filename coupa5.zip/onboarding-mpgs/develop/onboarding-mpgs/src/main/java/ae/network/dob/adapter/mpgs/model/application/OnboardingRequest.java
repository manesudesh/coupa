package ae.network.dob.adapter.mpgs.model.application;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * @author 
 * @version 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OnboardingRequest {

    @NotEmpty(message = "applications can not be empty")
    @Valid
    private List<Application> applications;
}
