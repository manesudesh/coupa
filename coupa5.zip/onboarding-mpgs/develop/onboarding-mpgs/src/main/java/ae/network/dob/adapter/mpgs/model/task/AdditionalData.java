package ae.network.dob.adapter.mpgs.model.task;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author 
 * @since 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AdditionalData {
  
	private Map<String, Object> dataMap = new HashMap<>();

    @JsonAnyGetter
    public Map<String, Object> getDataMap() {
        return this.dataMap;
    }

    @JsonAnySetter
    public void setDataMap(String name, Object value) {
        this.dataMap.put(name, value);
    }
}
