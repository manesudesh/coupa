package ae.network.dob.adapter.mpgs.model.application;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;

import com.fasterxml.jackson.annotation.JsonTypeInfo;

import lombok.Data;

/**
 * @author 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "serviceType", visible = true, defaultImpl = UnknownService.class)
@JsonSubTypes({
        @Type(value = QrPayService.class, name = "QRPAY"),
        @Type(value = PSPServiceParam.class, name = "PSP"),
        @Type(value = MPGSService.class, name = "MPGS")})
@Data
public class MerchantService {

    @JsonProperty("serviceType")
    protected String serviceType;
}
