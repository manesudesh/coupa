package ae.network.dob.adapter.mpgs.model.application;

import lombok.Builder;
import lombok.Data;

/**
 * @author 
 * @version 
 */
@Data
@Builder
public class MPGSServiceParam extends MerchantService {

    
}
