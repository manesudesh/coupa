package ae.network.dob.adapter.mpgs.config;

import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;


@Component
@Data
@ConfigurationProperties(prefix = "mpgs")
public class APIConfig {
	
	private Map<String, Map<String, ServiceConfig>> apiConfig;
	
	@Data
	@Component
	public static class ServiceConfig {
		private String url;
		private String apiCrUpdOperation;
		private String msoId;
		private String userName;
		private String userPass;
		private String acquirerLinkId;
		private boolean accountUpdaterEnabled;
		private String acquirerId;
		private String merchantLocale;
		private String merchantTimeZone;
		private List<String> allowableTransactionFrequency;
		private List<String> allowableTransactionSource;
		private List<String> cardType;
		private List<String> currency;
		private String defaultTransactionFrequency;
		private String defaultTransactionSource;
		private List<String> enforceCscOnTransactionSource;
		private String paymentType;
	    private String status;
	    private String defaultOrderCertainty;
	    private List<String> privilege;
	    private List<String> riskprivilege;
	    private List<String> service;
	    private String state;
	    private String cardMaskingFormat;
	    private String systemCapturedCardMaskingFormat;
//	    private String tradingName;
	    private String certificateSetId;
	    private String administrativePassword;
	    private String transactionRiskAssessment;
	    private boolean transactionFilterDynamic3DSecure;
	    private boolean ipRejectAnonymousProxy;
	    private boolean ipRejectUnknownCountry;
	    
	}
}
