package ae.network.dob.adapter.mpgs.service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import ae.network.dob.adapter.mpgs.api.request.APIAddress;
import ae.network.dob.adapter.mpgs.api.request.APICreateUpdateRequest;
import ae.network.dob.adapter.mpgs.api.request.APIEcomMerchant;
import ae.network.dob.adapter.mpgs.api.request.APIMerchant;
import ae.network.dob.adapter.mpgs.api.request.APISoftPosMerchant;
import ae.network.dob.adapter.mpgs.api.request.AcquirerAuthentication;
import ae.network.dob.adapter.mpgs.api.request.AcquirerLink;
import ae.network.dob.adapter.mpgs.api.request.AcquirerLinkRegion;
import ae.network.dob.adapter.mpgs.api.request.Authentication3DS1;
import ae.network.dob.adapter.mpgs.api.request.IPCountry;
import ae.network.dob.adapter.mpgs.api.request.MasterCardSecureCode;
import ae.network.dob.adapter.mpgs.api.request.PartnerManagedRiskAssessment;
import ae.network.dob.adapter.mpgs.api.request.Risk;
import ae.network.dob.adapter.mpgs.api.request.TransactionFiltering;
import ae.network.dob.adapter.mpgs.api.request.TransactionRiskAssessment;
import ae.network.dob.adapter.mpgs.api.request.VerifiedByVisa;
import ae.network.dob.adapter.mpgs.common.TextUtils;
import ae.network.dob.adapter.mpgs.config.APIConfig.ServiceConfig;
import ae.network.dob.adapter.mpgs.database.MPGSConfigDBEntity;
import ae.network.dob.adapter.mpgs.model.amendment.AmendmentType;
import ae.network.dob.adapter.mpgs.model.application.Address;
import ae.network.dob.adapter.mpgs.model.application.Merchant;
import ae.network.dob.adapter.mpgs.model.dto.MpgsApiClientKey;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MPGSHelper {

	public static final String POSTAL_CODE = "000000784";
	
	/** Build MPGS Merchant
	 * @param merchant
	 * @param serviceConfig
	 * @param mpgsConfig
	 * @return
	 */
	public APIMerchant buildMPGSMerchat(Merchant merchant, ServiceConfig serviceConfig, MPGSConfigDBEntity dbConfigEntity) {
		log.info("building MPGS Merchant");
		APIMerchant apiMerchant;
		if(merchant.isEcom()) {
			apiMerchant = buildEcomMPGSMerchant(merchant, serviceConfig);
		}else {
			apiMerchant = buildSoftPosMPGSMerchant(merchant);
		}
		
		apiMerchant.setAcquirerLink( buildAcquirerLink(merchant, serviceConfig, dbConfigEntity));
		
		Address address = merchant.getAddresses().get(0);
		apiMerchant.setAddress(buildAddress(address));
		apiMerchant.setCardMaskingFormat(serviceConfig.getCardMaskingFormat());
		apiMerchant.setCategoryCode(merchant.getFormatMcc());
		
		String fName = address.getName() == null ? "" : address.getName();
		String lName = address.getLastName() == null ? "" : address.getLastName();

		apiMerchant.setContactName(fName+" "+lName);
		apiMerchant.setDefaultOrderCertainty(serviceConfig.getDefaultOrderCertainty());
		apiMerchant.setEmail(address.getEmail());
		
		apiMerchant.setGoodsDescription(TextUtils.truncate( merchant.getBusinessLine(), 80));
		apiMerchant.setLocale(serviceConfig.getMerchantLocale());
		apiMerchant.setName(merchant.getMerchantName());
//		apiMerchant.setPartnerManagedRiskAssessment(buildPartnerManagerRisk(serviceConfig));
		apiMerchant.setPhone(address.getPhone());
		
		apiMerchant.setGovernmentCountryCode(merchant.getCountryOrigin());
		
		apiMerchant.setPrivilege(serviceConfig.getPrivilege());
//		apiMerchant.setRisk(buildRiskPrivilige(serviceConfig));
		apiMerchant.setService(serviceConfig.getService());
		apiMerchant.setState(serviceConfig.getState());
		apiMerchant.setSystemCapturedCardMaskingFormat(serviceConfig.getSystemCapturedCardMaskingFormat());
		apiMerchant.setTimeZone(serviceConfig.getMerchantTimeZone());
//		apiMerchant.setTransactionFiltering(TransactionFiltering.builder().);
//		apiMerchant.setWebSite(merchant.getWebsite());
		
		apiMerchant.setCertificateSetId(dbConfigEntity.getCertIdJASYPTENC());
		apiMerchant.setAdministrativePassword(dbConfigEntity.getAdminPasswordJASYPTENC());
		
		return apiMerchant;	
	}
	
	
	/**
	 * @param serviceConfig
	 * @return
	 */
	private PartnerManagedRiskAssessment buildPartnerManagerRisk( ServiceConfig serviceConfig) {
		log.info("calling PartnerManagedRiskAssessment()");
		PartnerManagedRiskAssessment partnerManagedRiskAssessment = PartnerManagedRiskAssessment.builder()
			.transactionRiskAssessment( TransactionRiskAssessment.builder().configuration(serviceConfig.getTransactionRiskAssessment()).build()  )
			.build();
		return partnerManagedRiskAssessment;
	}
	
	/**
	 * @param merchant
	 * @param serviceConfig
	 * @param mpgsConfig
	 * @return
	 */
	private AcquirerLink buildAcquirerLink(Merchant merchant, ServiceConfig serviceConfig, MPGSConfigDBEntity dbConfig) {
		log.info("calling buildAcquirerLink()");
		String merchantId = merchant.getMerchantId();
		
		String terminalId = merchant.getTerminals().get(0).getTerminalId();
		String truncateTerminalId = TextUtils.truncate(terminalId, 7);
		log.info("collecting 5 terminals ");
		List<String> terminalIds = Stream.iterate(65, n  ->  n  + 1)
		        .limit(5)
		        .map(charNumber -> (char)(int)charNumber +String.valueOf(truncateTerminalId))
		        .collect(Collectors.toList());
		
		 AcquirerLinkRegion acquirerLinkRegion = AcquirerLinkRegion.builder()
				.accountUpdaterEnabled(serviceConfig.isAccountUpdaterEnabled())
				.acquirerId(dbConfig.getAcquirerId())
				.allowableTransactionFrequency(serviceConfig.getAllowableTransactionFrequency())
				.allowableTransactionSource(serviceConfig.getAllowableTransactionSource())
				.bankMerchantId(merchantId)
				.cardType(serviceConfig.getCardType())
				.currency(serviceConfig.getCurrency())
				.defaultTransactionFrequency(serviceConfig.getDefaultTransactionFrequency())
				.defaultTransactionSource(serviceConfig.getDefaultTransactionSource())
				.enforceCscOnTransactionSource(serviceConfig.getEnforceCscOnTransactionSource())
				.paymentType(serviceConfig.getPaymentType())
				.status(serviceConfig.getStatus())
				.terminalId(terminalIds)
				.build();
		
		 if(merchant.isEcom()) {
			 acquirerLinkRegion.setAuthentication(buildAcqAuthentication(merchantId, terminalId));
		 }
		 
		 AcquirerLink acqirerLink = AcquirerLink.builder().acqLinkRegion(acquirerLinkRegion).build();
		 return acqirerLink;
	}
	
	/**
	 * @param merchantId
	 * @param terminalId
	 * @return
	 */
	private AcquirerAuthentication buildAcqAuthentication(String merchantId, String terminalId) {
		log.info("calling buildAcqAuthentication()");
		AcquirerAuthentication ack_auth = new AcquirerAuthentication();
		
		ack_auth.setMasterCardSecureCode(buildMasterCardSecureCode(merchantId));
		ack_auth.setVerifiedByVisa(buildVerifieVisa(merchantId, terminalId));
		return ack_auth;
	}

	/**
	 * @param merchantId
	 * @return
	 */
	private MasterCardSecureCode buildMasterCardSecureCode(String merchantId) {
		log.info("calling buildMasterCardSecureCode()");
		MasterCardSecureCode masterCardSecureCode = new MasterCardSecureCode();
		Authentication3DS1 masterCardauth3ds1 = new Authentication3DS1();
		masterCardauth3ds1.setMerchantId(TextUtils.truncate(merchantId, 24));
		masterCardSecureCode.setMastercard_3ds1Auth(masterCardauth3ds1);
		return masterCardSecureCode;
	}
	
	/**
	 * @param merchantId
	 * @param terminalId
	 * @return
	 */
	private VerifiedByVisa buildVerifieVisa(String merchantId, String terminalId) {
		log.info("calling buildVerifieVisa()");
		VerifiedByVisa verifiedByVisa = new VerifiedByVisa();
		Authentication3DS1 visaAuth3ds1 = new Authentication3DS1();
		visaAuth3ds1.setCardAcceptorId(TextUtils.truncate(merchantId, 15));
		visaAuth3ds1.setCardAcceptorTerminalId(TextUtils.truncate(terminalId, 8));
		verifiedByVisa.setVisa_3ds1Auth(visaAuth3ds1);
		return verifiedByVisa;
	}
	
	/**
	 * @param address
	 * @return
	 */
	private APIAddress buildAddress(Address address) {
		log.info("calling buildAddress()");
		APIAddress apiAddress = APIAddress.builder()
			.city(address.getCity())
			.countryCode(address.getCountryCode())
			.postcode(address.getPostalCode())
			.stateProvince(address.getState())
			.street1(address.getAddressLines().get(0))
			.build();
		return apiAddress;
	}
	
	/**
	 * @param serviceConfig
	 * @return
	 */
	private Risk buildRiskPrivilige( ServiceConfig serviceConfig) {
		log.info("calling buildRiskPrivilige");
		Risk riskPrivilige = Risk.builder()
			.privilege(serviceConfig.getRiskprivilege())
			.build();
		return riskPrivilige;
	}
	
	/** Create ECOM MPGS Merchant
	 * @param merchant
	 * @param serviceConfig
	 * @return
	 */
	private APIMerchant buildEcomMPGSMerchant(Merchant merchant, ServiceConfig serviceConfig) {
		log.info("calling buildEcomMPGSMerchant()");
		APIEcomMerchant apiMerchant = APIEcomMerchant.builder().build();
		apiMerchant.setPartnerManagedRiskAssessment(buildPartnerManagerRisk(serviceConfig));
		apiMerchant.setRisk(buildRiskPrivilige(serviceConfig));
		apiMerchant.setTransactionFiltering(TransactionFiltering.builder().dynamic3DSecure(false).ipCountry(new IPCountry(serviceConfig.isIpRejectAnonymousProxy(), serviceConfig.isIpRejectUnknownCountry())).build());
		apiMerchant.setWebSite(merchant.getWebsite());
		return apiMerchant;
	}
	
	
	/**Create POS MPGS Merchant
	 * @param merchant
	 * @return
	 */
	private APIMerchant buildSoftPosMPGSMerchant(Merchant merchant) {
		log.info("calling buildSoftPosMPGSMerchant()");
		APIMerchant apiMerchant = APISoftPosMerchant.builder()
				.tradingName(merchant.getLegalName())
				.build();
		return apiMerchant;
	}
	
	/**
	 * @param merchant
	 * @param createUpdateRequest
	 * @return
	 */
	public APICreateUpdateRequest buildAmendmentMerchant(Merchant merchant, APICreateUpdateRequest createUpdateRequest) {
		APIMerchant apiMerchant = createUpdateRequest.getMerchant();
		List <String> amendmentList = merchant.getAmendmentList();
		if(! CollectionUtils.isEmpty(amendmentList)) {
			if(amendmentList.contains(AmendmentType.MERCHANT_NAME.toString())) {
				apiMerchant.setName(merchant.getMerchantName());
			}
			if(amendmentList.contains(AmendmentType.LEGAL_NAME.toString()) && merchant.isSoftPOS()) {
				apiMerchant.setTradingName(merchant.getLegalName());
			}
			if(amendmentList.contains(AmendmentType.ADDRESS.toString())) {
				Address address = merchant.getAddresses().get(0);
				//if SF payload postalCode is empty then assign existing merchant's postalCode, even existing merchant postalCode does not found then assign constant
				if(address.getPostalCode() == null || address.getPostalCode().isEmpty() )
				{
					if(apiMerchant.getAddress() != null && apiMerchant.getAddress().getPostcode() != null && !apiMerchant.getAddress().getPostcode().trim().isEmpty()) {
						address.setPostalCode(apiMerchant.getAddress() .getPostcode());
					}else {
						address.setPostalCode(POSTAL_CODE);
					}
				}
				
				apiMerchant.setAddress(buildAddress(address));
				
				apiMerchant.setEmail(address.getEmail());
				apiMerchant.setPhone(address.getPhone());
				
				String fName = address.getName() == null ? "" : address.getName();
				String lName = address.getLastName() == null ? "" : address.getLastName();
	
				apiMerchant.setContactName(fName+" "+lName);
				
			}
			if(amendmentList.contains(AmendmentType.MCC.toString())) {
				apiMerchant.setCategoryCode(merchant.getMcc());
			}
			if(amendmentList.contains(AmendmentType.COUNTRY_ORIGIN.toString())) {
				apiMerchant.setGovernmentCountryCode(merchant.getCountryOrigin());
			}
		}
		return createUpdateRequest;
	}
	
	
	public MpgsApiClientKey buildFeignKey(String url, String userName, String credential)
	{
		MpgsApiClientKey feignKey = new MpgsApiClientKey(url, userName, credential);
		return feignKey;
	}
	
}
