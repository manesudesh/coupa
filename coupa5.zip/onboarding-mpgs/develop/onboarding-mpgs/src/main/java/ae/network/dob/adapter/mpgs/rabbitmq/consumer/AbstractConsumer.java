package ae.network.dob.adapter.mpgs.rabbitmq.consumer;


import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.dob.adapter.mpgs.common.MdcUtils;
import ae.network.dob.adapter.mpgs.exception.MaxRetryReachedException;
import ae.network.dob.adapter.mpgs.exception.MessageCancelledException;
import ae.network.dob.adapter.mpgs.exception.MessageRejectionException;
import ae.network.dob.adapter.mpgs.model.reply.ApplicationUpdate;
import ae.network.dob.adapter.mpgs.model.reply.ProcessingResult;
import ae.network.dob.adapter.mpgs.model.reply.ValidationError;
import ae.network.dob.adapter.mpgs.model.request.ApplicationRequest;
import ae.network.dob.adapter.mpgs.model.task.Task;
import ae.network.dob.adapter.mpgs.model.task.TaskHistory;
import ae.network.dob.adapter.mpgs.model.task.TaskStatus;
import ae.network.dob.adapter.mpgs.rabbitmq.config.RabbitQueue;
import ae.network.dob.adapter.mpgs.rabbitmq.service.RabbitService;
import lombok.extern.slf4j.Slf4j;

/**
 * @author 
 * @since 
 */
@Slf4j
public abstract class AbstractConsumer implements Consumer {

    /**
     * onMessage method listens for any
     * publish done on a queue. Listening
     * queue is the queue that publishes
     * are done on
     */
    private final RabbitQueue listeningQueue;
    /**
     * Injection of AMQP, i.e rabbitMQ
     */
    private final RabbitService rabbitService;
    /**
     * When a reschedule is perform during
     * a fail update, RETRY_DELAY_SECONDS
     * tells number of seconds to wait
     * before making a retry
     */
    private final int RETRY_DELAY_SECONDS;
    
    private final ObjectMapper objectmapper;

    protected AbstractConsumer(RabbitQueue listeningQueue, int retryPeriod, RabbitService rabbitService, ObjectMapper objectmapper) {
        this.listeningQueue = listeningQueue;
        this.RETRY_DELAY_SECONDS = retryPeriod;
        this.rabbitService = rabbitService;
        this.objectmapper = objectmapper;
    }

    /**
     * Bean to configure replyListener
     * Configuration of what queue to listen
     * to when a publish is made by any producer
     */
    @Bean
    SimpleMessageListenerContainer replyListener(ConnectionFactory connectionFactory) {
        SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
        container.setConnectionFactory(connectionFactory);
        container.setQueueNames(listeningQueue.getQueueName());
        container.setMessageListener(this);
        container.setErrorHandler(this);
        return container;
    }


    /**
     * Send result of message processing to updates queue
     */
    protected void sendUpdate(ApplicationUpdate applicationUpdate) {
        rabbitService.sendMessage(RabbitQueue.UPDATES, applicationUpdate);
    }

    /**
     * Reschedules a retry of listening of messages
     * if error is recoverable
     */
    private void retryMessage(Message message) {
        rabbitService.retryMessage(message, RETRY_DELAY_SECONDS);
    }

    /**
     * Receives the message on the queue
     * Does a default (which can be overridden)
     * computation by validating
     * and processing the message, throwing exceptions
     * and dispatching events when required based on
     * the actual workflow
     */
    @Override
    public void onMessage(Message message) {
        MdcUtils.setCorrId(message.getMessageProperties().getCorrelationId());
        try {
            onMessageHandler(message);
        } finally {
            MdcUtils.clearCorrId();
        }
    }

    private void onMessageHandler(Message message) {
        log.info("Received message : {}", message.getMessageProperties());

        // parse message
        String messageContent = new String(message.getBody());
        log.info("messageContent : {}", messageContent);
        ApplicationRequest applicationRequest = validateRequestContent(message, messageContent);
        String applicationId = applicationRequest.getApplicationId();

        boolean requestSupported;
        try {
            requestSupported = isRequestSupported(applicationRequest);
        } catch (Exception e) {
            log.error("Unexpected exception during checking if request is supported", e);
            throw new MessageRejectionException(applicationId, e.getMessage());
        }
        if (!requestSupported) {
            sendApplicationCancelled(applicationId);
            return;
        }

        Collection<ValidationError> validationErrors;
        try {
            validationErrors = validateApplication(applicationRequest).orElse(Collections.emptyList());
        } catch (Exception e) {
            log.error("Unexpected exception during validation of message", e);
            throw new MessageRejectionException(applicationId, e.getMessage());
        }

        if (validationErrors.isEmpty()) {
            log.info("Validation of application {} is successful, starting processing...", applicationId);

            // check dry run option
            if (applicationRequest.isDryRun()) {
                Optional<ApplicationUpdate> applicationUpdateOp = druRun(applicationRequest);
                if (applicationUpdateOp.isPresent()) {
                    sendUpdate(applicationUpdateOp.get());
                } else {
                    log.info("dry run not supported");
                    sendApplicationCancelled(applicationId);
                }
                return;
            }

            // process the application
            try {
                processApplication(applicationRequest);
            } catch (MessageCancelledException e) {
                sendApplicationCancelled(applicationId);
            } catch (MessageRejectionException e) {
                log.error("Message rejected, forward to DLQ for investigation", e);
                throw e;
            } catch (Exception e) {
                log.error("an error has occurred in the consumer", e);
                retryMessage(message);
            }
        } else {
            log.info("Sending results of problematic validation", applicationId);
            sendApplicationInvalid(applicationId, validationErrors);
        }
    }

    private void sendApplicationCancelled(String applicationId) {
        ProcessingResult cancelledProcessing = ProcessingResult.builder().finalStatus(TaskStatus.CANCELLED).build();
        ApplicationUpdate applicationUpdate = ApplicationUpdate.builder().applicationId(applicationId)
                .backendSystem(getBackendSystem()).processingResult(cancelledProcessing).build();
        sendUpdate(applicationUpdate);
    }

    private ApplicationRequest validateRequestContent(Message message, String messageContent) {
        ApplicationRequest applicationRequest;
        try {
        	applicationRequest = objectmapper.readValue(messageContent, ApplicationRequest.class);
        } catch (JsonProcessingException e) {
            String errorMessage = "Invalid JSON content";
            log.error(errorMessage, e);

            String applicationId = message.getMessageProperties().getCorrelationId();
            ValidationError error = ValidationError.builder()
                    .errorCode("0")
                    .errorMessage(errorMessage)
                    .fieldName("*")
                    .build();

            sendApplicationInvalid(applicationId, Collections.singletonList(error));

            throw new MessageRejectionException(applicationId, errorMessage, e);
        }
        return applicationRequest;
    }

    private void sendApplicationInvalid(String applicationId, Collection<ValidationError> validationErrors) {
        log.warn("Constructing update for application {}", applicationId);
        Task validationTask = new Task();
        validationTask.setName("Validation");
        validationTask.setTaskStatus(TaskStatus.FAILED);

        List<TaskHistory> taskHistoryList = validationErrors.stream().map(this::mapErrorToTaskHistory)
                .collect(Collectors.toList());
        validationTask.setTaskHistory(taskHistoryList);
        ProcessingResult processingResult = ProcessingResult.builder().tasks(Collections.singletonList(validationTask))
                .finalStatus(TaskStatus.FAILED).build();

        ApplicationUpdate applicationUpdate = ApplicationUpdate.builder().applicationId(applicationId)
                .backendSystem(getBackendSystem()).processingResult(processingResult).build();
        sendUpdate(applicationUpdate);
    }

    private TaskHistory mapErrorToTaskHistory(ValidationError error) {
        TaskHistory taskHistory = new TaskHistory();
        final Date now = new Date();
        taskHistory.setCreatedDate(now);
        taskHistory.setLastModifiedDate(now);
        taskHistory.setTaskStatus(TaskStatus.FAILED);
        taskHistory.setResponse(error.getFieldName() + " : " + error.getErrorMessage());
        taskHistory.setStatusCode(error.getErrorCode());
        return taskHistory;
    }


    @Override
    public void handleError(Throwable throwable) {
        log.error("An error has occurred while processing", throwable);
        if (throwable.getCause() instanceof MaxRetryReachedException) {
            MaxRetryReachedException ex = (MaxRetryReachedException) throwable.getCause();
            ApplicationUpdate applicationUpdate = ApplicationUpdate.builder().backendSystem(getBackendSystem())
                    .applicationId(ex.getApplicationId())
                    .processingResult(ProcessingResult.builder().finalStatus(TaskStatus.FAILED).build()).build();
            sendUpdate(applicationUpdate);
        }
    }

}
