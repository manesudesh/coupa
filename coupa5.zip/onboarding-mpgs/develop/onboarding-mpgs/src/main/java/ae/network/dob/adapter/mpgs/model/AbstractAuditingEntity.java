package ae.network.dob.adapter.mpgs.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

import static ae.network.dob.adapter.mpgs.common.DateFormat.FORMAT;

@Data
public abstract class AbstractAuditingEntity implements Serializable {
    @CreatedDate
    @JsonFormat(pattern = FORMAT)
    @DateTimeFormat(pattern = FORMAT)
    private Date createdDate = new Date();
    @LastModifiedDate
    @JsonFormat(pattern = FORMAT)
    @DateTimeFormat(pattern = FORMAT)
    private Date lastModifiedDate = new Date();
}