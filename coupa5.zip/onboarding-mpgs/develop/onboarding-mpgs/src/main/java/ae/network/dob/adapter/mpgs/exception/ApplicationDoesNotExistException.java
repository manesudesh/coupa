package ae.network.dob.adapter.mpgs.exception;

public class ApplicationDoesNotExistException extends MessageRejectionException {

    public ApplicationDoesNotExistException(String applicationId) {
        super(applicationId, "Application :".concat(applicationId).concat(" Dose Not Exist in MPGS Adapter configurations"));
    }
}