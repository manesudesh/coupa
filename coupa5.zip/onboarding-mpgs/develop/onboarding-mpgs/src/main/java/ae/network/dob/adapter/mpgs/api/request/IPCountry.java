package ae.network.dob.adapter.mpgs.api.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class IPCountry {

	private boolean rejectAnonymousProxy;
	
	private boolean rejectUnknownCountry;

}
