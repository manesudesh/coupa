package ae.network.dob.adapter.mpgs.model.application;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 
 * @version 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class FeesParam {

    private FeeType feeTypeName;
    private BigDecimal feeValue;
    
    private String feeClassifier;
    private Integer volCntLimit;
}
