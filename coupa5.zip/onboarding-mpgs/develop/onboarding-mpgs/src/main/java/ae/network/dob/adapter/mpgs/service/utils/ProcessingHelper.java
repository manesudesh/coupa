package ae.network.dob.adapter.mpgs.service.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import ae.network.dob.adapter.mpgs.api.db.APIData;
import ae.network.dob.adapter.mpgs.api.request.APICreateUpdateRequest;
import ae.network.dob.adapter.mpgs.api.response.APIResponse;
import ae.network.dob.adapter.mpgs.api.response.APIResponseError;
import ae.network.dob.adapter.mpgs.model.application.Merchant;
import ae.network.dob.adapter.mpgs.model.reply.ApplicationUpdate;
import ae.network.dob.adapter.mpgs.model.reply.ProcessingResult;
import ae.network.dob.adapter.mpgs.model.reply.ValidationError;
import ae.network.dob.adapter.mpgs.model.request.ApplicationRequest;
import ae.network.dob.adapter.mpgs.model.task.AdditionalData;
import ae.network.dob.adapter.mpgs.model.task.BackendSystem;
import ae.network.dob.adapter.mpgs.model.task.Task;
import ae.network.dob.adapter.mpgs.model.task.TaskHistory;
import ae.network.dob.adapter.mpgs.model.task.TaskName;
import ae.network.dob.adapter.mpgs.model.task.TaskStatus;

/**
 * @author 
 */
@Service
public class ProcessingHelper {
	
    public ProcessingHelper() {
        super();
    }

    public Task createTask(TaskName taskName, TaskStatus status) {
		Task task = Task.builder()
        .name(taskName.name())
        .taskStatus(status)
        .taskHistory(new ArrayList<TaskHistory>())
        .build();
		return task;
	}
    
	public TaskHistory createTaskHistory(TaskStatus status, String response, String statusCode) {
        TaskHistory taskHistory = new TaskHistory();
        final Date now = new Date();
        taskHistory.setCreatedDate(now);
        taskHistory.setLastModifiedDate(now);
        taskHistory.setTaskStatus(status);
        taskHistory.setResponse(response);
        taskHistory.setStatusCode(statusCode);
        return taskHistory;
    }
	    
	public Task assignValidationErrorTaskHistory(Collection<ValidationError> validationErrors, Task task) {
		List<TaskHistory> taskHistoryList = validationErrors.stream().map(
					e->  createTaskHistory(task.getTaskStatus(), e.getFieldName() + " : " + e.getErrorMessage(), e.getErrorCode()) )
				.collect(Collectors.toList());
        task.setTaskHistory(taskHistoryList);
        return task;
	}

	public static ApplicationUpdate createApplicationResponse(ApplicationRequest applicationRequest) {
    	AdditionalData additionalData = createAdditionalDataMap(applicationRequest); 
        return ApplicationUpdate.builder().applicationId(applicationRequest.getApplicationId())
                .backendSystem(BackendSystem.MPGS)
                .additionalData(additionalData)
                .processingResult(ProcessingResult.builder().finalStatus(calculateFinalStatus(applicationRequest))
                        .tasks(applicationRequest.getTasks()).build())
                .build();
    }
	
	 /**
     * @param apiData
     * @param merchantId
     * @return
     */
    public Task handleAPIResponseTask(APIResponse apiResponse, TaskName taskName, String merchantId) {
    	Task task;
    	if( (apiResponse != null) && (  apiResponse.getResult().equalsIgnoreCase("SUCCESS")) )
        {
    		task = createTask(taskName, TaskStatus.COMPLETED);
 			task.getTaskHistory().add(createTaskHistory(TaskStatus.COMPLETED, "API Response success for Merchant "+merchantId, "OK") ) ;

        } else 
        {
        	APIResponseError errorResponse = apiResponse.getError();
            
        	task =	createTask(taskName, TaskStatus.FAILED);
            task.getTaskHistory().add(createTaskHistory(TaskStatus.COMPLETED, "API Response Fail "+errorResponse.getCause()+" for Merchant "+merchantId, "FAILED") ) ;
        } 
    	return task;
    }
    
    public void handleAPIDataTask(APIData apiData, ApplicationRequest entity, TaskName taskName, String merchantId) {
    	if(apiData != null )
    	{
    		if(apiData.getCreateUpdateAPIData() != null && apiData.getCreateUpdateAPIData().getApiResponse() != null)
    		{
    			entity.getTasks().add (  handleAPIResponseTask(apiData.getCreateUpdateAPIData().getApiResponse(), TaskName.RECEIVE_API_CREATEUPDATE_RESPONSE, merchantId) );
    		}
    		if(apiData.getApproveMerchantAPIData() != null && apiData.getApproveMerchantAPIData().getApiResponse() != null)
    		{
    			entity.getTasks().add ( handleAPIResponseTask(apiData.getApproveMerchantAPIData().getApiResponse(), TaskName.RECEIVE_API_APPROVE_RESPONSE, merchantId) );
    			if("SUCCESS".equals(apiData.getApproveMerchantAPIData().getApiResponse().getResult() )) {
    				Task taskReq = createTask(taskName, TaskStatus.COMPLETED );
    		        taskReq.getTaskHistory().add( createTaskHistory(TaskStatus.COMPLETED, " Merchant : "+merchantId +" "+taskName, "OK") );
    		        entity.getTasks().add(taskReq);
    			}
    		}
    	}
    }
    
    public void handleSearchAPIResponseTask(APICreateUpdateRequest apiCreateUpdateMerchant, String merchantId, ApplicationRequest entity) {
    	if(apiCreateUpdateMerchant == null) {
    		Task detailsNotFoundTask = createTask(TaskName.MERCHANT_DETAILS_NOT_FOUND, TaskStatus.COMPLETED);
            detailsNotFoundTask.getTaskHistory().add(createTaskHistory(TaskStatus.COMPLETED, "Merchant is not found for Merchant "+merchantId, "OK") ) ;
            entity.getTasks().add(detailsNotFoundTask);
    	}else {
    		Task detailsFoundTask = createTask(TaskName.MERCHANT_DETAILS_AVAILABLE, TaskStatus.COMPLETED);
    		detailsFoundTask.getTaskHistory().add(createTaskHistory(TaskStatus.COMPLETED, "Merchant details found for Merchant "+merchantId, "OK") ) ;
            entity.getTasks().add(detailsFoundTask);
    	}
    }
	
	/**
    * @param applicationRequest
    * @return
    */
    public static TaskStatus calculateFinalStatus(ApplicationRequest applicationRequest) {
       Collection<Task> tasks = applicationRequest.getTasks().stream()
               .filter(task -> !"VALIDATION".equalsIgnoreCase(task.getName())).collect(Collectors.toList());
       if (tasks.stream().allMatch(task -> task.getTaskStatus().equals(TaskStatus.FAILED))) {
           return TaskStatus.FAILED;
       } else if (tasks.stream()
               .allMatch(task -> (task.getTaskStatus().equals(TaskStatus.COMPLETED)
                       || task.getTaskStatus().equals(TaskStatus.CANCELLED)))) {
           return TaskStatus.COMPLETED;
       } else {
           return TaskStatus.PARTIALLY_COMPLETED;
       }
    }
	
   /**
    * @param applicationRequest
    * @return
    */
    private static AdditionalData createAdditionalDataMap(ApplicationRequest applicationRequest) {
		AdditionalData additionalData = new AdditionalData();
		applicationRequest.getPayload().getApplications()
				.forEach(application -> application.getMerchants().forEach(merchant -> {
					if (!StringUtils.isEmpty(merchant.getMerchantId()))
						additionalData.setDataMap(merchant.getMerchantId(), merchant.getMerchantName());
				}));
   	
		return additionalData;
	}
    
    /**
	 * @param applicationRequest
	 * @return
	 */
	public List<Merchant> getValidMerchants(ApplicationRequest applicationRequest) {
    	List<Merchant> merchants = (List<Merchant>) applicationRequest.getPayload().getApplications().stream()
                .flatMap(app -> app.getMerchants().stream())
                .filter(merchant -> merchant.isValidService() && merchant.isValidAuthSystem() && merchant.isPspServiceSupportMpgs())
                .collect(Collectors.toList());
    	return merchants; 
    }
	
	public List<Merchant> getValidAmendmentMerchants(ApplicationRequest applicationRequest) {
    	List<Merchant> merchants = (List<Merchant>) applicationRequest.getPayload().getApplications().stream()
                .flatMap(app -> app.getMerchants().stream())
                .filter(merchant -> merchant.isValidAuthSystem() && merchant.isPspServiceSupportMpgs())
                .collect(Collectors.toList());
    	return merchants; 
    }
	
	/**
	 * @param entity
	 * @return
	 */
   //check if the any merchant dont have goodsdescription then invalid whole application
	public List<Merchant> getInvalidBusinessLineMerchants(ApplicationRequest entity) {
        List<Merchant> invalidBusinessLineList = (List<Merchant>) entity.getPayload().getApplications().stream()
                .flatMap(app -> app.getMerchants().stream())
                .filter(merchant -> merchant.isValidService() && merchant.isValidAuthSystem()  && ! merchant.isGoodDescription())
                .collect(Collectors.toList());
		return invalidBusinessLineList;
	}
}
