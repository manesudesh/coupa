package ae.network.dob.adapter.mpgs.rabbitmq.consumer;

import java.util.Collection;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.dob.adapter.mpgs.model.reply.ValidationError;
import ae.network.dob.adapter.mpgs.model.request.ApplicationRequest;
import ae.network.dob.adapter.mpgs.model.request.RequestType;
import ae.network.dob.adapter.mpgs.model.task.BackendSystem;
import ae.network.dob.adapter.mpgs.rabbitmq.config.RabbitQueue;
import ae.network.dob.adapter.mpgs.rabbitmq.service.RabbitService;
import ae.network.dob.adapter.mpgs.service.RequestProcessor;
import ae.network.dob.adapter.mpgs.service.utils.ProcessingHelper;
import lombok.extern.slf4j.Slf4j;

/**
 * @author : 
 * @version : 
 */
@Component
@Slf4j
public class MPGSConsumer extends AbstractConsumer {

    @Autowired
    private RequestProcessor requestProcessor;


    protected MPGSConsumer(RabbitService rabbitService, @Value("${octopus.consumer.error-retry-in-seconds}") int retryPeriod, RequestProcessor requestProcessor, ObjectMapper mapper) {
        super(RabbitQueue.MPGS, retryPeriod, rabbitService, mapper);
        this.requestProcessor = requestProcessor ;
    }

    @Override
    public boolean isRequestSupported(ApplicationRequest applicationRequest) {
		boolean isRequestSupportedFlag = false;
		final RequestType requestType = applicationRequest.getRequestType();

		if (requestType == RequestType.ONBOARDING) {
			isRequestSupportedFlag = requestProcessor.isAnyMerchantValid(applicationRequest);
			log.info("Request Type Onboarding is supported for Application: {} {}",
					applicationRequest.getApplicationId(), isRequestSupportedFlag);
			return isRequestSupportedFlag;
		} else if (requestType == RequestType.AMENDMENT) {
			isRequestSupportedFlag = true;
			log.info("Request Type Amendment is supported for Application: {} {}",
					applicationRequest.getApplicationId(), isRequestSupportedFlag);
			isRequestSupportedFlag = requestProcessor.isAnyAmendmentApplicationValid(applicationRequest);
			return isRequestSupportedFlag;
		} else {
			requestProcessor.saveApplicatioRequest(applicationRequest);
			isRequestSupportedFlag = false;
			log.error("Unsupported Request Type: {} for Application: {} {}", requestType,
					applicationRequest.getApplicationId(), isRequestSupportedFlag);
			return isRequestSupportedFlag;
		}
    }

    @Override
    public Optional<Collection<ValidationError>> validateApplication(ApplicationRequest applicationRequest) {
    	return requestProcessor.validateApplication(applicationRequest);
    }
    
  
    @Override
    public void processApplication(ApplicationRequest applicationRequest) {
        requestProcessor.process(applicationRequest);
        
        sendUpdate(ProcessingHelper.createApplicationResponse(applicationRequest));
        
    }

    @Override
    public BackendSystem getBackendSystem() {
        return BackendSystem.MPGS;
    }
    
}
