package ae.network.dob.adapter.mpgs.model.application;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import static ae.network.dob.adapter.mpgs.common.TextUtils.formatMcc;

/**
 * @author 
 * @version 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Slf4j
@JsonIgnoreProperties(ignoreUnknown = true)
public class Merchant {

    @NotNull
    private String merchantId;
    private String merchantName;
    private String legalName;
    @NotNull
    private MerchantType merchantType;
    
    @NotNull
    private String mcc;
    
    private String subMerchantType;
    
    private String website;
    
    private String storeType;
    
    private String debitAccountNumOrIban;
    private String creditAccountNumOrIban;
    
    @NotNull
    private String merchantCurrency;
    
    private String statementFrequency;
    private String statementDeliveryType;

    private String paymentMode;
	
    private boolean kyc;
    private boolean mcp;
    private String bankName;
	
    private String countryOrigin;
    
    private String businessLine;
    
    @NotNull
    @Valid
    private List<Address> addresses;

    private MerchantConfig configurations;

    @NotNull
    @NotEmpty
    @Valid
    private List<MerchantService> services;

    @Valid
    private List<Terminal> terminals;
    
    private List<String> amendmentList;
    
    public String getFormatMcc() {
        try {
            return formatMcc(Integer.parseInt(this.mcc));
        } catch (NumberFormatException e) {
            return null;
        }
    }
    /**
     * checks if the merchant has MPGS option or not
     *
     * @return true/false
     */
    public boolean isMPGS() {
    	MPGSService mpgsService = (MPGSService)getMerchantService(ServiceType.MPGS);
        if (mpgsService != null) {
        	log.info("Merchant "+merchantId+" has MPGS service");
        	return true;
        }
        else {
        	log.error("Merchant "+merchantId+" has NOT MPGS service");
        	return false;
        }
    }

    /**
     * @return
     */
    public boolean isQrPay() {
    	QrPayService qrService = (QrPayService)getMerchantService(ServiceType.QRPAY);
        if (qrService != null)
        {
        	log.info("Merchant "+merchantId+" has QRPAY service");
        	return true;
        }
        else {
        	log.info("Merchant "+merchantId+" has NOT QRPAY service");
        	return false;
        }
    }
    
    /**
	 * PSP checks - either PSP service is not available and if PSP available then need to check gateway n PSPChainId
	 * @return
	 */
	public boolean isPspServiceSupportMpgs() {
		PSPServiceParam pspServiceParam = (PSPServiceParam) getMerchantService(ServiceType.PSP);
		// either PSP service is not available and if PSP available then need to check
		// gateway
		if (pspServiceParam == null) {
			return true;
		}
		String gatewayType = pspServiceParam.getGatewayType();
		boolean isMpgsGatewayType = ServiceType.MPGS.toString().equals(gatewayType);
		if (isEcom()) {
			if(isMpgsGatewayType)
			{
				return true;
			}else {
				return false;
			}
		}
			
		return true;
		
	}
    
    /**
     * @return
     */
    public boolean isValidAuthSystem() {
    	String authSystem = "";
    	if(getConfigurations() == null) {
    		log.error("Merchant {} dont have MerchantConfig", merchantId);
    		return false;
    	}
    	if(isEcom() &&  (authSystem = getConfigurations().getEcomAuthSystem()) != null) {
    		log.info("ECOM Merchant "+merchantId+" has ecomAuthSystem "+authSystem);
    	}
    	else if(isSoftPOS() && (authSystem = getConfigurations().getSoftPosAuthSystem()) != null) 
    	{
    		log.info("POS Merchant "+merchantId+" has softPosAuthSystem "+authSystem);
    	}
    	if(ServiceType.MPGS.toString().equalsIgnoreCase(authSystem)) {
//    		log.info("Merchant "+merchantId+" has MPGS authSystem");
    		return true;
    	}
    	log.error("Merchant "+merchantId+" has NOT valid authSystem");
    	return false;
    }
    
    /**
     * @return
     */
    public boolean isValidService() {
    	boolean validService = isMPGS() && !isQrPay();
    	log.info("Merchant "+merchantId+" has MPGS service and non QRPAY service : "+validService);
    	return validService;
    }
    
    /**
     * @return
     */
    public boolean isGoodDescription() {
    	boolean isDescription = ( this.businessLine != null && this.businessLine.trim().length() > 0 );
    	log.info("Merchant "+merchantId+" has gooddescription : "+isDescription);
    	return isDescription; 
    }
    
    /**
     * @param serviceType
     * @return
     */
    public MerchantService getMerchantService(ServiceType serviceType) {
        if (services != null && !services.isEmpty()) {
            Optional<MerchantService> servOp = services.stream()
                    .filter(merchantService -> merchantService.getServiceType().equalsIgnoreCase(serviceType.getValue()))
                    .findFirst();

            if (servOp.isPresent()) {
            	log.info("Merchant "+merchantId+" has "+serviceType+" service ");
                return servOp.get();
            } else {
            	log.info("Merchant "+merchantId+" has NOT "+serviceType+" service ");
                return null;
            }
        }
        return null;
    }
    
    public boolean isEcom() {
    	log.info("Merchant "+merchantId+" has MerchantType is "+merchantType);
        return MerchantType.ECOM.equals(this.merchantType);
    }
    
    public boolean isSoftPOS() {
    	log.info("Merchant "+merchantId+" has MerchantType is "+merchantType);
        return MerchantType.POS.equals(this.merchantType);
    }

}
