package ae.network.dob.adapter.mpgs.model.task;

public enum TaskStatus {
    COMPLETED, PARTIALLY_COMPLETED, FAILED, CANCELLED
}
