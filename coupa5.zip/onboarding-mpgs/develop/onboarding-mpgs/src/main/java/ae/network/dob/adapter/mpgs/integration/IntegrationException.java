package ae.network.dob.adapter.mpgs.integration;

import ae.network.dob.adapter.mpgs.api.response.APIResponse;
import feign.FeignException;

/**
 * Non-recoverable exception, wraps API error response
 *
 * @author 
 * @since 
 */
public class IntegrationException extends FeignException {
    private final APIResponse error;

    public IntegrationException(int status, APIResponse error) {
        super(status, error.getError().getExplanation());
        this.error = error;
    }

    public APIResponse getError() {
        return error;
    }
}
