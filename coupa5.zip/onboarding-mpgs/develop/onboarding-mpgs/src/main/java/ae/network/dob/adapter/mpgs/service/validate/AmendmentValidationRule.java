package ae.network.dob.adapter.mpgs.service.validate;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import ae.network.dob.adapter.mpgs.config.PayloadErrorMessageConfig;
import ae.network.dob.adapter.mpgs.database.repository.RequestRepository;
import ae.network.dob.adapter.mpgs.model.amendment.AmendmentType;
import ae.network.dob.adapter.mpgs.model.application.Address;
import ae.network.dob.adapter.mpgs.model.application.Application;
import ae.network.dob.adapter.mpgs.model.application.Merchant;
import ae.network.dob.adapter.mpgs.model.errors.AdapterError;
import ae.network.dob.adapter.mpgs.model.errors.ErrorName;
import ae.network.dob.adapter.mpgs.model.request.ApplicationRequest;
import ae.network.dob.adapter.mpgs.service.utils.ProcessingHelper;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AmendmentValidationRule implements ValidationRule<ApplicationRequest> {

    @Autowired private PayloadErrorMessageConfig errorMessageConfig;

    @Autowired private RequestRepository requestRepository;
    
    @Autowired private ProcessingHelper processingHelper;

    @Override
    public ValidationResult validate(ApplicationRequest request) {

        log.info("Amendment validator started.");
        AdapterError error;

        if (isApplicationIdExist(request.getApplicationId())) {
            log.info("ApplicationId {} is already Exist.", request.getApplicationId());
            error = getError(ErrorName.APPLICATION_EXIST);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }

        List<Merchant> validMerchantList = processingHelper.getValidAmendmentMerchants(request);
        if (validMerchantList.isEmpty()) {
            log.info("All Merchants are Invalid for applicationId {}",  request.getApplicationId());
            error = getError(ErrorName.ALL_MERCHANTS_INVALID);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }
        
        List <Application> applicationList = request.getPayload().getApplications();
        if (CollectionUtils.isEmpty(applicationList)) {
            error = getError(ErrorName.APPLICATION_LIST_EMPTY);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }
        
        for(Application application : applicationList) {
        	if(application == null) {
        		error = getError(ErrorName.APPLICATION_LIST_EMPTY);
                return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
           
        	}
        
	        List<Merchant> merchantList = application.getMerchants();
	        if(CollectionUtils.isEmpty(merchantList)) {
	        	 error = getError(ErrorName.MERCHANT_NULL);
		            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
	        }
	
	        ValidationResult validationResultAmendmentList = validateAmendmentList(application); 
	        if(validationResultAmendmentList != null) {
	        	return validationResultAmendmentList;
	        }
	    }
        return ValidationResult.builder().passed(true).code("000").message("Success").build();
    }

	/**
	 * @param application
	 * @return
	 */
	private ValidationResult validateAmendmentList(Application application) {
		AdapterError error;
      
		List<Merchant> merchants = application.getMerchants().stream().filter(m-> ! CollectionUtils.isEmpty(m.getAmendmentList()) && m.getAmendmentList().stream().anyMatch(amend -> AmendmentType.isAmendmentType(amend))).collect(Collectors.toList());
		for(Merchant merchant : merchants) {
		
		    if (merchant == null || merchant.getMerchantId() == null) {
		        error = getError(ErrorName.MERCHANT_NULL);
		        return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
		    }
		    
		    if (merchant.getMerchantType() == null) {
		        error = getError(ErrorName.MERCHANT_TYPE_EMPTY);
		        return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
		    }

		    List<String> amendmentList = merchant.getAmendmentList();

			if (amendmentList.contains(AmendmentType.MERCHANT_NAME.name()) && merchant.getMerchantName() == null) {
				error = getError(ErrorName.MERCHANT_NAME_NULL);
				return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage())
						.build();
			}
		
			if (amendmentList.contains(AmendmentType.LEGAL_NAME.name()) && merchant.getLegalName() == null) {
				error = getError(ErrorName.LEGAL_NAME_NULL);
				return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage())
						.build();
			}

			if (amendmentList.contains(AmendmentType.MCC.name()) && merchant.getMcc() == null) {
				error = getError(ErrorName.MCC_NOT_FOUND);
				return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage())
						.build();
			}

			if (amendmentList.contains(AmendmentType.ADDRESS.name())) {
				if (merchant.getAddresses() == null || merchant.getAddresses().isEmpty()) {
					error = getError(ErrorName.ADDRESS_LIST_EMPTY);
					return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage())
							.build();
				}
				Address address = merchant.getAddresses().get(0);
				if (address == null || address.getPhone() == null || address.getEmail() == null || address.getCountryCode() == null
						|| address.getCity() == null || address.getAddressLines() == null) {
					error = getError(ErrorName.ADDRESS_INFO_MISSING);
					return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage())
							.build();
				}
			}
			if (amendmentList.contains(AmendmentType.COUNTRY_ORIGIN.name()) && StringUtils.isEmpty(merchant.getCountryOrigin()) ) {
				error = getError(ErrorName.COUNTRY_ORIGIN);
				return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage())
						.build();
			}
		}
		return null;
	}
	
	protected ValidationResult isAnyAmendmentApplicationValid(ApplicationRequest request)
	{
		AdapterError error;
		if(request==null || request.getPayload()==null || CollectionUtils.isEmpty(request.getPayload().getApplications())) {
			error = getError(ErrorName.APPLICATION_LIST_EMPTY);
		    return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
		}
		
		List<Merchant> validMerchantList = processingHelper.getValidAmendmentMerchants(request);
        if (validMerchantList.isEmpty()) {
            log.info("All Merchants are Invalid for applicationId {}",  request.getApplicationId());
            error = getError(ErrorName.ALL_MERCHANTS_INVALID);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }
		
		List <Application> applicationList = request.getPayload().getApplications();
		
		for(Application application : applicationList) {
		List<String> amendmentListAnyofMerchant = application.getMerchants().stream()
				.filter(m-> m.getAmendmentList()!=null && !m.getAmendmentList().isEmpty() && m.getAmendmentList().stream().anyMatch(amend -> AmendmentType.isAmendmentType(amend)))
				.flatMap(m-> m.getAmendmentList().stream()).collect(Collectors.toList());
			if(CollectionUtils.isEmpty(amendmentListAnyofMerchant)) {
				 error = getError(ErrorName.AMENDMENT_LIST_NOT_FOUND);
			     return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
			}
		}
		return ValidationResult.builder().passed(true).code("000").build();
	}

    private boolean isApplicationIdExist(String applicationId) {
        return requestRepository.findFirstByApplicationId(applicationId).isPresent();
    }

    private AdapterError getError(ErrorName error) {
        return errorMessageConfig.getMessages().stream()
                .filter(err -> err.getName().equals(error.name())).findFirst().get();
    }
}
