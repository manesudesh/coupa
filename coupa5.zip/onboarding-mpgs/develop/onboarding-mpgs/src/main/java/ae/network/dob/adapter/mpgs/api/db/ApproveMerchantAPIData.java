package ae.network.dob.adapter.mpgs.api.db;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import ae.network.dob.adapter.mpgs.api.request.APIRequest;
import ae.network.dob.adapter.mpgs.api.response.APIResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApproveMerchantAPIData {
	
	private APIRequest apiRequest;
	private APIResponse apiResponse;
}
