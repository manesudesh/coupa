package ae.network.dob.adapter.mpgs.api.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MasterCardSecureCode implements Serializable{
	
	public Authentication3DS1 mastercard_3ds1Auth;
}
