package ae.network.dob.adapter.mpgs.model.reply;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ValidationError {
    private String fieldName;
    private String errorMessage;
    private String errorCode;
}
