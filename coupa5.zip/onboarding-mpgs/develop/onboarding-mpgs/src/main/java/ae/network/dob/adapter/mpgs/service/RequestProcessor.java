package ae.network.dob.adapter.mpgs.service;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.dob.adapter.mpgs.api.db.APIData;
import ae.network.dob.adapter.mpgs.api.db.ApproveMerchantAPIData;
import ae.network.dob.adapter.mpgs.api.db.CreateUpdateAPIData;
import ae.network.dob.adapter.mpgs.api.db.SearchMerchantAPIData;
import ae.network.dob.adapter.mpgs.api.request.APICreateUpdateRequest;
import ae.network.dob.adapter.mpgs.api.request.APIMerchant;
import ae.network.dob.adapter.mpgs.api.request.APIRequest;
import ae.network.dob.adapter.mpgs.api.request.annotation.inspector.JAnnotationIntrospector;
import ae.network.dob.adapter.mpgs.api.response.APIResponse;
import ae.network.dob.adapter.mpgs.api.response.APIResponseError;
import ae.network.dob.adapter.mpgs.config.APIConfig;
import ae.network.dob.adapter.mpgs.config.APIConfig.ServiceConfig;
import ae.network.dob.adapter.mpgs.config.CacheService;
import ae.network.dob.adapter.mpgs.database.MPGSConfigDBEntity;
import ae.network.dob.adapter.mpgs.database.service.ConfigDBService;
import ae.network.dob.adapter.mpgs.database.service.MPGSRequestDBService;
import ae.network.dob.adapter.mpgs.exception.MessageCancelledException;
import ae.network.dob.adapter.mpgs.integration.APIFeignClient;
import ae.network.dob.adapter.mpgs.integration.IntegrationException;
import ae.network.dob.adapter.mpgs.model.amendment.AmendmentType;
import ae.network.dob.adapter.mpgs.model.application.Merchant;
import ae.network.dob.adapter.mpgs.model.dto.MpgsApiClientKey;
import ae.network.dob.adapter.mpgs.model.reply.ValidationError;
import ae.network.dob.adapter.mpgs.model.request.ApplicationRequest;
import ae.network.dob.adapter.mpgs.model.request.RequestType;
import ae.network.dob.adapter.mpgs.model.task.Task;
import ae.network.dob.adapter.mpgs.model.task.TaskName;
import ae.network.dob.adapter.mpgs.model.task.TaskStatus;
import ae.network.dob.adapter.mpgs.service.utils.ProcessingHelper;
import ae.network.dob.adapter.mpgs.service.validate.ValidationExecutor;
import ae.network.dob.adapter.mpgs.service.validate.ValidationResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class RequestProcessor {

	@Autowired private ValidationExecutor validationExecutor;
	
	@Autowired private APIConfig configProperties ;
	
    @Autowired private MPGSRequestDBService appRequestDB;
    
    @Autowired private ConfigDBService configDB;
    
    @Autowired private ProcessingHelper processingHelper;
    
    @Autowired private MPGSHelper MPGSHelper;
    
    @Autowired ObjectMapper mapper;
    @Autowired CacheService cacheService;
    
    /**
     * process Request, prepare data to be exported to MPGS
     *
     * @param entity
     */
	public void process(ApplicationRequest entity) {
		if (entity.getRequestType() == RequestType.ONBOARDING) {
			List<Merchant> merchantList = processingHelper.getValidMerchants(entity);
			// validate if changes required
			if (CollectionUtils.isEmpty(merchantList)) {
				log.error("Total number of valid merchants " + merchantList.size());
				saveApplicatioRequest(entity);
				throw new MessageCancelledException("No Merchant Available");
			}
			log.info("Total number of valid merchants " + merchantList.size());

			// create data and call MPGS API for each merchant
			merchantList.forEach(merchant -> {
				createMPGSMerchant(merchant, entity);
			});
		} else if (entity.getRequestType() == RequestType.AMENDMENT) {
			List<Merchant> merchants = entity.getPayload().getApplications().stream().flatMap(app -> app.getMerchants()
					.stream()
					.filter(m -> !CollectionUtils.isEmpty(m.getAmendmentList())
							&& m.getAmendmentList().stream().anyMatch(amend -> AmendmentType.isAmendmentType(amend)))
					)
					.collect(Collectors.toList());
			
			merchants.stream()
			.filter(merchant -> merchant.isValidAuthSystem() && merchant.isPspServiceSupportMpgs())
			.forEach(
					merchant -> amendmentMPGSMerchant(merchant, entity)
			);
		}
		saveApplicatioRequest(entity);
	}
    
    /**Method creates MPGS Merchant
     * @param merchant
     * @param entity
     * @return
     */
    private APIData createMPGSMerchant(Merchant merchant, ApplicationRequest entity) {
    	log.info("calling create MPGS merchant {} {}",merchant.getMerchantId(), merchant.getMerchantType());
    	String acquirer = entity.getAcquirer().name();
    	String merchantId = merchant.getMerchantId();
    	String merchantType = merchant.getMerchantType().name();
    	
    	ServiceConfig serviceConfig = configProperties.getApiConfig().get(acquirer).get(merchantType);

    	MPGSConfigDBEntity mpgsConfigDB = configDB.findFirstByAcquirerAndMerchantType(acquirer, merchantType);
    	
    	APIMerchant apiMerchant = MPGSHelper.buildMPGSMerchat(merchant, serviceConfig, mpgsConfigDB);
    	
        APIData apiReqResData = callMPGSApi(merchantId, apiMerchant, serviceConfig, mpgsConfigDB);
    	
        entity.getApiDatas().add(apiReqResData);
        
        processingHelper.handleAPIDataTask(apiReqResData, entity, TaskName.ONBOARDING_MERCHANT,  merchantId);
        
        return apiReqResData;
    }
    
    /**
     * @param merchant
     * @param entity
     * @return
     */
    private void amendmentMPGSMerchant(Merchant merchant, ApplicationRequest entity) {
    	log.info("calling amendment MPGS merchant {} {}",merchant.getMerchantId(), merchant.getMerchantType());
    	String acquirer = entity.getAcquirer().name();
    	String merchantId = merchant.getMerchantId();
    	String merchantType = merchant.getMerchantType().name();
    	
    	ServiceConfig serviceConfig = configProperties.getApiConfig().get(acquirer).get(merchantType);

    	MPGSConfigDBEntity mpgsConfigDB = configDB.findFirstByAcquirerAndMerchantType(acquirer, merchantType);
    	
    	APIData apiData = APIData.builder().merchantId(merchantId).merchantType(mpgsConfigDB.getMerchantType())
    			.searchAPIData(SearchMerchantAPIData.builder().build())
    			.build();
    	
    	APICreateUpdateRequest apiCreateUpdateMerchant = searchMPGSMerchant(merchant, serviceConfig, mpgsConfigDB, apiData.getSearchAPIData());
    	apiData.setSearchAPIData(SearchMerchantAPIData.builder().merchantApiDetails(apiCreateUpdateMerchant).build());
    	processingHelper.handleSearchAPIResponseTask(apiCreateUpdateMerchant, merchantId, entity);
    	if(apiCreateUpdateMerchant == null) {
    		entity.getApiDatas().add(apiData);
    		return ;
    	}
    	
    	apiCreateUpdateMerchant.setApiOperation(serviceConfig.getApiCrUpdOperation());
    	
    	apiCreateUpdateMerchant = MPGSHelper.buildAmendmentMerchant(merchant, apiCreateUpdateMerchant);
    	
    	invokeCreateUpdateEndpoint(merchantId, apiCreateUpdateMerchant, mpgsConfigDB, serviceConfig, apiData);
    	
        entity.getApiDatas().add(apiData);
        
        processingHelper.handleAPIDataTask(apiData, entity, TaskName.AMENDMENT_MERCHANT, merchantId);
        
    }
 
    /**
     * @param merchant
     * @param serviceConfig
     * @param mpgsConfigDB
     * @return
     */
    private APICreateUpdateRequest searchMPGSMerchant(Merchant merchant, ServiceConfig serviceConfig, MPGSConfigDBEntity mpgsConfigDB, SearchMerchantAPIData searchApiData) {
    	log.info("calling amendment MPGS merchant {} {}",merchant.getMerchantId(), merchant.getMerchantType());
    	String merchantId = merchant.getMerchantId();
    	APICreateUpdateRequest apiMerchantData = invokeGETApiEndpoint(merchantId, mpgsConfigDB, serviceConfig, searchApiData);
    	
        return apiMerchantData;
    }

    /** Method create MPGS Merchant and invoke API Endpoints
     * @param merchantId
     * @param apiMerchant
     * @param serviceConfig
     * @param mpgsConfig
     * @return
     */
    private APIData callMPGSApi(String merchantId, APIMerchant apiMerchant, ServiceConfig serviceConfig, MPGSConfigDBEntity mpgsConfigDB) {
    	log.info("calling callMPGSApi");
    	APICreateUpdateRequest apiRequest = APICreateUpdateRequest.builder()
    			.apiOperation(serviceConfig.getApiCrUpdOperation()).merchant(apiMerchant).build();
    	 
    	APIData apiData = APIData.builder().merchantId(merchantId).merchantType(mpgsConfigDB.getMerchantType()).build();
	
    	return invokeCreateUpdateEndpoint(merchantId, apiRequest, mpgsConfigDB, serviceConfig, apiData);
    }

	/** method invoke rest API EndPoint
	 * @param merchantId
	 * @param apiRequest
	 * @param mpgsConfig
	 * @param serviceConfig
	 * @return APIResponse
	 */
	private APIData invokeCreateUpdateEndpoint(String merchantId, APICreateUpdateRequest createUpdateApiRequest, MPGSConfigDBEntity mpgsConfigDB, ServiceConfig serviceConfig, APIData apiData)
    {
		log.info("calling invokeCreateUpdateEndpoint()");
    	try {
    		ObjectMapper mapperWritter = new ObjectMapper();
    		mapperWritter.setAnnotationIntrospector(new JAnnotationIntrospector(serviceConfig));
    		String jsonRequestCreateUpdateAPI = mapperWritter.writeValueAsString(createUpdateApiRequest);
	        log.info("API Request "+jsonRequestCreateUpdateAPI);
	        
	        apiData.setCreateUpdateAPIData(CreateUpdateAPIData.builder()
	        				.apiRequest(createUpdateApiRequest)
	        				.build() );
	        
	        String url = serviceConfig.getUrl().concat( mpgsConfigDB.getMsoId() );
	        
	        MpgsApiClientKey feignKey = MPGSHelper.buildFeignKey(url, mpgsConfigDB.getApiBasicAuthNameJASYPTENC(), mpgsConfigDB.getApiPasswordJASYPTENC());
	        APIFeignClient apiFeignClient = cacheService.buildFeignClient(feignKey);
	        String strResponseCreateUpdateAPI = apiFeignClient.createMerchant(merchantId, jsonRequestCreateUpdateAPI);
	        APIResponse responseCreateUpdateAPI = mapperWritter.readValue(strResponseCreateUpdateAPI, APIResponse.class);
	        apiData.getCreateUpdateAPIData().setApiResponse(responseCreateUpdateAPI);
	        
	        if( ! responseCreateUpdateAPI.getResult().equalsIgnoreCase("SUCCESS")) //FAIL case
	        {
	        	APIResponseError errorResponse = responseCreateUpdateAPI.getError();
	        	log.error("API_CREATEUPDATE response "+responseCreateUpdateAPI.getResult()+"  "+errorResponse.getCause()+"   "+errorResponse.getExplanation());
	        	return apiData;
	        } else //Success case
	        {
	        	log.info("Result of Create_Update Merchant :- "+merchantId+" "+responseCreateUpdateAPI.getResult());
	        	ApproveMerchantAPIData approveMerchantAPIData =  callApproveMerchantEndpoint(apiFeignClient, merchantId);
	        	apiData.setApproveMerchantAPIData(approveMerchantAPIData);
	        	return apiData;
	        } 
    	}catch(IntegrationException ie) {
    		log.error("IntegrationException Occurred while invoking CreateUpdate Endpoint "+ie.getError());
    		apiData.getCreateUpdateAPIData().setApiResponse(ie.getError());
			return apiData;
    	}
    	catch(Exception e) {
    		log.error("Exception Occurred while invoking CreateUpdate Endpoint "+e.getMessage());
    		APIResponse apiResponse = APIResponse.builder().result("ERROR")
    				.error(APIResponseError.builder().cause("Exception Occurred while invoking CreateUpdate Endpoint").build())
    				.build();
    		apiData.getCreateUpdateAPIData().setApiResponse(apiResponse);
    		return apiData;
    	}
    }
	
	/**
	 * @param merchantId
	 * @param mpgsConfigDB
	 * @param serviceConfig
	 * @param searchApiData
	 * @return
	 */
	private APICreateUpdateRequest invokeGETApiEndpoint(String merchantId, MPGSConfigDBEntity mpgsConfigDB, ServiceConfig serviceConfig, SearchMerchantAPIData searchApiData)
    {
		log.info("calling Search invokeGETEndpoint()");
		APICreateUpdateRequest responseCreateUpdateAPI = null;
		try {
			ObjectMapper mapperReader = new ObjectMapper();
			mapperReader.setAnnotationIntrospector(new JAnnotationIntrospector(serviceConfig));
	        String url = serviceConfig.getUrl().concat( mpgsConfigDB.getMsoId() );
	        
	        MpgsApiClientKey feignKey = MPGSHelper.buildFeignKey(url, mpgsConfigDB.getApiBasicAuthNameJASYPTENC(), mpgsConfigDB.getApiPasswordJASYPTENC());
	        APIFeignClient apiFeignClient = cacheService.buildFeignClient(feignKey);
	        String strResponseCreateUpdateAPI = apiFeignClient.searchMerchant(merchantId);
	        responseCreateUpdateAPI = mapperReader.readValue(strResponseCreateUpdateAPI, APICreateUpdateRequest.class);
	        searchApiData.setMerchantApiDetails(responseCreateUpdateAPI);
	        return responseCreateUpdateAPI;
    	}catch(IntegrationException ie) {
    		log.error("IntegrationException Occurred while invoking GET API Endpoint "+ie.getError());
    		searchApiData.setErrorResponse(ie.getError());
			return responseCreateUpdateAPI;
    	}
    	catch(Exception e) {
    		log.error("Exception Occurred while invoking GET API Endpoint "+e.getMessage());
    		APIResponse apiResponse = APIResponse.builder().result("ERROR")
    				.error(APIResponseError.builder().cause("Exception Occurred while invoking GET API Endpoint").build())
    				.build();
    		searchApiData.setErrorResponse(apiResponse);
    		return responseCreateUpdateAPI;
    	}
    }
	

    /**
	 * @param apiClient
	 * @param merchantId
	 * @param mapper
	 * @return
     * @throws  
	 * @throws JsonProcessingException
	 */
	private ApproveMerchantAPIData callApproveMerchantEndpoint(APIFeignClient apiClient, String merchantId) throws JsonProcessingException 
	{
		ApproveMerchantAPIData approveAPIData = ApproveMerchantAPIData.builder().build();
		try {
			log.info("calling Approve_Merchant Endpoint()");
			
			String approveAPIRequest = "{"
	    			+ "    \"apiOperation\": \"APPROVE_MERCHANT\" "
	    			+ "}";
			
			log.info(" request " +approveAPIRequest);
			
			approveAPIData.setApiRequest(APIRequest.builder().apiOperation("APPROVE_MERCHANT").build());
		        	
			String strResponseApprovalAPI = apiClient.approveMerchant(merchantId, approveAPIRequest);
			log.info(" Merchant Approve Response " +strResponseApprovalAPI);
			APIResponse responseApprovalAPI = mapper.readValue(strResponseApprovalAPI, APIResponse.class);
			
			approveAPIData.setApiResponse(responseApprovalAPI);
		
			return approveAPIData;
		}catch(IntegrationException ie) {
			log.error("IntegrationException Occurred while invoking Endpoint "+ie.getError());
			approveAPIData.setApiResponse(ie.getError());
			return approveAPIData;
	}
	catch(Exception e) {
		log.error("Exception Occurred while invoking Endpoint "+e.getMessage());
		APIResponse apiResponse = APIResponse.builder().result("ERROR")
				.error(APIResponseError.builder().cause("Exception Occurred while invoking Endpoint").build())
				.build();
		approveAPIData.setApiResponse(apiResponse);
		return approveAPIData;
	}
    }

	
	/** Method validate the Application
	 * @param applicationRequest
	 * @return
	 */
	public Optional<Collection<ValidationError>> validateApplication(ApplicationRequest applicationRequest) {
		log.info("calling validateApplication()");
		ValidationResult validationResult = validationExecutor.execute(applicationRequest);
        if (validationResult.isPassed()) {
            log.info("validation passed successfully.");
            Task task = processingHelper.createTask(TaskName.VALIDATION, TaskStatus.COMPLETED);
            task.getTaskHistory().add(processingHelper.createTaskHistory(TaskStatus.COMPLETED, "validationResult success "+applicationRequest.getApplicationId(),"OK"));
            applicationRequest.getTasks().add(task);
            return Optional.empty();
        } else {
            return handleInvalidValidationErrors(applicationRequest, validationResult);
        }
    }
	
	/**
	 * @param applicationRequest
	 * @return
	 */
	public boolean isAnyMerchantValid(ApplicationRequest applicationRequest) {
		log.info("calling isAnyMerchantValid()");
		ValidationResult validationResult =  validationExecutor.isAnyMerchantValid(applicationRequest);
		if (validationResult.isPassed()) {
            return true;
        } else {
        	log.error("No single merchant is valid in payload");
        	handleInvalidValidationErrors(applicationRequest, validationResult);
            return false;
        }
    }
	
	/**
	 * @param applicationRequest
	 * @return
	 */
	public boolean isAnyAmendmentApplicationValid(ApplicationRequest applicationRequest) {
		log.info("calling isAnyAmendmentApplicationValid()");
		ValidationResult validationResult =  validationExecutor.isAnyAmendmentApplicationValid(applicationRequest);
		if (validationResult.isPassed()) {
            return true;
        } else {
        	log.error("No any AmendmentList Application is valid in payload");
        	handleInvalidValidationErrors(applicationRequest, validationResult);
            return false;
        }
    }
	
	/**
	 * @param applicationRequest
	 * @return
	 */
	public boolean isAmendmentMerchantValid(ApplicationRequest applicationRequest) {
		log.info("calling isAmendmentMerchantValid()");
		ValidationResult validationResult =  validationExecutor.execute(applicationRequest);
		if (validationResult.isPassed()) {
            return true;
        } else {
        	log.warn("No single merchant is valid in payload");
        	handleInvalidValidationErrors(applicationRequest, validationResult);
            return false;
        }
    }


	/**
	 * @param applicationRequest
	 * @param validationResult
	 * @return
	 */
	private Optional<Collection<ValidationError>> handleInvalidValidationErrors(ApplicationRequest applicationRequest,
			ValidationResult validationResult) {
		log.info("validation errors found for this request {} : {}", applicationRequest.getApplicationId(), validationResult);
		List<ValidationError> validationErrorList = Arrays.asList(ValidationError.builder().errorCode(validationResult.getCode())
		                .errorMessage(validationResult.getMessage())
		                .fieldName("*")
		                .build());
		 
		Task task = processingHelper.createTask(TaskName.VALIDATION, TaskStatus.FAILED);
		processingHelper.assignValidationErrorTaskHistory(validationErrorList, task);
		 
		applicationRequest.getTasks().add(task);
		saveApplicatioRequest(applicationRequest);
		 
		return Optional.of(validationErrorList);
	}
	
	/**
	 * @param applicationRequest
	 */
	public void saveApplicatioRequest(ApplicationRequest applicationRequest) {
		appRequestDB.save(applicationRequest);
	}
	
}