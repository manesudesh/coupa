package ae.network.dob.adapter.mpgs.api.request;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class APIMerchant implements Serializable {

    private AcquirerLink acquirerLink;
    
    @JsonProperty(required = true)
    private APIAddress address;
    
    private String cardMaskingFormat;
    
    private String categoryCode;
    
    private String contactName;
    
    private String defaultOrderCertainty;
    
    private String email;
    
    private String governmentCountryCode;
    
    private String goodsDescription;
    
    private String webSite;
    
    private String locale;
    
    private String timeZone;
    
    private String name;
    
    private PartnerManagedRiskAssessment partnerManagedRiskAssessment;
    
    private String phone;
    
    private List<String> privilege;
    
    private Risk risk;
    
    private List<String> service;
    
    private String state;
    
    private String systemCapturedCardMaskingFormat;
    
    private TransactionFiltering transactionFiltering;
    
    private String certificateSetId;
    
    private String administrativePassword;
    
    private String tradingName;
}
