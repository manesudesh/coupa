package ae.network.dob.adapter.mpgs.integration;

import static feign.FeignException.errorStatus;

import java.nio.charset.StandardCharsets;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import ae.network.dob.adapter.mpgs.api.response.APIResponse;
import feign.FeignException;
import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;

/**
 * Wrap API error into IntegrationException
 */
@Slf4j
@Service
public class FeignExceptionErrorDecoder implements ErrorDecoder {

    @Override
    public Exception decode(String methodKey, Response response) {

        FeignException exception = errorStatus(methodKey, response);

        String responseContent;
        try {
            responseContent = new String(exception.responseBody().get().array(), StandardCharsets.UTF_8);
            log.error("error response {}", responseContent);
            APIResponse error = new ObjectMapper().readValue(responseContent, APIResponse.class);
            return new IntegrationException(exception.status(), error);
        } catch (Exception e) {
            log.error("Could not wrap API error", e);
            return exception;
        }
    }
}
