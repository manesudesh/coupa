package ae.network.dob.adapter.mpgs.model.application;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 
 * @version 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {

    @NotNull
    private AddressType addressType;
    @NotNull
    private String countryCode;
    @NotNull
    private String state;
    @NotNull
    private String city;
    @NotNull
    private String postalCode;
    @NotNull
    private String phone;
    private String pobox;
    
    private String mobile;
    private String lastName;
    private String flexiCutoffTime;
    private String flexiCutoffDay;
    private String birthName;
    private String additionalEmail;
    
    private String name;
	
    @NotNull
    private String email;
    
    @NotEmpty(message = "Address Lines is Empty")
    private List<String> addressLines;

    public String fullAddress() {
        List<String> addressParts = new ArrayList<>(addressLines);
        if (addressParts.size() < 2) {
            addressParts.add(city);
        }
        return String.join(", ", addressParts);
    }
}
