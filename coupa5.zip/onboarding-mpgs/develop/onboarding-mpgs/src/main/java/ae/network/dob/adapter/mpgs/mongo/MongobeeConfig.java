package ae.network.dob.adapter.mpgs.mongo;

import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.github.mongobee.Mongobee;
import com.mongodb.MongoClient;

import ae.network.dob.adapter.mpgs.config.APIConfig;
import lombok.Data;

/**
 * @author 
 */
@Configuration
@Data
public class MongobeeConfig {
	static APIConfig apiConfig;
    @Bean
    public Mongobee mongobee(MongoClient mongoClient, MongoTemplate mongoTemplate, MongoProperties mongoProperties, APIConfig apiConfig) {
        Mongobee mongobee = new Mongobee(mongoClient);
        mongobee.setDbName(mongoProperties.getMongoClientDatabase());
        mongobee.setMongoTemplate(mongoTemplate);
        // package to scan for migrations
        mongobee.setChangeLogsScanPackage(MongobeeConfig.class.getPackage().getName());
        mongobee.setEnabled(true);
        this.apiConfig = apiConfig;
        return mongobee;
    }
    
    public static APIConfig getAPIConfig() {
    	return apiConfig;
    }
}