package ae.network.dob.adapter.mpgs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.micrometer.core.aop.TimedAspect;
import io.micrometer.core.instrument.MeterRegistry;

@SpringBootApplication
public class MPGSAdapterApplication
{

		
    public static void main(String[] args) {
        SpringApplication.run(MPGSAdapterApplication.class, args);
    }

    /* io.micrometer.core.aop.TimedAspect
       org.springframework.context.annotation.Bean
       io.micrometer.core.instrument.MeterRegistry */
    @Bean
    public TimedAspect timedAspect(MeterRegistry registry) {
    	return new TimedAspect(registry);
    }
   
    @Bean
    protected ObjectMapper getObjectMapper() {
        ObjectMapper jsonMapper = new ObjectMapper();
        jsonMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        jsonMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
        jsonMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_USING_DEFAULT_VALUE, true);
        jsonMapper.configure(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES, true);
        return jsonMapper;
    }
}
