package ae.network.dob.adapter.mpgs.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Configuration
@Data
@ConfigurationProperties(prefix = "apifeigncache")
public class CacheProperties {
	public int expireAfterWrite;
	public int initialCapacity;

}
