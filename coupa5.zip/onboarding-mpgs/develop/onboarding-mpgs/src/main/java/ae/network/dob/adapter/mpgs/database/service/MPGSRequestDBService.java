package ae.network.dob.adapter.mpgs.database.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import ae.network.dob.adapter.mpgs.database.repository.RequestRepository;
import ae.network.dob.adapter.mpgs.model.request.ApplicationRequest;
import lombok.AllArgsConstructor;

/**
 * @author 
 */
@Service
@AllArgsConstructor
public class MPGSRequestDBService {

    /**
     * Injection of Repository object 	
     */
    private final RequestRepository repository;

    /**
     * Persist MPGSRequest document to the
     * database
     *
     * @param MPGSRequest
     * @return
     */
    public synchronized ApplicationRequest save(ApplicationRequest mpgsApplicationReq) {
        return repository.save(mpgsApplicationReq);
    }
    
    public Optional<ApplicationRequest> findByAppReqId(String appReqId) {
        return repository.findFirstByApplicationId(appReqId);
    }

}
