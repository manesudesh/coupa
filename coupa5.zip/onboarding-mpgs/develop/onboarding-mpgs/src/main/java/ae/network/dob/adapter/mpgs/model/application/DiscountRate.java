package ae.network.dob.adapter.mpgs.model.application;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * @author 
 * @version
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DiscountRate {
    private String currencyCode;
    private BigDecimal discountAmount;
    private AmountType amountType;
}
