package ae.network.dob.adapter.mpgs.model.application;

/**
 * @author 
 * @version
 */
public enum AmountType {
    ABSOLUTE_VALUE, PERCENTAGE
}
