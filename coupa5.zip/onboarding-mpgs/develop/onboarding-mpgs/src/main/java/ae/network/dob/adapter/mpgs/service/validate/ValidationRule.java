package ae.network.dob.adapter.mpgs.service.validate;

public interface ValidationRule<T> {
    ValidationResult validate(T entity);
}
