package ae.network.dob.adapter.mpgs.api.db;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class APIData {
	
	private String merchantId;
	private String merchantType;
	private SearchMerchantAPIData searchAPIData;
	private CreateUpdateAPIData createUpdateAPIData;
	private ApproveMerchantAPIData approveMerchantAPIData;
	
}
