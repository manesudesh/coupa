package ae.network.dob.adapter.mpgs.integration;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

@FeignClient
public interface APIFeignClient {
	
	@PutMapping("/{merchantId}")
	String createMerchant(@PathVariable String merchantId, String reqBody);
	
	@PutMapping("/{merchantId}")
	String approveMerchant(@PathVariable String merchantId, String reqBody);
	
	@GetMapping("/{merchantId}")
	String searchMerchant(@PathVariable String merchantId);
}
