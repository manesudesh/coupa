package ae.network.dob.adapter.mpgs.model.reply;

import ae.network.dob.adapter.mpgs.model.task.AdditionalData;
import ae.network.dob.adapter.mpgs.model.task.BackendSystem;
import ae.network.dob.adapter.mpgs.rabbitmq.message.QueueMessage;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ApplicationUpdate implements QueueMessage {
    private String applicationId;
    private BackendSystem backendSystem;
    private ProcessingResult processingResult;
    private AdditionalData additionalData;
}
