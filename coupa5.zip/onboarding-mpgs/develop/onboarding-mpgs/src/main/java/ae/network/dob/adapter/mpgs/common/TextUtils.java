package ae.network.dob.adapter.mpgs.common;

import java.text.DecimalFormat;

/**
 * @author
 * @since
 */
public class TextUtils {

    public static String truncate(String str, int maxLen) {
        if (str == null) {
            return null;
        }
        int maxLength = Math.min(str.length(), maxLen);
        return str.substring(0, maxLength).trim();
    }

    public static String toAlphaNumeric(String str) {
        if (str == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (char c : str.toCharArray()) {
            if (Character.isDigit(c) || Character.isLetter(c) || Character.isSpaceChar(c)) {
                sb.append(c);
            }
        }
        return sb.toString().trim();
    }


    public static String formatMcc(Integer mcc) {
        if (mcc == null) return null;
        return new DecimalFormat("0000").format(mcc);
    }
}
