package ae.network.dob.adapter.mpgs.model.application;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UnknownService extends MerchantService {
}
