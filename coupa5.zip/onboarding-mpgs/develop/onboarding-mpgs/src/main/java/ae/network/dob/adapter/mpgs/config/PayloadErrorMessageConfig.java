package ae.network.dob.adapter.mpgs.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import ae.network.dob.adapter.mpgs.model.errors.AdapterError;
import lombok.Data;

@Component
@Data
@EnableConfigurationProperties



@ConfigurationProperties(prefix = "errormessages")
public class PayloadErrorMessageConfig {

    private List<AdapterError> messages = new ArrayList<AdapterError>();

}
