package ae.network.dob.adapter.mpgs.model.request;

public enum Acquirer {
    NI, TYME
}
