package ae.network.dob.adapter.mpgs.mongo;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;

import ae.network.dob.adapter.mpgs.config.APIConfig;
import ae.network.dob.adapter.mpgs.config.APIConfig.ServiceConfig;
import ae.network.dob.adapter.mpgs.database.MPGSConfigDBEntity;

/**
 * Creating mongodb initial data
 *
 * @author 
 * @since 
 */
@Configuration
@ChangeLog(order = "001")
public class MongoInitialSetup {

	@Autowired 
	APIConfig apiConfig;
	
	@Autowired 
	Environment env;
	
    @ChangeSet(order = "01", author = "MPGS-Config", id = "01-addInitialMPGSConfig")
    public void createDefaultAdminUser(MongoTemplate mongoTemplate) {
    	apiConfig = MongobeeConfig.getAPIConfig();
    	Set<Entry<String, Map<String, ServiceConfig>>> configSet = apiConfig.getApiConfig().entrySet();
    	
    	configSet.forEach(conf -> prepareMPGSConfig(conf, mongoTemplate) );
    }
    
    /*structure of properties as 
     * 
     * MPGS:
     *    NI: //acquirer either NI or TYME
     *  	MerchantType:   //ECOM or POS
     *  		MSOID:      //config
     *  		ADMINPWD:   //config
     *  		CERT_ID:    //config
     *   
     */
    private void prepareMPGSConfig(Entry<String, Map<String, ServiceConfig>> entry, MongoTemplate mongoTemplate)
    {
    	String acquirer = entry.getKey();
    	Map<String, ServiceConfig> map = entry.getValue();
    	map.entrySet().forEach(e->mongoTemplate.save(createMPGSConfig(acquirer, e.getKey(), e.getValue() )));
    }

    /*
     *  	MerchantType:  either POS or ECOM
     *  		MSOID:     serviceConfig
     *  		ADMINPWD:  serviceConfig
     *  		CERT_ID:   serviceConfig
     *   
     */
    private MPGSConfigDBEntity createMPGSConfig(String acquirer, String merchantType, ServiceConfig serviceConfig) {
        return MPGSConfigDBEntity.builder()
        		.acquirer(acquirer)
        		.merchantType(merchantType)
        		.msoId(serviceConfig.getMsoId())
        		.acquirerId(serviceConfig.getAcquirerId())
        		.acquirerLinkId(serviceConfig.getAcquirerLinkId())
        		.adminPasswordJASYPTENC(serviceConfig.getAdministrativePassword())
        		.apiBasicAuthNameJASYPTENC(serviceConfig.getUserName())
        		.apiPasswordJASYPTENC(serviceConfig.getUserPass())
        		.certIdJASYPTENC(serviceConfig.getCertificateSetId())
        		.build();
    }
    
    
}