package ae.network.dob.adapter.mpgs.model.request;

import java.util.Collection;

import ae.network.dob.adapter.mpgs.model.task.TaskHistory;
import ae.network.dob.adapter.mpgs.model.task.TaskStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Task {
    private Long id;
    private String name;
    private String entityId;
    private TaskStatus taskStatus;
    private Collection<TaskHistory> taskHistory;
}
