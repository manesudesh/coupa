package ae.network.dob.adapter.mpgs.model.request;

public enum RequestType {
    ONBOARDING, AMENDMENT, MERCHANT_CLOSURE
}
