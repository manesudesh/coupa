package ae.network.dob.adapter.mpgs.common;

/**
 * @author
 * @since 
 */
public interface DateFormat {
    String FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
}
