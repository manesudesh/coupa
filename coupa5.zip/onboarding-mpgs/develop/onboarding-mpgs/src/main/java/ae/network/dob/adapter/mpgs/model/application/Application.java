package ae.network.dob.adapter.mpgs.model.application;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 
 * @version
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Application {

    private Chain chain;

    @NotNull(message = "merchant List can not be null")
    @NotEmpty(message = "merchant List can not be Empty")
    @Valid
    private List<Merchant> merchants;

    // local usage
    private String subId;
}
