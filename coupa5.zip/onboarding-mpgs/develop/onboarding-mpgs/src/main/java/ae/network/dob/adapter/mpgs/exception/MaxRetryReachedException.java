package ae.network.dob.adapter.mpgs.exception;

/**
 * @author 
 * @since 
 */
public class MaxRetryReachedException extends MessageRejectionException {
    public MaxRetryReachedException(String applicationId) {
        super(applicationId, "Maximum retries reached");
    }
}
