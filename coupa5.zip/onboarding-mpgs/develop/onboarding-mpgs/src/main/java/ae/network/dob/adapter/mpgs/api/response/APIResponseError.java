package ae.network.dob.adapter.mpgs.api.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class APIResponseError implements Serializable{

	
		 private String cause;

		 private String explanation;
		 
		 private String field;
		 
		 private String validationType;
}
