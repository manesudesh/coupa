package ae.network.dob.adapter.mpgs.model.application;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

/**
 * @author 
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MPGSService extends MerchantService{
/*
    @JsonProperty("serviceType")
    protected String serviceType;
    */
}
