package ae.network.dob.adapter.mpgs.integration;

import feign.RequestTemplate;
import feign.auth.BasicAuthRequestInterceptor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FeignRequestInterceptor extends BasicAuthRequestInterceptor {
	String username;
	String password;
	
    public FeignRequestInterceptor(String username, String password) {
		super(username, password);
		this.username = username;
		this.password = password;
    }



	private static final String CONFIG_CONTENT_TYPE = "application/json";



       @Override
    public void apply(RequestTemplate template) {
        super.apply(template);
        String contentType = "Content-Type";
        template.removeHeader(contentType);
        template.header(contentType, CONFIG_CONTENT_TYPE);
    }


}
