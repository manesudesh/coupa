package ae.network.dob.adapter.mpgs.database.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import ae.network.dob.adapter.mpgs.model.request.ApplicationRequest;

/**
 * @author 
 * @version
 */
public interface RequestRepository extends MongoRepository<ApplicationRequest, String> {

    /**
     * fond the application request by its application Id
     *
     * @param applicationId
     * @return ApplicationRequest
     */
    Optional<ApplicationRequest> findFirstByApplicationId(String applicationId);

}
