package ae.network.dob.adapter.mpgs.model.application;

import static ae.network.dob.adapter.mpgs.common.TextUtils.toAlphaNumeric;
import static ae.network.dob.adapter.mpgs.common.TextUtils.truncate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.ToString;

/**
 * @author 
 * @since 
 */
@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantUser {
    private String email;
    private String firstName;
    private String lastName;
    private String mobile;

    public String getTrimFirstName() {
        return truncate(toAlphaNumeric(firstName), 24);
    }

    public String getTrimLastName() {
        return truncate(toAlphaNumeric(lastName), 24);
    }
}
