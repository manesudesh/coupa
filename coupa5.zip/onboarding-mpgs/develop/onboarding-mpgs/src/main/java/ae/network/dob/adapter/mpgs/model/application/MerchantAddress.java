package ae.network.dob.adapter.mpgs.model.application;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 
 * @version 
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MerchantAddress {
    private String email;
    private String phone;
    private boolean useOneDefaultAddress;

}
