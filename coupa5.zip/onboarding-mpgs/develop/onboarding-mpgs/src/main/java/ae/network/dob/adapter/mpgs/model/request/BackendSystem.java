package ae.network.dob.adapter.mpgs.model.request;

import ae.network.dob.adapter.mpgs.rabbitmq.config.RabbitQueue;

public enum BackendSystem {
    MPGS(RabbitQueue.MPGS);

    private final RabbitQueue rabbitQueue;

    BackendSystem(RabbitQueue rabbitQueue) {
        this.rabbitQueue = rabbitQueue;
    }

    public RabbitQueue getRabbitQueue() {
        return rabbitQueue;
    }
}
