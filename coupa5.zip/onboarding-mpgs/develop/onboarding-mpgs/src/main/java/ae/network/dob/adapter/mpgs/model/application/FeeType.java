package ae.network.dob.adapter.mpgs.model.application;

public enum FeeType {
    MIS,
    ACQ_MMBR_FEE, // MEMBERSHIP FEE
    ACQ_RBT_FEE,
    MFEE_STRT, // STARTUP FEE
    MFEE_FRD_HND, // Fraud
    FRAUD_HAND_FEE, // Fraud Tyme
    TRANS_FEE, // for NI
    REFUND_FEE, // for NI
    STARTUP_FEE,
    MERCH_ALLOW_REFUND,
    FEE_MIN_COMM,
    CHARGEBACK_FEE,
    INT_CBK_FEE,
    INT_FRD_FEE,
    INT_RFND_FEE
}
