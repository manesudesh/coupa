package ae.network.dob.adapter.mpgs.service.validate;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ae.network.dob.adapter.mpgs.config.PayloadErrorMessageConfig;
import ae.network.dob.adapter.mpgs.database.repository.RequestRepository;
import ae.network.dob.adapter.mpgs.model.application.Merchant;
import ae.network.dob.adapter.mpgs.model.errors.AdapterError;
import ae.network.dob.adapter.mpgs.model.errors.ErrorName;
import ae.network.dob.adapter.mpgs.model.request.Acquirer;
import ae.network.dob.adapter.mpgs.model.request.ApplicationRequest;
import ae.network.dob.adapter.mpgs.service.utils.ProcessingHelper;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BoardingValidationRule implements ValidationRule<ApplicationRequest> {

    @Autowired private PayloadErrorMessageConfig errorMessageConfig;

    @Autowired private RequestRepository requestRepository;
    @Autowired private ProcessingHelper processingHelper;
    
    @Override
    public ValidationResult validate(ApplicationRequest entity) {

        AdapterError error;

        // check if the application ID is duplicate or not
        if (isApplicationIdExist(entity.getApplicationId())) {
            log.info("ApplicationId {} is already Exist.", entity.getApplicationId());
            error = getError(ErrorName.APPLICATION_EXIST);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }
        
        // check if the Acquirer ID is present or not
        Acquirer acquirer = entity.getAcquirer();
        if (! isAcquirerIdExist(acquirer)) {
            log.info("Acquirer {} is not supported for applicationId {}", acquirer, entity.getApplicationId());
            error = getError(ErrorName.ACQUIRER_INVALID);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }
        
        List<Merchant> invalidBusinessLineList = processingHelper.getInvalidBusinessLineMerchants(entity);
        if (! invalidBusinessLineList.isEmpty()) {
            error = getError(ErrorName.MERCHANT_INVALID_BUSINESSLINE);
            String invalidMerchantId = invalidBusinessLineList.stream()
            		.map(m -> m.getMerchantId() )
            		.collect(Collectors.joining(" , ", "[", "]"));
            String errorMessage = error.getMessage()+" " + invalidMerchantId;
            log.info("BuisnessLine not found for applicationId {} merchants {}", entity.getApplicationId(), invalidMerchantId);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(errorMessage).build();
        }
        /*
        List<Merchant> validMerchantList = processingHelper.getValidMerchants(entity);
        if (validMerchantList.isEmpty()) {
            log.info("All Merchants are Invalid for applicationId {}",  entity.getApplicationId());
            error = getError(ErrorName.ALL_MERCHANTS_INVALID);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }
        */

        log.info("performing annotation validation");
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<Object>> violations = validator.validate(entity);
        if (!violations.isEmpty()) {

            log.info("annotation violations size = {}", violations.size());

            List<String> basicValidationErrors = violations.stream()
                    .map(constraintViolation -> String.format("%s : %s", constraintViolation.getPropertyPath(),
                            constraintViolation.getMessage()))
                    .collect(Collectors.toList());

            String basicErrors = basicValidationErrors.stream().collect(Collectors.joining(","));

            log.error("annotation basic errors: {}", basicErrors);

            return ValidationResult.builder().passed(false).code("001").message(basicErrors).build();
        }
        return ValidationResult.builder().passed(true).code("000").build();
    }

    private AdapterError getError(ErrorName error) {
        return errorMessageConfig.getMessages().stream()
                .filter(err -> err.getName().equals(error.name())).findFirst().get();
    }

    protected boolean isApplicationIdExist(String applicationId) {
        return requestRepository.findFirstByApplicationId(applicationId).isPresent();
    }
    
    protected boolean isAcquirerIdExist(Acquirer acquirer) {
    	return Arrays.asList(Acquirer.values()).contains(acquirer) ? true : false;
    }
    
    protected ValidationResult isAnyMerchantValid(ApplicationRequest entity) {
    	AdapterError error;
    	List<Merchant> validMerchantList = processingHelper.getValidMerchants(entity);
        if (validMerchantList.isEmpty()) {
            log.info("All Merchants are Invalid for applicationId {}",  entity.getApplicationId());
            error = getError(ErrorName.ALL_MERCHANTS_INVALID);
            return ValidationResult.builder().passed(false).code(error.getCode()).message(error.getMessage()).build();
        }
        return ValidationResult.builder().passed(true).code("000").build();
    }
}
