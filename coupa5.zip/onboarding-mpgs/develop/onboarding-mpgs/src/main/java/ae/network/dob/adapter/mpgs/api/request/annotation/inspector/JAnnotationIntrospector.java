package ae.network.dob.adapter.mpgs.api.request.annotation.inspector;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.PropertyName;
import com.fasterxml.jackson.databind.introspect.Annotated;
import com.fasterxml.jackson.databind.introspect.AnnotatedField;
import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;

import ae.network.dob.adapter.mpgs.config.APIConfig.ServiceConfig;

@Component
public class JAnnotationIntrospector extends JacksonAnnotationIntrospector {

	ServiceConfig serviceConfig ;
	String ackReg_fieldName = "acqLinkRegion";   // variable name AcquirerLink
	String mastercard3ds1Authentication_fieldName = "mastercard_3ds1Auth";   // variable name in class MasterCardSecureCode.java class
	String visa3ds1Authentication_fieldName = "visa_3ds1Auth";   // variable name in class VerifiedByVisa.java class
	
	String regionId;  
	public JAnnotationIntrospector(ServiceConfig serviceConfig){
		this.serviceConfig = serviceConfig;
		regionId = serviceConfig.getAcquirerLinkId();
	}
    
    @Override
    public PropertyName findNameForSerialization(Annotated a) {
        if (a instanceof AnnotatedField) {
            String name = a.getName();
            if (name.equals(ackReg_fieldName)) {
                return PropertyName.construct(name.replace(ackReg_fieldName, regionId)); //"NETWORK2_S2I01"
            }
            else if (name.equals(mastercard3ds1Authentication_fieldName)) {
                return PropertyName.construct(name.replace(mastercard3ds1Authentication_fieldName, "3DS1"));
            }
            else if (name.equals(visa3ds1Authentication_fieldName)) {
                return PropertyName.construct(name.replace(visa3ds1Authentication_fieldName, "3DS1"));
            }
        }
        return super.findNameForSerialization(a);
    }

    @Override
    public PropertyName findNameForDeserialization(Annotated a) {
        if (a instanceof AnnotatedField) {
            String name = a.getName();
            if (name.equals(ackReg_fieldName)) {
                return PropertyName.construct(name.replace(ackReg_fieldName, regionId)); //"NETWORK2_S2I01"
            }
            else if (name.equals(mastercard3ds1Authentication_fieldName)) {
                return PropertyName.construct(name.replace(mastercard3ds1Authentication_fieldName, "3DS1"));
            }
            else if (name.equals(visa3ds1Authentication_fieldName)) {
                return PropertyName.construct(name.replace(visa3ds1Authentication_fieldName, "3DS1"));
            }
        }
        return super.findNameForDeserialization(a);
    }

}
