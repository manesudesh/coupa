package ae.network.dob.adapter.mpgs.service.validate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ae.network.dob.adapter.mpgs.model.request.ApplicationRequest;
import ae.network.dob.adapter.mpgs.model.request.RequestType;

@Service
public class ValidationExecutor {

    @Autowired
    private BoardingValidationRule validationRule;

    @Autowired
    private AmendmentValidationRule amendmentValidationRule;

    public ValidationResult execute(ApplicationRequest request) {
        if (request.getRequestType() == RequestType.ONBOARDING) {
            return validationRule.validate(request);
        } else if (request.getRequestType() == RequestType.AMENDMENT) {
            return amendmentValidationRule.validate(request);
        }
        return ValidationResult.builder().passed(true).code("000").build();
    }
    
    public ValidationResult isAnyMerchantValid(ApplicationRequest request) {
    	return validationRule.isAnyMerchantValid(request);
    }
    
    public ValidationResult isAnyAmendmentApplicationValid(ApplicationRequest request) {
    	return amendmentValidationRule.isAnyAmendmentApplicationValid(request);
    }
}
