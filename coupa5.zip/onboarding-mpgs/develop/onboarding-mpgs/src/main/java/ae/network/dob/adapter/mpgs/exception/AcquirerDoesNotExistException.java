package ae.network.dob.adapter.mpgs.exception;

public class AcquirerDoesNotExistException extends MessageRejectionException {

    public AcquirerDoesNotExistException(String acquirerName) {
        super(acquirerName, "Acquirer :".concat(acquirerName).concat(" Dose Not Exist in MPGS Adapter configurations"));
    }

    public static class CSVHeaderDoesNotMatchProvidedDataException extends MessageRejectionException {

        public CSVHeaderDoesNotMatchProvidedDataException(String applicationId, String message) {
            super(applicationId, message);
        }

        public CSVHeaderDoesNotMatchProvidedDataException(String applicationId, String message, Throwable cause) {
            super(applicationId, message, cause);
        }
    }
}
