package ae.network.dob.adapter.mpgs.database.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import ae.network.dob.adapter.mpgs.database.MPGSConfigDBEntity;

/**
 * @author 
 * @version
 */
public interface MPGSConfigRepository extends MongoRepository<MPGSConfigDBEntity, String> {

    /**
     * the application request by its application Id
     *
     * @param applicationId
     * @return ApplicationRequest
     */
    Optional<MPGSConfigDBEntity> findFirstByMerchantType(String merchantType);
    
    Optional<MPGSConfigDBEntity> findFirstByAcquirerAndMerchantType(String acquirer, String merchantType);

}
