package ae.network.dob.adapter.mpgs.model.amendment;

import java.util.stream.Stream;

public enum AmendmentType {
    MERCHANT_NAME,
    LEGAL_NAME,
    MCC,
    ADDRESS,
    COUNTRY_ORIGIN;
    
    public static boolean isAmendmentType(String amendStr) {
        return Stream.of(AmendmentType.values()).anyMatch(a -> a.toString().equals(amendStr)); 
    }
}
