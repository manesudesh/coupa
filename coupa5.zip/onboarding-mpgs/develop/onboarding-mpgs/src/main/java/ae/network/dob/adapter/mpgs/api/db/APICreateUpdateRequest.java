package ae.network.dob.adapter.mpgs.api.db;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import ae.network.dob.adapter.mpgs.api.request.APIMerchant;
import ae.network.dob.adapter.mpgs.api.request.APIRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString(includeFieldNames = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class APICreateUpdateRequest extends APIRequest implements Serializable {
    
    @JsonProperty(required = true)
    private APIMerchant merchant;
}
