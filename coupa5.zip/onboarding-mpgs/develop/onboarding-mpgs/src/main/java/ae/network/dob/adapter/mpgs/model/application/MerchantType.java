package ae.network.dob.adapter.mpgs.model.application;

/**
 * @author 
 * @version 
 */
public enum MerchantType {
    POS, ECOM
}
