package ae.network.dob.adapter.mpgs.model.application;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 
 * @version 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Terminal {

    private String terminalId;
    private String terminalType; // PC or ?
    private String maker;
    private String terminalModel;
    private boolean dccEnabled;

    @JsonIgnore
    private String merchantId;
    @JsonIgnore
    private String merchantCurrency;
    @JsonIgnore
    private ActionType actionType;

}
