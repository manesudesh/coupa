package ae.network.dob.adapter.mpgs.model.application;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 
 * @version 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Chain {

    @NotNull
    private String chainId;
    
    private String chainName;

    private String groupCode;
    
    private String chainLevelReportRequired;
    
    private String groupLevelReportingRequired;
	
    private boolean alreadyExist;
    
    private String organizationName;
}
