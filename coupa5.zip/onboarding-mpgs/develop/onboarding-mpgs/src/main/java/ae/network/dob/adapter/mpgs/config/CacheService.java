package ae.network.dob.adapter.mpgs.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import ae.network.dob.adapter.mpgs.integration.APIFeignClient;
import ae.network.dob.adapter.mpgs.integration.FeignExceptionErrorDecoder;
import ae.network.dob.adapter.mpgs.integration.FeignRequestInterceptor;
import ae.network.dob.adapter.mpgs.model.dto.MpgsApiClientKey;
import feign.Contract;
import feign.Feign;
import feign.Logger.Level;
import feign.codec.Encoder;
import feign.slf4j.Slf4jLogger;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CacheService {

	@Cacheable(value = "APIFeignCache")
	public APIFeignClient buildFeignClient(MpgsApiClientKey feignKey) {
		log.info("building Api Feign client");
		APIFeignClient apiClient = Feign.builder().contract(feignContract).encoder(feignEncoder)
				.logger(feignLogger).logLevel(Level.FULL)
				.requestInterceptor(new FeignRequestInterceptor(feignKey.getUserName(), feignKey.getPassword()))
				.errorDecoder(feignExceptionErrorDecoder).target(APIFeignClient.class, feignKey.getUrl());
		return apiClient;
	}
	
	
	@Autowired Contract feignContract;
	@Autowired Encoder feignEncoder;
	@Autowired Slf4jLogger feignLogger;
	@Autowired FeignExceptionErrorDecoder feignExceptionErrorDecoder;
}
