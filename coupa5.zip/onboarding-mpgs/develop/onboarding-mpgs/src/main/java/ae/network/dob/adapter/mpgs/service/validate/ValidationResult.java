package ae.network.dob.adapter.mpgs.service.validate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

/**
 * @author : 
 * @version :
 */
@Data
@AllArgsConstructor
@Builder
@ToString(includeFieldNames = false)
public class ValidationResult {
    private boolean passed;
    private String code;
    private String message;
}
