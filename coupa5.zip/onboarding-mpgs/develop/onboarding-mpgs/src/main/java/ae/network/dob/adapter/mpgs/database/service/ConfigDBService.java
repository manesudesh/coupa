package ae.network.dob.adapter.mpgs.database.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import ae.network.dob.adapter.mpgs.database.MPGSConfigDBEntity;
import ae.network.dob.adapter.mpgs.database.repository.MPGSConfigRepository;
import lombok.AllArgsConstructor;

/**
 * @author 
 */

@Service
@AllArgsConstructor
public class ConfigDBService {

    /**
     * Injection of MPGSConfig Repository
     */
    private MPGSConfigRepository mpgsConfigRepository;

    /**
     * Finds an mpgsconfig by
     * merchantType
     *
     * @param merchantType
     * @return
     */
    public MPGSConfigDBEntity findFirstByMerchantType(String merchantType) {
    	Optional<MPGSConfigDBEntity> mpgsConfig = mpgsConfigRepository.findFirstByMerchantType(merchantType);
         return	mpgsConfig.isPresent() ? mpgsConfig.get() : null;
    }
    /**
     * Finds an mpgsconfig by
     * an acquirerName and merchantType
     *
     * @param acquirer and merchantType
     * @return
     */
    public MPGSConfigDBEntity findFirstByAcquirerAndMerchantType(String acquirer, String merchantType) {
    	Optional<MPGSConfigDBEntity> mpgsConfig = mpgsConfigRepository.findFirstByAcquirerAndMerchantType(acquirer, merchantType);
         return	mpgsConfig.isPresent() ? mpgsConfig.get() : null;
    }

}
