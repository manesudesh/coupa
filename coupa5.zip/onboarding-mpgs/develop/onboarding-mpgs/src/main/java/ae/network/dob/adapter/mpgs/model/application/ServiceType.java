package ae.network.dob.adapter.mpgs.model.application;

/**
 * @author 
 * @version 
 */

public enum ServiceType {
	MPGS("MPGS"),
    DCC("DCC"),
    RENTAL("RENTAL"),
    MC_3D_SECURE("MC_3D_SECURE"),
    QRPAY("QRPAY"),
    PSP("PSP"),
    MCP("MCP");

    private final String value;

    ServiceType(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }
}
