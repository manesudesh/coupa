package ae.network.dob.adapter.mpgs.model.application;

/**
 * @author 
 * @version
 */

public enum AddressType {
    DEFAULT, STMT_ADDR, PAYM_ADDR, CORRESPONDING, TRADING
}
