package ae.network.dob.adapter.mpgs.exception;

/**
 * @author 
 * @since 
 */
public class MessageCancelledException extends MessageRejectionException {
    public MessageCancelledException(String applicationId) {
        super(applicationId, "No processing required");
    }
}
