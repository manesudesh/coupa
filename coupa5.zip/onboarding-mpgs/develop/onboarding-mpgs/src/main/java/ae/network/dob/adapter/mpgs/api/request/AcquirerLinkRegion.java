package ae.network.dob.adapter.mpgs.api.request;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AcquirerLinkRegion implements Serializable{
	
    private boolean accountUpdaterEnabled;
    private String acquirerId;
    private List<String> allowableTransactionFrequency;
    private List<String> allowableTransactionSource;
    private AcquirerAuthentication authentication;
    private String bankMerchantId;
    private List<String> cardType;
    private List<String> currency;
    private String defaultTransactionFrequency;
    private String defaultTransactionSource;
    @JsonInclude(Include.NON_NULL)
    private List<String> enforceCscOnTransactionSource;
    private String paymentType;
    private String status;
    private List<String> terminalId;
   
}
