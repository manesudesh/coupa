package ae.network.dob.adapter.mpgs.model.errors;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author : 
 * @version :
 */

@Data
@Builder
@ToString(includeFieldNames = true)
@AllArgsConstructor
@NoArgsConstructor
public class AdapterError {

    private String name;
    private String code;
    private String message;
}
