package ae.network.onboarding.admin.repository;

import ae.network.onboarding.admin.models.ReviewRequest;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface ReviewRequestRepository extends MongoRepository<ReviewRequest, String> {

    List<ReviewRequest> findByRequestId(String requestId);
    Optional<ReviewRequest> findFirstByRequestId(String requestId);

    List<ReviewRequest> findByMaker(String maker);
    Optional<ReviewRequest> findFirstByMaker(String maker);

    List<ReviewRequest> findByRequestType(String requestType);
    Optional<ReviewRequest> findFirstByRequestType(String requestType);

    List<ReviewRequest> findByStatus(String status);
    Optional<ReviewRequest> findFirstByStatus(String status);
}
