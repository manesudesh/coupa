package ae.network.onboarding.admin.dto;

import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Builder
@Getter
public class ApiError {

    private String status;
    private String message;
    private List<ErrorObject> errors;
}
