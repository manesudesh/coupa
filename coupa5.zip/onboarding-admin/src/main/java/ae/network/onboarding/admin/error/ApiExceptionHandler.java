package ae.network.onboarding.admin.error;

import ae.network.onboarding.admin.dto.ApiError;
import ae.network.onboarding.admin.dto.ErrorObject;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@ControllerAdvice
public class ApiExceptionHandler extends ResponseEntityExceptionHandler {
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException exception,
            HttpHeaders headers, HttpStatus status, WebRequest request) {

        List<ErrorObject> errors = new ArrayList<>();

        exception.getBindingResult().getFieldErrors().forEach(error -> {
            errors.add(new ErrorObject(error.getField(), error.getDefaultMessage()));
        });

        exception.getBindingResult().getGlobalErrors().forEach(error -> {
            errors.add(new ErrorObject(error.getObjectName(), error.getDefaultMessage()));
        });

        ApiError apiError = ApiError.builder()
                .status("ERROR")
                .message((exception.getLocalizedMessage()))
                .errors(errors)
                .build();
        return handleExceptionInternal(exception, apiError, headers, HttpStatus.BAD_REQUEST, request);
    }

    @Override
    protected ResponseEntity<Object> handleMissingServletRequestParameter(
            MissingServletRequestParameterException exceptions,
            HttpHeaders headers, HttpStatus status, WebRequest request) {

        List<ErrorObject> errors = new ArrayList<>();
        errors.add(new ErrorObject(exceptions.getParameterName(), "parameter is missing"));

        ApiError apiError = ApiError.builder()
                .status("ERROR")
                .message((exceptions.getLocalizedMessage()))
                .errors(errors)
                .build();

        return handleExceptionInternal(exceptions, apiError, headers, HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler({MethodArgumentTypeMismatchException.class})
    public ResponseEntity<Object> handleMethodArgumentTypeMismatch(
            MethodArgumentTypeMismatchException exceptions, WebRequest request) {

        List<ErrorObject> errors = new ArrayList<>();
        errors.add(new ErrorObject(exceptions.getName(), "should be of type " + Objects.requireNonNull(exceptions.getRequiredType()).getName()));

        ApiError apiError = ApiError.builder()
                .status("ERROR")
                .message((exceptions.getLocalizedMessage()))
                .errors(errors)
                .build();

        return handleExceptionInternal(exceptions, apiError, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
    }

    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(
            HttpRequestMethodNotSupportedException exceptions,
            HttpHeaders headers, HttpStatus status, WebRequest request) {

        String message = exceptions.getMethod() +
                " method is not supported. Supported methods are: " +
                Objects.requireNonNull(exceptions.getSupportedHttpMethods()).stream().map(Object::toString).collect(Collectors.joining(","));

        List<ErrorObject> errors = new ArrayList<>();
        errors.add(new ErrorObject("methodError", message));

        ApiError apiError = ApiError.builder()
                .status("ERROR")
                .message((exceptions.getLocalizedMessage()))
                .errors(errors)
                .build();
        return handleExceptionInternal(exceptions, apiError, new HttpHeaders(), HttpStatus.METHOD_NOT_ALLOWED, request);
    }

    @Override
    protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(
            HttpMediaTypeNotSupportedException exceptions,
            HttpHeaders headers, HttpStatus status, WebRequest request) {

        String message = exceptions.getContentType() +
                " media type is not supported. Supported media types are: " +
                exceptions.getSupportedMediaTypes().stream().map(Object::toString).collect(Collectors.joining(","));

        List<ErrorObject> errors = new ArrayList<>();
        errors.add(new ErrorObject("mediaTypeError", message));

        ApiError apiError = ApiError.builder()
                .status("ERROR")
                .message((exceptions.getLocalizedMessage()))
                .errors(errors)
                .build();
        return handleExceptionInternal(exceptions, apiError, new HttpHeaders(), HttpStatus.UNSUPPORTED_MEDIA_TYPE, request);
    }

    @ExceptionHandler({Exception.class})
    public ResponseEntity<Object> handleAll(Exception exceptions, WebRequest request) {
        ResponseStatusException responseStatusException = exceptions instanceof ResponseStatusException ?
                ((ResponseStatusException) exceptions) : null;

        String message = Objects.nonNull(responseStatusException) ? responseStatusException.getReason() : exceptions.getLocalizedMessage();
        HttpStatus httpStatus = Objects.nonNull(responseStatusException) ? responseStatusException.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR;

        List<ErrorObject> errors = new ArrayList<>();
        errors.add(new ErrorObject(httpStatus.toString(), message));

        ApiError apiError = ApiError.builder()
                .status("ERROR")
                .message(message)
                .errors(errors)
                .build();

        return handleExceptionInternal(exceptions, apiError, new HttpHeaders(), httpStatus, request);
    }
}
