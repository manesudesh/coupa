package ae.network.onboarding.admin.services;

import ae.network.onboarding.admin.dto.LoginRequest;
import ae.network.onboarding.admin.dto.LoginResponse;
import ae.network.onboarding.admin.dto.UserDto;

public interface UserAuthService {

    public String getAccessToken();

    public LoginResponse login(LoginRequest loginRequest);

    public void enableUser(String username);

    public void disableUser(String username);

    public void createUser(UserDto user);

}
