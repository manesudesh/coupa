package ae.network.onboarding.admin.services;

import ae.network.onboarding.admin.dto.ReviewResponseDto;
import ae.network.onboarding.admin.models.ReviewRequest;

import java.util.List;

public interface ReviewRequestService {

    public ReviewResponseDto createRequest(ReviewRequest reviewRequest);

    public ReviewResponseDto approveRequest(ReviewRequest reviewRequest);

    public ReviewResponseDto rejectRequest(ReviewRequest reviewRequest);

    public ReviewResponseDto updateRequest(ReviewRequest reviewRequest);

    public List<ReviewRequest> getPendingRequests();

    public List<ReviewRequest> getApprovedRequests();

    public List<ReviewRequest> getRejectedRequests();

    public List<ReviewRequest> getOnboardingRequests();

    public List<ReviewRequest> getAmendmentRequests();

    public List<ReviewRequest> getMerchantClosureRequests();

    public List<ReviewRequest> getTerminalClosureRequests();

    ReviewRequest getReviewRequestById(String requestId) throws IllegalArgumentException;
}
