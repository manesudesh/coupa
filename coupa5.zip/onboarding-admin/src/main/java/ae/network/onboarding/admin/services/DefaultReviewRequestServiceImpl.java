package ae.network.onboarding.admin.services;

import ae.network.onboarding.admin.converters.ReviewRequestConverter;
import ae.network.onboarding.admin.dto.ReviewResponseDto;
import ae.network.onboarding.admin.models.RequestType;
import ae.network.onboarding.admin.models.ReviewRequest;
import ae.network.onboarding.admin.models.Status;
import ae.network.onboarding.admin.repository.ReviewRequestRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Date;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DefaultReviewRequestServiceImpl implements ReviewRequestService {

    private final ReviewRequestRepository reviewRequestRepository;
    private final ReviewRequestConverter reviewRequestConverter;

    @Override
    public ReviewResponseDto createRequest(ReviewRequest reviewRequest) {
        reviewRequest.setCreated(new Date());
        reviewRequest.setStatus(Status.UNDER_REVIEW);
        ReviewRequest request = reviewRequestRepository.save(reviewRequest);
        return reviewRequestConverter.toResponseDtoOnWrite(request);
    }

    @Override
    public ReviewResponseDto approveRequest(ReviewRequest reviewRequest) {
        reviewRequest.setStatus(Status.APPROVED);
        return updateRequest(reviewRequest);
    }

    @Override
    public ReviewResponseDto rejectRequest(ReviewRequest reviewRequest) {
        reviewRequest.setStatus(Status.REJECTED);
        return updateRequest(reviewRequest);
    }

    @Override
    public ReviewResponseDto updateRequest(ReviewRequest reviewRequest) {
        reviewRequest.setLastUpdated(new Date());
        ReviewRequest request = reviewRequestRepository.save(reviewRequest);
        return reviewRequestConverter.toResponseDtoOnWrite(request);
    }

    @Override
    public List<ReviewRequest> getPendingRequests() {
        return reviewRequestRepository.findByStatus(Status.UNDER_REVIEW.name());
    }

    @Override
    public List<ReviewRequest> getApprovedRequests() {
        return reviewRequestRepository.findByStatus(Status.APPROVED.name());
    }

    @Override
    public List<ReviewRequest> getRejectedRequests() {
        return reviewRequestRepository.findByStatus(Status.REJECTED.name());
    }

    @Override
    public List<ReviewRequest> getOnboardingRequests() {
        return reviewRequestRepository.findByStatus(RequestType.ONBOARDING.name());
    }

    @Override
    public List<ReviewRequest> getAmendmentRequests() {
        return reviewRequestRepository.findByStatus(RequestType.AMENDMENT.name());
    }

    @Override
    public List<ReviewRequest> getMerchantClosureRequests() {
        return reviewRequestRepository.findByStatus(RequestType.MERCHANT_CLOSURE.name());
    }

    @Override
    public List<ReviewRequest> getTerminalClosureRequests() {
        return reviewRequestRepository.findByStatus(RequestType.TERMINAL_CLOSURE.name());
    }

    @Override
    public ReviewRequest getReviewRequestById(String requestId) throws IllegalArgumentException {
        return reviewRequestRepository.findFirstByRequestId(requestId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "invalid request id"));
    }
}
