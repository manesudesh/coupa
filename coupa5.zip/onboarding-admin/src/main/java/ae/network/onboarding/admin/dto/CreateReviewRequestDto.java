
package ae.network.onboarding.admin.dto;

import lombok.Data;

@Data
public class CreateReviewRequestDto {
    
    private String requestId;
    private String requestType;
    private String payload;
    private String comments;
    private String maker;
}
