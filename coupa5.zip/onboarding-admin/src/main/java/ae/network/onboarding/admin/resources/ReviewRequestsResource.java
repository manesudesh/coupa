package ae.network.onboarding.admin.resources;


import ae.network.onboarding.admin.converters.ReviewRequestConverter;
import ae.network.onboarding.admin.dto.CreateReviewRequestDto;
import ae.network.onboarding.admin.dto.ReviewResponseDto;
import ae.network.onboarding.admin.models.ReviewRequest;
import ae.network.onboarding.admin.services.DefaultReviewRequestServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequiredArgsConstructor
@RequestMapping("/onboarding-admin/review/v1")
public class ReviewRequestsResource {

    private final DefaultReviewRequestServiceImpl reviewRequestService;
    private final ReviewRequestConverter reviewRequestConverter;

    @PostMapping(value = "/application", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ReviewResponseDto> createRequest(@RequestBody CreateReviewRequestDto requestDto) {
        try {
            log.info("received ReviewRequest: {}", requestDto);
            ReviewRequest mapped = reviewRequestConverter.from(requestDto);
            ReviewResponseDto response = reviewRequestService.createRequest(mapped);
            return ResponseEntity.created(null).body(response);
        } catch (Exception exception) {
            log.error("unable to create review request", exception);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, exception.getMessage());
        }
    }

    @PutMapping(value = "/application/approve/{requestId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ReviewResponseDto> approveRequest(@PathVariable String requestId) {
        try {
            log.info("approval request received for requestId: {}", requestId);
            ReviewRequest reviewRequest = reviewRequestService.getReviewRequestById(requestId);
            ReviewResponseDto response = reviewRequestService.approveRequest(reviewRequest);
            return ResponseEntity.ok().body(response);
        } catch (Exception exception) {
            log.error("unable to approve review request", exception);
            if (exception instanceof ResponseStatusException) {
                throw exception;
            } else {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, exception.getMessage());
            }
        }
    }

    @PutMapping(value = "/application/reject/{requestId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ReviewResponseDto> rejectRequest(@PathVariable String requestId) {
        try {
            log.info("rejection request received for requestId: {}", requestId);
            ReviewRequest reviewRequest = reviewRequestService.getReviewRequestById(requestId);
            ReviewResponseDto response = reviewRequestService.rejectRequest(reviewRequest);
            return ResponseEntity.ok().body(response);
        } catch (Exception exception) {
            log.error("unable to reject review request", exception);
            if (exception instanceof ResponseStatusException) {
                throw exception;
            } else {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, exception.getMessage());
            }
        }
    }

    @GetMapping(value = "/application", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ReviewResponseDto>> getPendingRequests() {
        try {
            log.info("fetching pending ReviewRequest");
            List<ReviewRequest> reviewRequests = reviewRequestService.getPendingRequests();
            List<ReviewResponseDto> response = reviewRequests.stream().map(reviewRequestConverter::toResponseDtoOnRead).collect(Collectors.toList());
            return ResponseEntity.ok().body(response);
        } catch (Exception exception) {
            log.error("unable to fetch pending review request", exception);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, exception.getMessage());
        }
    }

}
