package ae.network.onboarding.admin.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "onboarding_admin_requests")
public class ReviewRequest {

    @Id
    private String id;
    private String requestId;
    private RequestType requestType;
    private String payload;
    private Status status;
    private String comments;
    private String maker;

    @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
    private java.util.Date created;

    @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
    private java.util.Date lastUpdated;
}
