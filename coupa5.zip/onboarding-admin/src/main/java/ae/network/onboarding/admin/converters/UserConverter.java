package ae.network.onboarding.admin.converters;

import ae.network.onboarding.admin.dto.LoginRequest;
import ae.network.onboarding.admin.dto.UserDto;
import ae.network.onboarding.admin.models.User;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = UserConverter.class)
public interface UserConverter {

    User from(LoginRequest loginRequest);

    User from(UserDto userDto);
}
