package ae.network.onboarding.admin.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class StaticHtmlConfig implements WebMvcConfigurer {
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry
                .addResourceHandler("/onboarding-admin/public/client/**")
                .addResourceLocations("classpath:/web-client/");
        registry
                .addResourceHandler("/onboarding-admin/public/sre-admin/**")
                .addResourceLocations("classpath:/sre-admin/");
    }
}