package ae.network.onboarding.admin.models;

public enum Role {
    ROLE_MAKER, ROLE_CHECKER, ROLE_INVALID
}
