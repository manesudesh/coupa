package ae.network.onboarding.admin.resources;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/onboarding-admin/public")
public class StaticResource {

    @Value("${onboarding-client.baseUrl}")
    private String onboardingClientBaseUrl;

    @RequestMapping(value={"", "/", "/client"})
    public String webClientHomePage() {
        return "redirect:" + onboardingClientBaseUrl + "/onboarding-admin/public/client/index.html";
    }

    @RequestMapping(value = "/sre-admin")
    public String sreAdminHomePage() {
        return "redirect:" + onboardingClientBaseUrl + "/onboarding-admin/public/sre-admin/index.html";
    }

}
