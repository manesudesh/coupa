package ae.network.onboarding.admin.converters;

import ae.network.onboarding.admin.dto.CreateReviewRequestDto;
import ae.network.onboarding.admin.dto.ReviewResponseDto;
import ae.network.onboarding.admin.models.ReviewRequest;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(componentModel = "spring", uses = ReviewRequestConverter.class)
public interface ReviewRequestConverter {

    ReviewRequest from(CreateReviewRequestDto createReviewRequestDto);

    @Mappings({
            @Mapping(target="requestStatus", source="reviewRequest.status"),
            @Mapping(target="submittedOn", source="reviewRequest.created"),
            @Mapping(target = "payload", ignore = true),
            @Mapping(target = "comments", ignore = true),
            @Mapping(target = "maker", ignore = true),
            @Mapping(target = "updatedOn", ignore = true),
    })
    ReviewResponseDto toResponseDtoOnWrite(ReviewRequest reviewRequest);

    @Mappings({
            @Mapping(target="requestStatus", source="reviewRequest.status"),
            @Mapping(target="submittedOn", source="reviewRequest.created"),
            @Mapping(target="updatedOn", source="reviewRequest.lastUpdated")
    })
    ReviewResponseDto toResponseDtoOnRead(ReviewRequest reviewRequest);
}
