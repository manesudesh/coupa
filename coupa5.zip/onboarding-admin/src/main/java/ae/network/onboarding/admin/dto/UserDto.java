
package ae.network.onboarding.admin.dto;

import ae.network.onboarding.admin.models.Role;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class UserDto {

    private String username;
    private String password;
    private Role role;
    boolean enabled;
}
