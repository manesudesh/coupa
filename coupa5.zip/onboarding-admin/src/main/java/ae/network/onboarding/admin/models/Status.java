package ae.network.onboarding.admin.models;

public enum Status {
    UNDER_REVIEW, REJECTED, APPROVED
}
