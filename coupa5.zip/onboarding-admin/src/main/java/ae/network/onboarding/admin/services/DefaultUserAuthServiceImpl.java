package ae.network.onboarding.admin.services;

import ae.network.onboarding.admin.configuration.OnboardingApiConfiguration;
import ae.network.onboarding.admin.converters.UserConverter;
import ae.network.onboarding.admin.dto.LoginRequest;
import ae.network.onboarding.admin.dto.LoginResponse;
import ae.network.onboarding.admin.dto.UserDto;
import ae.network.onboarding.admin.models.User;
import ae.network.onboarding.admin.repository.UserRepository;
import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import reactor.netty.tcp.ProxyProvider;
import reactor.netty.tcp.TcpClient;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.concurrent.TimeUnit;

@Service
public class DefaultUserAuthServiceImpl implements UserAuthService {

    private final WebClient webClient;
    private final MultiValueMap<String, String> credentials;
    private final UserRepository userRepository;
    private final UserConverter userConverter;

    public DefaultUserAuthServiceImpl(OnboardingApiConfiguration onboardingApiConfiguration, UserRepository userRepository, UserConverter userConverter) {
        webClient = initWebClient(onboardingApiConfiguration);
        this.userRepository = userRepository;
        this.userConverter = userConverter;
        credentials = new LinkedMultiValueMap<>();
        credentials.add("username", onboardingApiConfiguration.getAuth().getUsername());
        credentials.add("password", onboardingApiConfiguration.getAuth().getPassword());
    }

    private WebClient initWebClient(OnboardingApiConfiguration onboardingApiConfiguration) {
        TcpClient tcpClient = TcpClient
                .create()
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, onboardingApiConfiguration.getConnectTimeoutSeconds() * 1000)
                .doOnConnected(connection -> {
                    connection.addHandlerLast(new ReadTimeoutHandler(onboardingApiConfiguration.getReadTimeoutSeconds(), TimeUnit.SECONDS));
                    connection.addHandlerLast(new WriteTimeoutHandler(onboardingApiConfiguration.getWriteTimeoutSeconds(), TimeUnit.SECONDS));
                });

        String proxyHost = System.getProperty("https.proxyHost");
        String proxyPort = System.getProperty("https.proxyPort");

        if (!StringUtils.isEmpty(proxyHost) && !StringUtils.isEmpty(proxyHost)) {
            tcpClient.proxy(proxy -> proxy
                    .type(ProxyProvider.Proxy.HTTP)
                    .host(proxyHost)
                    .port(Integer.parseInt(proxyPort)));
        }

        return WebClient
                .builder()
                .clientConnector(new ReactorClientHttpConnector(HttpClient.from(tcpClient)))
                .baseUrl(onboardingApiConfiguration.getHost())
                .build();
    }

    @Override
    public String getAccessToken() {
        return webClient.post()
                .uri("/users/signin")
                .body(BodyInserters.fromMultipartData(credentials))
                .header(HttpHeaders.CONTENT_TYPE, MediaType.MULTIPART_FORM_DATA_VALUE)
                .accept(MediaType.TEXT_PLAIN)
                .acceptCharset(StandardCharsets.UTF_8)
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }

    @Override
    public LoginResponse login(LoginRequest loginRequest) {
        String username = loginRequest.getUsername();
        String password = loginRequest.getPassword();
        String passwordHash = DigestUtils.sha256Hex(password);

        User user = userRepository.findFirstByUsernameAndPassword(username, passwordHash)
                .orElseThrow(() -> new IllegalArgumentException("invalid credentials"));

        if (!user.isEnabled()) throw new IllegalStateException("Cannot login with a disabled user account");

        String accessToken = this.getAccessToken();

        return LoginResponse.builder()
                .accessToken(accessToken)
                .role(user.getRole().name())
                .build();
    }

    @Override
    public void enableUser(String username) {
        setEnabled(username, true);
    }

    @Override
    public void disableUser(String username) {
        setEnabled(username, false);
    }

    @Override
    public void createUser(UserDto userDto) {
        User user = userConverter.from(userDto);
        user.setPassword(DigestUtils.sha256Hex(userDto.getPassword()));
        user.setCreated(new Date());
        userRepository.save(user);
    }

    private void setEnabled(String username, boolean enable) {
        User user = userRepository.findFirstByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("invalid username"));
        user.setEnabled(enable);
        userRepository.save(user);
    }

}
