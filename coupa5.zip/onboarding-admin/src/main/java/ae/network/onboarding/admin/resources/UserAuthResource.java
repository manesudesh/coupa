package ae.network.onboarding.admin.resources;


import ae.network.onboarding.admin.dto.LoginRequest;
import ae.network.onboarding.admin.dto.LoginResponse;
import ae.network.onboarding.admin.services.UserAuthService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@Slf4j
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequiredArgsConstructor
@RequestMapping("/onboarding-admin/auth/v1")
public class UserAuthResource {

    private final UserAuthService userAuthService;

    @PostMapping(value = "/login", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<LoginResponse> login(
            @RequestParam(value = "username", required = true) String username,
            @RequestParam(value = "password", required = true) String password
    ) {
        try {
            log.info("received login request for username:: {}", username);
            LoginResponse response = userAuthService.login(LoginRequest.builder()
                    .username(username)
                    .password(password)
                    .build());
            return ResponseEntity.ok().body(response);
        } catch (Exception exception) {
            log.error("unable to login", exception);
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, exception.getMessage());
        }
    }


}
