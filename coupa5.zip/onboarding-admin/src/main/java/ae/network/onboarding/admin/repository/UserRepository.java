package ae.network.onboarding.admin.repository;

import ae.network.onboarding.admin.models.User;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface UserRepository extends MongoRepository<User, String> {

    Optional<User> findFirstByUsernameAndPassword(String username, String password);

    Optional<User> findFirstByUsername(String username);
}
