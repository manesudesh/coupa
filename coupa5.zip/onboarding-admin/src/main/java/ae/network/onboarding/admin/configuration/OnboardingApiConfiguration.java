package ae.network.onboarding.admin.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties("onboarding-api")
@Data
public class OnboardingApiConfiguration {

    private String host;
    private int connectTimeoutSeconds;
    private int readTimeoutSeconds;
    private int writeTimeoutSeconds;
    private Auth auth;

    @Data
    public static class Auth {
        private String username;
        private String password;
        private String path;
    }
}
