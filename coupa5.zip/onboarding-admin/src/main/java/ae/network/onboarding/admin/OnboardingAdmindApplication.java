package ae.network.onboarding.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnboardingAdmindApplication {

    public static void main(String[] args) {
        SpringApplication.run(OnboardingAdmindApplication.class, args);
    }
}
