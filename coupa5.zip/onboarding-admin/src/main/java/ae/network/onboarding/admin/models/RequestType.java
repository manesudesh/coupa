package ae.network.onboarding.admin.models;

public enum RequestType {
    ONBOARDING, AMENDMENT, MERCHANT_CLOSURE, TERMINAL_CLOSURE
}
