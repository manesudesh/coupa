package ae.network.onboarding.onboarding3ds2.database.repositories;

import ae.network.onboarding.onboarding3ds2.database.domain.AcquirerConfig;
import ae.network.onboarding.onboarding3ds2.model.Acquirer;

import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

/**
 * @author 
 */
public interface AcquirerConfigRepository extends MongoRepository<AcquirerConfig, String> {
    /**
     * Finds an Acquirer's config by the acquirer
     *
     * @param acquirer
     * @return
     */
    Optional<AcquirerConfig> findByAcquirer(Acquirer acquirer);
}
