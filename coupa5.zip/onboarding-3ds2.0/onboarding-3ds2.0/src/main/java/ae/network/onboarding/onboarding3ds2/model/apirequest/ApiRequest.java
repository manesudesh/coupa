package ae.network.onboarding.onboarding3ds2.model.apirequest;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
public class ApiRequest {
  private String action;

}
