package ae.network.onboarding.onboarding3ds2.model.application;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Size;
import java.util.List;

/**
 * @author 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {

    private AddressType addressType;

    private String countryCode;

    @Size(max = 3, message = "State cannot exceed 3 characters")
    private String state;

    @Size(max = 18, message = "Address City cannot exceed 18 characters")
    private String city;
    private String postalCode;

    @Size(max = 20, message = "Phone number cannot exceed 20 characters")
    private String phone;

    @Size(max = 25, message = "P.O Box cannot exceed 25 characters")
    private String pobox;

    private String email;
    private String fax;
    private String longitude;
    private String latitude;
    private String additionalEmail;
    private List<String> addressLines;
}
