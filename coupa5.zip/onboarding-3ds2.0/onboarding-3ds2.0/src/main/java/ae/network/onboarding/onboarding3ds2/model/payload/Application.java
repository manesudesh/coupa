package ae.network.onboarding.onboarding3ds2.model.payload;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import ae.network.onboarding.onboarding3ds2.model.application.Merchant;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class Application {

    @JsonProperty("merchants")
    private List<Merchant> merchants;

}