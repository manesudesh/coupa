package ae.network.onboarding.onboarding3ds2.model;

import ae.network.onboarding.onboarding3ds2.rabbitmq.config.RabbitQueue;

/**
 * List of all onboarding backend systems
 */
public enum BackendSystem {
    _3ds2(RabbitQueue._3ds2);

    private final RabbitQueue rabbitQueue;

    BackendSystem(RabbitQueue rabbitQueue) {
        this.rabbitQueue = rabbitQueue;
    }

    public RabbitQueue getRabbitQueue() {
        return rabbitQueue;
    }
}
