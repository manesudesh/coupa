package ae.network.onboarding.onboarding3ds2.model;

import java.util.ArrayList;
import java.util.Collection;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProcessingResult {
    private TaskStatus finalStatus;
    private Collection<Task> tasks = new ArrayList<>();
}
