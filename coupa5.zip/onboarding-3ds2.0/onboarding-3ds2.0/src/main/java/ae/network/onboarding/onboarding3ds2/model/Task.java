package ae.network.onboarding.onboarding3ds2.model;

import lombok.Builder;
import lombok.Data;

import java.util.Collection;

/**
 * @author 
 */
@Data
@Builder
public class Task {
    private Long id;
    private String name;
    private String entityId;
    private TaskStatus taskStatus;
    private Collection<TaskHistory> taskHistory;
    private boolean coreTask;
}
