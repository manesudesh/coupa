package ae.network.onboarding.onboarding3ds2.model.apirequest;


import lombok.Data;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
public class GetAPIRequest extends ApiRequest{

	private String transaction_id; 
	
	private String offset; 
	
	private String limit; 
	
}
