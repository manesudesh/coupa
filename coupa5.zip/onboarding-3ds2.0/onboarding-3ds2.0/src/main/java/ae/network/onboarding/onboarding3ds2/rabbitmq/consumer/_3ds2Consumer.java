package ae.network.onboarding.onboarding3ds2.rabbitmq.consumer;

import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import ae.network.onboarding.onboarding3ds2.database.service.AcquirerConfigService;
import ae.network.onboarding.onboarding3ds2.model.ApplicationRequest;
import ae.network.onboarding.onboarding3ds2.model.ApplicationUpdate;
import ae.network.onboarding.onboarding3ds2.model.BackendSystem;
import ae.network.onboarding.onboarding3ds2.model.RequestType;
import ae.network.onboarding.onboarding3ds2.model.Task;
import ae.network.onboarding.onboarding3ds2.model.TaskName;
import ae.network.onboarding.onboarding3ds2.model.TaskStatus;
import ae.network.onboarding.onboarding3ds2.model.ValidationError;
import ae.network.onboarding.onboarding3ds2.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.onboarding3ds2.rabbitmq.consumer.validator.ErrorCode;
import ae.network.onboarding.onboarding3ds2.rabbitmq.consumer.validator.MerchantValidator;
import ae.network.onboarding.onboarding3ds2.rabbitmq.service.RabbitService;
import ae.network.onboarding.onboarding3ds2.services._3ds2exchange._3ds2Service;
import lombok.extern.slf4j.Slf4j;

/**
 * @author 
 */
@Component
@Slf4j
public class _3ds2Consumer extends AbstractConsumer {
	
    
    @Qualifier("_3ds2Service")
    private _3ds2Service _3ds2Service;
    
    public _3ds2Consumer(
            RabbitService rabbitService,
            _3ds2Service _3ds2Service,
            AcquirerConfigService acquirerConfigService,
            @Value("${octopus.consumer.error-retry-in-seconds}") int retryPeriod) {
        super(RabbitQueue._3ds2, retryPeriod, rabbitService);
        this._3ds2Service = _3ds2Service;
    }

    
    @Override
    public synchronized Optional<Collection<ValidationError>> validateApplication(ApplicationRequest applicationRequest) {
    	MerchantValidator merchantValidator = MerchantValidator.instance(applicationRequest.getRequestType());

        List<ValidationError> validationErrors = applicationRequest.getPayload().getApplications().stream()
                .flatMap(app -> app.getMerchants().stream())
                .flatMap(merchant -> merchantValidator.validate(merchant).stream()).map(ErrorCode::toValidationError)
                .collect(Collectors.toList());
        if (validationErrors.isEmpty()) {
        	log.info("validation passed for this request");
        	handleValidationTask(applicationRequest,TaskName.VALIDATION, TaskStatus.COMPLETED, validationErrors);
        	return Optional.empty();
        }
        else {
	        log.info("validation errors found for this request");
	        handleValidationTask(applicationRequest, TaskName.VALIDATION, TaskStatus.FAILED, validationErrors);
	        _3ds2Service.save3ds2Db(applicationRequest);
	        return Optional.of(validationErrors);
        }
    }

    @Override
    public  synchronized void processApplication(ApplicationRequest applicationRequest) {
        log.info("Processing queued message {}", applicationRequest);
        try {
        	String applicationId = applicationRequest.getApplicationId();
        	
            if (applicationRequest != null ) {
            	//request for Create Merchant enrollment
            	_3ds2Service.createMerchantHandler(applicationRequest);
            	
            /*	below code snippet is for Http call Create GET PUT DELETE
             * if("Request for Create Merchant"=="Request for Create Merchant") {
            		_3ds2Service.createMerchantHandler(entityObj);
            	}
            	else if("Get call Merchant"=="Get call Merchant") {
            		_3ds2Service.getMerchantHandler(entityObj);
            	}
            	else if("Put call Merchant"=="Put call Merchant") {
            		
            	}
            	else if("Delete call Merchant"=="Delete call Merchant") {
            		
            	} 
            	*/
            } else {
            	log.error("Application request is empty");
                sendApplicationCancelled(applicationId);
            }
        } catch (IOException e) {
            log.error("Error thrown while writing payload to file, Retry file upload {}", e);
            throw new RuntimeException(e);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    private synchronized void handleValidationTask(ApplicationRequest applicationRequest, TaskName taskName, TaskStatus status, Collection<ValidationError> validationErrors ) {
        log.warn("Constructing update for application {}", applicationRequest.getApplicationId());
        Task task = null;// _3ds2Service.createTask( taskName,  status);
        
        if( status == TaskStatus.COMPLETED)
        {
        	task = _3ds2Service.assignTaskhistoryToTask(taskName, status, "validationResult success","OK");
        }else {
        	task = _3ds2Service.assignValidationErrorTaskHistory(validationErrors, taskName, status);
        	ApplicationUpdate applicationUpdate = _3ds2Service.assignResultToAppUpdate(task, applicationRequest.getApplicationId(), getBackendSystem());
        	sendUpdate(applicationUpdate);
        }
        applicationRequest.getTasks().add(task);
        log.info("Task "+taskName+" staus "+status);
//       _3ds2Service.save3ds2Db(applicationRequest);
    }

    @Override
    public BackendSystem getBackendSystem() {
        return BackendSystem._3ds2;
    }

    @Override
    public boolean isRequestSupported(ApplicationRequest applicationRequest) {
        return applicationRequest.getPayload().getApplications().stream()
                .flatMap(app -> app.getMerchants().stream())
                .anyMatch(merchant -> RequestType.MERCHANT_CLOSURE.equals(applicationRequest.getRequestType())
                        ? merchant.isEcom() : merchant.isEcom() && merchant.has3ds2());
    }
}
