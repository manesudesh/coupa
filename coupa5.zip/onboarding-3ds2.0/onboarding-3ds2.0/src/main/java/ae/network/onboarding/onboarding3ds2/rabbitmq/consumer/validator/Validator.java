package ae.network.onboarding.onboarding3ds2.rabbitmq.consumer.validator;

import java.util.Collection;

import ae.network.onboarding.onboarding3ds2.model.application.Merchant;

public interface Validator {
    Collection<ErrorCode> validate(Merchant merchant);
}
