package ae.network.onboarding.onboarding3ds2.rabbitmq.consumer.validator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import ae.network.onboarding.onboarding3ds2.model.RequestType;
import ae.network.onboarding.onboarding3ds2.model.application.Merchant;

/**
 * @author 
 */
public class MerchantValidator implements Validator {
    private static final MerchantNameValidator MERCHANT_NAME_VALIDATOR = new MerchantNameValidator();
    private static final MerchantIdValidator MERCHANT_ID_VALIDATOR = new MerchantIdValidator();
    private static final MerchantAmendmentListValidator AMENDMENT_LIST_VALIDATOR = new MerchantAmendmentListValidator();

    private final Set<Validator> validatorsList = new HashSet<>();

    private MerchantValidator() {
    }

    public static MerchantValidator instance(RequestType requestType) {
        MerchantValidator result = new MerchantValidator();
        result.add(MERCHANT_ID_VALIDATOR);

        if (requestType == RequestType.AMENDMENT) {
            result.add(AMENDMENT_LIST_VALIDATOR);
        } else {
            result.add(MERCHANT_NAME_VALIDATOR);
        }
        return result;
    }

    @Override
    public Collection<ErrorCode> validate(Merchant merchant) {
        if (merchant.hasMerchantNameAmendment()) {
            this.add(MERCHANT_NAME_VALIDATOR);
        }

        return validatorsList.stream().flatMap(validator -> validator.validate(merchant).stream())
                .collect(Collectors.toList());
    }

    private MerchantValidator add(Validator validator) {
        validatorsList.add(validator);
        return this;
    }

    private static class MerchantNameValidator implements Validator {
        @Override
        public Collection<ErrorCode> validate(Merchant merchant) {
            List<ErrorCode> result = new ArrayList<>();

            String merchantName = merchant.getMerchantName();
            if (merchantName == null || merchantName.isEmpty()) {
                result.add(ErrorCode.MERCHANT_NAME_EMPTY);
            } else if (!merchantName.matches("[\\w ]{2,128}")) {
                result.add(ErrorCode.MERCHANT_NAME_INVALID);
            }
            return result;
        }
    }

    private static class MerchantIdValidator implements Validator {
        @Override
        public Collection<ErrorCode> validate(Merchant merchant) {
            List<ErrorCode> result = new ArrayList<>();

            String merchantId = merchant.getMerchantId();
            if (merchantId == null || merchantId.isEmpty()) {
                result.add(ErrorCode.MERCHANT_ID_EMPTY);
            } else if (!merchantId.matches("[0-9]{6,15}")) {
                result.add(ErrorCode.MERCHANT_ID_INVALID);

            }
            return result;
        }
    }

    private static class MerchantAmendmentListValidator implements Validator {
        @Override
        public Collection<ErrorCode> validate(Merchant merchant) {
            List<ErrorCode> result = new ArrayList<>();

            List<String> amendmentList = merchant.getAmendmentList();
            if (amendmentList == null || amendmentList.isEmpty()) {
                result.add(ErrorCode.MERCHANT_NAME_EMPTY);
            }
            return result;
        }
    }
}
