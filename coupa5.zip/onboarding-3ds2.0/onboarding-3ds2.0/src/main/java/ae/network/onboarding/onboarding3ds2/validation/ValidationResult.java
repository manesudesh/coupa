package ae.network.onboarding.onboarding3ds2.validation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

/**
 * @author : 
 * @version : 1.0
 */
@Data
@AllArgsConstructor
@Builder
@ToString(includeFieldNames = false)
public class ValidationResult {

    private boolean passed;
    private String code;
    private String message;
}
