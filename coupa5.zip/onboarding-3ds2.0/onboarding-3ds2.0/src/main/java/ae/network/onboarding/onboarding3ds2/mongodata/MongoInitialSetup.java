package ae.network.onboarding.onboarding3ds2.mongodata;

import org.springframework.data.mongodb.core.MongoTemplate;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;

import ae.network.onboarding.onboarding3ds2.database.domain.AcquirerConfig;
import ae.network.onboarding.onboarding3ds2.model.Acquirer;

/**
 * Creating mongodb initial data
 *
 * @author 
 * @since 
 */
@ChangeLog(order = "001")
public class MongoInitialSetup {

    @ChangeSet(order = "01", author = "3ds2.0-acquirerConfig", id = "01-addInitialAcquirersConfig")
    public void createDefaultAdminUser(MongoTemplate mongoTemplate) {
        mongoTemplate.save(createConfig(Acquirer.NI));
    }

    private AcquirerConfig createConfig(Acquirer acquirer) {
        return AcquirerConfig.builder()
                .orgId("MC75")
                .acquirer(acquirer)
                .acquirerBin("230516")
                .acquirerCompanyId("126121")
                .companyName("network international")
                .acquirerPrimaryIca("3676")
                .build();
    }
}