package ae.network.onboarding.onboarding3ds2.database.domain;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import ae.network.onboarding.onboarding3ds2.model.Acquirer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author 
 */

@Data
@AllArgsConstructor
@Builder
@ToString(includeFieldNames = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "3ds2.0_acquirerConfig")
public class AcquirerConfig extends AbstractAuditingEntity {

    /**
     * Unique identifier of the document
     */
    @Id
    private String id;
    private String orgId;
    private String name;
    private boolean complexTariffStructure;
    /**
     * Acquirer Name
     */
    private Acquirer acquirer;
    /**
     * Acquirer Bin
     */
    private String acquirerBin;
    /**
     * Company Id of Acquirer
     */
    private String acquirerCompanyId;
    /**
     * Primary ICA of Acquirer
     */
    private String acquirerPrimaryIca;
    /**
     * Company Name of Acquirer
     */
    private String companyName;

}
