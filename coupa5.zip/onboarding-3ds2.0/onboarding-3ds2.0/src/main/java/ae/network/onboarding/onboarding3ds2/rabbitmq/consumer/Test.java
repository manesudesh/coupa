package ae.network.onboarding.onboarding3ds2.rabbitmq.consumer;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.support.converter.SimpleMessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ae.network.onboarding.onboarding3ds2.database.service.AcquirerConfigService;
import ae.network.onboarding.onboarding3ds2.rabbitmq.service.impl.RabbitServiceImpl;
import ae.network.onboarding.onboarding3ds2.services._3ds2exchange._3ds2Service;
import lombok.extern.slf4j.Slf4j;
@Slf4j
public class Test extends Thread {

	
	
Message message;
_3ds2Consumer _3ds2Consumer;
	
public Test(Message msg, _3ds2Consumer consum){
	message = msg;
	_3ds2Consumer = consum;
}
	

	@Override
	public void run() {
		log.info(message.toString());
//		_3ds2Consumer.onMessage(message);
	}


static String getJSONStr(int id) {
	return "{\r\n"
	+ "    \"_id\" : \"5f73"+id+"\",\r\n"
	+ "    \"acquirer\" : \"TYME\",\r\n"
	+ "    \"requestType\" : \"ONBOARDING\",\r\n"
	+ "    \"applicationId\" : \"7cc97fe9-6c42-4ac4-ab72-e47aa3a3dfe2\",\r\n"
	+ "    \"requestId\" : \"a0S3H000000eZwyUAE0\",\r\n"
	+ "    \"payload\" : {\r\n"
	+ "        \"applications\" : [ \r\n"
	+ "            {\r\n"
	+ "                \"chain\" : {\r\n"
	+ "                    \"chainId\" : \"500060008849\",\r\n"
	+ "                    \"chainName\" : \"560008849\",\r\n"
	+ "                    \"organizationName\" : \"testtradeSO30929\"\r\n"
	+ "                },\r\n"
	+ "                \"merchants\" : [ \r\n"
	+ "                    {\r\n"
	+ "                        \"merchantId\" : \"500860009"+id+"\",\r\n"
	+ "                        \"merchantName\" : \"testtradeSO30"+id+"\",\r\n"
	+ "                        \"merchantType\" : \"ECOM\",\r\n"
	+ "			\"website\" : \"https://Dbxv-class.com\",\r\n"
	+ "                        \"mcc\" : 8931,\r\n"
	+ "                        \"merchantCurrency\" : \"AED\",\r\n"
	+ "                        \"terminals\" : [ \r\n"
	+ "                            {\r\n"
	+ "                                \"terminalId\" : \"53006959\"\r\n"
	+ "                            }\r\n"
	+ "                        ],\r\n"
	+ "			\"addresses\" : [ \r\n"
	+ "                            {\r\n"
	+ "                                \"addressType\" : \"DEFAULT\",\r\n"
	+ "                                \"countryCode\" : \"ARE\",\r\n"
	+ "                                \"city\" : \"Dubai\",\r\n"
	+ "                                \"state\" : \"United Arab Emirates\"\r\n"
	+ "                            }\r\n"
	+ "                        ],\r\n"
	+ "                        \"services\" : [ \r\n"
	+ "                            {\r\n"
	+ "                                \"organizationName\" : \"testtradeSO30929\",\r\n"
	+ "                                \"channels\" : [ \r\n"
	+ "                                    \"ECOM\"\r\n"
	+ "                                ],\r\n"
	+ "                                \"currencyLimits\" : {\r\n"
	+ "                                    \"USD\" : 10000,\r\n"
	+ "                                    \"AED\" : 10000\r\n"
	+ "                                },\r\n"
	+ "                                \"paymentMethodCurrenciesMap\" : {\r\n"
	+ "                                    \"VISA\" : [ \r\n"
	+ "                                        \"AED\"\r\n"
	+ "                                    ],\r\n"
	+ "                                    \"MASTERCARD\" : [ \r\n"
	+ "                                        \"AED\"\r\n"
	+ "                                    ]\r\n"
	+ "                                },\r\n"
	+ "                                \"propositionServices\" : [ \r\n"
	+ "                                    \"samsung-pay\", \r\n"
	+ "                                    \"apple-pay\"				\r\n"
	+ "                                ],\r\n"
	+ "                                \"enable3DS\" : true,\r\n"
	+ "                                \"user\" : {\r\n"
	+ "                                    \"email\" : \"nabasmit@gmail.com\",\r\n"
	+ "                                    \"firstName\" : \"Mr\",\r\n"
	+ "                                    \"lastName\" : \"testS\"\r\n"
	+ "                                },\r\n"
	+ "                                \"serviceType\" : \"MC_3D_SECURE\"\r\n"
	+ "                            }\r\n"
	+ "                        ],\r\n"
	+ "                        \"validationErrors\" : []\r\n"
	+ "                    }\r\n"
	+ "                ]\r\n"
	+ "            }\r\n"
	+ "        ]\r\n"
	+ "    },\r\n"
	+ "    \"dryRun\" : false\r\n"
	+ "}\r\n"
	+ "";
	}

}