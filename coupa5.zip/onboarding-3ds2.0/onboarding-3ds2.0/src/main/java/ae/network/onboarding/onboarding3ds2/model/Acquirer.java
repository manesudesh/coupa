package ae.network.onboarding.onboarding3ds2.model;

public enum Acquirer {
    NI, TYME
}
