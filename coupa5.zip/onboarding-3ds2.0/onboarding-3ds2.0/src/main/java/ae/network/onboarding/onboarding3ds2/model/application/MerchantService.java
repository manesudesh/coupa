package ae.network.onboarding.onboarding3ds2.model.application;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
//@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "serviceType", visible = true)
//@JsonSubTypes({
//        @Type(value = DCCServiceParam.class, name = "DCC"),
//        @Type(value = RentalParam.class, name = "RENTAL"),
//        @Type(value = MC3DServiceParam.class, name = "MC_3D_SECURE")})
@Data
public class MerchantService {

    @JsonProperty("serviceType")
    protected String serviceType;
}
