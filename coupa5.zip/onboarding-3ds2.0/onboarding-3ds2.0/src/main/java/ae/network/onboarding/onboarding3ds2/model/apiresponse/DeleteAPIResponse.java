package ae.network.onboarding.onboarding3ds2.model.apiresponse;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Builder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@Data
public class DeleteAPIResponse extends ApiResponse {
//	private String transactionID;
	   
//    private String messageType;
   
//    private int totalRecords;
}