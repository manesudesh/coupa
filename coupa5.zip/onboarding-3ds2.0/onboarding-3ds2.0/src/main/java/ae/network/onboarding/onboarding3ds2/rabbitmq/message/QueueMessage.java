package ae.network.onboarding.onboarding3ds2.rabbitmq.message;

import java.io.Serializable;

/**
 * @author 
 * @since 
 * Marker interface for message sent to rabbit queues
 */
public interface QueueMessage extends Serializable {

    String getApplicationId();
}
