package ae.network.onboarding.onboarding3ds2.model.amendment;

/**
 * @author : 
 * @version : 1.0
 */
public enum AmendmentType {
    MERCHANT_NAME
}
