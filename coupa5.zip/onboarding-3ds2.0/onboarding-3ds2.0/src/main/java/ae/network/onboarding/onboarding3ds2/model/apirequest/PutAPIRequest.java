package ae.network.onboarding.onboarding3ds2.model.apirequest;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
public class PutAPIRequest extends ApiRequest{

	 /**
     * Merchant data
     */
//    private List<MerchantData> merchantData;
    
    /**
     * Processor name
     */
//    private String processorName;
}
