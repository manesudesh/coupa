package ae.network.onboarding.onboarding3ds2.model.application;

/**
 * @author 
 */
public enum ActionType {
    Add, Update, AddOrUpdate, CLOSURE
}