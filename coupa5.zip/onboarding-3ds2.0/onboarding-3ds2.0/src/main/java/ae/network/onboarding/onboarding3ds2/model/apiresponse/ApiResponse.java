package ae.network.onboarding.onboarding3ds2.model.apiresponse;

import lombok.Data;

@Data
public class ApiResponse {

}
