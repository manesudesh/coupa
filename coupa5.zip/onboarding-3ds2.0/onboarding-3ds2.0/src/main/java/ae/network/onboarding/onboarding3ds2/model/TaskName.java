package ae.network.onboarding.onboarding3ds2.model;

public enum TaskName {
    VALIDATION,
    SEND_APP_REQUEST,
    RECEIVE_APP_RESPONSE,
    ONBOARDING_MERCHANT
}
