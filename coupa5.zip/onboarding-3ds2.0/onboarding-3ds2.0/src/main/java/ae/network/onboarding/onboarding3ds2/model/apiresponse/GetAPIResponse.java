package ae.network.onboarding.onboarding3ds2.model.apiresponse;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import ae.network.onboarding.onboarding3ds2.model.apirequest.MerchantData;
import lombok.Builder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@Data
public class GetAPIResponse extends ApiResponse {
	 /**
     * Merchant data
     */
    private List<MerchantData> merchantData;
    
    /**
     * Processor name
     */
    private String processorName;
    
    private String transactionID;
    private String messageType;
    private int totalRecords;
    private int offset;
    private int limit;
    private String reportStatus;
    private String successRecords;
    private String failedRecords;
}