package ae.network.onboarding.onboarding3ds2.apiclient;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mastercard.api.core.ApiConfig;
import com.mastercard.api.core.ApiController;
import com.mastercard.api.core.exception.ApiException;
import com.mastercard.api.core.model.Action;
import com.mastercard.api.core.model.BaseObject;
import com.mastercard.api.core.model.OperationConfig;
import com.mastercard.api.core.model.OperationMetadata;
import com.mastercard.api.core.model.RequestMap;
import com.mastercard.api.core.security.Authentication;
import com.mastercard.api.match.ResourceConfig;

import ae.network.onboarding.onboarding3ds2.apiclient.APIPropertyConfig.APIProps;
import ae.network.onboarding.onboarding3ds2.model.apirequest.GetAPIRequest;
import ae.network.onboarding.onboarding3ds2.model.apirequest.MerchantData;
import ae.network.onboarding.onboarding3ds2.model.apirequest.PostAPIRequest;
import ae.network.onboarding.onboarding3ds2.model.apiresponse.ApiResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author : 
 * @version : 1.0
 */
@Slf4j
@Service
public class MerchantApiClient extends ApiController {

    @Autowired
    private ObjectMapper mapper;
    @Autowired
    APIProps apiProps;

    //private static final String RESOURCE_PATH = "/merchantenrollments/merchants";
    private static final String[] CORRELATION_HEADERS = {"correlation-id", "RequestId"};


    public ApiResponse merchantEnrollmentRequest(Authentication authentication, OperationConfig opConfig, RequestMap requestMap, ApiResponse resposeClass) throws ApiException {
    	log.info("calling merchant enrollment ");
    	BaseObject requestObject = new MerchantEnrollmentRequest(requestMap);
        OperationMetadata opMeta = new OperationMetadata(ResourceConfig.getInstance().getVersion(), ResourceConfig.getInstance().getHost(), ResourceConfig.getInstance().getContext());

        HttpRequestBase request = getRequest(authentication, opConfig, opMeta, requestObject);
//        CryptographyInterceptor interceptor = ApiConfig.getCryptographyInterceptor(request.getURI().getPath());

        CloseableHttpClient httpClient = ApiConfig.getHttpClientBuilder().build();

        int port = request.getURI().getPort();
        //request.addHeader("Accept-version", "v1");
        request.addHeader("Accept-version", apiProps.getAcceptVersion());
        String scheme = request.getURI().getScheme();
        HttpHost host = new HttpHost(request.getURI().getHost(), port, scheme);

        ApiClientResponseWrapper response;
        try {
        	response = executeAPI(httpClient, host, request, createResponseHandler() );
            if (response != null) {

            	ApiResponse responseDto = null;

                if (response.isJson()) {
                    responseDto = mapper.readValue(response.getPayload(), resposeClass.getClass());
                    log.info("JSON RESPONSE MAPPING : {}",responseDto);
                } 

                return responseDto;
            }
            
        } catch (Exception e) {
            log.error("Error in Calling MerchantEnrollment API with Request {}", request, e);
            throw new ApiException(e);
        } finally {
            try {
                httpClient.close();
            } catch (IOException e) {
                log.error("Error in Closing HTTP Client", e);
            }
        }

        throw new IllegalStateException();
    }

    
    public ApiClientResponseWrapper executeAPI(CloseableHttpClient httpClient, HttpHost host,  HttpRequestBase request, ResponseHandler<ApiClientResponseWrapper> resHandler) throws ClientProtocolException, IOException {
    	return  httpClient.execute(host, request, resHandler);
    }
    
    
    private ResponseHandler<ApiClientResponseWrapper> createResponseHandler() {

        return response -> {

            int status = response.getStatusLine().getStatusCode();

            HttpEntity entity = response.getEntity();
            ContentType contentType = ContentType.get(entity);
            String payload = EntityUtils.toString(entity, contentType.getCharset());
            log.info("MerchantEnrollment Response: {}", payload);

            if (status < 300) {
                if (entity != null) {
                    if (!payload.isEmpty()) {

                        if (contentType.getMimeType().equalsIgnoreCase(ContentType.APPLICATION_JSON.getMimeType())) {
                            // JSON
                            return new ApiClientResponseWrapper(payload, true, response.getAllHeaders());
                        } else {
                            // XML
                            return new ApiClientResponseWrapper(payload.replaceAll("\0", "").replaceFirst("xmlns:ns2=\"http://mastercard.com/inquiry\"", "").replaceAll("ns2:", ""), false, response.getAllHeaders());
                        }
                    }
                }
                return null;
            } else {
                List<String> responseStrings = Arrays.stream(response.getAllHeaders())
                        .map(header -> header.getName() + ":" + header.getValue()).collect(Collectors.toList());

                responseStrings.add(payload);
                log.error(String.join(", ", responseStrings));

                // response status Is not OK
                String requestId = null;
                for (String headerName : CORRELATION_HEADERS) {
                    Header header = response.getFirstHeader(headerName);
                    if (header != null) {
                        requestId = header.getValue();
                    }
                }
                throw new IOException("Response Status : " + status + " for request : " + requestId + " Response: " + responseStrings);
            }
        };
    }

    public RequestMap convertPostCallReqMap(PostAPIRequest reqObject) {
        RequestMap map = new RequestMap();
        // merchant info
        AtomicInteger index = new AtomicInteger(0);
        for (MerchantData merchant : reqObject.getMerchantData()) {
        	log.info(" creatring Merchant RequestMap["+index+"] ");
            map.set(MerchantRequestMapKey.ACQUIRER_BIN.getIndexedKey(index.get()), merchant.getAcquirerBIN());
            map.set(MerchantRequestMapKey.ACQUIRER_CID.getIndexedKey(index.get()), merchant.getAcquirerCID());
            map.set(MerchantRequestMapKey.ACQUIRER_ICA.getIndexedKey(index.get()), merchant.getAcquirerICA());
            map.set(MerchantRequestMapKey.ACQUIRER_NAME.getIndexedKey(index.get()), merchant.getAcquirerName());
            map.set(MerchantRequestMapKey.MERCHANT_ID.getIndexedKey(index.get()), merchant.getMerchantID());
            map.set(MerchantRequestMapKey.MERCHANT_NAME.getIndexedKey(index.get()), merchant.getMerchantName());
            map.set(MerchantRequestMapKey.IDENTITY_CHECK_EXPRESS.getIndexedKey(index.get()), merchant.getIdentityCheckExpress());
            map.set(MerchantRequestMapKey.DELETE_REASON.getIndexedKey(index.get()), merchant.getDeleteReason());

            index.incrementAndGet();
        }
        map.set(MerchantRequestMapKey.PROCESSOR_NAME.getKey(), reqObject.getProcessorName());
        map.set(MerchantRequestMapKey.ACTION.getKey(), reqObject.getAction());

        return map;

    }
    
    @Data
    @AllArgsConstructor 
      class ApiClientResponseWrapper {
        private String payload;
        private boolean json;
        private Header[] headers;

        public boolean hasPayload() {
            return payload != null && payload.length() > 0;
        }

    }
    
    
    public RequestMap convertGetCallReqMap(GetAPIRequest reqObject) {
        RequestMap map = new RequestMap();
        // merchant info
        map.set(MerchantRequestMapKey.TRANSACTION_ID.getKey(), reqObject.getTransaction_id());
        map.set(MerchantRequestMapKey.OFFSET.getKey(), reqObject.getOffset());
        map.set(MerchantRequestMapKey.LIMIT.getKey(), reqObject.getLimit());
        
        return map;
    }
    
    public OperationConfig createOpConfig(Action action, List <String> queryParamArr, List<String> queryValueArr) {
		OperationConfig opConfig = new OperationConfig(apiProps.getResourcePath(), action, queryParamArr, queryValueArr);
		return opConfig;
	}
}
