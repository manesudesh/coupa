package ae.network.onboarding.onboarding3ds2.model;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.HashMap;
import java.util.Map;

/**
 * @author 
 * @since 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AdditionalData {
    @JsonIgnore
    private Map<String, Object> dataMap = new HashMap<>();

    @JsonAnyGetter
    public Map<String, Object> getDataMap() {
        return this.dataMap;
    }

    @JsonAnySetter
    public void setDataMap(String name, Object value) {
        this.dataMap.put(name, value);
    }
}
