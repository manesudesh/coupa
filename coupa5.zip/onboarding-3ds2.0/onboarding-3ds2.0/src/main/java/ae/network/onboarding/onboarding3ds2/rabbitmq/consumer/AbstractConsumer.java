package ae.network.onboarding.onboarding3ds2.rabbitmq.consumer;

import ae.network.onboarding.onboarding3ds2.exception.MaxRetryReachedException;
import ae.network.onboarding.onboarding3ds2.exception.MessageCancelledException;
import ae.network.onboarding.onboarding3ds2.exception.MessageRejectionException;
import ae.network.onboarding.onboarding3ds2.model.*;
import ae.network.onboarding.onboarding3ds2.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.onboarding3ds2.rabbitmq.consumer.validator.ErrorCode;
import ae.network.onboarding.onboarding3ds2.rabbitmq.service.RabbitService;
import ae.network.onboarding.onboarding3ds2.common.MdcUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.context.annotation.Bean;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author 
 */
@Slf4j
public abstract class AbstractConsumer implements Consumer {

    /**
     * When a reschedule is perform during
     * a fail update, RETRY_DELAY_SECONDS
     * tells number of seconds to wait
     * before making a retry
     */
    private final int RETRY_DELAY_SECONDS;
    /**
     * onMessage method listens for any
     * publish done on a queue. Listening
     * queue is the queue that publishes
     * are done on
     */
    private final RabbitQueue listeningQueue;
    /**
     * Injection of AMQP, i.e rabbitMQ
     */
    private final RabbitService rabbitService;

    protected AbstractConsumer(RabbitQueue listeningQueue, int RETRY_DELAY_SECONDS, RabbitService rabbitService) {
        this.listeningQueue = listeningQueue;
        this.RETRY_DELAY_SECONDS = RETRY_DELAY_SECONDS;
        this.rabbitService = rabbitService;
    }

    /**
     * Bean to configure replyListener
     * Configuration of what queue to listen
     * to when a publish is made by any producer
     */
    @Bean
    SimpleMessageListenerContainer replyListener(ConnectionFactory connectionFactory) {
        SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
        container.setConnectionFactory(connectionFactory);
        container.setQueueNames(listeningQueue.getQueueName());
        container.setMessageListener(this);
        container.setErrorHandler(this);
        return container;
    }


    /**
     * Send result of message processing to updates queue
     */
    protected void sendUpdate(ApplicationUpdate applicationUpdate) {
        rabbitService.sendMessage(RabbitQueue.UPDATES, applicationUpdate);
    }

    /**
     * Reschedules a retry of listening of messages
     * if error is recoverable
     */
    private void retryMessage(Message message, int delaySeconds) {
        rabbitService.retryMessage(message, delaySeconds);
    }

    /**
     * Receives the message on the queue
     * Does a default (which can be overridden)
     * computation by validating
     * and processing the message, throwing exceptions
     * and dispatching events when required based on
     * the actual workflow
     */
    @Override
    public void onMessage(Message message) {
        MdcUtils.setCorrId(message.getMessageProperties().getCorrelationId());
        log.info("Received message : " + message.getMessageProperties());

        // parse message
        String messageContent = new String(message.getBody());
        ApplicationRequest applicationRequest = validateRequestContent(message, messageContent);
        String applicationId = applicationRequest.getApplicationId();

        boolean requestSupported;
        try {
            requestSupported = isRequestSupported(applicationRequest);
        } catch (Exception e) {
            log.error("Unexpected exception during checking if request is supported", e);
            throw new MessageRejectionException(applicationId, e.getMessage());
        }
        if (!requestSupported) {
        	log.error(" Request is not supported ");
            sendApplicationCancelled(applicationId);
            return;
        }

        Collection<ValidationError> validationErrors;
        try {
            validationErrors = validateApplication(applicationRequest).orElse(Collections.emptyList());
        } catch (Exception e) {
            log.error("Unexpected exception during validation of message", e);
            throw new MessageRejectionException(applicationId, e.getMessage());
        }

        if (validationErrors.isEmpty()) {
            log.info("Validation of application {} is successful, starting processing...", applicationId);

            // check dry run option
            if (applicationRequest.isDryRun()) {
                Optional<ApplicationUpdate> applicationUpdateOp = druRun(applicationRequest);
                if (applicationUpdateOp.isPresent()) {
                    sendUpdate(applicationUpdateOp.get());
                } else {
                    log.info("dry run not supported");
                    sendApplicationCancelled(applicationId);
                }
                return;
            }

            // process the application
            try {
                processApplication(applicationRequest);
            } catch (MessageCancelledException e) {
                sendApplicationCancelled(applicationId);
            } catch (MessageRejectionException e) {
                log.error("Message rejected, forward to DLQ for investigation", e);
                throw e;
            } catch (Exception e) {
                log.error("an error has occurred in the consumer", e);
                retryMessage(message, RETRY_DELAY_SECONDS);
            }
        } else {
            log.info("Sending results of problematic validation", applicationId);
            sendApplicationInvalid(applicationId, validationErrors);
        }
    }

    protected void sendApplicationCancelled(String applicationId) {
        ProcessingResult cancelledProcessing = ProcessingResult.builder().finalStatus(TaskStatus.CANCELLED).build();
        ApplicationUpdate applicationUpdate = ApplicationUpdate.builder().applicationId(applicationId)
                .backendSystem(getBackendSystem()).processingResult(cancelledProcessing).build();
        sendUpdate(applicationUpdate);
    }

    private ApplicationRequest validateRequestContent(Message message, String messageContent) {
        ApplicationRequest applicationRequest;
        try {
            applicationRequest = new ObjectMapper().readValue(messageContent, ApplicationRequest.class);
        } catch (JsonProcessingException e) {
            String errorMessage = "Invalid JSON content";
            log.error(errorMessage, e);

            String applicationId = message.getMessageProperties().getCorrelationId();

            sendApplicationInvalid(applicationId, Collections.singletonList(ErrorCode.INVALID_JSON.toValidationError()));

            throw new MessageRejectionException(applicationId, errorMessage, e);
        }
        return applicationRequest;
    }

    private void sendApplicationInvalid(String applicationId, Collection<ValidationError> validationErrors) {
        log.warn("Constructing update for application {}", applicationId);
        Task validationTask = Task.builder()
        .name("Validation")
        .taskStatus(TaskStatus.FAILED)
        .build();

        List<TaskHistory> taskHistoryList = validationErrors.stream().map(this::mapErrorToTaskHistory)
                .collect(Collectors.toList());
        validationTask.setTaskHistory(taskHistoryList);
        ProcessingResult processingResult = ProcessingResult.builder().tasks(Collections.singletonList(validationTask))
                .finalStatus(TaskStatus.FAILED).build();

        ApplicationUpdate applicationUpdate = ApplicationUpdate.builder().applicationId(applicationId)
                .backendSystem(getBackendSystem()).processingResult(processingResult).build();
        sendUpdate(applicationUpdate);
    }

    TaskHistory mapErrorToTaskHistory(ValidationError error) {
        TaskHistory taskHistory = new TaskHistory();
        final Date now = new Date();
        taskHistory.setCreatedDate(now);
        taskHistory.setLastModifiedDate(now);
        taskHistory.setTaskStatus(TaskStatus.FAILED);
        taskHistory.setResponse(error.getFieldName() + " : " + error.getErrorMessage());
        taskHistory.setStatusCode(error.getErrorCode());
        return taskHistory;
    }


    @Override
    public void handleError(Throwable throwable) {
        log.error("An error has occurred while processing", throwable);
        if (throwable.getCause() instanceof MaxRetryReachedException) {
            MaxRetryReachedException ex = (MaxRetryReachedException) throwable.getCause();
            ApplicationUpdate applicationUpdate = ApplicationUpdate.builder().backendSystem(getBackendSystem())
                    .applicationId(ex.getApplicationId())
                    .processingResult(ProcessingResult.builder().finalStatus(TaskStatus.FAILED).build()).build();
            sendUpdate(applicationUpdate);
        }
    }
}
