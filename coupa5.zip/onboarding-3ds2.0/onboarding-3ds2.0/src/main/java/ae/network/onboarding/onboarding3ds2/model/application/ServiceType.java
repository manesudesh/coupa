package ae.network.onboarding.onboarding3ds2.model.application;

/**
 * @author 
 */

public enum ServiceType {
	_3DS2("3ds2.0");
	
    private final String value;

    ServiceType(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }
}
