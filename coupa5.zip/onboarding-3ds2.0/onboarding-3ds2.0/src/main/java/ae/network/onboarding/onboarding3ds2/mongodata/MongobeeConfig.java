package ae.network.onboarding.onboarding3ds2.mongodata;

import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.github.mongobee.Mongobee;
import com.mongodb.MongoClient;

/**
 * @author 
 */
@Configuration
public class MongobeeConfig {
    @Bean
    public Mongobee mongobee(MongoClient mongoClient, MongoTemplate mongoTemplate, MongoProperties mongoProperties) {
        Mongobee mongobee = new Mongobee(mongoClient);
        mongobee.setDbName(mongoProperties.getMongoClientDatabase());
        mongobee.setMongoTemplate(mongoTemplate);
        // package to scan for migrations
        mongobee.setChangeLogsScanPackage(MongobeeConfig.class.getPackage().getName());
        mongobee.setEnabled(true);
        return mongobee;
    }
}