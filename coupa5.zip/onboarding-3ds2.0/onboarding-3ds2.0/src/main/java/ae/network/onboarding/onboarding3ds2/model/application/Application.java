package ae.network.onboarding.onboarding3ds2.model.application;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Application {

    @NotNull(message = "merchant List can not be null")
    @NotEmpty(message = "merchant List can not be Empty")
    private List<Merchant> merchants;

    private String subId;
}
