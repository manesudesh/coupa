package ae.network.onboarding.onboarding3ds2.database.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import ae.network.onboarding.onboarding3ds2.model.ApplicationRequest;

/**
 * @author 
 */
@Repository
public interface _3ds2RequestRepository extends MongoRepository<ApplicationRequest, String> {

}
