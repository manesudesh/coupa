package ae.network.onboarding.onboarding3ds2.model.application;

/**
 * @author 
 */
public enum AmountType {
    ABSOLUTE_VALUE, PERCENTAGE
}
