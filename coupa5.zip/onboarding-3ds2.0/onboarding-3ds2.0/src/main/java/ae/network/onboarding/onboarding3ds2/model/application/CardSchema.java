package ae.network.onboarding.onboarding3ds2.model.application;

public enum CardSchema {
    VISA,
    MC,
    PL, // Private Label
    JCB,
    CUP, // China Union Pay
    MER, // Mercury
    DCI, // Diners Club International
    AMEX,

    TBOD, // Departments
    DODB,
    DOCR,
    DOHY,
    SBOC,
    SBOD,
    DOPR,


}
