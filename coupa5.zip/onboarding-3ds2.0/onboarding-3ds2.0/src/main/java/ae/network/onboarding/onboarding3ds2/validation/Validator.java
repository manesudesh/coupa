package ae.network.onboarding.onboarding3ds2.validation;

/**
 * @param <T>
 * @author : 
 * @version 1.0
 */
public interface Validator<T> {

    /**
     * validate method
     */
    ValidationResult validate(T entity);
}
