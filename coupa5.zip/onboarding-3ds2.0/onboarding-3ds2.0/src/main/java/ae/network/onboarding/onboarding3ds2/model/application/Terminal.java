package ae.network.onboarding.onboarding3ds2.model.application;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 * @author 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class Terminal {


    @Size(max = 16)
    @NotBlank
    private String terminalId;

    @NotBlank
    private String terminalType; // PC or ?
    private String maker;
    private String terminalModel;
    private boolean dccEnabled;


    @JsonIgnore
    private String merchantId;
    @JsonIgnore
    private String merchantCurrency;
    @JsonIgnore
    private ActionType actionType;


}
