package ae.network.onboarding.onboarding3ds2.exception;

/**
 * @author 
 * @since 
 */
public class AcquierNotFoundException extends MessageRejectionException {
    public AcquierNotFoundException(String applicationId) {
        super(applicationId, "Acquirer not found");
    }
}
