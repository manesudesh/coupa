package ae.network.onboarding.onboarding3ds2.rabbitmq.config;

import java.util.Arrays;
import java.util.List;

/**
 * @author
 */
public enum RabbitQueue {
    // Working Queue
    _3ds2("3ds2.0", "routing.backend.3ds2.0"),
    // Reply Queue
    UPDATES("updates", "routing.updates");

    private final String queueName;
    private final String[] routingKeys;

    RabbitQueue(String queueName, String... routingKeys) {
        this.queueName = queueName;
        this.routingKeys = routingKeys;
    }

    public String getQueueName() {
        return queueName;
    }

    public List<String> getRoutingKeys() {
        return Arrays.asList(routingKeys);
    }
}
