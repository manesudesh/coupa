package ae.network.onboarding.onboarding3ds2.model;

import ae.network.onboarding.onboarding3ds2.rabbitmq.message.QueueMessage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Update message to queue (sent from consumers)
 *
 * @author 
 * @since 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationUpdate implements QueueMessage {
    private String applicationId;
    private BackendSystem backendSystem;
    private ProcessingResult processingResult;
    private AdditionalData additionalData;
}
