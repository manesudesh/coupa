package ae.network.onboarding.onboarding3ds2.model.application;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author 
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AcceptedCardMode {

    private CardModeName modeName;
    private BigDecimal rate;
    private List<DiscountRate> discountRates;
}
