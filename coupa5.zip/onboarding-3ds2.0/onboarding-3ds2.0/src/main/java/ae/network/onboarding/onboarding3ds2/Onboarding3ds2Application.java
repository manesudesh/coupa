package ae.network.onboarding.onboarding3ds2;

import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author 
 * @since
 */
@SpringBootApplication
//@EnableScheduling
@RestController
public class Onboarding3ds2Application extends SpringBootServletInitializer //implements CommandLineRunner
{

    public static void main(String[] args) {
        SpringApplication.run(Onboarding3ds2Application.class, args);
    }

    @GetMapping("/add")
    public String getString()
    {
    	return "Sudesh";
    }
 
    @Override
    protected SpringApplicationBuilder configure(
      SpringApplicationBuilder builder) {
        return builder.sources(Onboarding3ds2Application.class);
    }
    
    public void run(String... args) {
    	/*
    	 for(int i=0; i<5; i++) {
  		  SimpleMessageConverter converter = new SimpleMessageConverter();
  		  
  		  message = converter.toMessage(getJSONStr(i), new MessageProperties());
  		  message.getMessageProperties().setCorrelationId(i+"");
  		  
    		Test test = new Test(message, _3ds2Consumer);
    		test.start();
  		  
  		}
  		*/
    }
   
    
    @Bean("jasyptStringEncryptor")
    public StringEncryptor stringEncryptor() {
    	
    	
    PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
    SimpleStringPBEConfig config = new SimpleStringPBEConfig();
    config.setPassword("vhB2&SPAN626mcAa");
    config.setAlgorithm("PBEWithSHA1AndDESede");
    config.setKeyObtentionIterations("1000");
    config.setPoolSize("1");
//    config.setProviderName("SunJCE");
 //   config.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
//    config.setIvGeneratorClassName("org.jasypt.iv.RandomIvGenerator");
//    config.setStringOutputType("base64");
    encryptor.setConfig(config);
    return encryptor;
    }
    
   /* 
    @Autowired
	RabbitServiceImpl rabbitServiceImpl;
	@Autowired
	_3ds2Service _3ds2Service;
	@Autowired
	AcquirerConfigService acquirerConfigService;
	
	@Autowired
	_3ds2Consumer _3ds2Consumer;
	
	
	Message message;
	*/

	


public String getJSONStr(int id) {
	//if(id%2!=0)
	{
		id=id*999999999;
	}
	return "{\r\n"
	+ "    \"_id\" : \"5f73"+id+"\",\r\n"
	+ "    \"acquirer\" : \"NI\",\r\n"
	+ "    \"requestType\" : \"ONBOARDING\",\r\n"
	+ "    \"applicationId\" : \"7cc97fe9-6c42-4ac4-ab72-e47aa3a3d"+id+"\",\r\n"
	+ "    \"requestId\" : \"a0S3H000000eZwyUAE0\",\r\n"
	+ "    \"payload\" : {\r\n"
	+ "        \"applications\" : [ \r\n"
	+ "            {\r\n"
	+ "                \"chain\" : {\r\n"
	+ "                    \"chainId\" : \"500060008849\",\r\n"
	+ "                    \"chainName\" : \"560008849\",\r\n"
	+ "                    \"organizationName\" : \"testtradeSO30929\"\r\n"
	+ "                },\r\n"
	+ "                \"merchants\" : [ \r\n"
	+ "                    {\r\n"
	+ "                        \"merchantId\" : \"1500860009"+id+"\",\r\n"
	+ "                        \"merchantName\" : \"testtradeSO30"+id+"\",\r\n"
	+ "                        \"merchantType\" : \"ECOM\",\r\n"
	+ "			\"website\" : \"https://Dbxv-class.com\",\r\n"
	+ "                        \"mcc\" : 8931,\r\n"
	+ "                        \"merchantCurrency\" : \"AED\",\r\n"
	+ "                        \"terminals\" : [ \r\n"
	+ "                            {\r\n"
	+ "                                \"terminalId\" : \"53006959\"\r\n"
	+ "                            }\r\n"
	+ "                        ],\r\n"
	+ "			\"addresses\" : [ \r\n"
	+ "                            {\r\n"
	+ "                                \"addressType\" : \"DEFAULT\",\r\n"
	+ "                                \"countryCode\" : \"ARE\",\r\n"
	+ "                                \"city\" : \"Dubai\",\r\n"
	+ "                                \"state\" : \"United Arab Emirates\"\r\n"
	+ "                            }\r\n"
	+ "                        ],\r\n"
	+ "                        \"services\" : [ \r\n"
	+ "                            {\r\n"
	+ "                                \"organizationName\" : \"testtradeSO30929\",\r\n"
	+ "                                \"channels\" : [ \r\n"
	+ "                                    \"ECOM\"\r\n"
	+ "                                ],\r\n"
	+ "                                \"currencyLimits\" : {\r\n"
	+ "                                    \"USD\" : 10000,\r\n"
	+ "                                    \"AED\" : 10000\r\n"
	+ "                                },\r\n"
	+ "                                \"paymentMethodCurrenciesMap\" : {\r\n"
	+ "                                    \"VISA\" : [ \r\n"
	+ "                                        \"AED\"\r\n"
	+ "                                    ],\r\n"
	+ "                                    \"MASTERCARD\" : [ \r\n"
	+ "                                        \"AED\"\r\n"
	+ "                                    ]\r\n"
	+ "                                },\r\n"
	+ "                                \"propositionServices\" : [ \r\n"
	+ "                                    \"samsung-pay\", \r\n"
	+ "                                    \"apple-pay\"				\r\n"
	+ "                                ],\r\n"
	+ "                                \"enable3DS\" : true,\r\n"
	+ "                                \"user\" : {\r\n"
	+ "                                    \"email\" : \"nabasmit@gmail.com\",\r\n"
	+ "                                    \"firstName\" : \"Mr\",\r\n"
	+ "                                    \"lastName\" : \"testS\"\r\n"
	+ "                                },\r\n"
	+ "                                \"serviceType\" : \"MC_3D_SECURE\"\r\n"
	+ "                            }\r\n"
	+ "                        ],\r\n"
	+ "                        \"validationErrors\" : []\r\n"
	+ "                    }\r\n"
	+ "                ]\r\n"
	+ "            }\r\n"
	+ "        ]\r\n"
	+ "    },\r\n"
	+ "    \"dryRun\" : false\r\n"
	+ "}\r\n"
	+ "";
	}

}
