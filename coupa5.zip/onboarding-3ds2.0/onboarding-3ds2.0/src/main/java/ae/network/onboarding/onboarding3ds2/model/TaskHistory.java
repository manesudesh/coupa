package ae.network.onboarding.onboarding3ds2.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import ae.network.onboarding.onboarding3ds2.common.DateFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author 
 * @since 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaskHistory {
    private TaskStatus taskStatus;
    private String statusCode;
    private String response;
    @JsonFormat(pattern = DateFormat.FORMAT)
    @DateTimeFormat(pattern = DateFormat.FORMAT)
    private Date createdDate;
    @JsonFormat(pattern = DateFormat.FORMAT)
    @DateTimeFormat(pattern = DateFormat.FORMAT)
    private Date lastModifiedDate;
}
