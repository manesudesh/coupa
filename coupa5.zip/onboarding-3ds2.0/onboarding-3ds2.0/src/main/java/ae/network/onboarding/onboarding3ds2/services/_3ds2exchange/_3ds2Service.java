package ae.network.onboarding.onboarding3ds2.services._3ds2exchange;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mastercard.api.core.exception.ApiException;
import com.mastercard.api.core.model.Action;
import com.mastercard.api.core.model.OperationConfig;
import com.mastercard.api.core.model.RequestMap;
import com.mastercard.api.core.security.Authentication;

import ae.network.onboarding.onboarding3ds2.apiclient.MerchantApiClient;
import ae.network.onboarding.onboarding3ds2.apiclient.APIPropertyConfig.APIProps;
import ae.network.onboarding.onboarding3ds2.database.domain.API3ds2Dto;
import ae.network.onboarding.onboarding3ds2.database.domain.AcquirerConfig;
import ae.network.onboarding.onboarding3ds2.database.domain.GetApi3ds2Dto;
import ae.network.onboarding.onboarding3ds2.database.domain.PostApi3ds2Dto;
import ae.network.onboarding.onboarding3ds2.database.service.AcquirerConfigService;
import ae.network.onboarding.onboarding3ds2.database.service._3ds2DbRequestService;
import ae.network.onboarding.onboarding3ds2.exception.AcquierNotFoundException;
import ae.network.onboarding.onboarding3ds2.exception.MessageCancelledException;
import ae.network.onboarding.onboarding3ds2.model.AdditionalData;
import ae.network.onboarding.onboarding3ds2.model.ApplicationRequest;
import ae.network.onboarding.onboarding3ds2.model.ApplicationUpdate;
import ae.network.onboarding.onboarding3ds2.model.BackendSystem;
import ae.network.onboarding.onboarding3ds2.model.ProcessingResult;
import ae.network.onboarding.onboarding3ds2.model.RequestType;
import ae.network.onboarding.onboarding3ds2.model.Task;
import ae.network.onboarding.onboarding3ds2.model.TaskHistory;
import ae.network.onboarding.onboarding3ds2.model.TaskName;
import ae.network.onboarding.onboarding3ds2.model.TaskStatus;
import ae.network.onboarding.onboarding3ds2.model.ValidationError;
import ae.network.onboarding.onboarding3ds2.model.apirequest.GetAPIRequest;
import ae.network.onboarding.onboarding3ds2.model.apirequest.MerchantData;
import ae.network.onboarding.onboarding3ds2.model.apirequest.PostAPIRequest;
import ae.network.onboarding.onboarding3ds2.model.apiresponse.ApiResponse;
import ae.network.onboarding.onboarding3ds2.model.apiresponse.GetAPIResponse;
import ae.network.onboarding.onboarding3ds2.model.apiresponse.PostAPIResponse;
import ae.network.onboarding.onboarding3ds2.model.application.Merchant;
import ae.network.onboarding.onboarding3ds2.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.onboarding3ds2.rabbitmq.service.RabbitService;
import ae.network.onboarding.onboarding3ds2.services.utils.RequestProcessingHelper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * @author 
 */
@Service("_3ds2Service")
@Slf4j
@AllArgsConstructor
public class _3ds2Service {

    /**
     * Injection of 3ds2.0RequestService for database
     * handshaking
     */
	@Autowired
    private final _3ds2DbRequestService _3ds2DbRequestService;
	/**
     * Injection of Acquirer Component for
     * acquirer's details
     */
    //@Qualifier("acquirerConfigService")
    private AcquirerConfigService acquirerConfigService;
    
    private RequestProcessingHelper requestHelper;
    /**
     * Injection of Rabbit Service to update the
     * queue
     */
    private final RabbitService rabbitService;
    
    private Authentication authentication;
    
    private MerchantApiClient apiClient;
    
    /**
     * Default API properties
     */
	APIProps apiProp;
    
    /**
     * Retrieves the queued message, maps it
     * into an 3ds2Request object.
     * call to merchantEnrollment APIs
     * and persist the document
     *
     * @param 3ds2Baselines
     * @throws IOException
     */
    public synchronized void createMerchantHandler(ApplicationRequest appReqEntity) throws IOException {
        log.info("Handling queued message for Create Merchant {}", appReqEntity);
        if (appReqEntity != null ) {
        	
        	API3ds2Dto apiReqObject = mapApplicationsToPost3ds2(appReqEntity);
            
        	appReqEntity.set_3ds2ApiData(apiReqObject);
            
            Task taskReq = requestHelper.createTask(TaskName.SEND_APP_REQUEST, TaskStatus.COMPLETED);
            taskReq.getTaskHistory().add( requestHelper.createTaskHistory(TaskStatus.COMPLETED, "calling 3ds2.0 API", "OK") );
            
            appReqEntity.getTasks().add(taskReq);
            
//           save3ds2Db(appReqEntity);
            
            // call MerchantEnrollment APIs
			  try { 
				  	RequestMap reqObject = apiClient.convertPostCallReqMap((PostAPIRequest)appReqEntity.get_3ds2ApiData().getRequestCall());
				  	OperationConfig operationConfig = apiClient.createOpConfig(Action.create,new ArrayList<>(), new ArrayList<>());
				  	ApiResponse resDto = PostAPIResponse.builder().build();
				  	resDto = apiClient.merchantEnrollmentRequest(authentication, operationConfig, reqObject, resDto);
				  
				  	Task taskRes = requestHelper.createTask(TaskName.RECEIVE_APP_RESPONSE, TaskStatus.COMPLETED);
				  	taskRes.getTaskHistory().add( requestHelper.createTaskHistory(TaskStatus.COMPLETED, "Received 3ds2.0 response", "OK") );	  
				  	appReqEntity.getTasks().add(taskRes);
		            
//				  	((PostApi3ds2Dto) entity.get_3ds2ApiData()).setResponsePostCall(resDto); 
				  	appReqEntity.get_3ds2ApiData().setResponseCall(resDto);
		             
				  
				  sendUpdate(appReqEntity, TaskName.ONBOARDING_MERCHANT, "3ds2.0 Mercnat Created", resDto);
				  
				  save3ds2Db(appReqEntity);
				
			  } catch (ApiException e) { 
				  log.error("Error while merchant enrollment", e);
			  }
        }
    }

	
    /**
     * After mapping the JsonNode payload to
     * a list of application, the result is then
     * mapped to 3ds2 object
     *
     * @param applicationRequest
     * @return
     */
    private synchronized PostApi3ds2Dto mapApplicationsToPost3ds2(ApplicationRequest applicationRequest) throws NullPointerException {
    	log.info("Mapping request to Post API 3ds2 call ");
    	AcquirerConfig acquirerConfig = acquirerConfigService.findByAcquirer(applicationRequest.getAcquirer());
        if (acquirerConfig != null) {
        	
        	List<Merchant> merchants = getValidMerchants(applicationRequest);
            // validate if changes required
            if (merchants.size() == 0) {
                throw new MessageCancelledException("No changes required");
            }
            log.info("Total number of valid merchants "+merchants.size());
            List<MerchantData> merchantDataList = new ArrayList<MerchantData>();
            
            String delReason = getdeleteReason(applicationRequest.getRequestType());
            
            merchants.forEach(merchant -> addMerchantData(acquirerConfig, merchantDataList, merchant, delReason, apiProp.getIdentityCheckExpress()));
            
            String action = getAction(applicationRequest.getRequestType());
            log.info("DelReason - "+delReason+" and Action - "+action);
            PostApi3ds2Dto postReqDto = PostApi3ds2Dto.builder()
            		.requestCall(
	            				PostAPIRequest.builder()
	            				.merchantData(merchantDataList).
	            				processorName(apiProp.getProcessor()).
	            				action(action)
	            				.build()
            				)
		            .build();
            
            return postReqDto;
        }
        throw new AcquierNotFoundException(applicationRequest.getAcquirer().name());
    }
    

    /**
     * After mapping the JsonNode payload to
     * a list of application, the result is then
     * mapped to 3ds2 object
     *
     * @param applicationRequest
     * @return
     */
    private API3ds2Dto mapApplicationsToGET3ds2(ApplicationRequest applicationRequest, API3ds2Dto api3ds2Dto) throws NullPointerException {
     
    	GetAPIRequest apiReq = GetAPIRequest.builder().
//    			transaction_id("53408e9c-b8de-4fb5-b239-da1b31078bd7").
    			//transaction_id("fdc0fd13-6b7e-4e0d-bc3c-bb85e70337d9").
    			//transaction_id("b3cfecf2-bb84-45ec-807e-08b01e1d26f9").
//    			transaction_id("847a3ea9-d2dc-4cfa-8c53-5cb3fb92f425").
    			transaction_id("522d5c81-716c-4c9e-88b9-9c28aa627686").
    			offset("0")
    			.limit("3")
    			.build();

    	api3ds2Dto.setRequestCall(apiReq);
            
    	return api3ds2Dto;
    }
    
    
    private List<Merchant> getValidMerchants(ApplicationRequest applicationRequest) {
    	List<Merchant> merchants = applicationRequest.getPayload().getApplications().stream()
                .flatMap(app -> app.getMerchants().stream())
                .filter(merchant -> RequestType.MERCHANT_CLOSURE.equals(applicationRequest.getRequestType())
                        ? merchant.isEcom() : merchant.isEcom() && merchant.has3ds2())
                .collect(Collectors.toList());
    	return merchants;
    }

    
    private void addMerchantData(AcquirerConfig acquirerConfig, List<MerchantData> merchantDataList, Merchant merchant, String reason, String identityCheck) {
    	log.info("building merchant data ");
    	MerchantData merchantData = MerchantData.builder()
    			.acquirerBIN(acquirerConfig.getAcquirerBin())
    			.acquirerCID(acquirerConfig.getAcquirerCompanyId())
    			.acquirerICA(acquirerConfig.getAcquirerPrimaryIca())
    			.acquirerName(acquirerConfig.getCompanyName())
    			.merchantID(merchant.getMerchantId())
    			.merchantName(merchant.getMerchantName())
    			.identityCheckExpress(identityCheck)
    			.deleteReason(reason)
    			.build();
    	merchantDataList.add(merchantData);
 
    }
    
    public Task assignTaskhistoryToTask(TaskName taskName, TaskStatus status, String response, String statusCode) {
    	log.info("building taskhistory "+taskName+"  response "+response +" status "+status);
    	Task task = requestHelper.createTask(taskName, status);
		TaskHistory taskhist = requestHelper.createTaskHistory(status, response, statusCode);
		task.getTaskHistory().add(taskhist);
		return task;
    }
    
    public Task assignValidationErrorTaskHistory(Collection<ValidationError> validationErrors, TaskName taskName, TaskStatus status) {
    	log.info("building validationerror taskhistory "+taskName+" status "+status);
    	Task task = requestHelper.createTask(taskName, status);
		task = requestHelper.assignValidationErrorTaskHistory(validationErrors, task);
		return task;
    }
    
    public ApplicationUpdate assignResultToAppUpdate(Task task, String applicationId, BackendSystem backendSystem) {
    	log.info("building ApplicationUpdate "+applicationId+" "+backendSystem.name());
    	ProcessingResult result = requestHelper.createProcessingResult(task, task.getTaskStatus());
    	ApplicationUpdate applicationUpdate = requestHelper.createApplicationUpdate(applicationId, backendSystem, result);
		return applicationUpdate;
    }
    
    /**
     * Retrieves the queued message, maps it
     * into an 3ds2Request object.
     * call to merchantEnrollment APIs
     * and persist the document
     *
     * @param 3ds2Baselines
     * @throws IOException
     */
    public synchronized void getMerchantHandler(ApplicationRequest entity) throws IOException {
        log.info("Handling queued message for Create Merchant {}", entity);
        if (entity != null ) {
        	
        	GetApi3ds2Dto getApiReqObject = GetApi3ds2Dto.builder().build();
        	API3ds2Dto apiReqObject = mapApplicationsToGET3ds2(entity, getApiReqObject);
        	entity.set_3ds2ApiData(apiReqObject);
        	
            Task taskReq = requestHelper.createTask(TaskName.SEND_APP_REQUEST, TaskStatus.COMPLETED);
            taskReq.getTaskHistory().add( requestHelper.createTaskHistory(TaskStatus.COMPLETED, "calling 3ds2.0 API", "OK") );
            
            entity.getTasks().add(taskReq);
            
//            save3ds2Db(callRequest);
            
			  try { 
				  
				  GetAPIRequest getAPIRequest = (GetAPIRequest)apiReqObject.getRequestCall();
				  	RequestMap reqObject = apiClient.convertGetCallReqMap(getAPIRequest);
				  	
				  	OperationConfig operationConfig = apiClient.createOpConfig(Action.query, Arrays.asList("transaction_id","offset", "limit"), Arrays.asList(getAPIRequest.getTransaction_id(), getAPIRequest.getOffset(), getAPIRequest.getLimit()));
				  	ApiResponse resDto = GetAPIResponse.builder().build();
				  	resDto = apiClient.merchantEnrollmentRequest(authentication, operationConfig, reqObject, (GetAPIResponse)resDto);
				  
				  	Task taskRes = requestHelper.createTask(TaskName.RECEIVE_APP_RESPONSE, TaskStatus.COMPLETED);
				  	taskRes.getTaskHistory().add( requestHelper.createTaskHistory(TaskStatus.COMPLETED, "Received 3ds2.0 response", "OK") );	  
				  	entity.getTasks().add(taskRes);
		            
		            entity.get_3ds2ApiData().setResponseCall(resDto);
				  
				  sendUpdate(entity, TaskName.ONBOARDING_MERCHANT, "3ds2.0 Mercnat Query Call", resDto);
				  
				  save3ds2Db(entity);
				
			  } catch (ApiException e) { 
				  log.error("Error while retrieving merchant information", e);
			  }
        }
    }
	

    

    /**
     * send task to queue
     */
    private void sendUpdate(ApplicationRequest callRequest, TaskName taskName, String description, ApiResponse response) {
        log.info("sending task to updates queue");
                
        ApplicationUpdate update = new ApplicationUpdate();
        update.setApplicationId(callRequest.getApplicationId());
        update.setBackendSystem(BackendSystem._3ds2);
        if(response != null && response instanceof PostAPIResponse) {
        	AdditionalData addData = new AdditionalData();
            addData.setDataMap("transactionID",((PostAPIResponse)response).getTransactionID());
            addData.setDataMap("messageType",((PostAPIResponse)response).getMessageType());
            addData.setDataMap("totalRecords",((PostAPIResponse)response).getTotalRecords());
            update.setAdditionalData(addData);
        }
        Task task = requestHelper.createTask(taskName, TaskStatus.COMPLETED);
        task.getTaskHistory().add( requestHelper.createTaskHistory(TaskStatus.COMPLETED, description, "OK") );
        ProcessingResult processResult = requestHelper.createProcessingResult(task, TaskStatus.COMPLETED);
        update.setProcessingResult(processResult);
        
        callRequest.getTasks().add(task);
        
        rabbitService.sendMessage(RabbitQueue.UPDATES, update);
    }
    
    public void save3ds2Db(ApplicationRequest payloadRequest)
    {
    	_3ds2DbRequestService.save(payloadRequest);
    }
    
    public String getdeleteReason(RequestType requestType) {
    	return RequestType.ONBOARDING.equals(requestType) ? null : apiProp.getClosureMsg();
    }
    
    private String getAction(RequestType requestType) {
        String action;
        switch (requestType) {
            case ONBOARDING:
                action = "Add";
                break;
            case AMENDMENT:
            case MERCHANT_CLOSURE:
                action = "Delete";
                break;
            default:
                action = "Modify";
                break;
        }

        return action;
    }
    
}
