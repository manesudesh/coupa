package ae.network.onboarding.onboarding3ds2.exception;

/**
 * @author 
 * @since 
 */
public class MessageCancelledException extends MessageRejectionException {
    public MessageCancelledException(String applicationId) {
        super(applicationId, "No processing required");
    }
}
