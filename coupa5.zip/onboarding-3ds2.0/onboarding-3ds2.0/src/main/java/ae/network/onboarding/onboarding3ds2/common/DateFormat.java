package ae.network.onboarding.onboarding3ds2.common;

/**
 * @author 
 * @since 
 */
public interface DateFormat {
    String FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
}
