package ae.network.onboarding.onboarding3ds2.model.apirequest;

import java.util.List;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
public class PostAPIRequest extends ApiRequest{

	 /**
     * Merchant data
     */
    private List<MerchantData> merchantData;
    
    /**
     * Processor name
     */
    private String processorName;
}
