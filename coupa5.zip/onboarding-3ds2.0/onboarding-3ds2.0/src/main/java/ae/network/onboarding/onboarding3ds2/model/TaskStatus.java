package ae.network.onboarding.onboarding3ds2.model;

/**
 * @author 
 * @since 
 */
public enum TaskStatus {
    COMPLETED, PARTIALLY_COMPLETED, FAILED, CANCELLED, IN_PROGRESS
}
