package ae.network.onboarding.onboarding3ds2.apiclient;

import com.mastercard.api.core.ApiConfig;
import com.mastercard.api.core.security.Authentication;
import com.mastercard.api.core.security.oauth.OAuthAuthentication;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;

@Configuration
@Slf4j
public class APIPropertyConfig {

    @PostConstruct
    public void init() throws IOException {
        ApiConfigProps apiConfigProps = apiConfigProps();
        ApiConfig.setDebug(apiConfigProps.debug);
        ApiConfig.setSandbox(apiConfigProps.sandbox);
        ApiConfig.setAuthentication(authentication());

        log.info("apiConfigProps [{}]", apiConfigProps);
    }

    @Bean
    @ConfigurationProperties(prefix = "merchant.api-config")
    public ApiConfigProps apiConfigProps() {
        return new ApiConfigProps();
    }

    @Bean
    public Authentication authentication() throws IOException {
        AuthProps authProps = authProps();
        @Cleanup InputStream is = new ClassPathResource(authProps.p12path).getInputStream();
        return new OAuthAuthentication(authProps.consumerKey, is, authProps.keyAlias, authProps.keyPassword);
    }

    @Bean
    @ConfigurationProperties(prefix = "merchant.auth")
    public AuthProps authProps() {
        return new AuthProps();
    }
    
    @Bean
    @ConfigurationProperties(prefix = "merchant-exchange")
    public APIProps apiProps() {
        return new APIProps();
    }

    @Data
    public static class APIProps {
        private String processor;
        private String closureMsg;
        private String identityCheckExpress;
        private String resourcePath;
        private String acceptVersion;
        
    }

    @Data
    public static class ApiConfigProps {
        private Boolean debug;
        private Boolean sandbox;
    }

    @Data
    public static class AuthProps {
        private String consumerKey;
        private String keyAlias;
        private String keyPassword;
        private String p12path;
    }
}
