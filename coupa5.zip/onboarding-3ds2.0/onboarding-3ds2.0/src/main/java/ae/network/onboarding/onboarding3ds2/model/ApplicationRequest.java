package ae.network.onboarding.onboarding3ds2.model;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import ae.network.onboarding.onboarding3ds2.database.domain.API3ds2Dto;
import ae.network.onboarding.onboarding3ds2.database.domain.AbstractAuditingEntity;
import ae.network.onboarding.onboarding3ds2.model.payload.Payload;
import ae.network.onboarding.onboarding3ds2.rabbitmq.message.QueueMessage;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 
 * @since 
 */
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "3ds2.0_request")
public class ApplicationRequest extends AbstractAuditingEntity implements QueueMessage {
    /**
     * Partner acquirer
     */
    private Acquirer acquirer;
    /**
     * Request type (Create-update-close)
     */
    private RequestType requestType;
    /**
     * unique global id
     */
    private String applicationId;
    /**
     * acquirer request id (unique across each acquirer)
     */
    private String requestId;
    /**
     * dry run option
     */
    private boolean dryRun;
    /**
     * application content
     */
    private Payload payload;
    
    private API3ds2Dto _3ds2ApiData;
  
    private Collection<Task> tasks = new ArrayList<Task>(); 
}
