package ae.network.onboarding.onboarding3ds2.model.application;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * @author 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DiscountRate {
    private String currencyCode;
    private BigDecimal discountAmount;
    private AmountType amountType;
}
