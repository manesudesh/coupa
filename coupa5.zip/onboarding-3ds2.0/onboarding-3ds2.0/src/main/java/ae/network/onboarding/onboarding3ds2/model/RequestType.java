package ae.network.onboarding.onboarding3ds2.model;

public enum RequestType {
    ONBOARDING, AMENDMENT, MERCHANT_CLOSURE, TERMINAL_CLOSURE
}
