package ae.network.onboarding.onboarding3ds2.database.service;

import ae.network.onboarding.onboarding3ds2.database.domain.AcquirerConfig;
import ae.network.onboarding.onboarding3ds2.database.repositories.AcquirerConfigRepository;
import ae.network.onboarding.onboarding3ds2.model.Acquirer;
import lombok.AllArgsConstructor;

import java.util.Optional;

import org.springframework.stereotype.Service;

/**
 * @author 
 */

@Service("acquirerConfigService")
@AllArgsConstructor
public class AcquirerConfigService {

    /**
     * Injection of AcquirerConfig Repository
     */
    private AcquirerConfigRepository acquirerConfigRepository;

    /**
     * Finds an acquirer config by
     * an acquirer name
     *
     * @param acquirer
     * @return
     */
    public AcquirerConfig findByAcquirer(Acquirer acquirer) {
    	Optional<AcquirerConfig> acqConfig = acquirerConfigRepository.findByAcquirer(acquirer);
         return	acqConfig.isPresent() ? acqConfig.get() : null;
    }


    public void save(AcquirerConfig acquirer) {
        acquirerConfigRepository.insert(acquirer);
    }
}
