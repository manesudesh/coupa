package ae.network.onboarding.onboarding3ds2.rabbitmq.processors;

import javax.annotation.PostConstruct;

import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import ae.network.onboarding.onboarding3ds2.exception.MaxRetryReachedException;

/**
 * @author 
 * @since 
 */
@Component
public class MaxRetryProcessor implements MessagePostProcessor {
    public static final String MAX_RETRY_HEADER = "max_retry";

    private final RabbitTemplate rabbitTemplate;
    private final int maxRetryAttempts;


    public MaxRetryProcessor(RabbitTemplate rabbitTemplate,
                             @Value("${octopus.processor.max-retry}") int maxRetryAttempts) {
        this.rabbitTemplate = rabbitTemplate;
        this.maxRetryAttempts = maxRetryAttempts;
    }

    @Override
    public Message postProcessMessage(Message message) throws AmqpException {
        MessageProperties messageProperties = message.getMessageProperties();
        Integer maxRetry = messageProperties.getHeader(MAX_RETRY_HEADER);
        if (maxRetry == null) {
            messageProperties.setHeader(MAX_RETRY_HEADER, maxRetryAttempts);
        } else if (maxRetry == 0) {
            throw new MaxRetryReachedException(messageProperties.getCorrelationId());
        } else {
            messageProperties.setHeader(MAX_RETRY_HEADER, maxRetry - 1);
        }
        return message;
    }

    @PostConstruct
    public void init() {
        rabbitTemplate.addBeforePublishPostProcessors(this);
    }
}
