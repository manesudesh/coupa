package ae.network.onboarding.onboarding3ds2.services.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import ae.network.onboarding.onboarding3ds2.model.ApplicationUpdate;
import ae.network.onboarding.onboarding3ds2.model.BackendSystem;
import ae.network.onboarding.onboarding3ds2.model.ProcessingResult;
import ae.network.onboarding.onboarding3ds2.model.Task;
import ae.network.onboarding.onboarding3ds2.model.TaskHistory;
import ae.network.onboarding.onboarding3ds2.model.TaskName;
import ae.network.onboarding.onboarding3ds2.model.TaskStatus;
import ae.network.onboarding.onboarding3ds2.model.ValidationError;
import lombok.extern.slf4j.Slf4j;

/**
 * @author 
 */
@Service
@Slf4j
public class RequestProcessingHelper {

    public RequestProcessingHelper() {
        super();
    }

    public Task createTask(TaskName taskName, TaskStatus status) {
		Task task = Task.builder()
        .name(taskName.name())
        .taskStatus(status)
        .taskHistory(new ArrayList<TaskHistory>())
        .build();
		return task;
	}
    
	public TaskHistory createTaskHistory(TaskStatus status, String response, String statusCode) {
        TaskHistory taskHistory = new TaskHistory();
        final Date now = new Date();
        taskHistory.setCreatedDate(now);
        taskHistory.setLastModifiedDate(now);
        taskHistory.setTaskStatus(status);
        taskHistory.setResponse(response);
        taskHistory.setStatusCode(statusCode);
        return taskHistory;
    }
	
    
    public ApplicationUpdate createApplicationUpdate(String applicationId, BackendSystem backendSystem, ProcessingResult processingResult) {
		ApplicationUpdate applicationUpdate = ApplicationUpdate.builder().applicationId(applicationId)
                .backendSystem(backendSystem).processingResult(processingResult).build();
		return applicationUpdate;
	}

	public ProcessingResult createProcessingResult(Task task, TaskStatus status) {
		ProcessingResult processingResult = ProcessingResult.builder().tasks(Collections.singletonList(task))
		        .finalStatus(status).build();
		return processingResult;
	}

	public Task assignValidationErrorTaskHistory(Collection<ValidationError> validationErrors, Task task) {
		List<TaskHistory> taskHistoryList = validationErrors.stream().map(
					e->  createTaskHistory(task.getTaskStatus(), e.getFieldName() + " : " + e.getErrorMessage(), e.getErrorCode()) )
				.collect(Collectors.toList());
        task.setTaskHistory(taskHistoryList);
        return task;
	}

	
}
