package ae.network.onboarding.onboarding3ds2.model.application;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SchemeOverrideValue {
    private Integer mcc;
    private String dbaName;
}
