package ae.network.onboarding.onboarding3ds2.model.application;

/**
 * @author 
 */
public enum RentalModeCode {
    CASH, CHEQUE
}
