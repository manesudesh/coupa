package ae.network.onboarding.onboarding3ds2.model.apirequest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@Data
public class MerchantData {

	/**
     * Merchant Id
     */
    @EqualsAndHashCode.Include
    private String merchantID;
    /**
     * Name of merchant
     */
    @EqualsAndHashCode.Include
    private String merchantName;
    /**
     * acquirer bin
     */
    private String acquirerBIN;
    /**
     * Company id of Acquirer
     */
    private String acquirerCID;
    /**
     * Primary ICA of Acquirer
     */
    private String acquirerICA;
    /**
     * Name of Company
     */
    private String acquirerName;
    /**
     * Reasons why should delete
     */
    private String deleteReason;
    /**
     * Identity Check Express solution
     */
    private String identityCheckExpress;
    /**
     * Check status
     */
    private String status;
    
    /**
     * reason
     */
    private String reason;

}