package ae.network.onboarding.onboarding3ds2.model.application;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author 
 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
@Builder
public class AcceptedCardParam {

    private CardSchema cardScheme;
    private BigDecimal tariffRate; // for Tyme only , for NI should be from accepted modes as it has many moods, electronics, manual ..etc
    private List<AcceptedCardMode> acceptedCardModes;
    private SchemeOverrideValue schemeOverrideValue;

}
