package ae.network.onboarding.onboarding3ds2.model.application;

public enum FeeType {
    MIS,
    ACQ_MMBR_FEE, // MEMBERSHIP FEE
    MFEE_STRT, // STARTUP FEE
    MFEE_FRD_HND, // Fraud
    FRAUD_HAND_FEE, // Fraud Tyme
    TRANS_FEE, // for NI
    REFUND_FEE // for NI
}
