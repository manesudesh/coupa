package ae.network.onboarding.onboarding3ds2.rabbitmq.consumer.validator;

import ae.network.onboarding.onboarding3ds2.model.ValidationError;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ErrorCode {
    INVALID_JSON("MCSEC000", "*", "invalid JSON content"),

    MERCHANT_NAME_EMPTY("MCSEC0001", "merchant.name", "Merchant name is required"),
    MERCHANT_NAME_INVALID("MCSEC0002", "merchant.name", "Merchant name is invalid"),
    MERCHANT_ID_EMPTY("MCSEC0003", "merchant.id", "Merchant id is required"),
    MERCHANT_ID_INVALID("MCSEC0004", "merchant.id", "Merchant id is invalid"),
    MERCHANT_AMENDMENT_LIST_EMPTY("MCSEC0019", "merchant.amendmentList", "Amendment list is required for this type of request");

    private String errorCode;
    private String fieldName;
    private String errorMessage;

    public ValidationError toValidationError() {
        return ValidationError.builder().errorCode(errorCode).errorMessage(errorMessage).fieldName(fieldName).build();
    }
}
