package ae.network.onboarding.onboarding3ds2.model.application;

public enum PaymentModeType {

    EFT,
    EQ, // Emirates Islamic
    FN, // Emirates NBD
    IFT,
    MC,
    NN, // No payment
    OB, // Other banks
    TT // Telegraphic transfers
}
