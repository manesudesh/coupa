package ae.network.onboarding.onboarding3ds2.database.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ae.network.onboarding.onboarding3ds2.database.repositories._3ds2RequestRepository;
import ae.network.onboarding.onboarding3ds2.model.ApplicationRequest;
import lombok.AllArgsConstructor;

/**
 * @author 
 */
@Service("_3ds2DbRequestService")
@AllArgsConstructor
public class _3ds2DbRequestService {

    /**
     * Injection of Repository object
     */
    private final _3ds2RequestRepository repository;

    /**
     * Persist 3ds2Request document to the
     * database
     *
     * @param 3ds2Request
     * @return
     */
    public synchronized ApplicationRequest save(ApplicationRequest _3ds2Req) {
        return repository.save(_3ds2Req);
    }

}
