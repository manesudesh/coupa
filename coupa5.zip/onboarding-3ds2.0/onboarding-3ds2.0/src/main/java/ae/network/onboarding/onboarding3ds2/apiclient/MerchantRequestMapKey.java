package ae.network.onboarding.onboarding3ds2.apiclient;

/**
 * @author : 
 * @version : 1.0
 */
public enum MerchantRequestMapKey {

	PROCESSOR_NAME("processorName"),
	ACTION("action"),
	ACQUIRER_BIN("merchantData[%d].acquirerBIN"),
	ACQUIRER_CID("merchantData[%d].acquirerCID"),
	ACQUIRER_ICA("merchantData[%d].acquirerICA"),
	ACQUIRER_NAME("merchantData[%d].acquirerName"),
	MERCHANT_ID("merchantData[%d].merchantID"),
	MERCHANT_NAME("merchantData[%d].merchantName"),
	IDENTITY_CHECK_EXPRESS("merchantData[%d].identityCheckExpress"),
	DELETE_REASON("merchantData[%d].deleteReason"),
	
	TRANSACTION_ID("transaction_id"),
	OFFSET("offset"),
	LIMIT("limit");
	

    private String key;

    MerchantRequestMapKey(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    public String getIndexedKey(int index) {
        return String.format(key, index);
    }
}
