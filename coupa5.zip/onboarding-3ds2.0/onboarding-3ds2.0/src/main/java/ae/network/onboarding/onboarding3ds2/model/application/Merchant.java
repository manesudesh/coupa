package ae.network.onboarding.onboarding3ds2.model.application;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import static ae.network.onboarding.onboarding3ds2.common.TextUtils.*;

/**
 * @author 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Merchant {

    private static final String MERCHANT_NAME_TYPE = "MERCHANT_NAME";

    @JsonProperty("merchantId")
    private String merchantId;
    @JsonProperty("merchantName")
    private String merchantName;
    @JsonProperty("merchantType")
    private String merchantType;
    @JsonProperty("services")
    private List<MerchantService> services;
    @JsonProperty("amendmentList")
    private List<String> amendmentList;

    public String getMerchantName() {
        return truncate(toAlphaNumeric(this.merchantName), 25);
    }


    public boolean hasMerchantNameAmendment() {
        return hasAmendment(MERCHANT_NAME_TYPE);
    }

    private boolean hasAmendment(String amendmentType) {
        return amendmentList != null && amendmentList.stream().anyMatch(amendmentType::equalsIgnoreCase);
    }

    public boolean isEcom() {
        return "ECOM".equalsIgnoreCase(this.merchantType);
    }

    public boolean has3ds2() {
        if (this.services != null && !this.services.isEmpty()) {
            return this.services.stream().anyMatch(merchantService -> "MC_3D_SECURE".equalsIgnoreCase(merchantService.getServiceType()));
        }
        return false;
    }

}
