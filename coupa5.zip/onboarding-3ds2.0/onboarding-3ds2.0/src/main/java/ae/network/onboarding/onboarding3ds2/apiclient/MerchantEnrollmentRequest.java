package ae.network.onboarding.onboarding3ds2.apiclient;

import java.util.HashMap;
import java.util.Map;

import com.mastercard.api.core.model.BaseObject;
import com.mastercard.api.core.model.OperationConfig;
import com.mastercard.api.core.model.OperationMetadata;
import com.mastercard.api.core.model.RequestMap;
import com.mastercard.api.match.ResourceConfig;

public class MerchantEnrollmentRequest extends BaseObject  {

	private static Map<String, OperationConfig> operationConfigs;

	static {
		operationConfigs = new HashMap<String, OperationConfig>();
	}

	public MerchantEnrollmentRequest() {
	}

	public MerchantEnrollmentRequest(BaseObject o) {
		putAll(o);
	}

	public MerchantEnrollmentRequest(RequestMap requestMap) {
		putAll(requestMap);
	}

	@Override protected final OperationConfig getOperationConfig(String operationUUID) throws IllegalArgumentException{
		OperationConfig operationConfig = operationConfigs.get(operationUUID);

		if(operationConfig == null) {
			throw new IllegalArgumentException("Invalid operationUUID supplied: " + operationUUID);
		}

		return operationConfig;
	}

	@Override protected OperationMetadata getOperationMetadata() throws IllegalArgumentException {
		return new OperationMetadata(ResourceConfig.getInstance().getVersion(), ResourceConfig.getInstance().getHost(), ResourceConfig.getInstance().getContext());
	}

	
	





}
