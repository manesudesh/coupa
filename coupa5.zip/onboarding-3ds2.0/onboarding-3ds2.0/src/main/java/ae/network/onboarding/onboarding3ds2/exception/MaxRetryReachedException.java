package ae.network.onboarding.onboarding3ds2.exception;

/**
 * @author 
 * @since 
 */
public class MaxRetryReachedException extends MessageRejectionException {
    public MaxRetryReachedException(String applicationId) {
        super(applicationId, "Maximum retries reached");
    }
}
