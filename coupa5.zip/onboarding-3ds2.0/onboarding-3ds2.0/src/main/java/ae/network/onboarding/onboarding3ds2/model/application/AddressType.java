package ae.network.onboarding.onboarding3ds2.model.application;

/**
 * @author 
 */

public enum AddressType {
    DEFAULT, STMT_ADDR, PAYM_ADDR, CORRESPONDING, TRADING
}
