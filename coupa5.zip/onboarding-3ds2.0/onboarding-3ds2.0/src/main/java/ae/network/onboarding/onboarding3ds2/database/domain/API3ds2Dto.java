package ae.network.onboarding.onboarding3ds2.database.domain;

import org.springframework.data.annotation.Id;

import ae.network.onboarding.onboarding3ds2.model.apirequest.ApiRequest;
import ae.network.onboarding.onboarding3ds2.model.apiresponse.ApiResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class API3ds2Dto {

    @Id
    private String id;
    
    /**
     * Action of the instance of
     * this object
     */
//    @EqualsAndHashCode.Include
//    private String action;
    
    private ApiRequest requestCall;
    
    private ApiResponse responseCall;
}
