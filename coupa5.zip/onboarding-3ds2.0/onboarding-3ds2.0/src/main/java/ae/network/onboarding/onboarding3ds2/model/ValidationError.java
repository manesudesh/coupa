package ae.network.onboarding.onboarding3ds2.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ValidationError {
    private String fieldName;
    private String errorMessage;
    private String errorCode;
}
