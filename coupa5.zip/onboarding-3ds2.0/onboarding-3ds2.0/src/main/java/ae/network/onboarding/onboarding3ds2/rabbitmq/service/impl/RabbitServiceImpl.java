package ae.network.onboarding.onboarding3ds2.rabbitmq.service.impl;

import ae.network.onboarding.onboarding3ds2.rabbitmq.config.RabbitExchange;
import ae.network.onboarding.onboarding3ds2.rabbitmq.config.RabbitQueue;
import ae.network.onboarding.onboarding3ds2.rabbitmq.message.QueueMessage;
import ae.network.onboarding.onboarding3ds2.rabbitmq.service.RabbitService;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;


@Service
@Slf4j
public class RabbitServiceImpl implements RabbitService {
    private final RabbitTemplate rabbitTemplate;

    public RabbitServiceImpl(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    @Override
    public void sendMessage(RabbitQueue queue, QueueMessage message) {
        logQueueMessage(queue, message);
        MessagePostProcessor corrIdSetter = m -> {
            m.getMessageProperties().setCorrelationId(message.getApplicationId());
            return m;
        };
        rabbitTemplate.convertAndSend(RabbitExchange.ONBOARDING.getExchangeName(), getDefaultRoutingKey(queue), message, corrIdSetter);
    }

    @Override
    public void retryMessage(Message message, int seconds) {
        MessageProperties messageProperties = message.getMessageProperties();
        messageProperties.setDelay(seconds * 1000);
        log.info("Scheduling retry to message {} in {} seconds", message, seconds);
        rabbitTemplate.send(RabbitExchange.ONBOARDING_RETRY.getExchangeName(), messageProperties.getReceivedRoutingKey(), message);
    }

    private void logQueueMessage(RabbitQueue queue, QueueMessage message) {
        try {
            log.info("Sending to queue {} message {}", queue.getQueueName(), new ObjectMapper().writeValueAsString(message));
        } catch (JsonProcessingException ignored) {
        }
    }

    private String getDefaultRoutingKey(RabbitQueue queue) {
        if (queue.getRoutingKeys().isEmpty()) {
            throw new AmqpException("Invalid destination");
        }
        return queue.getRoutingKeys().get(0);
    }
}
