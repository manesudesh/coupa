package ae.network.onboarding.onboarding3ds2.database.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.ToString;
import lombok.experimental.SuperBuilder;


@ToString(includeFieldNames = true)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@SuperBuilder
public class GetApi3ds2Dto extends API3ds2Dto{
//	private GetApiRequest requestCall;
//  private GetApiResponse responseCall;
}
