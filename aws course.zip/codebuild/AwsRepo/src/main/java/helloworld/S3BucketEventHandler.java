package helloworld;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.lambda.runtime.events.models.s3.S3EventNotification.S3Entity;
import com.amazonaws.util.StringUtils;

import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.cloudfront.CloudFrontClient;
import software.amazon.awssdk.services.cloudfront.model.CreateInvalidationRequest;
import software.amazon.awssdk.services.cloudfront.model.CreateInvalidationResponse;
import software.amazon.awssdk.services.cloudfront.model.InvalidationBatch;
import software.amazon.awssdk.services.cloudfront.model.Paths;
import software.amazon.awssdk.services.sns.SnsClient;
import software.amazon.awssdk.services.sns.model.PublishRequest;
import software.amazon.awssdk.services.sns.model.PublishResponse;

public class S3BucketEventHandler implements RequestHandler<S3Event, String> {
	
	@Override
	public String handleRequest(S3Event event, Context context) {
		try {
			 

			AwsBasicCredentials credentials = AwsBasicCredentials.create("AKIAYHJANCWH5N2FUBGZ",
					"Gfk90QNTHC/ir0zad1JycPhkz5XVxkoViKDM0PIC");

			String distributionId = System.getenv("cloudfrontid") == null ? "E9WP1B26PBI29"
					: System.getenv("cloudfrontid");

			String callerReference = UUID.randomUUID().toString() + String.valueOf(System.currentTimeMillis());

			List<String> keyNames = new ArrayList<>();

			event.getRecords().forEach(record -> {
				S3Entity s3Obj = record.getS3();
				String bucketName = s3Obj.getBucket().getName();
				String objectKey = s3Obj.getObject().getKey();
				long objectSize = s3Obj.getObject().getSize();
				objectKey = objectKey.replace("+", "%20");
				context.getLogger().log("Bucket: " + bucketName + ", KeyName: " + objectKey + ", size: " + objectSize);
				keyNames.add("/" + objectKey);
			});

			CloudFrontClient cloudFrontClient = CloudFrontClient.builder().region(Region.US_EAST_1) 
					.credentialsProvider(StaticCredentialsProvider.create(credentials)).build();

			Paths paths = Paths.builder()
//		                .items(keyNames)
						.items("/*")
		                .quantity(1)
		                .build();
				
//				context.getLogger().log(distributionId+" CloudFront Invalidation Path "+keyNames);
				
				   InvalidationBatch invalidationBatch = InvalidationBatch.builder()
		                .paths(paths)
		                .callerReference(callerReference)
		                .build();
		        context.getLogger().log("Callerrefernce Invalidation "+callerReference);


		        CreateInvalidationRequest request = CreateInvalidationRequest.builder()
		                .distributionId(distributionId)
		                .invalidationBatch(invalidationBatch)
		                .build();
		        context.getLogger().log(request.distributionId()+" created Request Invalidation ");
		        CreateInvalidationResponse response = cloudFrontClient.createInvalidation(request);
		        context.getLogger().log("Cleared files from cloudfront "+response.location()  + response.responseMetadata().requestId());

		        return "Processed " + event.getRecords().size() + " records.";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private String getEnvValue(String param, String defVal) {
		String envVal = System.getenv(param);
		if(! envVal.isEmpty()) {
			return envVal;
		}
		else {
			return defVal;
		}
	}
	 
    public void sendtoTopic(Context context, String topicArn, String message) {
    	context.getLogger().log("snsclient preparation to topic: " + message);
    	
    	context.getLogger().log("preparation request to topic: " + message);
	    PublishRequest request = PublishRequest.builder().topicArn(topicArn).message(message).build();
	    
	    context.getLogger().log("Sending to topic: " + message);
		PublishResponse result = snsClient.publish(request);
		
		context.getLogger().log("sent to topic: " + result.messageId());
    }
   
    
    
    
    
	SnsClient snsClient = SnsClient.builder().region(Region.US_EAST_1)
			.credentialsProvider(StaticCredentialsProvider.create(AwsBasicCredentials.create("AKIAYHJANCWHTWVOYSJ7","Uq7Ew7+oqX8h2UBJ3NFGiu1019a22rkn9pJC46CN")))
			.build();
	final String topicArn = "arn:aws:sns:us-east-1:565393036687:ProjectName-UploadsNotificationTopic";
	



	 

}

